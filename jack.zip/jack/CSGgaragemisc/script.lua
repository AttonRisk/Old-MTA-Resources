function onStartOpenGarage()
	for i=1,49 do
		setGarageOpen(i,true)
	end
end
addEventHandler("onResourceStart",resourceRoot,onStartOpenGarage)
