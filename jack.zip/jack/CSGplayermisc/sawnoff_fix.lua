function onWeaponSwitch(last,now)
	if now == 26 then
		ammo = getPedAmmoInClip(source)
		if (ammo == 0) then
			setControlState("fire",false)
			enableFire = setTimer(enableFire,1000,0,source)
		else
			return
		end
	end
end
addEventHandler("onClientPlayerWeaponSwitch",root,onWeaponSwitch)

function enableFire(player)
	if player then
		ammo = getPedAmmoInClip(player)
		if (ammo == 0) then
			outputDebugString(getPlayerName(player).." shotgun is still reloading, returning..",0,255,0,0)
			return false
		else
			killTimer(enableFire)
			setControlState("fire",true)
		end
	end
end