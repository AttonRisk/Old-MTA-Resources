function disableJumping(key,state)
	local jumpState = false
	if (state == "down") then
		interior = getElementInterior(localPlayer)
		dimension = getElementDimension(localPlayer)
		if (interior == 7 and dimension == 1) then
			if (jumpState == false) then
				local jumpState = true
				toggleControl("jump",false)
			end
		else
			local jumpState = false
			toggleControl("jump",true)
		end
	end
end
bindKey("lshift","down",disableJumping)
bindKey("rshift","down",disableJumping)