function cancelDamage(attacker,weapon)
	if (getElementInterior(source) == 7) and (getElementDimension(source) == 1) then
		if not (weapon == 3) then
			cancelEvent()
		end
	end
end
addEventHandler("onClientPlayerDamage",localPlayer,cancelDamage)
