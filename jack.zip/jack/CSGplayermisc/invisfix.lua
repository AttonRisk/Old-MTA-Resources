addEvent("onClientPlayerTeamChange",true)
addEventHandler("onClientPlayerTeamChange",root,
function (newTeam,oldTeam)
	setElementAlpha(source,255)
end)