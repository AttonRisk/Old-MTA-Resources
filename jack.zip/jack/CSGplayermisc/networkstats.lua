showing = false

function networkstats()
    dxDrawRectangle(987.0,183.0,287.0,466.0,tocolor(0,0,0,128),false)
    dxDrawText("Testing network stats",1004.0,212.0,1244.0,629.0,tocolor(255,255,255,255),1.2,"default-bold","center","center",false,false,false)
end
addEventHandler("onClientRender",root,networkstats)

function show(cmd)
	if (showing == false) then
		addEventHandler("onClientRender",localPlayer,networkstats)
		showing = true
		outputDebugString("Showing network stats for: "..getPlayerName(localPlayer))
	else
		removeEventHandler("onClientRender",localPlayer,networkstats)
		showing = false
		outputDebugString("Stopped showing network stats for: "..getPlayerName(localPlayer))
	end
end
addCommandHandler("networkstats",show)