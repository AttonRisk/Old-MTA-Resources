vehiclePositions = {
[1] = {567,868.45, -1332.22, 13.34,270,870.42, -1331.16, 12.59,360}
--[2] = {567,912.13, -1715.88, 13.33,179,912.91, -1717.97, 12.52,278,270},
--[3] = {567,1260.27, -1798.3, 13.28,51,1258.12, -1797.7, 0},
--[4] = {0,480.76, -1526.27, 20.01,13}
}

destroyTimers = {}
tempVehicles = {}
veh = nil
fines = nil
distance = nil
testing = false
patrolInProgress = false
vehicleTableID = nil

addEventHandler("onClientResourceStart",resourceRoot,
function()
	setTimer(prepairPatrol,180000,0,localPlayer)
end)

function prepairPatrol(player)
	if getPlayerTeam(player) == "Civilian Workers" and exports.server:getPlayerOccupation(player) == "Traffic Patrol" then
		if not patrolInProgress == true then
			onStart(player)
		else
			return
		end
	else
		if patrolInProgress == true then
			destroyElement(veh)
			destroyElement(marker)
			killTimer(destroyVeh)
			killTimer(destroyMarker)
			killTimer(outputMessage)
		end
	end
end

function setPlayerJob(player,cmd)
	exports.server:setPlayerOccupation(player,"Traffic Patrol")
	setPlayerTeam(player,getTeamFromName("Civilian Workers"))
end
addCommandHandler("traffic",setPlayerJob)

function onStart(player)
	v = math.random(1,#vehiclePositions)
	if v and patrolInProgress == false then
		vehicleTableID = v
		fines = math.random(500,3000)
		time = math.random(7,10)
		outputChatBox("There is a vehicle wanted for not paying fines of a total of $"..fines,255,255,0)
		outputChatBox("Find the vehicle and boot its tyre so that vehicle isn't going nowhere until the fines are paid.",255,255,0)
		outputChatBox("Find it within "..time.." minutes! the vehicle is in the "..getZoneName(vehiclePositions[v][2],vehiclePositions[v][3],vehiclePositions[v][4],false).." area.",255,0,0)
		------
		x,y,z = getElementPosition(localPlayer)
		distance = getDistanceBetweenPoints2D(x,y,vehiclePositions[v][2],vehiclePositions[v][3])
		------
		veh = createVehicle(vehiclePositions[v][1],vehiclePositions[v][2],vehiclePositions[v][3],vehiclePositions[v][4],0,0,vehiclePositions[v][5])
		marker = createMarker(0,0,0,"cylinder",1,255,0,0)
		attachElementToElement(marker,veh,1.2,2.05,-0.7,0,0,0)
		setElementData(marker,"bootingMarker",true)
		setVehicleLocked(veh,true)
		setElementFrozen(veh,true)
		prepairOwnerLeave(player,time*60000,veh,marker) --TESTED: OK!
		patrolInProgress = true
	else
		outputChatBox("A vehicle booting is already in progress, returning...",255,0,0)
	end
end
addCommandHandler("startBoot",onStart)

function prepairOwnerLeave(player,time,vehicle,marker) --TESTED: OK!
	if player and time and vehicle and marker then
		destroyVeh = setTimer(destroyElement,time,1,vehicle)
		destroyMarker = setTimer(destroyElement,time,1,marker)
		outputMessage = setTimer(outputChatBox,time,1,"The owner left the area with his vehicle, you lost him!",255,0,0)
	end
end

function onBootMarkerHit(hitElement,matchingDimension) --TESTED: Needs finishing.
	if getElementData(source,"bootingMarker") == true and hitElement == localPlayer and not isPedInVehicle(hitElement) then
		setTimer(destroyElement,500,1,source)
		setTimer(destroyElement,10000,1,veh)
		setTimer(startVehicleBootingProcess,1000,1,hitElement,source)
		killTimer(destroyVeh)
		killTimer(destroyMarker)
		killTimer(outputMessage)
		totalpay = fines
		setTimer(payCivil,1000,1,player,totalpay)
		distance = nil
		fines = nil
		patrolInProgress = false
	end
end
addEventHandler("onClientMarkerHit",root,onBootMarkerHit)

function startVehicleBootingProcess(player,marker)
	if player and marker then
		vX,vY,vZ = getElementPosition(veh)
		x,y,z = getElementRotation(player)
		setElementRotation(player,0,0,vehiclePositions[vehicleTableID][9])
		------
		setPedAnimation(player,"bomber","bom_plant_in",5000,false,true,false,false)
	else
		outputDebugString("Error while finding player / marker")
	end
end

function payCivil(player,amount)
	if not testing == true then
		triggerServerEvent("payCivilOnServerSide",player,amount)
		outputDebugString("Toggling serverside")
	else
		outputChatBox("Due to testing, your money was not given to you.",255,0,0)
		outputChatBox("Though just to troll you, you would have earned: $"..math.floor(amount),0,255,0)
	end
end
function giveRotation(player,cmd)
	x,y,z = getElementRotation(player)
	outputChatBox("Rotation: "..math.floor(z))
end
addCommandHandler("getRotation",giveRotation)

function getVehicleID(player,cmd,name)
	if name ~= "" then
		vehID = getVehicleIDFromName(name)
		outputChatBox("ID: "..vehID,255,0,0)
	end
end
addCommandHandler("getID",getVehicleID)

function boost(player,cmd)
	if player then
		if not getPlayerName(player) == "[CSG]Jack" then outputChatBox("HA no. its MINE!! (<3 Jack)",255,0,0) return false end
		veh = getPedOccupiedVehicle(getPlayerFromName("[CSG]Jack"))
		x,y,z = getElementVelocity(veh)
		--setWorldSpecialPropertyEnabled("aircars",true)
		setWorldSpecialPropertyEnabled("hovercars",true)
	end
end
addCommandHandler("boostvehicleLOL2",boost)