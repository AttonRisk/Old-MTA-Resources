addEvent("payCivilOnServerSide",true)
addEventHandler("payCivilOnServerSide",root,
function(amount)
	newAmount = math.floor(amount/2)
	givePlayerMoney(source,tonumber(newAmount))
	outputChatBox("Job finished! paycheck: $"..newAmount,source,0,255,0,false)
end)