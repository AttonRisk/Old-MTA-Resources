addEvent("givePlayerHouseRaidEarnings",true)
addEventHandler("givePlayerHouseRaidEarnings",root,
function(earnings)
	if (earnings) then
		givePlayerMoney(source,earnings)
		--exports.CSGlogging:logAction(source,"money",getPlayerName(source).." earned $"..earnings.." from houseraiding.")
	end
end)