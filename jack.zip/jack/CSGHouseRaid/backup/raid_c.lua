houseRaidTable = {
{915.61, -1816.85, 13.3},
{263.97, -1765.46, 4.75},
{192.79, -1747.76, 4.3},
{263.79, -1752.52, 4.75},
{663.25, -1711.66, 13.87},
{778.88, -1743.58, 12.5},
{2591.46, -1072.75, 69.83},
{2581.76, -1104, 66.46},
{2469.77, -1698.48, 13.51},
{2524.72, -1702.84, 13.37},
{2505.78, -2036.24, 13.54},
{2435.88, -2035.63, 13.9}
}

-------------------------------------

houseRaid = false

function resourceStart()
	setTimer(triggerRaidableHouse,20000,0,localPlayer)
end
addEventHandler("onClientResourceStart",resourceRoot,resourceStart)

function triggerRaidableHouse(player)
	if (player) then
		if (getPlayerTeam(player) == getTeamFromName("Police")) or (getPlayerTeam(player) == getTeamFromName("SWAT")) or (getPlayerTeam(player) == getTeamFromName("Department of Defense")) then
			if (houseRaid == false) then
				local randomHouse = math.random(1,#houseRaidTable)
				if randomHouse then
					raidMarker = createMarker(houseRaidTable[randomHouse][1],houseRaidTable[randomHouse][2],houseRaidTable[randomHouse][3]-1,"cylinder",2,0,0,255)
					raidMarkerBlip = createBlipAttachedTo(raidMarker,31,2,0,0,0,255,0,99999)
					outputChatBox("A house has a warrant for a drug search.",0,255,0)
					setTimer(secondMessage,1000,1,"Head to the green blip to do the raid.",0,255,0)
					houseRaid = true
					--outputDebugString("Creating house rob for player: "..getPlayerName(player))
				end
			end
		elseif not (getPlayerTeam(player) == getTeamFromName("Police")) or not(getPlayerTeam(player) == getTeamFromName("SWAT")) or not(getPlayerTeam(player) == getTeamFromName("Department of Defense")) then
			if (houseRaid == true) then
				destroyElement(raidMarker)
				destroyElement(raidMarkerBlip)
				houseRaid = false
			end
		end
	end
end

function secondMessage(message)
	outputChatBox(message,0,255,0)
end

function raidMarkerHit(hitElement,matchingDimension)
	if (hitElement == localPlayer) and (source == raidMarker) and not(isPlayerInVehicle(hitElement)) then
		luck = math.random(1,5)
		if (luck == 1 or 4) then
			winnedCash = math.random(200,1500)
			fadeCamera(false,1.0)
			setTimer(fadeCamera,2500,1,true,1.0)
			outputChatBox("House raided, you found drugs worth over $"..exports.server:convertNumber(winnedCash),0,255,0)
			destroyElement(raidMarker)
			destroyElement(raidMarkerBlip)
			houseRaid = false
			triggerServerEvent("givePlayerHouseRaidEarnings",localPlayer,winnedCash)
		else
			outputChatBox("House raided, you didn't find any evidence of drugs.",255,0,0)
			fadeCamera(false,1.0)
			setTimer(fadeCamera,2500,1,true,1.0)
			destroyElement(raidMarker)
			destroyElement(raidMarkerBlip)
			houseRaid = false
		end
	end
end
addEventHandler("onClientMarkerHit",root,raidMarkerHit)