function changeHeadlights(player,cmd,red,green,blue)
	if (cmd == "headlights") or (cmd == "hl") then
		if not (red) then
			red = math.random(1,255)
		elseif not (green) then
			green = math.random(1,255)
		elseif not (blue) then
			blue = math.random(1,255)
		else
			red = tonumber(red)
			green = tonumber(green)
			blue = tonumber(blue)
		end
		--now we set.
		if (isPlayerInVehicle(player)) then
			vehicle = getPlayerOccupiedVehicle(player)
			seat = getVehicleOccupant(vehicle,0)
			if seat == player then	
				hl = setVehicleHeadLightColor(vehicle,red,green,blue)
				if (hl) then
					outputChatBox("You're vehicle headlights have been changed.",player,0,255,0)
				else
					outputChatBox("Failed to set your vehicle headlights, rememeber! use numbers!!",player,255,0,0)
				end
			else
				outputChatBox("You are not the driver of this vehicle.",player,255,0,0)
			end
		else
			outputChatBox("You are not in a vehicle!",player,255,0,0)
		end
	end
end
addCommandHandler("headlights",changeHeadlights)
addCommandHandler("hl",changeHeadlights)