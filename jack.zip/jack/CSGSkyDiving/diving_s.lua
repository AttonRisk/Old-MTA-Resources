addEvent("startSkydiving",true)
addEventHandler("startSkydiving",root,
function(player,amount)
	if (player) and (amount) then
		setElementInterior(player,0)
		setElementPosition(player,359.052734375, 995.890625, 3999)
	end
end)

addEvent("takePlayerCash",true)
addEventHandler("takePlayerCash",root,
function(player,amount)
	if (player) and (amount) then
		setElementInterior(player,9)
		takePlayerMoney(player,tonumber(amount))
		--exports.CSGlogging:logAction(player,"money",getPlayerName(player).." spent $"..amount.." on Sky Diving")
		giveWeapon(player,46,1,true)
	end
end)