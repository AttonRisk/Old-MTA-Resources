divingMarkers = {}
divingMarkers["LV"] = createMarker(1663.1999511719,1466.5,12,"arrow",2,0,255,113)
divingMarkers["LS"] = createMarker(1642.15,-2335.3,14.54,"arrow",2,0,255,113)
divingMarkers["SF"] = createMarker(-1422.19,-286.3,15.14,"arrow",2,0,255,113)
planeMarker = createMarker(315.8681640625,1033.9951171875,1940.9372558594,"cylinder",10,255,255,255,10)
for i,v in pairs(divingMarkers) do
	createBlipAttachedTo(v,38,2,0,0,0,255,0,999)
end
setElementInterior(planeMarker,9)

windows = {}

function onStart()
	rx,ry = guiGetScreenSize()
	width,height = 347,251
	X = (rx/2) - (width/2)
	Y = (ry/2) - (height/2)
	divingWindow = guiCreateWindow(X,Y,width,height,"Sky Diving",false)
	divingLabel = guiCreateLabel(8,24,336,179,"Welcome to sky diving. If you don't know what sky diving is, it's you jumping out of a plane at 1000k feet with a parachute falling to the ground. Sounds simple huh? ofcourse it is.\n\nTo get started, simply click \"Accept\" below, Or if your too chicken, just click \"Changed my mind.\".\n\nENJOY!",false,divingWindow)
	guiLabelSetHorizontalAlign(divingLabel,"center",true)
	acceptBtn = guiCreateButton(9,204,127,33,"Challenge Accepted.",false,divingWindow)
	declineBtn = guiCreateButton(212,204,126,33,"Changed my mind.",false,divingWindow)
	lbl = guiCreateLabel(138,204,73,30,"Price: $1,000",false,divingWindow)
	guiLabelSetVerticalAlign(lbl,"center")
	guiLabelSetHorizontalAlign(lbl,"center",false)
	guiSetVisible(divingWindow,false)
end
addEventHandler("onClientResourceStart",resourceRoot,onStart)

function clickhandler(button,state)
	if button == "left" and state == "up" then
		if (source == acceptBtn) then
			if not (getPlayerMoney(localPlayer) < 1000) then
				triggerSkyDiving(localPlayer)
				guiSetVisible(divingWindow,false)
				showCursor(false)
			else 
				exports.DENhelp:createNewHelpMessageForPlayer("You do not have enough money to go sky diving!",255,0,0)
			end
		elseif (source == declineBtn) then
			showCursor(false)
			guiSetVisible(divingWindow,false)
		end
	end
end
addEventHandler("onClientGUIClick",root,clickhandler)

function onClientMarkerHit(hitElement,matchingDimension)
	for k,v in pairs(divingMarkers) do
		if (source == v) then
			if (hitElement == localPlayer) and (isElement(hitElement)) and not (isPedInVehicle(hitElement)) then
				showCursor(true)
				guiSetVisible(divingWindow,true)
			end
		end
	end
end
addEventHandler("onClientMarkerHit",root,onClientMarkerHit)

function triggerSkyDiving(player)
	if player then
		triggerServerEvent("takePlayerCash",player,player,1000)
		setElementPosition(player,315.8085937,973.734375,1961.4948730469)
		setElementDimension(player,9)
	end
end

function divingMarker(hitElement,matchingDimension)
	if (isElement(hitElement)) then
		if (source == planeMarker) and (getElementDimension(hitElement) == 9) then
			triggerServerEvent("startSkydiving",hitElement,hitElement,1000)
			setElementDimension(player,0)
		end
	end
end
addEventHandler("onClientMarkerHit",root,divingMarker)