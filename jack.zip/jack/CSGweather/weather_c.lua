local timeWhenChangeWeather = 300000 --5 minutes--
local nextWeather = 0
local previousWeatherID = 0
local currentWeatherID = 0
local waveHeight = 2.8
changeWeather = nil
weatherNames = {
["0"] = {"Blue Skies / Cloudy"},
["1"] = {"Blue Skies / Cloudy"},
["2"] = {"Blue Skies / Cloudy"},
["3"] = {"Blue Skies / Cloudy"},
["4"] = {"Blue Skies / Cloudy"},
["5"] = {"Blue Skies / Cloudy"},
["6"] = {"Blue Skies / Cloudy"},
["7"] = {"Blue Skies / Cloudy"},
["8"] = {"Stormy"},
["9"] = {"Cloudy and Foggy"},
["10"] = {"Clear sky"},
["11"] = {"Scorching Hot (Clear Sky!)"},
["12"] = {"Very Dull and Hazy"},
["13"] = {"Very Dull and Hazy"},
["14"] = {"Very Dull and Hazy"},
["15"] = {"Very Dull and Hazy"},
["16"] = {"Dull and Cloudy"},
["17"] = {"Scorching Hot"},
["18"] = {"Scorching Hot"},
["19"] = {"Sandstorm"}, -- should be blocked.
["20"] = {"Foggy"}
}


addEventHandler("onClientResourceStart",resourceRoot,
function()
	checkTimer = setTimer(checkForFisherman,2000,0,localPlayer)
end)

addEventHandler("onClientResourceStop",resourceRoot,
function()
	killTimer(checkTimer)
	setWeather(0)
	setWaveHeight(1.35)
end)

function checkForFisherman(player)
	if player then
		if getPlayerTeam(player) == "Civilian Workers" and exports.server:getPlayerOccupation(player) == "Fisherman" then
			changeWeather = setTimer(changeWeatherAutomatically,timeWhenChangeWeather,0)
		else
			if isElement(changeWeather) then
				killTimer(changeWeather)
			end
			if getWeather() ~= 0 then
				setWeather(0)
			end
			if getWaveHeight() ~= 1.35 then
				setWaveHeight(1.35)
			end
		end
	end
end

function changeWeatherAutomatically()
	outputDebugString("[WEATHER] Attempting to change weather...")
	if nextWeather then --get next weather \o/
		previousWeatherID = getWeather()
		setWeather(tonumber(nextWeather))
		currentWeatherID = getWeather()
		checkForRain()
		nextWeather = math.random(0,20)
		outputDebugString("[WEATHER] Weather changed.")
	else
		nextWeather = math.random(0,20)
		setTimer(changeWeather,1000,1)
		outputDebugString("[WEATHER] Could not find nextWeather ID, recalling with new ID.")
	end
end

function checkForRain()
	if getWeather() == 8 then
		setWaveHeight(waveHeight)
	else
		setWaveHeight(1.35)
	end
end