addEvent("givePlayerHouseRobEarnings",true)
addEventHandler("givePlayerHouseRobEarnings",root,
function(earnings,wanted)
	if (earnings) then
		givePlayerMoney(source,earnings)
		--exports.CSGlogging:logAction(source,"money",getPlayerName(source).." earned $"..earnings.." from houserob.")
		if (wanted == true) then
			exports.server:givePlayerWantedPoints(source,20)
		end
	end
end)