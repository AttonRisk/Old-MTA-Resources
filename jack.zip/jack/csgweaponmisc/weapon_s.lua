-- ..., no just no.
stopResource(getThisResource())

function onDamage(attacker,weapon,body,loss)
	if not (getTeamName(getPlayerTeam(source)) == "Staff") then
		if (weapon == 33 or weapon == 34) then
			if (body == 3 or 5 or 6 or 9) then --torso, left/right arm, head.
				killPed(source,attacker,weapon,body)
			end
		end
	else
		outputDebugString("Player is in staff team, returning.")
		return
	end
end
addEventHandler("onPlayerDamage",root,onDamage)