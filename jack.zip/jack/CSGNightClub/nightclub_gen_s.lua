addEvent("onClubPurchase",true)
addEventHandler("onClubPurchase",root,
function(player,purchaseType,amount,message)
	if purchaseType and amount and message then
		if purchaseType == "drink" then
			setPlayerHealth(player,getPlayerHealth(player) + 5)
			takePlayerMoney(player,amount)
			outputChatBox(message,player,0,255,0)
		elseif purchaseType == "example" then
			--blah--
		end
	end
end)