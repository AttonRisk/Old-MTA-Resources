addEvent("givePlayerHouseRobEarnings",true)
addEventHandler("givePlayerHouseRobEarnings",root,
function(earnings,wanted)
	if (earnings) then
		givePlayerMoney(source,earnings)
		if (wanted == true) then
			exports.server:givePlayerWantedPoints(source,20)
		end
	end
end)