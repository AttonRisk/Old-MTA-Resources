function createVeh()
	veh = createVehicle(567, 326.2, -1738.57, 4.42,0,0,85)
	marker = createMarker(326.2,-1738.57,4.42,"cylinder",1,255,0,0)
	if veh and marker then
		attachElementToElement(marker,veh,1.2,2.05,-0.7,0,0,0)
	end
end
addCommandHandler("createVeh",createVeh)

function flyveh(player,cmd,state)
	if (exports.server:isPlayerStaff(player)) then
		if state == "on" then
			setWorldSpecialPropertyEnabled("aircars",true)
		elseif state == "off" then
			setWorldSpecialPropertyEnabled("aircars",false)
		end
	end
end
addCommandHandler("flymeboy",flyveh)