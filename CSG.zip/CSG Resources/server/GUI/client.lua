-- Get the username and/or password is saved
function getAccountXMLData ()
	local theFile = xmlLoadFile ( "Files/account.xml" )
	if not ( theFile ) then
		theFile = xmlCreateFile( "Files/account.xml","accounts" )
		xmlCreateChild( theFile, "username" )
		xmlCreateChild( theFile, "password" )
		xmlSaveFile( theFile )
		return "", ""
	else
		usernameNode = xmlFindChild( theFile, "username", 0 )
		username = xmlNodeGetValue ( usernameNode )
		passwordNode = xmlFindChild( theFile, "password", 0 )
		password = xmlNodeGetValue ( passwordNode )
		return username, password
	end
end

-- Update the XML file with the new data
addEvent ( "updateAccountXMLData", true )
function updateAccountXML ( username, password, usernameTick, passwordTick )
	local theFile = xmlLoadFile ( "Files/account.xml" )
	if not ( theFile ) then
		theFile = xmlCreateFile( "Files/account.xml","accounts" )
		xmlCreateChild( theFile, "username" )
		xmlCreateChild( theFile, "password" )
		xmlSaveFile( theFile )
	else
		usernameNode = xmlFindChild( theFile, "username", 0 )
		xmlNodeSetValue( usernameNode, username )
		passwordNode = xmlFindChild( theFile, "password", 0 )
		xmlNodeSetValue( passwordNode, password )
		
		if not ( usernameTick ) then
          	usernameNode = xmlFindChild( theFile, "username", 0 )
          	xmlNodeSetValue( usernameNode, "" )
     	end
			
     	if not ( passwordTick ) then
          	passwordNode = xmlFindChild( theFile, "password", 0 )
          	xmlNodeSetValue( passwordNode, "" )
     	end
		xmlSaveFile( theFile )
	end
end
addEventHandler( "updateAccountXMLData", root, updateAccountXML )

function createAccountingWindows ()
	-- Login window
	local username, password = getAccountXMLData ()
	CSGLoginWindow = guiCreateWindow(433,258,377,406,"Community of Social Gaming ~ Login",false)
	CSGLoginImage = guiCreateStaticImage(23,32,324,91,"Files/logo.png",false,CSGLoginWindow)
	CSGLoginLabel1 = guiCreateLabel(8,127,359,17,"Accountname:",false,CSGLoginWindow)
	guiLabelSetColor(CSGLoginLabel1,238, 154, 0)
	guiLabelSetHorizontalAlign(CSGLoginLabel1,"center",false)
	guiSetFont(CSGLoginLabel1,"default-bold-small")
	CSGLoginUsernameField = guiCreateEdit(46,146,287,22,username,false,CSGLoginWindow)
	CSGLoginLabel2 = guiCreateLabel(8,183,359,17,"Password:",false,CSGLoginWindow)
	guiLabelSetColor(CSGLoginLabel2,238,154,0)
	guiLabelSetHorizontalAlign(CSGLoginLabel2,"center",false)
	guiSetFont(CSGLoginLabel2,"default-bold-small")
	CSGLoginPasswordField = guiCreateEdit(46,203,287,22,password,false,CSGLoginWindow)
	guiEditSetMasked (CSGLoginPasswordField,true)
	CSGLoginUsernameCheckbox = guiCreateCheckBox(74,236,112,23,"Save username",false,false,CSGLoginWindow)
	guiSetFont(CSGLoginUsernameCheckbox,"default-bold-small")
	CSGLoginPasswordCheckbox = guiCreateCheckBox(199,236,111,23,"Save password",false,false,CSGLoginWindow)
	guiSetFont(CSGLoginPasswordCheckbox,"default-bold-small")
	CSGLoginJoinButton = guiCreateButton(47,303,287,23,"Join the game",false,CSGLoginWindow)
	CSGLoginCreateButton = guiCreateButton(47,332,287,23,"Create a new account",false,CSGLoginWindow)
	CSGLoginPasswordButton = guiCreateButton(47,362,287,23,"Request a new password",false,CSGLoginWindow)
	CSGLoginLabel3 = guiCreateLabel(8,273,359,17,"Always read the rules before playing on this server!",false,CSGLoginWindow)
	guiLabelSetColor(CSGLoginLabel3,34,139,34)
	guiLabelSetHorizontalAlign(CSGLoginLabel3,"center",false)
	guiSetFont(CSGLoginLabel3,"default-bold-small")
	if ( username ~= "" ) then guiCheckBoxSetSelected( CSGLoginUsernameCheckbox, true ) end
	if ( password ~= "" ) then guiCheckBoxSetSelected( CSGLoginPasswordCheckbox, true ) end
	centerWindows ( CSGLoginWindow )
	guiWindowSetMovable (CSGLoginWindow, true)
	guiWindowSetSizable (CSGLoginWindow, false)
	guiSetVisible (CSGLoginWindow, false)
	-- Register window
	CSGRegisterWindow = guiCreateWindow(495,183,377,492,"Community of Social Gaming ~ Create account",false)
	CSGRegisterImage = guiCreateStaticImage(23,32,324,91,"Files/logo.png",false,CSGRegisterWindow)
	CSGRegisterLabel1 = guiCreateLabel(8,127,359,17,"Accountname:",false,CSGRegisterWindow)
	guiLabelSetColor(CSGRegisterLabel1,238	,154,0)
	guiLabelSetHorizontalAlign(CSGRegisterLabel1,"center",false)
	guiSetFont(CSGRegisterLabel1,"default-bold-small")
	CSGRegisterUsernameField = guiCreateEdit(46,146,287,22,"",false,CSGRegisterWindow)
	CSGRegisterLabel2 = guiCreateLabel(8,183,359,17,"Password:",false,CSGRegisterWindow)
	guiLabelSetColor(CSGRegisterLabel2,238,154,0)
	guiLabelSetHorizontalAlign(CSGRegisterLabel2,"center",false)
	guiSetFont(CSGRegisterLabel2,"default-bold-small")
	CSGRegisterPasswordField = guiCreateEdit(46,203,287,22,"",false,CSGRegisterWindow)
	guiEditSetMasked(CSGRegisterPasswordField,true)
	CSGRegisterLabel3 = guiCreateLabel(10,392,359,17,"Dual accounting is not allowed. Always read the rules.",false,CSGRegisterWindow)
	guiLabelSetColor(CSGRegisterLabel3,34,139,34)
	guiLabelSetHorizontalAlign(CSGRegisterLabel3,"center",false)
	guiSetFont(CSGRegisterLabel3,"default-bold-small")
	CSGRegisterLabel4 = guiCreateLabel(8,238,359,17,"Repeat password:",false,CSGRegisterWindow)
	guiLabelSetColor(CSGRegisterLabel4,238,154,0)
	guiLabelSetHorizontalAlign(CSGRegisterLabel4,"center",false)
	guiSetFont(CSGRegisterLabel4,"default-bold-small")
	CSGRegisterPassword2Field = guiCreateEdit(46,258,287,22,"",false,CSGRegisterWindow)
	guiEditSetMasked(CSGRegisterPassword2Field,true)
	CSGRegisterLabel5 = guiCreateLabel(8,290,359,17,"Email Address:",false,CSGRegisterWindow)
	guiLabelSetColor(CSGRegisterLabel5,238,154,0)
	guiLabelSetHorizontalAlign(CSGRegisterLabel5,"center",false)
	guiSetFont(CSGRegisterLabel5,"default-bold-small")
	CSGRegisterEmailField = guiCreateEdit(46,310,287,22,"",false,CSGRegisterWindow)
	CSGRegisterLabel6 = guiCreateLabel(8,343,359,17,"Gender:",false,CSGRegisterWindow)
	guiLabelSetColor(CSGRegisterLabel6,238,154,0)
	guiLabelSetHorizontalAlign(CSGRegisterLabel6,"center",false)
	guiSetFont(CSGRegisterLabel6,"default-bold-small")
	CSGRegisterMaleGender = guiCreateRadioButton(132,362,45,19,"Male",false,CSGRegisterWindow)
	CSGRegisterFemaleGender = guiCreateRadioButton(181,362,67,19,"Female",false,CSGRegisterWindow)
	CSGRegisterCreateButton = guiCreateButton(47,426,287,23,"Create new account",false,CSGRegisterWindow)
	CSGRegisterReturnButton = guiCreateButton(47,456,287,23,"Return to the login screen",false,CSGRegisterWindow)
	centerWindows ( CSGRegisterWindow )
	guiWindowSetMovable (CSGRegisterWindow, true)
	guiWindowSetSizable (CSGRegisterWindow, false)
	guiSetVisible (CSGRegisterWindow, false)
	-- Password request window
	CSGPasswordWindow = guiCreateWindow(495,183,377,350,"Community of Social Gaming ~ Password request",false)
	CSGPasswordImage = guiCreateStaticImage(23,32,324,91,"Files/logo.png",false,CSGPasswordWindow)
	CSGPasswordLabel1 = guiCreateLabel(8,127,359,17,"Accountname:",false,CSGPasswordWindow)
	guiLabelSetColor(CSGPasswordLabel1,238,154,0)
	guiLabelSetHorizontalAlign(CSGPasswordLabel1,"center",false)
	guiSetFont(CSGPasswordLabel1,"default-bold-small")
	CSGPasswordUsernameField = guiCreateEdit(46,146,287,22,"",false,CSGPasswordWindow)
	CSGPasswordCancelButton = guiCreateButton(47,310,287,23,"Return to the login screen",false,CSGPasswordWindow)
	CSGPasswordLabel2 = guiCreateLabel(10,245,359,17,"A new password will be sent to your email!",false,CSGPasswordWindow)
	guiLabelSetColor(CSGPasswordLabel2,34,139,34)
	guiLabelSetHorizontalAlign(CSGPasswordLabel2,"center",false)
	guiSetFont(CSGPasswordLabel2,"default-bold-small")
	CSGPasswordRequestButton = guiCreateButton(47,278,287,23,"Request new password",false,CSGPasswordWindow)
	CSGPasswordEmailField = guiCreateEdit(46,203,287,22,"",false,CSGPasswordWindow)
	CSGPasswordLabel3 = guiCreateLabel(8,181,359,17,"Email Adress:",false,CSGPasswordWindow)
	guiLabelSetColor(CSGPasswordLabel3,238,154,0)
	guiLabelSetHorizontalAlign(CSGPasswordLabel3,"center",false)
	guiSetFont(CSGPasswordLabel3,"default-bold-small")
	centerWindows ( CSGPasswordWindow )
	guiWindowSetMovable (CSGPasswordWindow, true)
	guiWindowSetSizable (CSGPasswordWindow, false)
	guiSetVisible (CSGPasswordWindow, false)
	-- Popup window after creating account
	CSGRegisterPopup = guiCreateWindow(495,184,253,157,"Community of Social Gaming",false)
	CSGRegisterPopupLabel1 = guiCreateLabel(8,27,238,17,"Warning:",false,CSGRegisterPopup)
	guiLabelSetColor(CSGRegisterPopupLabel1,34,139,34)
	guiLabelSetHorizontalAlign(CSGRegisterPopupLabel1,"center",false)
	guiSetFont(CSGRegisterPopupLabel1,"default-bold-small")
	CSGRegisterPopupLabel2 = guiCreateLabel(8,52,235,61,"Your account is created and ready to use!\nBefore playing read the rules.\n\nVisit also: www.csgmta.net",false,CSGRegisterPopup)
	guiLabelSetHorizontalAlign(CSGRegisterPopupLabel2,"center",false)
	guiSetFont(CSGRegisterPopupLabel2,"default-bold-small")
	CSGRegisterPopupButton = guiCreateButton(25,121,208,23,"Return to the login screen",false,CSGRegisterPopup)	
	centerWindows ( CSGRegisterPopup )
	guiWindowSetMovable (CSGRegisterPopup, true)
	guiWindowSetSizable (CSGRegisterPopup, false)
	guiSetVisible (CSGRegisterPopup, false)
	-- Rules window
	CSGRulesWindow = guiCreateWindow(398,141,647,574,"CSG ~ Rules",false)
	registerRulesMemo = guiCreateMemo(9,24,629,496,"1. Deathmatching is not allowed outside the city of Las Venturas.\nCriminals are allowed to attack Law agents IF they are wanted and being chased by them.\nAlso, killing other players in ANY interior is not allowed, even if its in Las Venturas;\n\n2. The use of trainers and bugs is strictly forbidden and will result in a ban from the server;\n\n3. Insulting and being racist towards other players will result in a severe punishment;\n\n4. Annoying the Server Staff is not allowed and will result in a punishment;\n\n5. Any attempt to avoid punishment by the server staff will only result in a larger punishment to be applied;\n\n6. Advertising about other servers and commercial products is not allowed;\n\n7. It is not allowed to share hacks, cracks or mods on the server nor it is allowed to abuse any kind of bugs that give you an unfair advantage or spoil the fun of other players;\n\n8. Do not force/blackmail other players to do something they dont want to;\n\n9. Only language allowed in public channels is English (Main chat, team chat and support). In the Local chat, Personal Messaging and Group chat, any language can be spoken;\n\n10. Camping at the hospital, Spawn-killing and Spawn arresting are forbidden;\n\n11. Spamming chats is not allowed. Also, misusing the Support Channel will be punished with a mute;\n\n12. Selling accounts or other in-game contents is not allowed;\n\n13. You must use normal names. Names with spam, advertisement and inappropriate things are not allowed;\n\n14. Trolling other players is not allowed and is severely punished;\n\n15. Always listen to server staff;",false,CSGRulesWindow)
	registerRulesButton = guiCreateButton(202,528,257,36,"Accept (60 seconds)",false,CSGRulesWindow)
	centerWindows ( CSGRulesWindow )
	guiWindowSetMovable (CSGRulesWindow, true)
	guiWindowSetSizable (CSGRulesWindow, false)
	guiSetVisible (CSGRulesWindow, false)
	
	addEventHandler( "onClientGUIClick", registerRulesButton, function () triggerServerEvent( "spawnPlayerIntoGame", localPlayer ) guiSetVisible(CSGRulesWindow,false) showCursor(false) end, false )
	
	addEventHandler( "onClientGUIClick", CSGPasswordRequestButton, onClientPlayerPasswordRequest, false )
	addEventHandler( "onClientGUIClick", CSGRegisterCreateButton, onClientPlayerRegister, false )
	addEventHandler( "onClientGUIClick", CSGLoginJoinButton, onClientPlayerLogin, false )
	addEventHandler( "onClientGUIClick", CSGLoginCreateButton, showRegisterWindow, false )
	addEventHandler( "onClientGUIClick", CSGLoginPasswordButton, showPasswordWindow, false )
	addEventHandler( "onClientGUIClick", CSGRegisterReturnButton, showLoginWindow, false )
	addEventHandler( "onClientGUIClick", CSGPasswordCancelButton, showLoginWindow, false )
	addEventHandler( "onClientGUIClick", CSGRegisterPopupButton, showLoginWindow, false )
end

-- Create the GUI on connect or start
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), 
	function ()
		guiSetInputMode("no_binds_when_editing")
		createAccountingWindows()
		screenX, screenY = guiGetScreenSize()
		if ( screenX >= 800 ) and ( screenY >= 600 ) then
			triggerServerEvent( "doSpawnPlayer", localPlayer )
		else
			triggerServerEvent( "doKickPlayer", localPlayer )
		end
	end
)

-- Effect when the player enters a button with the mouse
addEventHandler( "onClientMouseEnter", root, 
    function()
        if ( getElementType ( source ) == "gui-button" ) then
			guiSetProperty( source, "HoverTextColour", "FFEE9A00" )
		end
    end
)

addEventHandler( "onClientMouseLeave", root, 
    function()
        if ( getElementType ( source ) == "gui-button" ) then
			guiSetProperty( source, "HoverTextColour", "FFFFFFFF" )
		end
    end
)

-- Clear all fields
function clearEditFields ()
	guiSetText( CSGPasswordUsernameField, "" )
	guiSetText( CSGPasswordEmailField, "" )
	guiSetText( CSGRegisterUsernameField, "" )
	guiSetText( CSGRegisterPasswordField, "" )
	guiSetText( CSGRegisterPassword2Field, "" )
	guiSetText( CSGRegisterEmailField, "" )
end

-- Enable cursor
addEvent ( "setCursorEnabled", true )
function enableCursor ( state )
	if ( state ) then
		showCursor( true )
	else
		showCursor( false )
	end
end
addEventHandler( "setCursorEnabled", root, enableCursor )

-- Center the windows
function centerWindows ( theWindow )
	local screenW,screenH=guiGetScreenSize()
	local windowW,windowH=guiGetSize(theWindow,false)
	local x,y = (screenW-windowW)/2,(screenH-windowH)/2
	guiSetPosition(theWindow,x,y,false)
end

-- Set the rules window visable
addEvent ( "setRulesWindowVisable", true )
function showRulesWindow ()
	guiSetEnabled ( registerRulesButton, false ) 
	guiSetVisible (CSGRulesWindow, true)
	guiSetVisible (CSGLoginWindow, false)
	guiSetVisible (CSGRegisterWindow, false)
	guiSetVisible (CSGPasswordWindow, false)
	guiSetVisible (CSGRegisterPopup, false)
	checkRemainingTime()
	clearEditFields ()
	enableCursor ( true )
end
addEventHandler( "setRulesWindowVisable", root, showRulesWindow )

-- Set the login window visable
addEvent ( "setLoginWindowVisable", true )
function showLoginWindow ()
	guiSetVisible (CSGLoginWindow, true)
	guiSetVisible (CSGRegisterWindow, false)
	guiSetVisible (CSGPasswordWindow, false)
	guiSetVisible (CSGRegisterPopup, false)
	clearEditFields ()
	enableCursor ( true )
end
addEventHandler( "setLoginWindowVisable", root, showLoginWindow )

-- Set the register window visable
addEvent ( "setRegisterWindowVisable", true )
function showRegisterWindow ()
	guiSetVisible (CSGLoginWindow, false)
	guiSetVisible (CSGRegisterWindow, true)
	guiSetVisible (CSGPasswordWindow, false)
	guiSetVisible (CSGRegisterPopup, false)
	enableCursor ( true )
end
addEventHandler( "setRegisterWindowVisable", root, showRegisterWindow )

-- Set the password window visable
addEvent ( "setPasswordWindowVisable", true )
function showPasswordWindow ()
	guiSetVisible (CSGLoginWindow, false)
	guiSetVisible (CSGRegisterWindow, false)
	guiSetVisible (CSGPasswordWindow, true)
	guiSetVisible (CSGRegisterPopup, false)
	enableCursor ( true )
end
addEventHandler( "setPasswordWindowVisable", root, showPasswordWindow )

-- Set the poup window visable
addEvent ( "setPopupWindowVisable", true )
function showPopupWindow ()
	guiSetVisible (CSGLoginWindow, false)
	guiSetVisible (CSGRegisterWindow, false)
	guiSetVisible (CSGPasswordWindow, false)
	guiSetVisible (CSGRegisterPopup, true)
	enableCursor ( true )
end
addEventHandler( "setPopupWindowVisable", root, showPopupWindow )

-- Hide all windows
addEvent ( "setAllWindowsHided", true )
function hideAllWindows ()
	guiSetVisible (CSGLoginWindow, false)
	guiSetVisible (CSGRegisterWindow, false)
	guiSetVisible (CSGPasswordWindow, false)
	guiSetVisible (CSGRegisterPopup, false)
	enableCursor ( false )
end
addEventHandler( "setAllWindowsHided", root, hideAllWindows )

-- Get all the fields from the login screen
function getLoginWindowData ()
	return guiGetText ( CSGLoginUsernameField ), guiGetText ( CSGLoginPasswordField ), guiCheckBoxGetSelected ( CSGLoginUsernameCheckbox ), guiCheckBoxGetSelected ( CSGLoginPasswordCheckbox )
end

-- Get all the fields from register window
function getRegisterWindowData ()
	local username = guiGetText ( CSGRegisterUsernameField )
	local password1 = guiGetText ( CSGRegisterPasswordField )
	local password2 = guiGetText ( CSGRegisterPassword2Field )
	local email = guiGetText ( CSGRegisterEmailField )
	local genderMale = guiRadioButtonGetSelected( CSGRegisterMaleGender )
	local genderFemale = guiRadioButtonGetSelected( CSGRegisterFemaleGender )
	return username, password1, password2, email, genderMale, genderFemale
end

-- Get all the data from the password request screen
function getPasswordWindowData ()
	return guiGetText ( CSGPasswordUsernameField ), guiGetText ( CSGPasswordEmailField )
end

-- Set the warning label data
addEvent ( "setWarningLabelText", true )
function setWarningLabelText ( theText, theType, r, g, b )
	if ( theType == "loginWindow" ) then
		guiSetText( CSGLoginLabel3, theText )
		if ( r ) and ( g ) and ( b ) then guiLabelSetColor( CSGLoginLabel3, r, g, b ) end
	elseif ( theType == "registerWindow" ) then
		guiSetText( CSGRegisterLabel3, theText )
		if ( r ) and ( g ) and ( b ) then guiLabelSetColor( CSGRegisterLabel3, r, g, b ) end
	elseif ( theType == "passwordWindow" ) then
		guiSetText( CSGPasswordLabel2, theText )
		if ( r ) and ( g ) and ( b ) then guiLabelSetColor( CSGPasswordLabel2, r, g, b ) end
	end
end
addEventHandler( "setWarningLabelText", root, setWarningLabelText )

-- Button countdown for the rules
local remainingTime = 60

function checkRemainingTime ()
	if ( remainingTime ) < 1 then 
		guiSetEnabled ( registerRulesButton, true ) 
		guiSetText ( registerRulesButton, "Accept" )
	else
		remainingTime = remainingTime -1 
		guiSetText ( registerRulesButton, "Accept (".. remainingTime .." seconds)" )
		setTimer(checkRemainingTime, 1000, 1)
	end
end