local screenX, screenY = guiGetScreenSize()
local scaleMain = 2
local scaleGeneral = 1.5
local startX, startY = 80.0, 98.0
local sizeHeight = 150

local hospitalTable = {
	{ "Los Santos All Saints hospital", 1179.1, -1324.4, 14.15, 270.12222290039, 1215.4975585938, -1343.1850585938, 35.528800964355, 1214.7266845703, -1342.7204589844, 35.093036651611, 0, 70 },
	{ "Los Santos Country Central hospital", 2030.31, -1406.77, 17.2, 178.76403808594, 2012.4608154297, -1440.1544189453, 33.239101409912, 2012.8569335938, -1439.3461914063, 32.803337097168, 0, 70 },
	{ "Los Santos Crippen Memorial hospital", 1245.22, 334.22, 19.55, 335.55230712891, 1275.6314697266, 348.43908691406, 37.013999938965, 1274.9337158203, 347.95013427734, 36.490543365479, 0, 7 },
	{ "Las Venturas Fort Carson hospital", -319.24, 1057.76, 19.74, 343.53948974609, -307.31741333008, 1085.3322753906, 37.267700195313, -307.63153076172, 1084.5151367188, 36.784400939941, 0, 70 },
	{ "Las Venturas General hospital", 1607.87, 1823, 10.82, 1.5188903808594, 1631.53125, 1867.3415527344, 25.293199539185, 1631.1346435547, 1866.4654541016, 25.018928527832, 0, 70 },
	{ "Las Venturas El Quebrados hospital", -1514.85, 2528.23, 55.72, 358.66787719727, -1499.2265625, 2558.5263671875, 66.142501831055, -1499.6668701172, 2557.7001953125, 65.791000366211, 0, 70 },
	{ "San Fierro General hospital", -2647.62, 631.2, 14.45, 176.91278076172, -2627.0493164063, 582.10327148438, 28.898700714111, -2627.5827636719, 582.89117431641, 28.591079711914, 0, 70 },
	{ "San Fierro Angel pine hospital", -2199.24, -2310.78, 30.62, 319.53399658203, -2178.7451171875, -2288.4621582031, 41.820098876953, -2179.4353027344, -2289.0139160156, 41.352130889893, 0, 70 }
}

if ( screenX == 1024 ) then 	
	scaleMain = 1.5	
	scaleGeneral = 1 
	sizeHeight = 125
elseif ( screenX == 800 ) then
	scaleMain = 1.5
	scaleGeneral = 1
	sizeHeight = 100
	startY = 98		
elseif ( screenX == 600 ) then	
	scaleMain = 1.1
	scaleGeneral = 0.8	
	sizeHeight = 70		
end

-- When the player pressed login
function onClientPlayerLogin ()
	local username, password, usernameTick, passwordTick = getLoginWindowData()
	if ( username:match( "^%s*$" ) ) then
		setWarningLabelText ( "The accountname field is empty!", "loginWindow", 225, 0, 0 )
	elseif ( password:match( "^%s*$" ) ) then
		setWarningLabelText ( "The password field is empty!", "loginWindow", 225, 0, 0 )
	else
		setWarningLabelText ( "Attempting to login...", "loginWindow", 225, 165, 0 )
		triggerServerEvent( "doPlayerLogin", localPlayer, username, password, usernameTick, passwordTick )
	end
end

-- When the player pressed register
function onClientPlayerRegister ()
	local username, password1, password2, email, genderMale, genderFemale = getRegisterWindowData ()
	if ( username:match( "^%s*$" ) ) then
		setWarningLabelText ( "The accountname field is empty!", "registerWindow", 225, 0, 0 )
	elseif ( password1:match( "^%s*$" ) ) or ( password2:match( "^%s*$" ) ) then
		setWarningLabelText ( "The password field is empty!", "registerWindow", 225, 0, 0 )
	elseif ( password1 ~= password2 ) then
		setWarningLabelText ( "The passwords don't match!", "registerWindow", 225, 0, 0 )
	elseif ( string.len( password1 ) < 8 ) then
		setWarningLabelText ( "Your password is too short!", "registerWindow", 225, 0, 0 )
	elseif not ( genderMale ) and not ( genderFemale ) then
		setWarningLabelText ( "You didn't select a gender!", "registerWindow", 225, 0, 0 )
	elseif ( ( string.match( email, "^.+@.+%.%a%a%a*%.*%a*%a*%a*") ) ) then
		setWarningLabelText ( "Creating a new account...", "registerWindow", 225, 165, 0 )
		triggerServerEvent( "doAccountRegister", localPlayer, username, password1, password2, email, genderMale, genderFemale )
	else
		setWarningLabelText ( "You didn't enter a vaild email adress!", "registerWindow", 225, 0, 0 )
	end
end

-- When player requests a new password
function onClientPlayerPasswordRequest ()
	local username, email = getPasswordWindowData ()
	if ( email:match("^%s*$") ) then
		setWarningLabelText ( "You didn't enter a email adress!", "passwordWindow", 225, 0, 0 )
	elseif ( username:match("^%s*$") ) then
		setWarningLabelText ( "You didn't enter a accountname!", "passwordWindow", 225, 0, 0 )
	elseif not ( string.match(email, "^.+@.+%.%a%a%a*%.*%a*%a*%a*") )then
		setWarningLabelText ( "You didn't enter a vaild email adress!", "passwordWindow", 225, 0, 0 )
	else
		triggerServerEvent( "doPlayerPasswordReset", localPlayer, email, username, exports.server:randomString( 10 ) )
	end
end

-- Convert a timeStamp to a date
function timestampConvert (timeStamp)
	local time = getRealTime(timeStamp)
	local year = time.year + 1900
	local month = time.month + 1
	local day = time.monthday
	local hour = time.hour
	local minute = time.minute

	return "" .. hour ..":" .. minute .." - " .. month .."/" .. day .."/" .. year ..""
end

-- Show the ban screen when trigger serverside
addEvent("drawClientBanScreen", true)
function dxDrawBanScreen( banSerial, banReason, banBantime, bannedby ) 
	if ( banBantime == 0 ) then banBantime = "Permanently Banned" end
	TheBanSerial = banSerial
	TheBanReason = banReason
	TheBanBantime = timestampConvert( banBantime )
	TheBanBanner = bannedby
	addEventHandler("onClientRender", root, drawBanScreen ) 
end
addEventHandler("drawClientBanScreen", root, dxDrawBanScreen )

-- Draw the ban screen window
function drawBanScreen ()
	dxDrawText("This serial is banned from the server!",startX, startY,796.0,157,tocolor(200,0,0,230),scaleMain,"pricedown","left","top",false,false,false)
	dxDrawText("Reason: "..TheBanReason,startX,startY+(sizeHeight*1)+15,796.0,sizeHeight,tocolor(238,118,0,230),scaleGeneral,"pricedown","left","top",false,false,false)
	dxDrawText("Banned till: "..TheBanBantime,startX,startY+(sizeHeight*2)+5,796.0,sizeHeight,tocolor(238,118,0,230),scaleGeneral,"pricedown","left","top",false,false,false)
	dxDrawText("Banned By: "..TheBanBanner ,startX,startY+(sizeHeight*3)+5,796.0,sizeHeight,tocolor(0,120,0,230),scaleGeneral,"pricedown","left","top",false,false,false)
	dxDrawText("Serial: "..TheBanSerial,startX,startY+(sizeHeight*4)+5,796.0,sizeHeight,tocolor(0,120,0,230),scaleGeneral,"pricedown","left","top",false,false,false)
end

-- Event triggerd when the player dies
addEventHandler ( "onClientPlayerWasted", localPlayer, 
function ()
	if not ( getElementHealth( localPlayer ) > 0 ) then
		local hospitalDist = false
		local nearestHospital = false
		for i=1,#hospitalTable do
			local px, py, pz = getElementPosition( localPlayer )
			local hx, hy, hz = hospitalTable[i][2], hospitalTable[i][3], hospitalTable[i][4]
			local distance = getDistanceBetweenPoints3D ( px, py, pz, hx, hy, hz )
			if not ( hospitalDist ) or ( distance < hospitalDist ) then
				hospitalDist = distance
				nearestHospital = i
			end
		end
		
		if ( nearestHospital ) then
			local ID = nearestHospital
			local hx, hy, hz, rotation, hospitalName = hospitalTable[ID][2], hospitalTable[ID][3], hospitalTable[ID][4], hospitalTable[ID][5], hospitalTable[ID][1]
			local mx, my, mz, lx, ly, lz = hospitalTable[ID][6], hospitalTable[ID][7], hospitalTable[ID][8], hospitalTable[ID][9], hospitalTable[ID][10], hospitalTable[ID][11]
			setTimer( function () triggerServerEvent( "respawnDeadPlayer", localPlayer, hx, hy, hz, rotation, mx, my, mz, lx, ly, lz, hospitalName ) end, 4000, 1 )
		end
		
		-- Spawn protection
		setTimer(
		function ()
			setElementData( localPlayer, "spawnProtection", true )
			toggleControl ( "fire", false )
			toggleControl ( "next_weapon", false )
			toggleControl ( "previous_weapon", false )
			setPlayerCollidable ( localPlayer, false )
			setElementAlpha( localPlayer, 170 )
			
			setTimer( setElementData, 15000, 1, localPlayer, "spawnProtection", false )
			setTimer( toggleControl, 15000, 1, "fire", true )
			setTimer( toggleControl, 15000, 1, "next_weapon", true )
			setTimer( toggleControl, 15000, 1, "previous_weapon", true )
			setTimer( setPlayerCollidable, 15000, 1, localPlayer, true )
			setTimer( setElementAlpha, 15000, 1, localPlayer, 255)
		end, 9000, 1 )
	end
end
)

-- Set the element colidable with other players
function setPlayerCollidable ( thePlayer, state )
	if not ( state ) then state = false end
	for k, i in ipairs ( getElementsByType( "player" ) ) do
		setElementCollidableWith( i, thePlayer, state )
	end
end

-- Spawn protection damage control
addEventHandler( "onClientPlayerDamage", root,
function()
	if ( getElementData( localPlayer, "spawnProtection" ) ) then
		cancelEvent()
	end
end
)

-- Show the AFK window
addEvent( "onClientShowAFK", true )
addEventHandler( "onClientShowAFK", root,
	function ( state ) 
		if ( state ) then
			addEventHandler( "onClientRender", root, onDrawAFKWindow )
		else
			removeEventHandler( "onClientRender", root, onDrawAFKWindow )
		end
	end
)

local sx,sy = guiGetScreenSize()

function onDrawAFKWindow ()
	if ( sx == 1152 ) and ( sy == 864 ) then scale = 1.2 elseif ( sx == 1024 ) and ( sy == 768 ) then scale = 1.1 elseif ( sx <= 800 ) and ( sy <= 600 ) then scale = 1.0 else scale = 1.3 end
	dxDrawRectangle(sx*(342.0/1440),sy*(392.0/900),sx*(789.0/1440),sy*(41.0/900),tocolor(0,0,0,180),false)
    dxDrawText("You where AFK while spawning and moved to another dimension. Move to get back in the normal world.",sx*(355.0/1440),sy*(402.0/900),sx*(1124.0/1440),sy*(424.0/900),tocolor(225,0,0,225),scale,"default","left","top",false,false,false)
end

-- Sync weapons since MTA fails with serverside weapon sync
function getWeaponString( player )
	local weapons = { }
	local hasAnyWeapons = false
	for slot = 0, 12 do
		local weapon = getPedWeapon( player, slot )
		if ( weapon > 0 ) then
			local ammo = getPedTotalAmmo( player, slot )
			if ( ammo > 0 ) then
				weapons[weapon] = ammo
				hasAnyWeapons = true
			end
		end
	end
	if ( hasAnyWeapons ) then
		return "" .. toJSON( weapons ):gsub( " ", "" ) .. ""
	else
		return "NULL"
	end
end

setTimer (
function ()
	setElementData ( localPlayer, "WL", getPlayerWantedLevel( localPlayer ) )
	setElementData ( localPlayer, "Money", "$ "..exports.server:convertNumber( getPlayerMoney( localPlayer ) ) )
	setElementData ( localPlayer, "City", exports.server:getPlayChatZone() )	
	triggerServerEvent ( "syncPlayerWeaponString", localPlayer, getWeaponString( localPlayer ) )
end, 1000, 0 
)

-- Event when the client player logged in
addEvent("clientPlayerLogin", true)
function clientPlayerLogin ( userid, username )
	triggerEvent( "onSetPlayerSettings", root, source )
	triggerEvent( "onClientPlayerLogin", root, source, userid, username )
end
addEventHandler( "clientPlayerLogin", root, clientPlayerLogin )

-- Playtime
setTimer (
function ()
	local playTime = getElementData ( localPlayer, "playTime" )
	if ( playTime ) then
		local theTime = ( playTime + 5 )
		setElementData( localPlayer, "playTime", math.floor( theTime ) )
		setElementData( localPlayer, "Play Time", math.floor( theTime / 60 ).." Hours" )
	else
		setElementData( localPlayer, "playTime", 0 )
		setElementData( localPlayer, "Play Time", 0 )
	end
end, 300000, 0 
)

addEvent( "onClientPlayerLogin" )
addEventHandler( "onClientPlayerLogin", localPlayer,
function ( userID, username )
	local playTime = getElementData ( localPlayer, "playTime" )
	if ( playTime ) then
		local theTime = ( playTime + 5 )
		setElementData( localPlayer, "playTime", math.floor( theTime ) )
		setElementData( localPlayer, "Play Time", math.floor( theTime / 60 ).." Hours" )
	else
		setElementData( localPlayer, "playTime", 0 )
		setElementData( localPlayer, "Play Time", 0 )
	end
end
)

-- Settings from the CSG Phone
addEventHandler( "onPlayerSettingChange", root,
function ( theSetting, newValue, oldValue )
	if ( newValue ~= nil ) then
		if ( theSetting == "blur" ) then
			if ( newValue == true ) then
				setBlurLevel ( 36 )
			else
				setBlurLevel ( 0 )
			end
		elseif ( theSetting == "heathaze" ) then
			if ( newValue == true ) then
				setHeatHaze ( 100 )
			else
				setHeatHaze ( 0 )
			end
		elseif ( theSetting == "fpsmeter" ) then
			if ( newValue == true ) then
				addEventHandler("onClientRender", root, onClientDrawFPS)
			else
				removeEventHandler("onClientRender", root, onClientDrawFPS)
			end
		elseif ( theSetting == "clouds" ) then
			setCloudsEnabled ( newValue )
		elseif ( theSetting == "chatbox" ) then
			showChat ( newValue )
		elseif ( theSetting == "sms" ) then
			setElementData( localPlayer, "SMSoutput", newValue )
		elseif ( theSetting == "shaders" ) then
			triggerEvent( "onClientSwitchDetail", localPlayer, newValue )
		elseif ( theSetting == "speedmeter" ) then
			triggerEvent( "onClientSwitchSpeedMeter", localPlayer, newValue )
		elseif ( theSetting == "damagemeter" ) then
			triggerEvent( "onClientSwitchDamageMeter", localPlayer, newValue )
		elseif ( theSetting == "fuelmeter" ) then
			triggerEvent( "onClientSwitchFuelMeter", localPlayer, newValue )
		elseif ( theSetting == "groupblips" ) then
			triggerEvent( "onClientSwitchGroupBlips", localPlayer, newValue )
		elseif ( theSetting == "grouptags" ) then
			triggerEvent( "onClientSwitchGroupTags", localPlayer, newValue )
		end
	end
end
)

local FPSLimit, lastTick, framesRendered, FPS = 100, getTickCount(), 0, 0
local screenWidth, screenHeight = guiGetScreenSize(); local width, height = screenWidth - 5, screenHeight - 5; screenWidth = nil; screenHeight = nil
 
function onClientDrawFPS()
	local currentTick = getTickCount()
	local elapsedTime = currentTick - lastTick
	
	if elapsedTime >= 1000 then
		FPS = framesRendered
		lastTick = currentTick
		framesRendered = 0
	else
		framesRendered = framesRendered + 1
	end
	
	if FPS > FPSLimit then
		FPS = FPSLimit
	end
	
	if FPS == 20 then
		FPSColor = tocolor(255, 0, 0, 255)
	elseif FPS < 20 then
		FPSColor = tocolor(255, 0, 0, 255)
	elseif FPS >20 then
		FPSColor = tocolor(0, 255, 0, 255)
	end
	
	dxDrawText(tostring(FPS), 0, 0, width, height, FPSColor, 1, "bankgothic", "right")
end