addEvent ("respawnDeadPlayer", true)
function respawnDeadPlayer ( hx, hy, hz, rotation, mx, my, mz, lx, ly, lz, hospitalName )
	if ( getTeamName( getPlayerTeam( source ) ) == "Military Forces" ) then
		fadeCamera( source, false, 1.0, 0, 0, 0 )
		setTimer( setCameraMatrix, 1000, 1, source, 113.79219818115, 1837.3602294922, 51.73709869384, 114.40268707275, 1838.0476074219, 51.34362411499, 0, 70 )
		setTimer( fadeCamera, 2000, 1, source, true, 1.0, 0, 0, 0 )
		setTimer( respawnPlayer, 6000, 1, source, 277.54, 1989.42, 17.64, 268.97412109375 )
		exports.DENhelp:createNewHelpMessageForPlayer( source, "You spawned at the Military Forces base", 225, 225, 225 )
	else
		fadeCamera( source, false, 1.0, 0, 0, 0 )
		setTimer( setCameraMatrix, 1000, 1, source, mx, my, mz, lx, ly, lz )
		setTimer( fadeCamera, 2000, 1, source, true, 1.0, 0, 0, 0 )
		setTimer( respawnPlayer, 6000, 1, source, hx, hy, hz, rotation )
		exports.DENhelp:createNewHelpMessageForPlayer( source, "You respawned at the "..hospitalName, 225, 225, 225 )
	end
end
addEventHandler ("respawnDeadPlayer", root, respawnDeadPlayer)

function respawnPlayer ( thePlayer, hx, hy, hz, rotation )
	if ( isElement( thePlayer ) ) then
		fadeCamera( thePlayer, true)
		setCameraTarget( thePlayer, thePlayer )
		spawnPlayer( thePlayer, hx + math.random ( 0.1, 2 ), hy + math.random ( 0.1, 2 ), hz, rotation, getElementModel( thePlayer ), 0, 0 )
		
		local playerID = exports.server:playerID( thePlayer )
		local dataTable = exports.DENmysql:querySingle( "SELECT * FROM accounts WHERE id = ?", playerID )
		local weapons = fromJSON( dataTable.weapons )
		if ( weapons ) then
			for weapon, ammo in pairs( weapons ) do
				if not ( tonumber(weapon) == 35 ) and  not ( tonumber(weapon) == 36 ) and not ( tonumber(weapon) == 37 ) and not ( tonumber(weapon) == 38 ) and not ( tonumber(weapon) == 18 ) then
					giveWeapon( thePlayer, tonumber(weapon), tonumber(ammo) )
				end
			end
		end
			
		local playerStatus = exports.DENmysql:querySingle( "SELECT * FROM playerstats WHERE userid = ?", playerID )
		if ( playerStatus ) then
			local wepSkills = fromJSON( playerStatus.weaponskills )
			if ( wepSkills ) then
				for skillint, valueint in pairs( wepSkills ) do
					if ( tonumber(valueint) > 950 ) then
						setPedStat ( thePlayer, tonumber(skillint), 995 )
					else
						setPedStat ( thePlayer, tonumber(skillint), tonumber(valueint) )
					end
				end
			end
		end
	end
end

addEvent ("spawnTurfingPlayer", true)
function spawnTurfingPlayer ( x, y, z, rotation )
	if ( isElement( source ) ) then
		spawnPlayer( source, x + math.random ( 0.1, 2 ), y + math.random ( 0.1, 2 ), z, rotation, getElementModel( source ), 0, 0 )

		local playerID = exports.server:playerID( source )
		local dataTable = exports.DENmysql:querySingle( "SELECT * FROM accounts WHERE id = ?", playerID )
		local weapons = fromJSON( dataTable.weapons )
		if ( weapons ) then
			for weapon, ammo in pairs( weapons ) do
				if not ( tonumber(weapon) == 35 ) and  not ( tonumber(weapon) == 36 ) and not ( tonumber(weapon) == 37 ) and not ( tonumber(weapon) == 38 ) and not ( tonumber(weapon) == 18 ) then
					giveWeapon( source, tonumber(weapon), tonumber(ammo) )
				end
			end
		end
			
		local playerStatus = exports.DENmysql:querySingle( "SELECT * FROM playerstats WHERE userid = ?", playerID )
		if ( playerStatus ) then
			local wepSkills = fromJSON( playerStatus.weaponskills )
			if ( wepSkills ) then
				for skillint, valueint in pairs( wepSkills ) do
					if ( tonumber(valueint) > 950 ) then
						setPedStat ( source, tonumber(skillint), 995 )
					else
						setPedStat ( source, tonumber(skillint), tonumber(valueint) )
					end
				end
			end
		end
	end
end
addEventHandler ("spawnTurfingPlayer", root, spawnTurfingPlayer)

local spawnAFK = {}

function onSpawnMoveAFK ( thePlayer )
	spawnAFK[thePlayer] = false
	setElementDimension( thePlayer, 0 )
	unbindKey( thePlayer, "w", "down", onSpawnMoveAFK )
	unbindKey( thePlayer, "a", "down", onSpawnMoveAFK )
	unbindKey( thePlayer, "d", "down", onSpawnMoveAFK )
	unbindKey( thePlayer, "s", "down", onSpawnMoveAFK )	
	triggerClientEvent( thePlayer, "onClientShowAFK", thePlayer, false )
end

function onSetPlayerAFK( thePlayer )
	if ( isElement ( thePlayer ) ) and ( spawnAFK[thePlayer] ) and ( exports.server:isPlayerLoggedIn ( thePlayer ) ) and not ( getElementData( source, "isPlayerJailed" ) ) and not ( getElementData( source, "isPlayerArrested" ) ) then
		setElementDimension( thePlayer, math.random(100, 20000) )
		bindKey( thePlayer, "w", "down", onSpawnMoveAFK )
		triggerClientEvent( thePlayer, "onClientShowAFK", thePlayer, true )
	end
end

addEventHandler( "onPlayerSpawn", root,
	function ()
		if ( exports.server:isPlayerLoggedIn ( source ) ) and not ( getElementData( source, "isPlayerJailed" ) ) and not ( getElementData( source, "isPlayerArrested" ) )  then
			spawnAFK[source] = true
			setTimer( onSetPlayerAFK, 16000, 1, source )
			bindKey( source, "w", "down", onSpawnMoveAFK )
			bindKey( source, "a", "down", onSpawnMoveAFK )
			bindKey( source, "d", "down", onSpawnMoveAFK )
			bindKey( source, "s", "down", onSpawnMoveAFK )
		end
	end
)