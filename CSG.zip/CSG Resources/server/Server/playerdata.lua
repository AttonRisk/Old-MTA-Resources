local weaponStringTable = {}

function getWeaponString( player )
	local weapons = { }
	local hasAnyWeapons = false
	for slot = 0, 12 do
		local weapon = getPedWeapon( player, slot )
		if weapon > 0 then
			local ammo = getPedTotalAmmo( player, slot )
			if ammo > 0 then
				weapons[weapon] = ammo
				hasAnyWeapons = true
			end
		end
	end
	if hasAnyWeapons then
		return "" .. toJSON( weapons ):gsub( " ", "" ) .. ""
	else
		return "NULL"
	end
end

function getPlayerWeaponString ( player )
	if ( weaponStringTable[player] ) then
		return weaponStringTable[player]
	else
		return getWeaponString( player )
	end
end

addEvent("syncPlayerWeaponString", true)
addEventHandler("syncPlayerWeaponString", root,
	function ( theString )
		if ( weaponStringTable[source] ) then
			if ( theString ) and not ( theString == "NULL" ) then
				weaponStringTable[source] = theString
			end
		else
			if ( theString ) and not ( theString == "NULL" ) then
				weaponStringTable[source] = {}
				weaponStringTable[source] = theString
			end
		end
	end
)

function onSavePlayerData ()
	if not ( isGuestAccount(getPlayerAccount( source ) ) ) and not ( getElementData( source, "registerRulesShowing" ) ) then
		if ( getElementData( source, "joinTick" ) ) and ( getTickCount()-getElementData( source, "joinTick" ) > 5000 ) then
			local playerID = exports.server:playerID( source )
		
			if ( isPedDead ( source ) ) then
				armor = 0
			else
				armor = getPedArmor ( source )
			end
		
			local wanted = getElementData( source, "wantedPoints" )
			local x, y, z = getElementPosition ( source )
			local interior = getElementInterior ( source )
			local dimension = getElementDimension ( source )
			local rotation = getPedRotation ( source )
			local playerTeam = getPlayerTeam ( source ) 
			local money = getPlayerMoney ( source ) 
			local health = getElementHealth ( source ) 
			local armor = getPedArmor ( source )
			local playTime = getElementData( source, "playTime" )
		
			local updateDatabase = exports.DENmysql:exec( "UPDATE accounts SET money=?, health=?, armor=?, wanted=?, x=?, y=?, z=?, interior=?, dimension=?, rotation=?, weapons=?, occupation=?, team=?, playtime=? WHERE id=?"
						,money
						,health
						,armor
						,wanted
						,x
						,y
						,z
						,interior
						,dimension
						,rotation
						,getPlayerWeaponString( source )
						,getElementData( source, "Occupation" )
						,getTeamName ( playerTeam )
						,playTime
						,playerID
			)
		end
	end
end
addEventHandler ( "onPlayerQuit", root, onSavePlayerData )
addEventHandler ( "onPlayerWasted", root, onSavePlayerData )
addEventHandler ( "onPlayerLogout", root, onSavePlayerData)

addEventHandler ( "onResourceStart", getResourceRootElement(getThisResource()),
function ()
	local players = getElementsByType ( "player" ) 
	for k, player in ipairs ( players ) do 
		local account = getPlayerAccount ( player ) 
		if ( not isGuestAccount ( account ) ) then 
			triggerEvent( "onPlayerJoin", player )
			logOut ( player )
		end
	end
end
)