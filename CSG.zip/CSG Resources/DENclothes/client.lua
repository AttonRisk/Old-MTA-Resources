skinDB = {
[0] = "CJ Skin",
[1] = "The Truth",
[2] = "Maccer",
[9] = "Bfori",
[10] = "Old Woman",
[11] = "Casino croupier",
[12] = "Rich Woman",
[13] = "Street Girl",
[14] = "Bmori",
[15] = "Mr.Whittaker",
[16] = "Airport Ground Worker",
[17] = "Buisnessman",
[18] = "Beach Visitor",
[19] = "DJ", 
[20] = "Madd Dogg's Manager", 
[22] = "Bmyst", 
[23] = "BMXer", 
[24] = "Madd Dogg Bodyguard 1", 
[25] = "Madd Dogg Bodyguard 2",
[26] = "Backpacker",
[27] = "Construction Worker",
[28] = "Drug Dealer 1",
[29] = "Drug Dealer 2",
[30] = "Drug Dealer 3",
[31] = "Farm-Town inhabitant 1",
[32] = "Farm-Town inhabitant 2",
[33] = "Farm-Town inhabitant 3",
[34] = "Farm-Town inhabitant 4",
[35] = "Gardener",
[36] = "Golfer 1",
[37] = "Golfer 2",
[38] = "Hfori",
[39] = "Hfost",
[40] = "Hfyri",
[43] = "Hmori",
[44] = "Hmost",
[45] = "Hmybe",
[46] = "Hymri",
[47] = "Hmycr",
[48] = "Hmyst",
[49] = "Snakehead (Da Nang)",
[50] = "Mechanic",
[51] = "Mountain Biker 1",
[53] = "Big Fat Guy",
[54] = "Ofost",
[55] = "Ofyri",
[56] = "Ofyst",
[57] = "Omori",
[58] = "Omost",
[59] = "Omyri",
[60] = "Omyst",
[62] = "Colonel Fuhrberger",
[63] = "Prostitute 1",
[64] = "Prostitute 2",
[66] = "Pool Player 1",
[67] = "Pool Player 2",
[68] = "Priest/Preacher",
[69] = "Sbfyst",
[70] = "Scientist",
[71] = "Security Guard",
[72] = "Hippy 1",
[73] = "Hippy 2",
[75] = "Prostitute 3",
[76] = "Wfystew",
[77] = "Homeless 1",
[78] = "Homeless 2",
[79] = "Homeless 3",
[80] = "Boxer 1",
[81] = "Boxer 2",
[82] = "Black Elvis",
[83] = "White Elvis",
[84] = "Blue Elvis",
[85] = "Prostitute 4",
[87] = "Stripper",
[88] = "Wfori",
[89] = "Wfost",
[90] = "Jogger",
[91] = "Rich Woman",
[92] = "Rollerskater",
[93] = "Wfyst",
[95] = "Wmyjg",
[96] = "Wmost",
[98] = "Wmyri",
[99] = "Wmyro",
[100] = "Biker",
[101] = "Wmyst",
[102] = "Balla 1",
[103] = "Balla 2",
[104] = "Balla 4",
[105] = "Groove Street Families 1",
[106] = "Groove Street Families 2",
[107] = "Groove Street Families 3",
[108] = "Los Santos Vagos 1",
[109] = "Los Santos Vagos 2",
[110] = "Los Santos Vagos 3",
[111] = "The Russian Mafia 1",
[112] = "The Russian Mafia 2",
[113] = "The Russian Mafia 3",
[114] = "Varios Los Aztecas 1",
[115] = "Varios Los Aztecas 2",
[116] = "Varios Los Aztecas 3",
[117] = "Traid 1",
[118] = "Traid 2",
[120] = "Traid Boss",
[121] = "Da Nang Boy 1",
[122] = "Da Nang Boy 2",
[123] = "Da Nang Boy 3",
[124] = "The Mafia 1",
[125] = "The Mafia 2",
[126] = "The Mafia 3",
[127] = "The Mafia 3",
[128] = "Farm Inhabitant 1",
[129] = "Farm Inhabitant 2",
[130] = "Farm Inhabitant 3",
[131] = "Farm Inhabitant 4",
[132] = "Farm Inhabitant 5",
[133] = "Farm Inhabitant 6",
[134] = "Homeless 1",
[135] = "Homeless 2",
[136] = "Sbmytr3",
[137] = "Homeless 3",
[138] = "Beach Visitor 1",
[139] = "Beach Visitor 2",
[140] = "Beach Visitor 3",
[141] = "Buisnesswoman 1",
[142] = "Taxi Driver",
[143] = "Crack Maker 1",
[144] = "Crack Maker 2",
[145] = "Crack Maker 3",
[146] = "Crack Maker 4",
[147] = "Buisnessman",
[148] = "Buisnesswoman 2",
[150] = "Buisnesswoman 3",
[151] = "Dwfylc1",
[152] = "Wfypro",
[153] = "Construction Worker",
[154] = "Beach Visitor 4",
[155] = "Well Stacked Pizza Worker",
[156] = "Barber 1",
[157] = "Hillbilly 1",
[158] = "Farmer 1",
[159] = "Hillbilly 2",
[160] = "Hillbilly 3",
[161] = "Farmer 2",
[162] = "Hillbilly 4",
[163] = "Black Bouncer",
[164] = "White Bouncer",
[165] = "White MIB agent",
[166] = "Black MIB agent",
[167] = "Cluckin' Bell Worker",
[168] = "Hotdog/Chilli Dog Vendor",
[169] = "Sofyri",
[170] = "Somyst",
[171] = "Blackjack Dealer",
[172] = "Casino croupier",
[173] = "San Fierro Rifa 1",
[174] = "San Fierro Rifa 2",
[175] = "San Fierro Rifa 3",
[176] = "Barber 2",
[177] = "Barber 3",
[178] = "Whore",
[179] = "Ammunation Salesman",
[180] = "Tattoo Artist",
[181] = "Punk",
[182] = "Cab Driver",
[183] = "Vbmycr",
[184] = "Vhmycr",
[185] = "Sbmyri",
[186] = "Somyri",
[187] = "Somybu",
[188] = "Swmyst",
[189] = "Valet",
[190] = "Barbara Schternvart",
[191] = "Helena Wankstein",
[192] = "Michelle Cannes",
[193] = "Katie Zhan",
[194] = "Millie Perkins",
[195] = "Denise Robinson",
[196] = "Farm-Town inhabitant 5",
[197] = "Hillybilly 5",
[198] = "Farm-Town inhabitant 6",
[199] = "Farm-Town inhabitant 7",
[201] = "Farmer 3",
[202] = "Farmer 4",
[203] = "Karate Teacher 1",
[204] = "Karate Teacher 2",
[205] = "Burger Shot Cashier",
[206] = "Cab Driver",
[207] = "Prostitute 5",
[209] = "Noodle stand vendor",
[210] = "Boater",
[212] = "Homeless 4",
[213] = "Weird old man",
[214] = "Waitress (Maria Latore)",
[215] = "Sbfori",
[216] = "Swfyri",
[218] = "Sbfost",
[219] = "Rich Woman",
[220] = "Cab Driver",
[221] = "Sbmori",
[222] = "Sbmost",
[223] = "Shmycr",
[224] = "Sofori",
[225] = "Sofost",
[226] = "Sofyst",
[227] = "Buisnessman",
[228] = "Somori",
[229] = "Somost",
[230] = "Homeless 5",
[231] = "Swfori",
[232] = "Swfost",
[233] = "Swfyst",
[234] = "Cab Driver",
[235] = "Swmori",
[236] = "Swmost",
[237] = "Prostitute 6",
[238] = "Prostitute 7",
[239] = "Homeless 6",
[240] = "The D.A",
[241] = "Afro-American",
[242] = "Mexican",
[243] = "Prostitute 8",
[244] = "Stripper 1",
[245] = "Prostitute 9",
[246] = "Stripper 2",
[247] = "Biker 2",
[248] = "Biker 3",
[249] = "Pimp",
[250] = "Swmycr",
[251] = "Lifeguard",
[252] = "Valet 2",
[254] = "Biker Drug Dealer",
[256] = "Stripper 3",
[257] = "Stripper 4",
[258] = "Heckler 1",
[259] = "Heckler 2",
[260] = "Construction Worker",
[261] = "Cab Driver 1",
[262] = "Cab driver 2",
[263] = "Vwfywa2",
[264] = "Clown",
[269] = "Melvin Big Smoke Harris",
[270] = "Sean Sweet Johnson",
[271] = "Lance Ryder Wilson",
[272] = "Mafia Boss",
[290] = "Ken Rosenberg",
[291] = "Kent Paul",
[292] = "Cesar Vialpando",
[293] = "Jeffery OG Loc Martin/Cross",
[294] = "Wu Zi Mu - Woozie",
[295] = "Michael Toreno",
[296] = "Jizzy B",
[297] = "Mad Dogg",
[298] = "Catalina",
[299] = "Claude Speedfrom GTA3",
}

skinPremiumDB = {
[41] = "Smooth guy",
[52] = "Julian ",
[94] = "Guy in suit",
}

local clothesMarkers = { 
-- LS shops
[1] = {207.58, -101.21, 1005.25, 15, 5, 2.3263854980469},
[2] = {204.23, -160.03, 1000.52, 14, 12, 0.53009033203125},
[3] = {161.38, -84.08, 1001.8, 18, 1, 1.8814392089844},
[4] = {207.11, -129.94, 1003.5, 3, 13, 1.8814392089844},
-- SF shops
[5] = {204.01, -43.9, 1001.8, 1, 1, 2.8921813964844},
[6] = {207.9, -101.35, 1005.25, 15, 6, 357.28359985352},
[7] = {161.38, -84, 1001.8, 18, 2, 356.77270507812},
[8] = {207.33, -10.34, 1001.21, 5, 10, 356.77270507812},
-- LV shops
[9] = {207.83, -100.99, 1005.25, 15, 7, 1.3266296386719},
[10] = {161.51, -84.46, 1001.8, 18, 3, 1.1069030761719},
[11] = {207.64, -100.76, 1005.25, 15, 8, 3.4195556640625},
[12] = {161.35, -84.88, 1001.8, 18, 4, 1.1069030761719},
[13] = {203.96, -44.04, 1001.8, 1, 2, 2.4195556640625}
} 

function createClothesWindow()

	ClothesWindow = guiCreateWindow(337,88,289,518,"CSG ~ Clothes Store",false)
	ClothesGrid = guiCreateGridList(9,24,271,423,false,ClothesWindow)
	guiGridListSetSelectionMode(ClothesGrid,0)
	local column1 = guiGridListAddColumn( ClothesGrid, "Skin Name:", 0.69 )
	local column2 = guiGridListAddColumn( ClothesGrid, "ID:", 0.2 )
	ClothesButton1 = guiCreateButton(9,452,133,29,"Buy skin ($250)",false,ClothesWindow)
	ClothesButton2 = guiCreateButton(146,452,134,29,"Buy nothing",false,ClothesWindow)
	ClothesButton3 = guiCreateButton(9,486,271,23,"Premium clothes (Premium members only!)",false,ClothesWindow)
	addEventHandler("onClientGUIClick", ClothesButton2, function() guiSetVisible(ClothesWindow, false) showCursor(false) setElementModel ( localPlayer, tonumber( getElementData( localPlayer, "clothesSkin" )), true ) end, false)
	addEventHandler ( "onClientGUIClick", ClothesGrid, selectSkin )
	addEventHandler ( "onClientGUIClick", ClothesButton1, buySkin )
	addEventHandler ( "onClientGUIClick", ClothesButton3, showVipClothesWindow )
	
	guiWindowSetMovable (ClothesWindow, true)
	guiWindowSetSizable (ClothesWindow, false)
	guiSetVisible (ClothesWindow, false)
	
	local screenW,screenH=guiGetScreenSize()
	local windowW,windowH=guiGetSize(ClothesWindow,false)
	local x,y = (screenW-windowW)/1,(screenH-windowH)/1
	guiSetPosition(ClothesWindow,x +3,y,false)
	
	vipClothesWindow = guiCreateWindow(490,448,173,253,"CSG ~ Premium Skins",false)
	vipClothesGrid = guiCreateGridList(9,26,154,165,false,vipClothesWindow)
	local column3 = guiGridListAddColumn( vipClothesGrid, "Skin Name:", 0.80 )
	guiGridListSetSelectionMode(vipClothesGrid,0)
	vipClothesButon1 = guiCreateButton(9,196,155,22,"Set skin (FREE)",false,vipClothesWindow)
	vipClothesButon2 = guiCreateButton(9,223,155,22,"Close window",false,vipClothesWindow)
	
	addEventHandler ( "onClientGUIClick", vipClothesButon1, onClientSetPremiumSkin )
	addEventHandler ( "onClientGUIClick", vipClothesButon2, function () guiSetVisible(vipClothesWindow, false) guiSetVisible(ClothesWindow, true) setElementModel ( localPlayer, tonumber( getElementData( localPlayer, "clothesSkin" )) ) end )
	addEventHandler ( "onClientGUIClick", vipClothesGrid, selectPremiumSkin )
	
	guiWindowSetMovable (vipClothesWindow, true)
	guiWindowSetSizable (vipClothesWindow, false)
	guiSetVisible (vipClothesWindow, false)
	
	local screenW,screenH=guiGetScreenSize()
	local windowW,windowH=guiGetSize(vipClothesWindow,false)
	local x,y = (screenW-windowW)/1,(screenH-windowH)/1
	guiSetPosition(vipClothesWindow,x +3,y,false)

	for i=0,299 do
		local skinname = skinDB[i]
		if ( skinname ) then
			local row = guiGridListAddRow ( ClothesGrid )
			guiGridListSetItemText ( ClothesGrid, row, 1, skinname, false, false )
			guiGridListSetItemText ( ClothesGrid, row, 2, i, false, true )
		end
	end	
	
	for i=1,299 do
		local skinname = skinPremiumDB[i]
		if ( skinname ) then
			local row = guiGridListAddRow ( vipClothesGrid )
			guiGridListSetItemText ( vipClothesGrid, row, 1, skinname, false, false )
			guiGridListSetItemData ( vipClothesGrid, row, 1, i )
		end
	end
end

function selectSkin ()     
	local skinID = guiGridListGetItemText ( ClothesGrid, guiGridListGetSelectedItem ( ClothesGrid ), 2 )	   
	setElementModel ( localPlayer, skinID )
end

function selectPremiumSkin ()
	local selectedRow, selectedColumn = guiGridListGetSelectedItem(vipClothesGrid)
    local skinID = guiGridListGetItemData(vipClothesGrid, selectedRow, selectedColumn)
	if ( skinID ) or ( skinID == "" ) or ( skinID == " ") then
		setElementModel ( localPlayer, skinID )
	end
end

function showVipClothesWindow ()
	if ( guiGetEnabled ( ClothesButton3 ) ) then
		guiSetVisible (ClothesWindow, false)
		guiSetVisible (vipClothesWindow, true)
	end
end

function onClientSetPremiumSkin ()
	local selectedRow, selectedColumn = guiGridListGetSelectedItem(vipClothesGrid)
    local skinID = guiGridListGetItemData(vipClothesGrid, selectedRow, selectedColumn)
	if not ( skinID ) or ( skinID == "" ) or ( skinID == " ") then
		exports.DENhelp:createNewHelpMessage("You didn't select a skin!", 200, 0, 0)
	else
		triggerServerEvent("onPlayerSetPremiumSkin", localPlayer, skinID)
		guiSetVisible (vipClothesWindow, false)
		showCursor(false)
	end
end

function buySkin () 
	local costs = 250
	local money = getPlayerMoney(localPlayer)
	if (money < costs) then
		exports.DENhelp:createNewHelpMessage("You dont have enough money for new clothes!", 200, 0, 0)
	else     
		local finalSkinID = guiGridListGetItemText ( ClothesGrid, guiGridListGetSelectedItem ( ClothesGrid ), 2, 1 )
		triggerServerEvent("buySkin", localPlayer, finalSkinID)
	end
end

addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), 
	function ()
		createClothesWindow()
	end
)

function clothesMarkerHit (hitElement, dimension)
if dimension then
	if hitElement == localPlayer then
		local x, y, z = getElementPosition ( localPlayer )
		guiSetVisible(ClothesWindow,true)
		showCursor(true,true)
		if getElementData(localPlayer, "isPlayerPremium") then guiSetEnabled ( ClothesButton3, true) else guiSetEnabled ( ClothesButton3, false) end
		setElementData ( localPlayer, "clothesSkin", getElementModel ( localPlayer ), true )
		end
	end
end

for ID in pairs(clothesMarkers) do 
	local x, y, z = clothesMarkers[ID][1], clothesMarkers[ID][2], clothesMarkers[ID][3] 
	local interior = clothesMarkers[ID][4] 
	local dimension = clothesMarkers[ID][5]
	local clothesShopMarkers = createMarker(x,y,z -1,"cylinder",2,200,0,0,150) 
	setElementInterior(clothesShopMarkers, interior)
	setElementDimension ( clothesShopMarkers, dimension ) 
	addEventHandler("onClientMarkerHit", clothesShopMarkers, clothesMarkerHit)
end

addEvent( "closeScreen", true )
function closeScreen ()
    guiSetVisible (ClothesWindow, false)
    showCursor(false,false)
end
addEventHandler( "closeScreen", root, closeScreen )

addEvent( "closeScreen2", true )
function closeScreen2 ()
    setElementModel ( localPlayer, tonumber( getElementData( localPlayer, "clothesSkin" )))
    guiSetVisible (ClothesWindow, false)
    showCursor(false,false)
end
addEventHandler( "closeScreen2", root, closeScreen2 )

addEvent( "resetSkin", true )
function resetSkin ()
    setElementModel ( source, tonumber( getElementData( source, "clothesSkin" )) )
end
addEventHandler( "resetSkin", root, resetSkin )