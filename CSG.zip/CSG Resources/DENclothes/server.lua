addEvent( "buySkin", true )
function buySkin ( skinID )
	local playerTeam = getPlayerTeam ( source )
	local teamFromName = getTeamName ( playerTeam ) 

	local playerID = exports.server:playerID(source)
	local MySQL = exports.DENmysql:exec( "UPDATE accounts SET skin=? WHERE id=?", skinID, playerID)
	
	if ( tonumber( skinID ) == 0 ) then
		local CJTable = exports.DENmysql:querySingle( "SELECT * FROM accounts WHERE id = ?", playerID )
		local CJCLOTTable = fromJSON( tostring( CJTable.cjskin ) )
	
		if CJCLOTTable then
			for theType, index in pairs( CJCLOTTable ) do
				local texture, model = getClothesByTypeIndex ( theType, index )
				addPedClothes ( source, texture, model, theType )
			end
		end
	end
	
	if teamFromName == "Criminals" or teamFromName == "Unemployed" or teamFromName == "Unoccupied" then		
		local takemoney = takePlayerMoney ( source, 250 )
		setElementModel ( source, skinID )
		exports.DENhelp:createNewHelpMessageForPlayer(source, "New skin is set! Price: $250", 0, 200, 0)
		triggerClientEvent ( source, "closeScreen", source )
	else
		local takemoney = takePlayerMoney ( source, 250 )
		exports.DENhelp:createNewHelpMessageForPlayer(source, "New skin bought, but not set due job clothes!", 0, 200, 0)
		triggerClientEvent ( source, "closeScreen2", source )
	end
end
addEventHandler( "buySkin", root, buySkin )

addEvent( "onPlayerSetPremiumSkin", true )
function onPlayerSetPremiumSkin ( skinID )	
	local playerTeam = getPlayerTeam ( source )
	local teamFromName = getTeamName ( playerTeam ) 
	
	if teamFromName == "Criminals" or teamFromName == "Unemployed" or teamFromName == "Unoccupied" then
		setElementModel ( source, skinID )
		local playerID = exports.server:playerID(source)
		local MySQL = exports.DENmysql:exec( "UPDATE accounts SET skin=? WHERE id=?", skinID, playerID)
		exports.DENhelp:createNewHelpMessageForPlayer(source, "Your premium skin is set!", 0, 200, 0)
	else
		local playerID = exports.server:playerID(source)
		local MySQL = exports.DENmysql:exec( "UPDATE accounts SET skin=? WHERE id=?", skinID, playerID)
		exports.DENhelp:createNewHelpMessageForPlayer(source, "Your premium skin is set, but not active due job clothes!", 0, 200, 0)
		triggerClientEvent( source, "resetSkin", source )
	end
end
addEventHandler( "onPlayerSetPremiumSkin", root, onPlayerSetPremiumSkin )