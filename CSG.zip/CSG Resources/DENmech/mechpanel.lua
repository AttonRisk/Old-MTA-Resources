-- Medic panel
mechPanelWindow = guiCreateWindow(409,182,441,459,"CSG ~ Mechanic Panel",false)
mechPanelGrid = guiCreateGridList(9,23,423,249,false,mechPanelWindow)
guiGridListSetSelectionMode(mechPanelGrid,0)

local column1 = guiGridListAddColumn(mechPanelGrid," Vehiclename and owner:",0.47)
local column2 = guiGridListAddColumn(mechPanelGrid,"Health:",0.10)
local column3 = guiGridListAddColumn(mechPanelGrid,"Location:",0.38)

mechPanelButton1 = guiCreateButton(10,277,134,33,"Mark vehicle",false,mechPanelWindow)
mechPanelButton2 = guiCreateButton(148,277,137,33,"Mark all vehicles",false,mechPanelWindow)
mechPanelButton3 = guiCreateButton(290,277,141,33,"Delete blips",false,mechPanelWindow)

mechPanelRadio1 = guiCreateRadioButton(14,320,361,22,"Show all damaged vehicles",false,mechPanelWindow)
mechPanelRadio2 = guiCreateRadioButton(14,346,361,22,"Show only vehicles with less then 80% health",false,mechPanelWindow)
mechPanelRadio3 = guiCreateRadioButton(14,372,361,22,"Show only vehicles with less then 60% health",false,mechPanelWindow)
mechPanelRadio4 = guiCreateRadioButton(14,398,361,22,"Show only vehicles with less then 40% health",false,mechPanelWindow)
mechPanelRadio5 = guiCreateRadioButton(14,424,361,22,"Show only vehicles with less then 20% health",false,mechPanelWindow)

guiRadioButtonSetSelected(mechPanelRadio1,true)

local screenW,screenH=guiGetScreenSize()
local windowW,windowH=guiGetSize(mechPanelWindow,false)
local x,y = (screenW-windowW)/2,(screenH-windowH)/2
guiSetPosition(mechPanelWindow,x,y,false)

guiWindowSetMovable (mechPanelWindow, true)
guiWindowSetSizable (mechPanelWindow, false)
guiSetVisible (mechPanelWindow, false)

function showMechPanel ()
	if ( getElementData ( localPlayer, "isPlayerLoggedin" ) ) and (getTeamName(getPlayerTeam(localPlayer)) == "Civilian Workers") and (getElementData(localPlayer, "Occupation") == "Mechanic") then
		if guiGetVisible(mechPanelWindow) then
			guiSetVisible(mechPanelWindow, false)
			showCursor(false,false)
		else
			guiSetVisible(mechPanelWindow,true)
			loadInjuredVehicles()
			showCursor(true,true)
		end
	end
end
bindKey ( "F5", "down", showMechPanel )

function onUserChangedMechPanelSetting ()
	if ( source == mechPanelRadio1 ) or ( source == mechPanelRadio2 ) or ( source == mechPanelRadio3 ) or ( source == mechPanelRadio4 ) or ( source == mechPanelRadio5 ) then
		loadInjuredVehicles()
	end
end
addEventHandler ( "onClientGUIClick", root, onUserChangedMechPanelSetting )

local doAutoUpdateBlips = false

setTimer ( function ()
	if ( doAutoUpdateBlips ) then
		onMarkAllVehicles()
	end
end, 10000, 0)

function onMarkSelectedVehicle ()
	local theVehicle = guiGridListGetItemData(mechPanelGrid, guiGridListGetSelectedItem ( mechPanelGrid ), 1)
	if not ( isElement( theVehicle ) ) then
		outputChatBox("You didn't select a player!", 225 ,0 ,0)
	else
		if ( isElement( theVehicle ) ) then
			local attachedElements = getAttachedElements ( theVehicle )
			if ( attachedElements ) then
				for ElementKey, ElementValue in ipairs ( attachedElements ) do
					if ( getElementType ( ElementValue ) == "blip" ) then
						if ( getBlipIcon ( ElementValue ) == 22 ) then
							return
						end
					end
				end
			end
			local theBlip = createBlipAttachedTo ( theVehicle, 22 )
		end
	end
end
addEventHandler("onClientGUIClick", mechPanelButton1, onMarkSelectedVehicle, false)

function onMarkAllVehicles ()
	local healthSetting = 100
	if ( guiRadioButtonGetSelected( mechPanelRadio1 ) ) then healthSetting = 100 end
	if ( guiRadioButtonGetSelected( mechPanelRadio2 ) ) then healthSetting = 80  end
	if ( guiRadioButtonGetSelected( mechPanelRadio3 ) ) then healthSetting = 60  end
	if ( guiRadioButtonGetSelected( mechPanelRadio4 ) ) then healthSetting = 40  end
	if ( guiRadioButtonGetSelected( mechPanelRadio5 ) ) then healthSetting = 20  end
	
	onRemoveAllBlips()
	
	for id, vehicle in ipairs(getElementsByType("vehicle")) do
		if ( math.floor(getElementHealth( vehicle ) / 10 ) < math.floor(tonumber(healthSetting) )) then
			if getElementData(vehicle, "vehicleOwner") then
				local theBlip = createBlipAttachedTo ( vehicle, 22 )
				doAutoUpdateBlips = true
			end
		end
	end
end
addEventHandler("onClientGUIClick", mechPanelButton2, onMarkAllVehicles, false)

function onRemoveAllBlips ()
	for id, vehicle in ipairs(getElementsByType("vehicle")) do
		local attachedElements = getAttachedElements ( vehicle )
		if ( attachedElements ) then 
			for ElementKey, ElementValue in ipairs ( attachedElements ) do
				if ( getElementType ( ElementValue ) == "blip" ) then
					if ( getBlipIcon ( ElementValue ) == 22 ) then
						destroyElement( ElementValue )
						doAutoUpdateBlips = false
					end
				end
			end
		end
	end
end
addEventHandler("onClientGUIClick", mechPanelButton3, onRemoveAllBlips, false)

function loadInjuredVehicles()
	local healthSetting = 100
	if ( guiRadioButtonGetSelected( mechPanelRadio1 ) ) then healthSetting = 100 end
	if ( guiRadioButtonGetSelected( mechPanelRadio2 ) ) then healthSetting = 80  end
	if ( guiRadioButtonGetSelected( mechPanelRadio3 ) ) then healthSetting = 60  end
	if ( guiRadioButtonGetSelected( mechPanelRadio4 ) ) then healthSetting = 40  end
	if ( guiRadioButtonGetSelected( mechPanelRadio5 ) ) then healthSetting = 20  end
	
	local vehicleFound = false
	
	guiGridListClear ( mechPanelGrid )
	for id, vehicle in ipairs(getElementsByType("vehicle")) do
		if ( math.floor(getElementHealth( vehicle ) / 10) < tonumber(healthSetting) ) then
			if getElementData(vehicle, "vehicleOwner") then
 				vehicleFound = true
				local vehicleOwner = getElementData(vehicle, "vehicleOwner")
				local x, y, z = getElementPosition ( vehicle )
				local row = guiGridListAddRow ( mechPanelGrid )
				guiGridListSetItemText ( mechPanelGrid, row, 1, getVehicleName ( vehicle ).." / "..getPlayerName(vehicleOwner), false, false )
				guiGridListSetItemText ( mechPanelGrid, row, 2, "  "..math.floor(getElementHealth ( vehicle )  / 10).."%", false, false )
				guiGridListSetItemText ( mechPanelGrid, row, 3, "  "..getZoneName ( x, y, z ).." ("..calculateVehicleZone( x, y, z )..")", false, false )
				guiGridListSetItemData ( mechPanelGrid, row, 1, vehicle)
				
				if ( math.floor(getElementHealth ( vehicle ) / 10 ) < 30 ) then
					guiGridListSetItemColor ( mechPanelGrid, row, 2, 225, 0, 0 )
				elseif ( math.floor(getElementHealth ( vehicle ) / 10 ) > 290 ) and  ( math.floor(getElementHealth ( vehicle ) / 10 ) < 70 ) then
					guiGridListSetItemColor ( mechPanelGrid, row, 2, 225, 165, 0 )
				else
					guiGridListSetItemColor ( mechPanelGrid, row, 2, 0, 225, 0 )
				end
			end
		end
	end
	
	if not ( vehicleFound ) then
		local row = guiGridListAddRow ( mechPanelGrid )
		guiGridListSetItemText ( mechPanelGrid, row, 1, "No vehicles found", false, false )
		guiGridListSetItemText ( mechPanelGrid, row, 2, "  N/A", false, false )
		guiGridListSetItemText ( mechPanelGrid, row, 3, "  N/A", false, false )
	end
end

addEvent( "onClientPlayerTeamChange" )
addEventHandler ( "onClientPlayerTeamChange", root,
function ()
	if ( source == localPlayer ) then
		onRemoveAllBlips ()
	end
end
)

function calculateVehicleZone( x, y, z )
	if x < -920 then
		return "SF"
	elseif y < 420 then
		return "LS"
	else
		return "LV"
	end
end