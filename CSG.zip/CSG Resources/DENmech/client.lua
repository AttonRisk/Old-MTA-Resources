mechanicFixWindow = guiCreateWindow(557,364,281,214,"CSG ~ Mechanic",false)
mechanicFixLabel = guiCreateLabel(8,27,266,18,"Dennis want to fix you vehicle",false,mechanicFixWindow)
guiLabelSetColor(mechanicFixLabel,0,200,0)
guiLabelSetHorizontalAlign(mechanicFixLabel,"center",false)
guiSetFont(mechanicFixLabel,"default-bold-small")
mechanicFixOption1 = guiCreateRadioButton(11,55,132,21,"Buy 5 nitro ($1000)",false,mechanicFixWindow)
mechanicFixOption2 = guiCreateRadioButton(11,82,143,24,"Buy hydraulics ($1000)",false,mechanicFixWindow)
mechanicFixOption3 = guiCreateRadioButton(11,111,161,24,"Fix vehicle wheels ($150)",false,mechanicFixWindow)
mechanicFixOption4 = guiCreateRadioButton(12,138,260,24,"Complete vehicle repair (without upgrades)",false,mechanicFixWindow)
mechanicFixBuyButton = guiCreateButton(9,175,130,30,"Buy selected",false,mechanicFixWindow)
mechanicFixCloseButton = guiCreateButton(143,175,129,30,"No Thanks",false,mechanicFixWindow)

local screenW,screenH=guiGetScreenSize()
local windowW,windowH=guiGetSize(mechanicFixWindow,false)
local x,y = (screenW-windowW)/2,(screenH-windowH)/2
guiSetPosition(mechanicFixWindow,x,y,false)

guiWindowSetMovable (mechanicFixWindow, true)
guiWindowSetSizable (mechanicFixWindow, false)
guiSetVisible (mechanicFixWindow, false)

addEventHandler( "onClientResourceStart", getResourceRootElement(getThisResource()),
    function ( resourceName )
        triggerServerEvent("bindMechanicAimFunction", localPlayer)
    end
);

bindKey ("x", "down", function()
	if getElementData(localPlayer, "Occupation") == "Mechanic" then
		if isCursorShowing() == false then
			setElementData(localPlayer, "mechanicCursor", true)
			showCursor ( true, true )
		else
			setElementData(localPlayer, "mechanicCursor", false)
			showCursor ( false, false )
		end
	end
end)

function onMechanicShowGUI (theMechanic, vehicle)
guiSetText(mechanicFixLabel, "" .. getPlayerName(theMechanic) .. " want to fix you vehicle")
	guiSetVisible( mechanicFixWindow, true )
		guiBringToFront( mechanicFixWindow )
			showCursor ( true, true )
				thePlayerMechanic = theMechanic
				theVehicle = vehicle
end
addEvent("onMechanicShowGUI", true)
addEventHandler("onMechanicShowGUI", getRootElement(), onMechanicShowGUI)

function onMechanicReject ()
	guiSetVisible( mechanicFixWindow, false )
		showCursor ( false, false )
			triggerServerEvent("rejectMechanicRequest", localPlayer, thePlayerMechanic)
end
addEventHandler("onClientGUIClick", mechanicFixCloseButton, onMechanicReject, false)

function onMechanicAccept ()
	if(guiRadioButtonGetSelected(mechanicFixOption1))then
	-- Nitro option
	triggerServerEvent("doVehicleRepair", localPlayer, "option1", thePlayerMechanic, theVehicle)
	closeWindow()
	elseif(guiRadioButtonGetSelected(mechanicFixOption2))then
	-- Hydraulics option
	triggerServerEvent("doVehicleRepair", localPlayer, "option2", thePlayerMechanic, theVehicle)
	closeWindow()
	elseif(guiRadioButtonGetSelected(mechanicFixOption3))then
	-- Fixing wheels option
	triggerServerEvent("doVehicleRepair", localPlayer, "option3", thePlayerMechanic, theVehicle)
	closeWindow()
	elseif(guiRadioButtonGetSelected(mechanicFixOption4))then
	-- Complete vehicle repair option
	triggerServerEvent("doVehicleRepair", localPlayer, "option4", thePlayerMechanic, theVehicle)
	closeWindow()
	end
end
addEventHandler("onClientGUIClick", mechanicFixBuyButton, onMechanicAccept, false)

function closeWindow ()
	guiSetVisible( mechanicFixWindow, false )
		showCursor ( false, false )
end
