function onMehanicVehicleClicked (player)
local target = getPlayerTarget (player)
	if getPedWeapon(player) == 0 and not isPedInVehicle(player) and getElementData(player, "Occupation") == "Mechanic" then
		if isElement (target) and getElementType (target) == "vehicle" then
			local px, py, pz = getElementPosition(player)
			local vx, vy, vz = getElementPosition(target)
			if getDistanceBetweenPoints2D ( px, py, vx, vy ) < 3 then
				if getElementData(target, "vehicleOwner") then
					local sx, sy, sz = getElementVelocity(target)  
					local speed = (sx^2 + sy^2 + sz^2)^(0.5)*100
					if speed < 12 then
						local vehicleOwner = getElementData(target, "vehicleOwner") -- Elementdata of the vehicle owner
						triggerClientEvent(vehicleOwner, "onMechanicShowGUI", vehicleOwner, player, target)
						exports.DENhelp:createNewHelpMessageForPlayer(player, "Waiting for customer response...", 0, 200, 0)
					end
				end
			end
		end
	end
end

function bindMechanicAimFunction()
	bindKey (source,"aim_weapon","down", onMehanicVehicleClicked)
end
addEvent("bindMechanicAimFunction", true)
addEventHandler ("onPlayerLogin",getRootElement(),bindMechanicAimFunction)
addEventHandler("bindMechanicAimFunction", root, bindMechanicAimFunction)

function rejectMechanicRequest (theMechanic)
	exports.DENhelp:createNewHelpMessageForPlayer(theMechanic, " " .. getPlayerName(source) .. " dont want a car fix.", 200, 0, 0)
end
addEvent("rejectMechanicRequest", true)
addEventHandler("rejectMechanicRequest", root, rejectMechanicRequest)

function doVehicleRepair (option, mechanic, vehicle)
	if (option == "option1") then
	-- Nitro option
		if ( source == mechanic ) then
			if getPlayerMoney(source) > 600 then
				addVehicleUpgrade ( vehicle, 1008 )
				takePlayerMoney ( source, 600 )
				setVehicleDamageProof ( vehicle, false )
				outputChatBox("You bought nitro for your own vehicle, you paid 60% of the price. ($600)", source, 0, 225, 0)
			else
				outputChatBox("You don't have enough money for this", source, 225, 0, 0, 0)
			end
		else
			if getPlayerMoney(source) > 1008 then
				addVehicleUpgrade ( vehicle, 1008 )
				takePlayerMoney ( source, 1000 )
				givePlayerMoney ( mechanic, 1000 )
				setVehicleDamageProof ( vehicle, false )
				outputChatBox("You bough 5 nitros for your vehicle you paid $1000 by " .. getPlayerName ( mechanic ) .. "", source, 0, 225, 0)
				outputChatBox("".. getPlayerName(source) .." bought nitro for his vehicle, you earned $1000", mechanic, 0, 225, 0)
			else
				outputChatBox("You don't have enough money for this", source, 225, 0, 0, 0)
			end
		end
	elseif (option == "option2") then
	-- Hydraulics option
		if ( source == mechanic ) then
			if getPlayerMoney(source) > 600 then
				addVehicleUpgrade ( vehicle, 1087  )
				takePlayerMoney ( source, 600 )
				setVehicleDamageProof ( vehicle, false )
				outputChatBox("You bought hydraulics for your own vehicle, you paid 60% of the price. ($600)", source, 0, 225, 0)
			else
				outputChatBox("You don't have enough money for this", source, 225, 0, 0, 0)
			end
		else
			if getPlayerMoney(source) > 1000 then
				addVehicleUpgrade ( vehicle, 1087  )
				takePlayerMoney ( source, 1000 )
				givePlayerMoney ( mechanic, 1000 )
				setVehicleDamageProof ( vehicle, false )
				outputChatBox("You bought hydraulics for your vehicle you paid $1000 by " .. getPlayerName ( mechanic ) .. "", source, 0, 225, 0)
				outputChatBox("".. getPlayerName(source) .." bought hydraulics for his vehicle, you earned $1000", mechanic, 0, 225, 0)
			else
				outputChatBox("You don't have enough money for this", source, 225, 0, 0, 0)
			end
		end
	elseif (option == "option3") then
	-- Fixing wheels option
	local wheel1, wheel2, wheel3, wheel4 = getVehicleWheelStates ( vehicle )
	if ( wheel1 == 1 ) or ( wheel2 == 1 ) or ( wheel3 == 1 ) or ( wheel4 == 1 ) then
		if ( source == mechanic ) then
			if getPlayerMoney(source) > 75 then
				setVehicleWheelStates ( vehicle, 0, 0, 0, 0 )
				takePlayerMoney ( source, 75 )
				setVehicleDamageProof ( vehicle, false )
				outputChatBox("You repaired the wheels of your vehicle, you paid 50% of the price. ($75)", source, 0, 225, 0)
			else
				outputChatBox("You don't have enough money for this", source, 225, 0, 0, 0)
			end
		else
			if getPlayerMoney(source) > 150 then
				setVehicleWheelStates ( vehicle, 0, 0, 0, 0 )
				takePlayerMoney ( source, 150 )
				givePlayerMoney ( mechanic, 150 )
				setVehicleDamageProof ( vehicle, false )
				outputChatBox("Your vehicle wheels are repaired for $150 by " .. getPlayerName ( mechanic ) .. "", source, 0, 225, 0)
				outputChatBox("".. getPlayerName(source) .." bought new wheels for his vehicle, you earned $150", mechanic, 0, 225, 0)
			else
				outputChatBox("You don't have enough money for this", source, 225, 0, 0, 0)
			end
		end
	else
		outputChatBox("You're vehicle wheels are not broken, repair not needed", source, 225, 0, 0)
	end
	elseif (option == "option4") then
	-- Complete vehicle repair option
		if (getElementHealth(vehicle) < 999) then
			local vehicleFixPrice = math.floor(1000-getElementHealth(vehicle))
			if ( source == mechanic ) then
				local moneySaving = ( 60 / 100 * vehicleFixPrice )
				local totalPrice = ( vehicleFixPrice - moneySaving )
					if getPlayerMoney(source) > totalPrice then
						fixVehicle ( vehicle )
						local rx, ry, rz = getVehicleRotation ( vehicle )
							if ( rx > 110 ) and ( rx < 250 ) then
							local x, y, z = getElementPosition ( vehicle )
							setVehicleRotation ( vehicle, rx + 180, ry, rz )
							setElementPosition ( vehicle, x, y, z + 2 )
						end
						setElementFrozen ( vehicle, false )
						setVehicleDamageProof ( vehicle, false )
						takePlayerMoney ( source, math.floor(totalPrice) )
						outputChatBox("You repaired your vehicle, you paid 60% of the price. ($".. math.floor(totalPrice) ..")", source, 0, 225, 0)
					else
						outputChatBox("You don't have enough money for this", source, 225, 0, 0, 0)
					end
			else
				if getPlayerMoney(source) > vehicleFixPrice then
					fixVehicle ( vehicle )
					local rx, ry, rz = getVehicleRotation ( vehicle )
						if ( rx > 110 ) and ( rx < 250 ) then
						local x, y, z = getElementPosition ( vehicle )
						setVehicleRotation ( vehicle, rx + 180, ry, rz )
						setElementPosition ( vehicle, x, y, z + 2 )
					end
					setElementFrozen ( vehicle, false )
					takePlayerMoney ( source, vehicleFixPrice )
					givePlayerMoney ( mechanic, vehicleFixPrice )
					setVehicleDamageProof ( vehicle, false )
					outputChatBox("Your vehicle is repaired for $".. vehicleFixPrice .." by " .. getPlayerName ( mechanic ) .. "", source, 0, 225, 0)
					outputChatBox("You repaired ".. getPlayerName(source) .."'s vehicle, you earned $".. vehicleFixPrice .."", mechanic, 0, 225, 0)
				else
					outputChatBox("You don't have enough money for this", source, 225, 0, 0, 0)
				end
			end
		else
			outputChatBox("This vehicle doesn't need a repair!", mechanic, 225, 0, 0)
		end
	end
end
addEvent("doVehicleRepair", true)
addEventHandler("doVehicleRepair", root, doVehicleRepair)