local theGateColID = {}
local gateMarkers = getGatesTable ()
local lawOpenedGate = {}

function gateOpen(hitElement, mathchingDimension)
	if (theGateColID[source]) then
		local gateID = theGateColID[source]
		if (getElementType(hitElement) == "player") and ( mathchingDimension ) then
			local x, y, z = getElementPosition( hitElement )
			if (z < gateMarkers[gateID][4]+5 and z > gateMarkers[gateID][4]-5) then
				if not (getPedOccupiedVehicle(hitElement)) then
					if ( getPlayerTeam( hitElement ) ) and ( getTeamName( getPlayerTeam( hitElement ) ) == "SWAT" ) or ( getTeamName( getPlayerTeam( hitElement ) ) == "Military Forces" ) or ( getTeamName( getPlayerTeam( hitElement ) ) == "Department of Defense" ) then
						if ( lawOpenedGate[account] ) and ( getTickCount()-lawOpenedGate[account] < 300000 ) then
							exports.DENhelp:createNewHelpMessageForPlayer(source, "You're not allowed to open a base gate at this time. Bye.", 225, 0, 0)
						else
							moveObject( gateID, gateMarkers[ID][11], gateMarkers[ID][8], gateMarkers[ID][9], gateMarkers[ID][10] )
							local account = exports.server:getPlayerAccountId(source)
							lawOpenedGate[account] = getTickCount()
						end
					end
					if ((exports.server:getPlayerGroupName(source)) and (exports.server:getPlayerGroupName(source) == intMarkers[markerID][12])) or (( getPlayerTeam( hitElement ) ) and ( getTeamName( getPlayerTeam( hitElement ) ) == "Staff" )) then
						moveObject( gateID, gateMarkers[ID][11], gateMarkers[ID][8], gateMarkers[ID][9], gateMarkers[ID][10] )
					end
				end
			end
		end
	end
end

for ID=1,#gates do
	local object, x, y, z, int, dim = gateMarkers[ID][1], gateMarkers[ID][2], gateMarkers[ID][3], gateMarkers[ID][4], gateMarkers[ID][5], gateMarkers[ID][6]
    local theGateCol = createColSphere(x, y, z, gateMarkers[ID][12])
	local theGate = createObject (object, z, y, z, gateMarkers[ID][5], gateMarkers[ID][6], gateMarkers[ID][7])
    theGateColID[theGate] = ID
	addEventHandler("onClientColShapeHit", theGateCol, gateOpen)
	addEventHandler("onClientColShapeLeave", theGateCol, gateClose)
end