local theMarkerID = {}
local intMarkers = getInteriorMarkers () 

function intWarps(hitElement, mathchingDimension)
	if (theMarkerID[source]) then
		local markerID = theMarkerID[source]
		if (getElementType(hitElement) == "player") and ( mathchingDimension ) then
			local x, y, z = getElementPosition( hitElement )
			if (z < intMarkers[markerID][3]+5 and z > intMarkers[markerID][3]-5) then
				if not (getPedOccupiedVehicle(hitElement)) then
					if (( getPlayerTeam( hitElement ) ) and ( getTeamName( getPlayerTeam( hitElement ) ) == "SWAT" ) or ( getTeamName( getPlayerTeam( hitElement ) ) == "Military Forces" ) or ( getTeamName( getPlayerTeam( hitElement ) ) == "Department of Defense" ) or ( getTeamName( getPlayerTeam( hitElement ) ) == "Staff" ) or ( getTeamName( getPlayerTeam( hitElement ) ) == intMarkers[markerID][13] )) or (exports.server:getPlayerGroupName(source)) and (exports.server:getPlayerGroupName(source) == intMarkers[markerID][12]) then
						setElementPosition(hitElement, intMarkers[markerID][6], intMarkers[markerID][7], intMarkers[markerID][8])
						setPedRotation(hitElement, intMarkers[markerID][9])
						setElementInterior(hitElement, intMarkers[markerID][10], intMarkers[markerID][6], intMarkers[markerID][7], intMarkers[markerID][8] )
						setElementDimension(hitElement, intMarkers[markerID][11])
					end
				end
			end
		end
	end
end



for ID=1,#intMarkers do
	local x, y, z, int, dim = intMarkers[ID][1], intMarkers[ID][2], intMarkers[ID][3], intMarkers[ID][4], intMarkers[ID][5]
    local theMarker = createMarker(x, y, z, "arrow", 1.5, 255, 255, 255)
	setElementInterior(theMarker, int, x, y, z)
	setElementDimension(theMarker, dim)
    theMarkerID[theMarker] = ID
	addEventHandler("onClientMarkerHit", theMarker, intWarps)
end