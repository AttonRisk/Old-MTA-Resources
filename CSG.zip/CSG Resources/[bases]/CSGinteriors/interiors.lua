local intMarkers = {
	--------------------------------------------------------------------
	------------------- ADD HERE AS MUCH GATES YOU WANT! ---------------
	-- Xmarker, Ymarker, Zmarker, INTmarker, DIMmarker, Xwarp, Ywarp, Zwarp, rotWarp, INTwarp, DIMwarp (start from 6000 with dimensions), groupname, teamname
	-- IF YOU DONT WANT A TEAM ENTER NIL, ALWAYS ADD A GROUP!
	-- You need to be sure that the exit of 1 isn't the same as the exit from another.
	--------------------------------------------------------------------
	{1265.599609375, -1611.8994140625, 14.699999809265, 0, 0, 1227.14, -1616.8994140625, 74.800003051758, 272.67657470703, 0, 0, "SWAT Team", "SWAT"}, --SWAT BASE
	{1225.2998046875, -1616.8994140625, 74.800003051758, 0, 0, 1265.599609375, -1613.45, 14.699999809265, 174.57818603516, 0, 0, "SWAT Team", "SWAT"}, -- SWAT BASE
	{1258.099609375, -1616, 14.9, 0, 0, 1262.37, -1616, 8, 273.23690795898, 0, 0, "SWAT Team", "SWAT"}, -- SWAT BASE
	{1259.2998046875, -1616, 8, 0, 0, 1260.37, -1616, 14.9, 270.24856567383, 0, 0, "SWAT Team", "SWAT"}, -- SWAT BASE
	{1201.5,  -1619.7, 15.1, 0, 0, 246.22, 110.49, 1003.21, 0, 10, 6000, "SWAT Team", "SWAT"}, -- SWAT BASE
	{246.22, 107.94, 1004.21, 10, 6000, 1202.87,  -1619.7, 15.1, 267.47998046875, 0, 0, "SWAT Team", "SWAT"}, -- SWAT BASE
	{2068.39, 600.3, 12.21, 0, 0, 1263.43, -785.63, 1091.9, 268.56762695312, 5, 6001, "The Smurfs"},-- "Criminals"}, -- The Smurfs base
	{1260.64, -785.63, 1092.9, 5, 6001, 2065.78, 600.3, 11.71, 86.252227783203, 0, 0, "The Smurfs"},-- "Criminals"}, -- The Smurfs base
	{2214.75, -1150.55, 1026.59, 15, 6001, 2026.25, 603.94, 11.12, 355.68505859375, 0, 0, "The Smurfs"},-- "Criminals"}, -- The Smurfs base
	{2026.19, 601.73, 12.12, 0, 0, 2217.22, -1150.55, 1025.79, 271.08352661133, 15, 6001, "The Smurfs"},-- "Criminals"}, -- The Smurfs base
}
	--------------------------------------------------------------------
	-------------- CHANGE ONLY STUFF BETWEEN THIS AND ABOVE ------------
	--------------------------------------------------------------------


function getInteriorMarkers ()
	return intMarkers
end