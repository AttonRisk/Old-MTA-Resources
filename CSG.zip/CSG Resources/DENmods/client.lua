addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()),
	function ()
	-- SWAT Skin
	txd = engineLoadTXD ( "swat.txd" )
	engineImportTXD ( txd,285)
	dff = engineLoadDFF ( "swat.dff",285)
	engineReplaceModel ( dff,285)
	-- MF Skin
	txd = engineLoadTXD ( "af.txd" )
	engineImportTXD ( txd,97)
	dff = engineLoadDFF ( "af.dff",97)
	engineReplaceModel ( dff,97)
	end
)