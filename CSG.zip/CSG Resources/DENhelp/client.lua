local Messages = {message={}, rgb={}}
local scx,scy = guiGetScreenSize()

local theFont = "Tahoma bold"
local theFontSize = 1.8

local messages = {}
local displayMessageTimer = {}
local fadeMessageTimer = {}
local toBeDisplayedMesssages = {}
local handlingDX = false

-- Add new message in the tabe, function is exported too
function createNewHelpMessage( message, r, g, b )

	if message then
	
	if not r then r=255 end
	if not g then g=255 end
	if not b then b=255 end
	local alpha = 255

	for i, msgTable in ipairs(messages) do 
		if msgTable[1] == message then
			return false
		end
	end
	
	for i, msgTable in ipairs(toBeDisplayedMesssages) do
		if msgTable[1] == message then 
			return false
		end
	end

	if #messages < 3 then
	
		table.insert( messages, { message, r, g, b, alpha } )
		local msgIndex = 1
		for i, msg in ipairs(messages) do
			if msg[1] == message then 
				msgIndex = i 
			end
		end	
		
		if not isTimer ( displayMessageTimer[message] ) then
			displayMessageTimer[message] = setTimer( fadeMessage, 3000, 1, message, msgIndex )
		end	
		
	else
		table.insert( toBeDisplayedMesssages, { message, r, g, b, alpha } )
	end	
	
		if handlingDX == false then
			addEventHandler ( "onClientRender", root, DrawText )
			handlingDX = true
		end		
	end
end
addEvent( "createNewHelpMessage", true )
addEventHandler( "createNewHelpMessage", root, createNewHelpMessage )

function DrawText()	
	if messages[1] and not messages[2] and not messages[3] then
	-- draw newest ( msg1 )
		local msgcolor = tocolor ( messages[1][2], messages[1][3], messages[1][4], messages[1][5] )
		dxDrawRectangle( 3, 3, scx - 6, 27, tocolor( 25, 25, 25, 165 ) ) -- Center
		dxDrawText(""..messages[1][1].."", 0,0,scx,scy,msgcolor,theFontSize, theFont,"center","top",false,false,false)		
	elseif messages[2] and not messages[3] then	
	-- draw newest ( msg2 )	
		local msgcolor = tocolor ( messages[2][2], messages[2][3], messages[2][4], messages[2][5] )
		dxDrawRectangle( 3, 30, scx - 6, 27, tocolor( 25, 25, 25, 165 ) ) -- Center
		dxDrawText(""..messages[2][1].."", 0,30,scx,scy,msgcolor,theFontSize, theFont,"center","top",false,false,false)	
	-- draw second ( msg1 )
		local msgcolor = tocolor ( messages[1][2], messages[1][3], messages[1][4], messages[1][5] )
		dxDrawRectangle( 3, 3, scx - 6, 27, tocolor( 25, 25, 25, 165 ) ) -- Center	
		dxDrawText(""..messages[1][1].."", 0,0,scx,scy,msgcolor,theFontSize, theFont,"center","top",false,false,false)		
	elseif messages[3] then
	-- draw newest ( msg3 )	
		local msgcolor = tocolor ( messages[3][2], messages[3][3], messages[3][4], messages[3][5] )
		dxDrawRectangle( 3, 57, scx - 6, 27, tocolor( 25, 25, 25, 165 ) ) -- Center	
		dxDrawText(""..messages[3][1].."", 0,57,scx,scy,msgcolor,theFontSize, theFont,"center","top",false,false,false)
	-- draw second ( msg2 )	
		local msgcolor = tocolor ( messages[2][2], messages[2][3], messages[2][4], messages[2][5])
		dxDrawRectangle( 3, 30, scx - 6, 27, tocolor( 25, 25, 25, 165 ) ) -- Center	
		dxDrawText(""..messages[2][1].."", 0,30,scx,scy,msgcolor,theFontSize, theFont,"center","top",false,false,false)		
	-- draw third ( msg1 )	
		local msgcolor = tocolor ( messages[1][2], messages[1][3], messages[1][4], messages[1][5] )
		dxDrawRectangle( 3, 3, scx - 6, 27, tocolor( 25, 25, 25, 165 ) ) -- Center
		dxDrawText(""..messages[1][1].."", 0,0,scx,scy,msgcolor,theFontSize, theFont,"center","top",false,false,false)		
	end	
end

function fadeMessage ( message, index )
	if not isTimer(fadeMessageTimer[message]) then
		fadeMessageTimer[message] = setTimer ( decreaseAlpha, 80, 0, message, index )	
	end	
end

function decreaseAlpha ( message, index )

local msgIndex = 1
	for i, msg in ipairs(messages) do
		if msg[1] == message then
			msgIndex = i
		end
	end	
	
	if messages[msgIndex] then
		if messages[msgIndex][5] > 25 then
			messages[msgIndex][5] = messages[msgIndex][5] - 10		
		else
			removeMessage ( messages[msgIndex], msgIndex )			
		end		
	end
end

function removeMessage ( message, index )
	local msgIndex = 1
	
	for i, msg in ipairs(messages) do
		if msg == message then
			msgIndex = i 
		end
	end
	
	if isTimer ( fadeMessageTimer[message[1]] ) then killTimer ( fadeMessageTimer[message[1]] ) end
	
	table.remove( messages, index )
	local firstEmptySlot = #messages+1
	
	if not messages[firstEmptySlot] and toBeDisplayedMesssages[1] then 
		messages[firstEmptySlot] = toBeDisplayedMesssages[1]
		table.remove ( toBeDisplayedMesssages, 1 )
		if not isTimer ( displayMessageTimer[messages[firstEmptySlot][1]] ) then
			displayMessageTimer[messages[firstEmptySlot][1]] = setTimer( fadeMessage, 3000, 1, messages[firstEmptySlot][1], firstEmptySlot )	
		end	
	end


	if not messages[1] then
		if handlingDX == true then
			removeEventHandler ( "onClientRender", root, DrawText )
			handlingDX = false		
		end		
	end	
end