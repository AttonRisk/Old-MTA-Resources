function createNewHelpMessageForPlayer (thePlayer, message, r, g, b)
	triggerClientEvent ( thePlayer, "createNewHelpMessage", thePlayer, message, r, g, b)
end