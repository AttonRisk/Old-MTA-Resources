local weaponDrops = {}
local spamDrop = {}
 
local specialWeps = { [40]=true, [46]=true, [45]=true, [44]=true,[15]=true, [14]=true, [12]=true, [11]=true, [10]=true, [9]=true, [8]=true, [7]=true, [6]=true, [5]=true, [4]=true, [3]=true, [2]=true, [1]=true }

addCommandHandler ( 'dropwep',
function ( thePlayer, cmd, theAmmo )
    local x, y, z = getElementPosition ( thePlayer )
    local theWeapon = getPedWeapon( thePlayer )
	if ( spamDrop[thePlayer] ) and ( getTickCount()-spamDrop[thePlayer] < 10000 ) and not ( exports.server:isPlayerStaff( thePlayer ) ) then
		exports.DENhelp:createNewHelpMessageForPlayer( thePlayer, "Wait 10 seconds before you drop another item!", pPlayer, 255,0, 0 )
	else
		if ( theAmmo ) then
			if ( getPedTotalAmmo ( thePlayer ) >= tonumber( theAmmo ) ) then
				if ( getElementData( thePlayer, "Occupation" ) == "Paramedic" ) and ( theWeapon == 41 ) then
					exports.DENhelp:createNewHelpMessageForPlayer( thePlayer, "You can't drop this weapon while being a paramedic!", pPlayer, 255,0, 0 )
					return
				elseif ( specialWeps[theWeapon] )then
					takeWeapon ( thePlayer, theWeapon )
					thePickup = createPickup( x, y, z, 2, theWeapon, 0, theAmmo )
					setElementDimension( thePickup, getElementDimension( thePlayer ) )
					setElementInterior( thePickup, getElementInterior( thePlayer ) )
					weaponDrops[thePickup] = getTickCount()
					spamDrop[thePlayer] = getTickCount()
					return
				elseif ( tonumber(theAmmo) >= 20 ) or ( exports.server:isPlayerStaff( thePlayer ) ) then
					takeWeapon( thePlayer, theWeapon, tonumber( theAmmo ))
					thePickup = createPickup( x, y, z, 2, theWeapon, 0, theAmmo )
					setElementDimension( thePickup, getElementDimension( thePlayer ) )
					setElementInterior( thePickup, getElementInterior( thePlayer ) )
					weaponDrops[thePickup] = getTickCount()
					spamDrop[thePlayer] = getTickCount()
					return
				else
					exports.DENhelp:createNewHelpMessageForPlayer( thePlayer, "The minimum amount to drop is 20!", pPlayer, 255,0, 0 )
				end
			else
				exports.DENhelp:createNewHelpMessageForPlayer( thePlayer, "You don't have enough ammo to drop!", pPlayer, 255,0, 0 )
			end
		else
			exports.DENhelp:createNewHelpMessageForPlayer( thePlayer, "You didn't enterd how much ammo you want to drop!", pPlayer, 255,0, 0 )
		end
	end
end
)

addEventHandler ( 'onPickupUse', root,
function ( thePlayer )
    if ( getPickupType ( source ) == 2 ) then
		if ( weaponDrops[source] ) and ( getTickCount()-weaponDrops[source] < 3000 ) then   
			cancelEvent()
		elseif ( weaponDrops[source] ) then
			weaponDrops[source] = {}
			cancelEvent()
			local theAmmo = getPickupAmmo ( source )                               
			local theWeapon = getPickupWeapon( source )
			giveWeapon( thePlayer, theWeapon, theAmmo, true )
			destroyElement( source )
		else
			destroyElement( source )
		end
	end
end
)