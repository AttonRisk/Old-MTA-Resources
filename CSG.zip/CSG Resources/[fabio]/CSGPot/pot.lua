accessAccounts = {
["jack"] = {"jack"},
["racerboy"] = {"racerboy"},
["imaster"] = {"imaster"},
["brenda"] = {"brenda"}
}

blacklist = {
}
-------
local potXML = xmlLoadFile("goldenpot.xml")
local banXML = nil

--potSettings = true
potAdding = true
potPaying = true
potOutput = true

addCommandHandler("totalpots",
function(player)
	pots = xmlNodeGetChildren(potXML)
	outputChatBox("Theres a total of "..#pots.." pots in system.",player,0,255,0)
end)

addCommandHandler("totalbans",
function(player)
	if exports.server:isPlayerStaff(player) then
		allBans = xmlNodeGetChildren(banXML)
		outputChatBox("Total bans in the system: "..#allBans,player,255,0,0)
	end
end)

addEventHandler("onResourceStart",resourceRoot,
function()
	banXML = xmlLoadFile("potBans.xml")
	if not banXML then
		banXML = xmlCreateFile("potBans.xml", "bannedAccs")
		if banXML then
			outputDebugString("Pot bans file created.")
		end
	end
	
	accounts = xmlNodeGetChildren(banXML)
	if accounts then
		outputDebugString("[POT-BLKLIST] Pot started, Loading banned accounts into blacklist...")
		for i=1, #accounts do
			local account = xmlNodeGetAttribute(accounts[i], "account")
			local reason = xmlNodeGetAttribute(accounts[i], "reason")
			if account and reason then
				--outputDebugString("Account: "..account.." reason: "..reason)
				blacklist[account] = {reason}
				--[[if blacklist[account] then
					outputDebugString("Account: "..account.." added to blacklist.")
				else
					outputDebugString("Failed to add "..account.." to blacklist.")
				end]]--
			end
		end
		outputDebugString("[POT-BLKLIST] ...DONE!")
	end
	--outputDebugString("[POT-BLKLIST] Total bans on table: "..#blacklist)
	--outputDebugString("[POT-BLKLIST] Total bans in XML: "..#accounts)
end)

addEventHandler("onResourceStop",resourceRoot,
function()
	xmlUnloadFile(potXML)
	xmlSaveFile(banXML)
	xmlUnloadFile(banXML)
end)
---------------------------------------------------

antiCheatStartTimer = nil
clue = nil
potEnabled = true
potPickup = nil

function createPot(player, manual, pClue, pX, pY, pZ)
	if not (manual) then
		if ( not isElement(potPickup) ) then
			if not (potEnabled == false) then
				local allChild = xmlNodeGetChildren(potXML)
				local randomPot = math.random(1,#allChild)
				local pot = allChild[randomPot]
				if (pot) then
					local potAtt = xmlNodeGetAttributes(pot)
					if not pX and pY and pZ then
						local x = tonumber(potAtt["x"])
						local y = tonumber(potAtt["y"])
						local z = tonumber(potAtt["z"])
					else
						local x = pX
						local y = pY
						local z = pZ
					end
					description = potAtt["des"]
					amount = math.random(1000,10000)
					potPickup = createPickup(x,y,z,3,2203,999999999)
					if not pClue then
						clue = description
					else
						clue = pClue
					end
					trig = addEventHandler("onPickupUse",potPickup,potPickupUsed)
					setElementData(potPickup,"goldenpot","true")
					setElementData(potPickup,"cash",potPickup)
					if (potOutput == true) then
						exports.DENhelp:createNewHelpMessageForPlayer(root,"A Pot of gold has been placed somewhere in SA! You have 10 minutes to find it!",0,255,255)
						setTimer(output2ndmessage, 3000, 1)
						outputDebugString("CLUE: "..clue)
					end
					antiCheatStartTimer = getTickCount()
					removeTimer = setTimer(removePot,600000,1)
					--[[if removeTimer then
						outputDebugString("Pot's remove timer started.")
					else
						outputDebugSTring("Error starting pot remover timer.")
					end]]--
				else
					outputDebugString("ERROR while finding pot requirements...",0,255,0,0)
				end
			else
				--outputDebugString("Pot system is disabled, ask jack to re-enable the system.",0,0,255,0) -- disabled due to spam!!s
			end
		else
			destroyElement(potPickup)
			killTimer(removeTimer)
			outputDebugString("Recall on createPot was triggered")
			setTimer(createPot,1000,1)
		end
	else
		if (potPickup) then
			destroyElement(potPickup)
			killTimer(removeTimer)
			outputDebugString(getPlayerName(player).." restarted the pot.",0,0,255,0)
			restartTimer = setTimer(createPot,1000,1)
			if restartTimer then
				outputDebugString("restart timer started.",0,255,0,0)
			end
		end
	end
end
addEventHandler("onResourceStart",resourceRoot,createPot)
	
function output2ndmessage()
	exports.DENhelp:createNewHelpMessageForPlayer(root,"Clue: "..description,255,0,0)
end

function removePot(player,cmd,manually)
	if (potPickup) then
		if not (player) then --if wasn't called by event managers
			exports.DENhelp:createNewHelpMessageForPlayer(root,"The pot has been taken away.",255,0,0)
			antiCheatStartTimer = nil
			clue = nil
			destroyElement(potPickup)
		else -- if it was called by event managers
			account = exports.server:getPlayerAccountName(player)
			if (accessAccounts[account]) then 
				outputDebugString("Pot removed / stopped manually by "..getPlayerName(player),0,0,255,0)
				outputChatBox(getPlayerName(player).." removed / stopped the pot.",root,255,0,0)
				if not (potPickup == nil) then
					destroyElement(potPickup)
					potPickup = nil
					if (isElement(removeTimer)) then
						killTimer(removeTimer)
					end
				end
				clue = nil
				antiCheatStartTimer = nil
			else
				return
			end
		end
	end
end
addCommandHandler("removepot", removePot)

function createPotManually(player,cmd)
	account = exports.server:getPlayerAccountName(player)
	if (accessAccounts[account]) then
		if potEnabled == true then
			createPot(player,true)
		else
			outputChatBox("Enable pot first with /startpot",player,255,0,0,false)
		end
	else
		return
	end
end
addCommandHandler("createpot",createPotManually)

function stopPot(player,cmd)
	account = exports.server:getPlayerAccountName(player)
	if (accessAccounts[account]) then
		if not (potEnabled == false) then
			removePot(player,nil,true)
			potEnabled = false
			clue = nil
			outputChatBox("Pot is now disabled.",player,255,0,0,true)
		else
			outputChatBox("Pot is already disabled!",player,255,0,0,true)
		end
	else
		return
	end
end
addCommandHandler("stoppot",stopPot)

function startPot(player,cmd)
	account = exports.server:getPlayerAccountName(player)
	if (accessAccounts[account]) then
		if not (potEnabled == true) then
			potEnabled = true
			outputChatBox("Pot is now enabled.",player,0,255,0,false)
			createPot()
		else
			outputChatBox("Pot is already enabled.",player,255,0,0,false)
		end
	else
		return
	end
end
addCommandHandler("startpot",startPot)

function potPickupUsed(player)
	if (isElement(player)) and (getElementType(player) ~= "vehicle") then
		--Blacklist area--
		account = exports.server:getPlayerAccountName(player)
		serial = getPlayerSerial(player)
		if (blacklist[account] or blacklist[serial]) then
			reason = blacklist[account or serial][1]
			if reason then
				outputChatBox("You are banned from using pot! reason: "..reason,player,255,0,0)
			end
			cancelEvent()
			return false
		end
		--end of blacklist--
		
		--anti-cheat area--
		if (getElementData(player,"superman:flying") == true) then
			account = exports.server:getPlayerAccountName(player)
			reason = "Abusing pot by using superman [Ban type: PERMANENT]"
			outputDebugString("[POT-AC] Abuser found! acc: "..account..", reason: Using superman. Account is now blacklisted.",0,255,255,0)
			--blacklist[account] = {reason}
			banAccountFromPot(account,reason)
			cancelEvent()
			return false
		end
		
		if math.floor(getTickCount() / 1000) - math.floor(antiCheatStartTimer / 1000) < 5 then
			account = exports.server:getPlayerAccountName(player)
			reason = "Possible teleportation hack [Ban type: PERMANENT]"
			outputDebugString("[POT-AC] Hacker found! acc: "..account..", reason: "..reason..". Account is now blacklisted.",0,255,255,0)
			--blacklist[account] = {reason}
			banAccountFromPot(account,reason)
			cancelEvent()
			return false
		end
		--end of anti-cheat--
		
		endTimer = getTickCount()
		if (isElement(potTimer)) then
			killTimer(potTimer)
		end
		exports.DENhelp:createNewHelpMessageForPlayer(root,getPlayerName(player).." found the pot",255,255,0)
		outputDebugString("Time took: "..math.floor(endTimer-antiCheatStartTimer/1000))
		exports.DENhelp:createNewHelpMessageForPlayer(player,"Good job! you found the pot, heres the earnings: $"..amount,255,0,0)
		antiCheatStartTimer = nil
		if (potPaying == true) then
			givePlayerMoney(player, amount)
		else
			outputChatBox("Testing status is enabled, money was not given.",player,255,0,0)
		end
		luck = math.random(1,5)
		if (luck == 3) then
			playerGotCaught(player)
		end
		potclue = nil -- added due to bug
	end
end

function banAccountFromPot(account,reason)
	if account and reason and account ~= "" and reason ~= "" then
		if banXML then
			--outputDebugString("[POT-BANSYS] Ban requested for account: "..account..", attempting to add account..")
			checkForBan = xmlFindChild(banXML,account,0)
			if not checkForBan then
				--outputDebugString("Account was not found in the database, adding..")
				accountBan = xmlCreateChild(banXML,tostring(account))
				if accountBan then
					xmlNodeSetAttribute(accountBan,"account",tostring(account))
					xmlNodeSetAttribute(accountBan,"reason",tostring(reason))
				end
				xmlSaveFile(banXML)
			else
				--outputDebugString("[POT-BANSYS] Account "..account.." was already found, cancelling..")
				return
			end
			blacklist[account] = {reason}
		else
			return false
		end
	end
end

function playerGotCaught(player)
	if player then
		exports.DENhelp:createNewHelpMessageForPlayer(player,"The pot was involved in police evidence, your now wanted!",255,0,0)
		exports.server:givePlayerWantedPoints(player,20)
	end
end

function getClue(player,command)
	if player then
		if not (clue == nil) then
			exports.DENhelp:createNewHelpMessageForPlayer(player,"Last clue: "..clue,0,255,0)
		else
			exports.DENhelp:createNewHelpMessageForPlayer(player,"There is no clue available (pot not spawned)",255,0,0)
		end
	end
end
addCommandHandler("potclue",getClue)

--[[function getAccountName(player,cmd)
	if player then
		accountname = exports.server:getPlayerAccountName(player)
		outputChatBox("account name: "..accountname,player,255,0,0)
	end
end
addCommandHandler("accountname",getAccountName)]]--

setTimer(createPot,1200000,0) -- Call the pot every 20 minutes

addCommandHandler("resetWater",
function()
	resetWaterLevel()
end)

addCommandHandler("moveVeh",
function()
	x,y,z = getElementPosition(getPedOccupiedVehicle(getPlayerFromName("[CSG]Jack")))
	x = x + 5
	z = z + 100
	setElementPosition(getPedOccupiedVehicle(getPlayerFromName("[CSG]Jack")),x,y,z)
end)