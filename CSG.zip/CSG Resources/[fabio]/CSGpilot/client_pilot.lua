
local passengers = {}
local passengerMarkers = {}


addEvent ( "airport_c_onPassengerEnter", true )
function pilot_onPassengerEnter ( targetX, targetY )

	if not passengers[ source ] then 
	
		local x,y,z = getElementPosition ( localPlayer )
		local passengerMarker = createMarker ( targetX, targetY, getGroundPosition ( targetX, targetY, z ), "cylinder", 3, 200, 0, 0 )
		local passengerBlip = createBlipAttachedTo ( passengerMarker, 41 )
		addEventHandler ( "onClientMarkerHit", passengerMarker, pilot_onTargetMarkerHit, false )
		addEventHandler ( "onClientPlayerQuit", source, pilot_onPassengerExit, false )
		addEventHandler ( "onClientPlayerWasted", source, pilot_onPassengerExit, false )
		
		table.insert( passengers, source )
		table.insert( passengerMarkers, passengerMarker )
		setElementData ( localPlayer, "airport_pilot_passengers", passengers )
		setElementData ( passengerMarker, "airport_markerPassenger", source )
		setElementData ( passengerMarker, "airport_markerBlip", passengerBlip )
	
		exports.denhelp:createNewHelpMessage ( getPlayerName(source).." has entered your vehicle.", 0, 255, 0 )
		local plane = getPedOccupiedVehicle(localPlayer)
		
		if #passengers == 1 then 
		
			addEventHandler ( "onClientVehicleExit", plane, pilot_onPlaneExit, false )
			addCommandHandler ( "air", airChatForPilot )
			passengersThatShouldPay = {}
			checkMarkerZTimer = setTimer ( checkMarkerZs, 500, 0 )
			addEventHandler ( "onClientPlayerWasted", localPlayer, pilot_onPilotWasted, false )

		end
		
		stopCargo()
		
	end
	
end

addEventHandler ( "airport_c_onPassengerEnter", root, pilot_onPassengerEnter )

function checkMarkerZs ()

	for i=1, #passengerMarkers do
	
		if isElement ( passengerMarkers[i] ) then
	
			local x,y,z = getElementPosition ( passengerMarkers[i] )
			local px,py,pz = getElementPosition ( localPlayer )
			
			if getGroundPosition ( x, y, pz ) ~= z then
		
				setElementPosition ( passengerMarkers[i], x, y, getGroundPosition ( x, y, pz ) )
			
			end
			
		end
		
	end

end

function pilot_onPlaneExit ( thePlayer )

	if isPlayerPassenger( thePlayer ) then

		pilot_onPassengerExit( thePlayer )
		
	elseif thePlayer == localPlayer then
		
		pilot_onPilotExit()
		
	end

end

function pilot_onPilotExit ()

	triggerServerEvent ( "airport_s_pilotExit", localPlayer, passengers )
	removeEventHandler ( "onClientVehicleExit", getPedOccupiedVehicle ( localPlayer ), pilot_onPlaneExit, false )
	removeEventHandler ( "onClientPlayerWasted", localPlayer, pilot_onPilotWasted, false )
	removeCommandHandler ( "air", airChatForPilot )
	if isTimer(checkMarkerZTimer) then destroyTimer ( checkMarkerZTimer ) end

	pilot_reset()


end

function isPlayerPassenger( player )

	for i=1, #passengers do
	
		if passengers[i] == player then
		
			return true
			
		end
		
	end
	
	return false

end

function pilot_onPassengerExit( passenger )

	for i=1, #passengers do
	
		if passengers[i] == passenger then
		
			triggerServerEvent ( "airport_s_onPassengerExit", localPlayer, passenger, shouldPassengerPay ( passenger ) )
			removeEventHandler ( "onClientMarkerHit", passengerMarkers[i], pilot_onTargetMarkerHit, false )
			removeEventHandler ( "onClientPlayerQuit", passenger, pilot_onPassengerExit, false )
			removeEventHandler ( "onClientPlayerWasted", passenger, pilot_onPassengerExit, false )
			destroyElement ( getElementData ( passengerMarkers[i], "airport_markerBlip" ) )
			destroyElement ( passengerMarkers[i] )
			table.remove ( passengerMarkers, i )
			table.remove ( passengers, i )
			setElementData ( localPlayer, "airport_pilot_passengers", passengers )

			if #passengers <= 0 then 
			
				removeEventHandler ( "onClientVehicleExit", getPedOccupiedVehicle ( localPlayer ), pilot_onPlaneExit, false )
				removeEventHandler ( "onClientPlayerWasted", localPlayer, pilot_onPilotWasted, false )
				removeCommandHandler ( "air", airChatForPilot )
				if isTimer(checkMarkerZTimer) then destroyTimer ( checkMarkerZTimer ) end

			end
			
		end
		
	end
	
	for i = 1, #passengersThatShouldPay do
	
		if passengersThatShouldPay[i] == passenger then
		
			table.remove ( passengersThatShouldPay, i )
			
		end
		
	end
	
	if #passengers == 0 then
	
		initCargo()
		
	end
	exports.denhelp:createNewHelpMessage ( getPlayerName( passenger ).." has left your vehicle.", 0, 255, 0 )
	
end

function pilot_onPilotWasted()

	triggerServerEvent ( "airport_s_pilotDied", localPlayer, passengers )
	removeEventHandler ( "onClientVehicleExit", getPedOccupiedVehicle ( localPlayer ), pilot_onPlaneExit, false )
	removeEventHandler ( "onClientPlayerWasted", localPlayer, pilot_onPilotWasted, false )
	removeCommandHandler ( "air", airChatForPilot )
	if isTimer(checkMarkerZTimer) then killTimer ( checkMarkerZTimer ) end
	pilot_reset()
	
end

function pilot_reset()

	setTimer ( function () passengers = {} end, 1500, 1 )
	setTimer ( function () passengersThatShouldPay = {} end, 1500, 1 )
	for i=1, #passengerMarkers do
	
		if isElement ( passengerMarkers[i] ) then destroyElement ( passengerMarkers[i] ) end
		
	end
	setTimer ( function () passengerMarkers = {} end, 1500, 1 )
	
end


function shouldPassengerPay( passenger )

	for i=1, #passengersThatShouldPay do
	
		if passengersThatShouldPay[i] == passenger then
		
			return true
			
		end
		
	end
	
	return false

end

function airChatForPilot(commandName, ...)

local arg = {...}
local allMessages = tostring( table.concat( arg, " " ) )

	if allMessages then
	
		if getElementData(localPlayer, "Occupation" ) == "Pilot" then
		
			local passengers = nil
			passengers = getElementData ( localPlayer, "airport_pilot_passengers" )
					
				if passengers then

					triggerServerEvent ( "airport_s_chat", localPlayer, allMessages, localPlayer, passengers )
				
				end

		end

	end	

end

function pilot_onTargetMarkerHit()
local passenger = getElementData ( source, "airport_markerPassenger" )

	if passenger then
	
		if not shouldPassengerPay ( passenger ) then table.insert ( passengersThatShouldPay, passenger ) end
		triggerServerEvent ( "airport_s_notifyPassengerOfArrival", passenger )
		
	end
	
end

-- cargo

function onElementDataChange( dataName, oldValue )

	if dataName == "Occupation" and getElementData(localPlayer,dataName) == "Pilot" then
	
		initCargo()
		
	elseif dataName == "Occupation" then
	
		stopCargo()
		
	end

end

addEventHandler ( "onClientElementDataChange", localPlayer, onElementDataChange, false ) 

function onPilotTeamChange ( oldTeam, newTeam )

	if getElementData ( localPlayer, "Occupation" ) == "Pilot" and source == localPlayer then

		setTimer ( function ()
			if getPlayerTeam( localPlayer ) then
				local newTeam = getTeamName ( getPlayerTeam( localPlayer ) )

				if newTeam == "Unoccupied" then
	
					stopCargo()
		
				elseif getElementData ( localPlayer, "Occupation" ) == "Pilot" and newTeam == "Civilian Workers" then

					initCargo()
	
				end

			end
	
		end, 200, 1 )
		
	end

end

addEventHandler( "onClientPlayerTeamChange", localPlayer, onPilotTeamChange, false )

local destinations = 
{
{},
{},
{}
}

local cargoMissionTimer
local lastCargoMission

function initCargo()

	if not onCargoMission and not isTimer ( cargoMissionTimer ) then
	
		cargoMissionTimer = setTimer ( startCargoMission, 180000, 1 )
		
	end

end

function startCargoMission ()

	if getPedOccupiedVehicle ( localPlayer ) then

		local mission = math.random(1,#destinations)
		local x,y,z = destinations[mission][1],destinations[mission][2],destinations[mission][3]
		local px, py, pz = getElementPosition ( localPlayer )
	
		while mission == lastCargoMission and getDistanceBetweenPoints2D (x,y,z,px,py,pz) < 350 do
	
			mission = math.random(1,#destinations)
			x,y,z = destinations[mission][1],destinations[mission][2],destinations[mission][3]
		
		end
		lastCargoMission = mission
		exports.denhelp:createNewHelpMessage ( "Deliver cargo to the red blip to earn money.", 0, 255, 0 )
		cargoTargetMarker = createMarker ( x,y,z, "cylinder", 3, 0, 0, 255 )
		cargoTargetBlip = createBlipAttachedTo ( cargoTargetMarker, 0, 3.5 )
		addEventHandler ( "onClientMarkerHit", cargoTargetMarker, onCargoMarkerHit, false )
		addEventHandler ( "onClientVehicleExit", getPedOccupiedVehicle( localPlayer ), onCargoVehicleExit, false )
		
	end

end

function onCargoVehicleExit(thePlayer)

	if thePlayer == localPlayer then
	
		stopCargo()
		
	end

end

function onCargoMarkerHit( hitElement )

	if hitElement == localPlayer then
	
		stopCargo()
		triggerServerEvent ( "onCargoFinish", localPlayer )
		cargoMissionTimer = setTimer ( startCargoMission, math.random(180000,300000), 1 )
	
	end

end

function stopCargo()

	if isTimer ( cargoMissionTimer ) then
	
		killTimer ( cargoMissionTimer )
		
	elseif onCargoMission then
	
		if isElement ( cargoTargetBlip ) then destroyElement ( cargoTargetBlip ) end
		if isElement ( cargoTargetMarker ) then destroyElement ( cargoTargetMarker ) end
		onCargoMission = false
		removeEventHandler ( "onClientVehicleExit", getPedOccupiedVehicle( localPlayer ), onCargoVehicleExit, false )
		
	end

end
