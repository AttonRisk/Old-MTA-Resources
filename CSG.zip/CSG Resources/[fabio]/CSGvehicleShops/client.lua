
-- price table
local vehiclePriceTable = {
-- FAST CARS:
[429] = 100000, -- Banshee
[541] = 120000, -- Bullet
[559] = 130000, -- Jester
[415] = 150000, -- cheetah
[561] = 80000, -- Stratum
[480] = 120000, -- Comet
[562] = 90000, -- Elegy
[506] = 180000, -- Super GT
[565] = 80000, -- Flash
[411] = 260000, -- Infernus
[451] = 250000, -- Turismo
[434] = 100000, -- Hotknife
[558] = 76000, -- Uranus
[494] = 130000, -- Hotring Racer
[555] = 60000, -- Windsor
[502] = 130000, -- Hotring Racer 2
[477] = 160000, -- ZR-350
[503] = 130000, -- Hotring Racer 3
[424] = 70000, -- BF Injection
[504] = 90000, -- Bloodring Banger
[579] = 60000, -- Huntley
[402] = 95000, -- Buffalo
[542] = 60000, -- Clover
[603] = 120000, -- Phoenix
[475] = 90000, -- Sabre
[560] = 55000, -- Sultan
-- PLANES:
[553] = 300000, -- Nevada
[488] = 100000, -- News Chopper
[511] = 60000, -- Beagle
[548] = 160000, -- Cargobob
[563] = 140000, -- Raindance
[512] = 90000, -- Cropduster
[476] = 2000000, -- Rustler
[447] = 2000000, -- Seasparrow
[593] = 40000, -- Dodo
[519] = 150000, -- Shamal
[460] = 200000, -- Skimmer
[417] = 140000, -- Leviathan
[469] = 75000, -- Sparrow
[487] = 100000, -- Maverick
[513] = 85000, -- Stuntplane
-- BIKES:
[581] = 14000, --BF-400
[510] = 1000, -- Mountain Bike
[509] = 800, -- Bike    
[522] = 99000, -- NRG-500
[481] = 1000, -- BMX
[461] = 18000, -- PCJ-600
[462] = 5000, -- Faggio
[448] = 5000, -- Pizza Boy
[521] = 22000, -- FCR-900     
[468] = 11000, -- Sanchez 
[463] = 12000, -- Freeway
[586] = 9499, -- Wayfarer
[471] = 6800, -- Quadbike
[571] = 5499, -- Kart
-- BOATS:
[472] = 80000, -- Coastguard
[473] = 40000, -- Dinghy
[493] = 120000, -- Jetmax
[595] = 300000, -- Launch
[484] = 100000, -- Marquis
[453] = 70000, -- Reefer
[452] = 110000, -- Speeder
[446] = 110000, -- Squalo
[454] = 90000, -- Tropic
[539] = 100000, -- Vortex
-- INDUSTIAL:
[499] = 15000, -- Benson
[588] = 35000, -- Hotdog
[609] = 30000, -- Black Boxville
[403] = 90000, -- Linerunner (NOTE: is from tank commander)
[498] = 30000, -- Boxville
[514] = 90000, -- Linerunner 
[524] = 70000, -- Cement Truck
[422] = 24000, -- Bobcat
[423] = 40000, -- Mr. Whoopee
[420] = 23000, -- Taxi
[532] = 100000, -- Combine Harvester
[414] = 39000, -- Mule
[578] = 60000, -- DFT-30
[443] = 99000, -- Packer
[486] = 110000, -- Dozer
[515] = 89000, -- Roadtrain
[531] = 20000, -- Tractor
[573] = 79000, -- Dune
[456] = 36000, -- Yankee
[455] = 60000, -- Flatbed
[530] = 14000, -- Forklift
[444] = 150000, -- Monster
[556] = 150000, -- Monster 2
[557] = 150000, -- Monster 3
[568] = 34000, -- Bandito
[508] = 45000, -- journey
[552] = 29000, -- Utility Van
[431] = 89000, -- Bus
[438] = 20000, -- Cabbie
[525] = 30000, -- Towtruck
[437] = 89000, -- Coach
[418] = 16000, -- Moonbeam
[572] = 4000, -- Mower
[582] = 37000, -- News Van
[413] = 31000, -- Pony
[440] = 31000, -- Rumpo
[459] = 31000, -- Berkley's RC Van
[400] = 40000, -- Landstalker
[404] = 17000, -- Perennial
[479] = 18000, -- Regina
[442] = 30000, -- Romero
-- NORMAL:
[458] = 30000, -- Solair
[438] = 40000, -- camper
[489] = 35000, -- Rancher
[445] = 28000, -- Admiral
[467] = 35000, -- Oceanic
[426] = 35000, -- Premier
[507] = 32000, -- Elegant
[547] = 26000, -- Primo
[585] = 30000, -- Emperor
[405] = 35000, -- Sentinel
[587] = 38000, -- Euros
[409] = 66000, -- Stretch
[466] = 26000, -- Glendale
[550] = 27000, -- Sunrise
[492] = 26000, -- Greenwood
[566] = 24000, -- Tahoma
[546] = 23000, -- Intruder
[540] = 36000, -- Vincent
[551] = 34900, -- Merit
[421] = 32000, -- Washington
[516] = 24900, -- Nebula
[529] = 27900, -- Willard
[602] = 38900, -- Alpha
[478] = 20000, -- Walton
[545] = 39000, -- Hustler
[496] = 38000, -- Blista Compact
[517] = 24900, -- Majestic
[401] = 21000, -- Bravura
[410] = 22000, -- Manana
[518] = 38000, -- Buccaneer
[600] = 28000, -- Picador
[527] = 29000, -- Cadrona
[436] = 22000, -- Previon
[589] = 30000, -- Club
[580] = 25900, -- Stafford
[500] = 25000, -- Mesa
[419] = 25000, -- Esperanto
[439] = 35000, -- Stallion
[533] = 29000, -- Feltzer
[549] = 23900, -- Tampa
[526] = 26900, -- Fortune
[491] = 22000, -- Virgo
[474] = 40000, -- Hermes
[536] = 31000, -- Blade
[575] = 32000, -- Broadway
[534] = 33000, -- Remington
[567] = 34000, -- Savanna
[535] = 41000, -- Slamvan
[576] = 32000, -- Tornado
[412] = 31000 -- Voodoo
}

-------------

local sw, sh = guiGetScreenSize()
shopMarkers = {}
-- bikes
local bikesLVMarker = createMarker ( 1940.6201171875, 2041.306640625, 9.8 , "cylinder", 1.5, 250, 134, 2 )
local bikesCountryMarker = createMarker ( 702.42, -519.34, 15.33 , "cylinder", 1.5, 250, 134, 2 )
local bikesSFMarker = createMarker ( -2071.6599121094, -92.908683776855, 34.2 , "cylinder", 1.5, 250, 134, 2 )
table.insert ( shopMarkers, bikesLVMarker )
table.insert ( shopMarkers, bikesCountryMarker )
table.insert ( shopMarkers, bikesSFMarker )

exports.customblips:createCustomBlip ( 1943.38, 2060.72, 10, 10, "bike.png", 300 )
exports.customblips:createCustomBlip ( 701.73, -520.89, 10, 10, "bike.png", 300 )
exports.customblips:createCustomBlip (-2083.79, -91.17, 10, 10, "bike.png", 300 )
	-- colShapes
	
-- boats
local boatsLSMarker = createMarker (-36.2548828125, -1592.8994140625, 2.4, "cylinder", 2, 250, 134, 2 )
local boatsLVMarker1 = createMarker (2359.3896484375, 525.70703125, 0.7, "cylinder", 2, 250, 134, 2 )
local boatsLVMarker2 = createMarker (2289.166015625, 525.0625, 0.7, "cylinder", 2, 250, 134, 2 )
local boatsLVBlipPosX, boatsLVBlipPosY, boatsLVBlipPosZ = interpolateBetween( 2359.3896484375, 525.70703125, 0.7, 2289.166015625, 525.0625, 0.7, 0.5, "Linear" )
local boatsLVBlipMarker = createMarker (boatsLVBlipPosX, boatsLVBlipPosY, boatsLVBlipPosZ, "cylinder", 2, 0, 0, 0, 0 )

local boatsSFMarker1 = createMarker( -2192.2197265625, 2410.3134765625, 3.9, "cylinder", 2, 250, 134, 2 )
local boatsSFMarker2 = createMarker( -2241.5595703125, 2458.3232421875, 3.9, "cylinder", 2, 250, 134, 2 )
local boatsSFBlipPosX, boatsSFBlipPosY, boatsSFBlipPosZ = interpolateBetween( -2192.22, 2410.31, 3.9, -2241.56, 2458.32, 3.9, 0.5, "Linear" )
local boatsSFBlipMarker = createMarker (boatsSFBlipPosX, boatsSFBlipPosY, boatsSFBlipPosZ, "cylinder", 2, 0, 0, 0, 0 )
table.insert ( shopMarkers, boatsLSMarker )
table.insert ( shopMarkers, boatsLVMarker1 )
table.insert ( shopMarkers, boatsLVMarker2 )
table.insert ( shopMarkers, boatsSFMarker1 )
table.insert ( shopMarkers, boatsSFMarker2 )
	--	blips
	
	createBlipAttachedTo ( boatsLSMarker, 9, 2, 0, 0, 0, 255, 0, 400 )
	createBlipAttachedTo ( boatsLVBlipMarker, 9, 2, 0, 0, 0, 255, 0, 400 )
	createBlipAttachedTo ( boatsSFBlipMarker, 9, 2, 0, 0, 0, 255, 0, 400 )


	-- colShapes
	
	local boatsLSColCuboid = nil
	local boatsLVColCuboid = nil
	local boatsSFColCuboid = nil
	
-- air
local airSFMarker = createMarker (-1549.7734375, -633.5146484375, 13.2, "cylinder", 2, 250, 134, 2 )
local airLVMarker = createMarker (1615.05, 1222.95, 10.1, "cylinder", 2, 250, 134, 2 )
local airLSMarker = createMarker (2129.0537109375, -2484.6267089844, 12.5, "cylinder", 2, 250, 134, 2 )
table.insert ( shopMarkers, airSFMarker )
table.insert ( shopMarkers, airLVMarker )
table.insert ( shopMarkers, airLSMarker )

	--	blips
	
	createBlipAttachedTo ( airLSMarker, 5, 2, 0, 0, 0, 255, 0, 400 )
	createBlipAttachedTo ( airLVMarker, 5, 2, 0, 0, 0, 255, 0, 400 )
	createBlipAttachedTo ( airSFMarker, 5, 2, 0, 0, 0, 255, 0, 400 )

	-- colShapes
	
	local airLSColCuboid = nil
	local airLVColCuboid = nil
	local airSFColCuboid = nil

-- fastCar
local fastCarLSMarker = createMarker (560.34130859375, -1256.5847167969, 16.2, "cylinder", 2, 250, 134, 2 )
local fastCarLVMarker = createMarker ( 2152.392578125, 1403.4052734375, 10.1, "cylinder", 2, 250, 134, 2 )
local fastCarSFMarker = createMarker ( -1656.6567382813, 1210.9990234375, 6.3, "cylinder", 2, 250, 134, 2 )
table.insert ( shopMarkers, fastCarSFMarker )
table.insert ( shopMarkers, fastCarLVMarker )
table.insert ( shopMarkers, fastCarLSMarker )
	-- blips
	
	createBlipAttachedTo ( fastCarLSMarker, 55, 2, 0, 0, 0, 255, 0, 400 )
	createBlipAttachedTo ( fastCarLVMarker, 55, 2, 0, 0, 0, 255, 0, 400 )
	createBlipAttachedTo ( fastCarSFMarker, 55, 2, 0, 0, 0, 255, 0, 400 )

	-- colShapes
	
	local fastCarLSColCuboid = nil
	local fastCarLVColCuboid = nil
	local fastCarSFColCuboid = nil	

-- slowCar

local slowCarLVMarker = createMarker ( 1736.70703125, 1881.8420410156, 9.7, "cylinder", 2, 250, 134, 2 )
local slowCarLSMarker = createMarker ( 2136.79, -1121.97, 24.4, 'cylinder', 2, 250, 134, 2 )
local slowCarSFMarker = createMarker ( -1967.91, 300.25, 34.2, 'cylinder', 2, 250, 134, 2 )
table.insert ( shopMarkers, slowCarLVMarker )
table.insert ( shopMarkers, slowCarLSMarker )
table.insert ( shopMarkers, slowCarSFMarker )

	-- blips
	
	createBlipAttachedTo ( slowCarLVMarker, 55, 2, 0, 0, 0, 255, 0, 400 )
	createBlipAttachedTo ( slowCarLSMarker, 55, 2, 0, 0, 0, 255, 0, 400 )
	createBlipAttachedTo ( slowCarSFMarker, 55, 2, 0, 0, 0, 255, 0, 400 )

	-- colShapes
	
	local slowCarLSColCuboid = nil
	local slowCarLVColCuboid = nil
	local slowCarSFColCuboid = nil	
	


-- industrial

local indLVMarker = createMarker ( 615.38470458984, 1670.693359375, 6, "cylinder", 2, 250, 134, 2 )
local indLSMarker = createMarker ( 2297.46, -2329.07, 12.6, "cylinder", 2, 250, 134, 2 )
local indSFMarker = createMarker ( -1963.89, -2467.64, 29.7, 'cylinder', 2, 250, 134, 2 )
table.insert ( shopMarkers, indLVMarker )
table.insert ( shopMarkers, indLSMarker )
table.insert ( shopMarkers, indSFMarker )

	-- blips
	
	createBlipAttachedTo ( indLVMarker, 11, 2, 0, 0, 0, 255, 0, 400 )
	createBlipAttachedTo ( indLSMarker, 11, 2, 0, 0, 0, 255, 0, 400 )
	createBlipAttachedTo ( indSFMarker, 11, 2, 0, 0, 0, 255, 0, 400 )

	-- colShapes
	
	local indLSColCuboid = nil
	local indLVColCuboid = nil
	local indSFColCuboid = nil	

-- Check where the player want to buy a vehicle and in wich city
function setCurrentCity(Marker)

local oldLocation = getElementData ( localPlayer, "vehShop_location" )

	if Marker == bikesCountryMarker then
	
		setElementData ( localPlayer, "vehShop_location", "COUNTRYBIKE" )		
		
	elseif Marker == bikesLVMarker then
	
		setElementData ( localPlayer, "vehShop_location", "LVBIKE" )
		
	elseif Marker == bikesSFMarker then
	
		setElementData ( localPlayer, "vehShop_location", "SFBIKE" )				
		
	elseif Marker == boatsLSMarker then
	
		setElementData ( localPlayer, "vehShop_location", "LSBOAT" )	
		
	elseif Marker == boatsLVMarker1 or Marker == boatsLVMarker2 then
	
		setElementData ( localPlayer, "vehShop_location", "LVBOAT" )	
		
	elseif Marker == boatsSFMarker1 or Marker == boatsSFMarker2 then

		setElementData ( localPlayer, "vehShop_location", "SFBOAT" )	
		
	elseif Marker == airSFMarker then

		setElementData ( localPlayer, "vehShop_location", "SFAIR" )	
	
	elseif Marker == airLVMarker then
		
		setElementData ( localPlayer, "vehShop_location", "LVAIR" )	
		
	elseif Marker == airLSMarker then	
	
		setElementData ( localPlayer, "vehShop_location", "LSAIR" )	
		
	elseif Marker == fastCarLSMarker then	
	
		setElementData ( localPlayer, "vehShop_location", "LSFAST" )	
		
	elseif Marker == fastCarLVMarker then
	
		setElementData ( localPlayer, "vehShop_location", "LVFAST" )
		
	elseif Marker == fastCarSFMarker then
	
		setElementData ( localPlayer, "vehShop_location", "SFFAST" )		
		
	elseif Marker == slowCarLVMarker then
	
		setElementData ( localPlayer, "vehShop_location", "LVSLOW" )		

	elseif Marker == slowCarLSMarker then

		setElementData ( localPlayer, "vehShop_location", "LSSLOW" )			
		
	elseif Marker == slowCarSFMarker then

		setElementData ( localPlayer, "vehShop_location", "SFSLOW" )		

	elseif Marker == indLVMarker then

		setElementData ( localPlayer, "vehShop_location", "LVIND" )
		
	elseif Marker == indLSMarker then

		setElementData ( localPlayer, "vehShop_location", "LSIND" )
		
	elseif Marker == indSFMarker then

		setElementData ( localPlayer, "vehShop_location", "SFIND" )

	end
	
	if oldLocation == getElementData ( localPlayer, "vehShop_location" ) then --  als de city verandert is dan true anders false ( dan is die niet goed gezet )
	
		return false
		
	else
	
		return true -- ? ik betwijfel het, maar ik weet niet of dit het probleem is... dat dacht ik maar ingame returned hij wel true
		
	end	
	
end

-- Marker functions
activeShowVehicleMarker = nil
activeVehicle = nil
editVehicle = nil
buyingVehicle = false


function showRoomMarkerHit ( hitElement )

local mx, my, mz = getElementPosition ( source )
local px, py, pz = getElementPosition ( localPlayer )

	if hitElement == localPlayer then
	
		if not ( getPedOccupiedVehicle( localPlayer ) ) then
		
			if ( pz + 3 ) > mz and ( pz - 3 ) < mz then -- 
			
				if buyingVehicle == false then
				
					buyingVehicle = true
					addGUI()
					setCurrentCity(source)
					
				end

			end

		end

	end	
	
end	


	for i,marker in ipairs( shopMarkers) do
		addEventHandler ( "onClientMarkerHit", marker, showRoomMarkerHit )
	end	


-- GUI things
function playerClicked ( button, state, abX, abY, worldX, worldY, worldZ, worldElementClicked )

	if button == "left" and state == "up" and isElement(worldElementClicked) then
	
		if getElementType ( worldElementClicked ) == "vehicle" and getElementData ( worldElementClicked, "showRoomVehicle" ) == true then
		
			if checkLicense(getVehicleType(worldElementClicked), getElementModel(worldElementClicked)) then
				local vehID = getElementModel ( worldElementClicked )	
				local x,y,z = getElementPosition ( worldElementClicked )			
				if isElement(activeShowVehicleMarker) then destroyElement(activeShowVehicleMarker) end	
					activeShowVehicleMarker = createMarker ( x,y,z+8,"arrow", 2.5, 0, 255, 0 )		
				if getVehicleType(worldElementClicked) == "Boat" or getVehicleType(worldElementClicked) == "Plane" or getVehicleType(worldElementClicked) == "Helicopter" then
					attachElements ( activeShowVehicleMarker, worldElementClicked, 0, 0, 8 )
				else
					attachElements ( activeShowVehicleMarker, worldElementClicked, 0, 0, 4.5 )
				end
			
				activeVehicle = worldElementClicked		
			
			else
			
				exports.DENhelp:createNewHelpMessage( "You don't have the license for this vehicle!", 255, 0, 0 )
			
			end	
			
		end
		
	end	
	
end

function checkLicense ( vehType, vehID )

	if vehType == "Plane" and getElementData ( localPlayer, "planeLicence" ) then

		return true
	
	elseif vehType == "Helicopter" and getElementData( localPlayer, "chopperLicence" ) then
	
		return true

	elseif ( vehType == "Automobile" or vehType == "Monster Truck" ) and getElementData( localPlayer, "carLicence" ) then
	
		return true
		
	elseif ( vehType == "Bike" or vehType == "Quad" ) and getElementData( localPlayer, "bikeLicence" ) then 
	
		return true
		
	elseif vehType == "BMX" then

		return true
		
	elseif vehType == "Boat" and getElementData ( localPlayer, "boatLicence" ) then

		return true
		
	end	

return false

end

-- Toggle the cursor
function toggleCursor ()

	local state = isCursorShowing()
	showCursor ( not state )
	
end

function findShopVehicles()

local vehicles = getElementsByType("vehicle")
local shopVehicles = {}
local px, py, pz = getElementPosition(localPlayer)
	for i=1, #vehicles do
	
		if getElementData(vehicles[i], "showRoomVehicle" ) == true then
		
			local vx,vy,vz = getElementPosition(vehicles[i])
			if getDistanceBetweenPoints3D(vx,vy,vz,px,py,pz) <= 200 then
			
				local ID = getElementModel(vehicles[i])
				local price = "$"..tostring(exports.server:convertNumber( getVehiclePrice(ID) ) )
				local name = tostring(getVehicleNameFromModel(ID))
				table.insert(shopVehicles, { vx, vy, vz, price, name, vehicles[i]} )
				
			end
			
		end
		
	end
	
	return shopVehicles

end

-- Create the GUI
function addGUI ()

	addEventHandler ( "onClientClick", root, playerClicked )
	bindKey ( "B", "down", toggleCursor )
	selectVehicleWindow = guiCreateWindow(sw-313,200,313,144,"CSG ~ Vehicle Store",false)

	cursorHelp = guiCreateLabel(13,20,297,82,"Welcome to the CSG vehicle shop.\nPress B to show/hide the cursor, then select the\nvehicle you'd like to buy and click \"Select Vehicle\".\n\nIf you want to leave the shop click \"Leave Store\".",false,selectVehicleWindow)
	button_buy = guiCreateButton(9,106,144,29,"Select Vehicle",false,selectVehicleWindow)
	button_cancel = guiCreateButton(156,106,144,29,"Leave Store",false,selectVehicleWindow)
	addEventHandler ( "onClientGUIClick", root, showroom_buttons )
	checkDistanceTimer = setTimer ( checkDistance, 10000, 0 )
	shopVehicles = findShopVehicles()
	if not drawingShopVehiclesInfo then
		addEventHandler ( "onClientRender", root, drawShopVehiclesInfo )
		drawingShopVehiclesInfo = true
	end
	
end

function drawShopVehiclesInfo()
local px,py,pz = getElementPosition(localPlayer)
local x,y,z = shopVehicles[1][1], shopVehicles[1][2], shopVehicles[1][3]
	if shopVehicles then

		local px,py,pz = getElementPosition(localPlayer)
		for i=1,#shopVehicles do
	
			local x,y,z = shopVehicles[i][1], shopVehicles[i][2], shopVehicles[i][3]
		
			if isElementOnScreen(shopVehicles[i][6]) and isLineOfSightClear(px,py,pz,x,y,z,true,true,true,true,true,false,false,shopVehicles[i][6]) then
		
				local sx,sy,dist = getScreenFromWorldPosition(x,y,z)
				if sx and sy and sx-100 < sw and sy - 60 < sh then
			
					dxDrawText ( shopVehicles[i][4], sx-100,sy-60, sx, sy-45 )
					dxDrawText ( shopVehicles[i][5], sx-100,sy-40, sx, sy-25 )
				
				end
			
			end
		
		end
		
	else

		removeEventHandler ( "onClientRender", root, drawShopVehiclesInfo )
		drawingShopVehiclesInfo = false	
		
	end

end

function checkDistance ()

local posX, posY, posZ, rotZ = getEditVehiclePosition ( )
local playerX, playerY, playerZ = getElementPosition(localPlayer)

	if ( posX and posY and posZ ) and getDistanceBetweenPoints3D ( posX, posY, posZ, playerX, playerY, playerZ ) > 200 then

		exports.DENhelp:createNewHelpMessage( "You went too far away!", 255, 0, 0)
		closeGUI()

	end

end

addEvent ( "closeGUIS", true )

-- Close the GUI
function closeGUI ()

	if buyingVehicle == true then
	
		buyingVehicle = false
		if isElement(activeShowVehicleMarker) then destroyElement(activeShowVehicleMarker) end
		if isElement(cursorHelp) then destroyElement(cursorHelp) end
		unbindKey ( "B", "down", toggleCursor )
		removeEventHandler (  "onClientClick", root, playerClicked )
		if isElement(button_buy) then destroyElement(button_buy) end
		if isElement(button_cancel) then destroyElement(button_cancel) end
		removeEventHandler ( "onClientGUIClick", root, showroom_buttons )
		activeShowVehicleMarker = nil
		activeVehicle = nil
		closeEditGUI ()
		showCursor(false)
		if isElement(selectVehicleWindow) then destroyElement(selectVehicleWindow) end		
		if isTimer(checkDistanceTimer) then killTimer(checkDistanceTimer) end
		setElementData ( localPlayer, "vehShop_location", nil )
		if drawingShopVehiclesInfo then
			removeEventHandler ( "onClientRender", root, drawShopVehiclesInfo )
			drawingShopVehiclesInfo = false	
		end
		shopVehicles = nil
		
	end	
	
end

addEventHandler ( "closeGUIS", root, closeGUI )
function showroom_buttons ()

	if source == button_buy then
	
		if isElement(activeShowVehicleMarker) and activeVehicle then	
			local color1, color2, color3, color4 = getVehicleColor(activeVehicle)		
			startEditVehicle ( getElementModel(activeVehicle), color1, color2, color3, color4 )		
		else
			exports.DENhelp:createNewHelpMessage( "You must select a vehicle using B and clicking on a vehicle!", 255, 0, 0)
		end		
		
	elseif source == button_cancel then
	
		closeGUI()	
		
	end
	
end


function addEditGUI ()

window_edit_vehicle = guiCreateWindow(sw-331,sh-561,331,207,"CSG ~ Vehicle Shop",false)
vehicle_Name = guiCreateLabel(11,27,111,20,"Vehicle Name:",false,window_edit_vehicle)
guiSetFont(vehicle_Name,"default-bold-small")
vehicle_Price = guiCreateLabel(11,54,111,20,"Vehicle Price:",false,window_edit_vehicle)
guiSetFont(vehicle_Price,"default-bold-small")
vehicle_Sellprice = guiCreateLabel(11,81,111,20,"Sell Price:",false,window_edit_vehicle)
guiSetFont(vehicle_Sellprice,"default-bold-small")
vehicle_Name_Label = guiCreateLabel(128,27,111,20,"Vehicle Name:",false,window_edit_vehicle)
vehicle_Price_Label = guiCreateLabel(128,56,111,20,"Vehicle Name:",false,window_edit_vehicle)
vehicle_Sellprice_Label = guiCreateLabel(128,84,111,20,"Vehicle Name:",false,window_edit_vehicle)
button_edit_color = guiCreateButton(9,128,153,32,"Choose vehicle color",false,window_edit_vehicle)
button_edit_buy = guiCreateButton(170,128,152,32,"Buy vehicle",false,window_edit_vehicle)
button_edit_cancel = guiCreateButton(9,166,313,28,"Back",false,window_edit_vehicle)
if isElement(cursorHelp) then destroyElement(cursorHelp) end
unbindKey ( "B", "down", toggleCursor )
if isElement(button_buy) then destroyElement(button_buy) end
if isElement(button_cancel) then destroyElement(button_cancel) end
if isElement(selectVehicleWindow) then destroyElement(selectVehicleWindow) end
addEventHandler ( "onClientGUIClick", root, editButtons )
if drawingShopVehiclesInfo then
	removeEventHandler ( "onClientRender", root, drawShopVehiclesInfo )
	drawingShopVehiclesInfo = false	
end
		
end

function editButtons ()

	if source == button_edit_buy then
	
		local r1, g1, b1, r2, g2, b2, r3, g3, b3, r4, g4, b4 = getVehicleColor(editVehicle,true)
		
		local ID = getElementModel ( editVehicle )
		
		local price = getVehiclePrice ( ID )

		triggerServerEvent ( "vehShop_spawnBuyedVehicle", localPlayer, ID, r1, g1, b1, r2, g2, b2, price )
		
	elseif source == button_edit_cancel then
	
		closeEditGUI ()
		
		removeEventHandler ( "onClientClick", root, playerClicked )
		unbindKey ( "B", "down", toggleCursor )	
		removeEventHandler ( "onClientGUIClick", root, showroom_buttons )
		showCursor(false)
		
		addGUI ()
		if not drawingShopVehiclesInfo then
			addEventHandler ( "onClientRender", root, drawShopVehiclesInfo )
			drawingShopVehiclesInfo = true	
		end
		
	elseif source == button_edit_color then

		if cpicker ~= true then
		
			local r1, g1, b1, r2, g2, b2, r3, g3, b3, r4, g4, b4 = getVehicleColor(editVehicle,true)
		
			cpicker = true
			openColorPicker(editVehicle)
			
		end	
	
	end	

end

function closeEditGUI ()

	if editingVehicle == true then
	
		closeColorPicker()
		setElementDimension ( localPlayer, 0 )
		if isElement ( editingVehicle ) then destroyElement(editingVehicle) end
		editingVehicle = false
		if isElement(window_edit_vehicle) then destroyElement(window_edit_vehicle) end
		if isElement(editVehicle) then destroyElement(editVehicle) end
		
		removeEventHandler ( "onClientGUIClick", root, editButtons )
		setCameraTarget(localPlayer)
		cpicker = false
		if isTimer(editCollisionTimer) then killTimer(editCollisionTimer) end
		removeEventHandler( "onClientRender", root, rotateCameraAroundEditVehicle )
		setElementAlpha ( localPlayer, 255 )

	end	

end

-- buying it + color picker
editingVehicle = false

function getVehiclePrice (ID)

	if vehiclePriceTable[ID] then
	
		return vehiclePriceTable[ID]
		
	else
		local message = "WARNING: Could not find price for vehicle, please report the missing vehicle price for ID " .. tostring(ID) .. "."
		outputChatBox ( message, 255, 0, 0 )
		exports.DENhelp:createNewHelpMessage( message, 255, 0, 0)

		return 50000
	
	end	

end


function startEditVehicle ( ID, color1, color2, color3, color4 )

	if editingVehicle ~= true and ID and color1 and color2 and color3 and color4 then
	
		editingVehicle = true
		addEditGUI()
		
		guiSetText ( vehicle_Name_Label, getVehicleNameFromModel(ID))
		guiSetText ( vehicle_Price_Label, "$" .. exports.server:convertNumber(getVehiclePrice(ID) ))
		local sellPrice = ( getVehiclePrice(ID) - getVehiclePrice(ID) / 100 * 5 )
		guiSetText ( vehicle_Sellprice_Label, "$" .. exports.server:convertNumber(sellPrice) ) 
		local posX, posY, posZ, rotZ = getEditVehiclePosition (ID)
		editVehicle = createVehicle ( ID, posX, posY, posZ, 0, 0, rotZ )
		
		setVehicleColor ( editVehicle, color1, color2, color3, color4 )

		setElementDimension ( editVehicle, 1 )
		setElementDimension ( localPlayer, 1 )
		setElementAlpha ( localPlayer, 0 )
		setElementFrozen( editVehicle, true )
		editCollisionTimer = setTimer ( setElementCollisionsEnabled, 1500, 1, editVehicle, false )
		addEventHandler( "onClientRender", root, rotateCameraAroundEditVehicle )
		
	end	

end

local positions = {
[1]={"COUNTRYBIKE",698.9921875, -527.6708984375, 16.1875, 271.32525634766},
[2]={"LVBIKE",1942.4873046875, 2034.1689453125, 11, 178.22021484375},
[3]={"SFBIKE",-2064.7985839844, -97.725082397461, 36, 269	},
[4]={"LSBOAT",-23.8515625, -1667.6767578125, 1, 187},
[5]={"LVBOAT",2279.818359375, 478.658203125, 1, 184.66375732422},
[6]={"SFBOAT",-2189.486328125, 2457.8759765625, 1.5, 266.54611206055},
[7]={"SFAIR",-1492.5205078125, -606.2412109375, 15.5, 285},
[8]={"LVAIR",1477.62, 1258.22, 14.5, 0},
[9]={"LSAIR",2072.4189453125, -2493.9272460938, 13.546875, 90},
[10]={"LSFAST",545.07, -1254.43, 16.64, 302},
[11]={"LVFAST",2162.224609375, 1421.2333984375, 10.8203125, 41},
[12]={"SFFAST",-1634.0780029297, 1211.2263183594, 7.0390625, 223.66842651367},
[13]={"LVSLOW",1736.5439453125, 1862.0196533203, 11, 92.306419372559},
[14]={"LSSLOW",2160.86, -1137.38, 25.27, 269},
[15]={"SFSLOW",-1975.47, 288.01, 35.17, 92},
[16]={"LVIND",560.63977050781, 1664.7332763672, 8, 121.49691772461},
[17]={"LSIND",2283.18, -2330.75, 13.54, 315},
[18]={"SFIND",-1967.8, -2478.75, 30.62, 103}
}

function getEditVehiclePosition (ID)
		
	local data = getElementData ( localPlayer, "vehShop_location" )
	for i=1,#positions do
		if positions[i][1] == data then
			return positions[i][2],  positions[i][3],  positions[i][4],  positions[i][5]
		end
	end		

end

local facing = 0
function rotateCameraAroundEditVehicle( ) -- credits to 50p

	if editVehicle then
	
		local x, y, z = getElementPosition( editVehicle )

		local multiplier = 7
		local vehType =getVehicleType( editVehicle)
			if vehType == "Boat" or vehType == "Plane" or vehType == "Helicopter" then
				multiplier = 14
			elseif string.find ( getElementData ( localPlayer, "vehShop_location" ), "IND" ) then
				multiplier = 20
			end
		
		local camX = x + math.cos( facing / math.pi * 180 ) * multiplier
		local camY = y + math.sin( facing / math.pi * 180 ) * multiplier
	
		setCameraMatrix( camX, camY, z+3, x, y, z )
		facing = facing + 0.0002
		
	else	
		removeEventHandler( "onClientRender", root, rotateCameraAroundEditVehicle )
		
	end	
end