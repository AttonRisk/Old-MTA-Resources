function openColorPicker()

	if (editVehicle) then
	
		colorPicker.openSelect(colors)
		
	end
	
end

function closeColorPicker()
	
	colorPicker.closeSelect()
	
end

function closedColorPicker()

	local r1, g1, b1, r2, g2, b2 = getVehicleColor(editVehicle, true)
	setVehicleColor(editVehicle, r1, g1, b1, r2, g2, b2)
	local r, g, b = getVehicleHeadLightColor(editVehicle)
	setVehicleHeadLightColor(editVehicle, r, g, b)
	colorPicker.closeSelect()
	cpicker = false
	
end

function updateColor()
	if (not colorPicker.isSelectOpen) then return end
	local r, g, b = colorPicker.updateTempColors()
	if (editVehicle and isElement(editVehicle)) then
		local r1, g1, b1, r2, g2, b2 = getVehicleColor(editVehicle, true)
		if (guiCheckBoxGetSelected(checkColor1)) then
			r1, g1, b1 = r, g, b
		end
		if (guiCheckBoxGetSelected(checkColor2)) then
			r2, g2, b2 = r, g, b
		end
		if (guiCheckBoxGetSelected(checkColor3)) then
			setVehicleHeadLightColor(editVehicle, r, g, b)
		end
		setVehicleColor(editVehicle, r1, g1, b1, r2, g2, b2)
	end
end
addEventHandler("onClientRender", root, updateColor)