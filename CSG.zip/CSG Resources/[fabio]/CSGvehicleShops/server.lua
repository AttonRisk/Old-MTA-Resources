addEvent ( "vehShop_spawnBuyedVehicle", true )

local positions = {
[1]={"COUNTRYBIKE",698.9921875, -527.6708984375, 16.1875, 271.32525634766},
[2]={"LVBIKE",1942.4873046875, 2034.1689453125, 11, 178.22021484375},
[3]={"SFBIKE",-2064.7985839844, -97.725082397461, 36, 269	},
[4]={"LSBOAT",-23.8515625, -1667.6767578125, 1, 187},
[5]={"LVBOAT",2279.818359375, 478.658203125, 1, 184.66375732422},
[6]={"SFBOAT",-2189.486328125, 2457.8759765625, 1.5, 266.54611206055},
[7]={"SFAIR",-1492.5205078125, -606.2412109375, 15.5, 285},
[8]={"LVAIR",1477.62, 1258.22, 14.5, 0},
[9]={"LSAIR",2072.4189453125, -2493.9272460938, 13.546875, 90},
[10]={"LSFAST",545.07, -1254.43, 16.64, 302},
[11]={"LVFAST",2162.224609375, 1421.2333984375, 10.8203125, 41},
[12]={"SFFAST",-1634.0780029297, 1211.2263183594, 7.0390625, 223.66842651367},
[13]={"LVSLOW",1736.5439453125, 1862.0196533203, 11, 92.306419372559},
[14]={"LSSLOW",2160.86, -1137.38, 25.27, 269},
[15]={"SFSLOW",-1975.47, 288.01, 35.17, 92},
[16]={"LVIND",560.63977050781, 1664.7332763672, 8, 121.49691772461},
[17]={"LSIND",2283.18, -2330.75, 13.54, 315},
[18]={"SFIND",-1967.8, -2478.75, 30.62, 103}

}
setGarageOpen ( 40, true )

function getBuyVehiclePosition (player, ID)
	local data = getElementData ( player, "vehShop_location" )
	for i=1,#positions do
		if positions[i][1] == data then
			return positions[i][2],  positions[i][3],  positions[i][4],  positions[i][5]
		end
	end		

end



function spawnTheVehicle ( ID, r1, g1, b1, r2, g2, b2, price )
local maxSlots = exports.DENvehicles:getPlayerVehicleSlots(source)
	if getPlayerMoney ( source ) >= price and ID and r1 and r2 then

		if ( not exports.server:getPlayerVehicles ( source ) ) or ( #exports.server:getPlayerVehicles ( source ) < maxSlots ) then
			local posX, posY, posZ, rotZ = getBuyVehiclePosition ( source,ID )
			local playerX, playerY, playerZ = getElementPosition(source)
			if ( posX and posY and posZ ) and getDistanceBetweenPoints3D ( posX, posY, posZ, playerX, playerY, playerZ ) < 200 then
			
				takePlayerMoney ( source, price )
				local color1 = exports.server:convertRGBToHEX( r1, g1, b1 )
				local color2 = exports.server:convertRGBToHEX( r2, g2, b2 )
				local ownerID = exports.server:getPlayerAccountId(source)
				removePedJetPack ( source )
		
				exports.server:addPlayerVehicle ( source, ID, ownerID, 1000, price, color1, color2, posX, posY, posZ, rotZ )
				local playerVeh = getPedOccupiedVehicle ( source )
				setVehicleDamageProof( playerVeh, true )
				setTimer ( function(vehicle)if vehicle then setVehicleDamageProof( vehicle, false ) end end, 10000, 1, playerVeh )
				
				triggerClientEvent ( source, "closeGUIS", source )
				
			else

				exports.DENhelp:createNewHelpMessageForPlayer(source, "You are too far away!", 255, 0, 0)
				triggerClientEvent ( source, "closeGUIS", source )
				
			end	
				
		else

			exports.DENhelp:createNewHelpMessageForPlayer(source, "You can only have "..tostring(maxSlots).." vehicles!", 255, 0, 0)
			exports.DENhelp:createNewHelpMessageForPlayer(source, "Sell one to buy a new one.", 255, 0, 0)

			
		end	
			
	else

		exports.DENhelp:createNewHelpMessageForPlayer(source, "You need atleast $" .. tostring(price) .. " to buy this vehicle.", 255, 0, 0)
		
	end	

end

addEventHandler ( "vehShop_spawnBuyedVehicle", root, spawnTheVehicle )

