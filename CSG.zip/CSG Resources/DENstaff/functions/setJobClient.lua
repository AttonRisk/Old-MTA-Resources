local theJobs = { 
[1]={"SWAT"},
[2]={"Military Forces"},
[3]={"Police"},
[4]={"Mechanic"},
[5]={"Hooker"},
[6]={"Paramedic"},
[7]={"Pilot"},
[8]={"Trucker"},
[9]={"Taxi Driver"},
[10]={"Criminal"},
}

setJobWindow = guiCreateWindow(614,253,233,417,"CSG ~ Set Job",false)
setJobLabel1 = guiCreateLabel(16,29,217,15,"Playername:",false,setJobWindow)
guiSetFont(setJobLabel1,"default-bold-small")
setJobUser = guiCreateEdit(10,48,213,28,"",false,setJobWindow)
setJobGrid = guiCreateGridList(10,105,211,203,false,setJobWindow)
guiGridListSetSelectionMode(setJobGrid,0)
setJobLabel2 = guiCreateLabel(16,87,217,15,"Choose a job:",false,setJobWindow)
guiSetFont(setJobLabel2,"default-bold-small")
setJobLabel3 = guiCreateLabel(16,325,217,15,"Occupation:",false,setJobWindow)
guiSetFont(setJobLabel3,"default-bold-small")
setJobOccupation = guiCreateEdit(10,344,213,28,"",false,setJobWindow)
setJobButton = guiCreateButton(11,379,110,28,"Set Job",false,setJobWindow)
setJobClose = guiCreateButton(127,379,97,28,"Close",false,setJobWindow)
local column = guiGridListAddColumn( setJobGrid, "Job Name:", 0.69 )

for ID in pairs(theJobs) do
local row = guiGridListAddRow ( setJobGrid )
guiGridListSetItemText ( setJobGrid, row, column, theJobs[ID][1], false, true )
end

addEventHandler("onClientGUIClick", setJobClose, function() guiSetVisible(setJobWindow, false) showCursor(false) end, false)

local screenW,screenH=guiGetScreenSize()
local windowW,windowH=guiGetSize(setJobWindow,false)
local x,y = (screenW-windowW)/2,(screenH-windowH)/2
guiSetPosition(setJobWindow,x,y,false)

guiWindowSetMovable (setJobWindow, true)
guiWindowSetSizable (setJobWindow, false)
guiSetVisible (setJobWindow, false)


function showAddJobWindow ()
	if (getTeamName(getPlayerTeam(localPlayer)) == "Staff") and getElementData(localPlayer, "isPlayerStaff") then
	guiSetVisible(setJobWindow,true)
	showCursor(true,true)
	guiSetInputMode("no_binds_when_editing")
	end
end
addCommandHandler ( "setjob", showAddJobWindow )

function setOccupation ()
local selectedItem = guiGridListGetItemText ( setJobGrid, guiGridListGetSelectedItem ( setJobGrid ), 1 )
	if selectedItem then 
		if selectedItem == "SWAT" then
		guiSetText(setJobOccupation, "SWAT Team")
		guiEditSetReadOnly ( setJobOccupation, false )
		elseif selectedItem == "Military Forces" then
		guiSetText(setJobOccupation, "Military Forces")
		guiEditSetReadOnly ( setJobOccupation, false )
		elseif selectedItem == "Police" then
		guiSetText(setJobOccupation, "Police Officer")
		guiEditSetReadOnly ( setJobOccupation, true )
		elseif selectedItem == "Hooker" then
		guiSetText(setJobOccupation, "Prostitute")
		guiEditSetReadOnly ( setJobOccupation, true )
		elseif selectedItem == "Mechanic" then
		guiSetText(setJobOccupation, "Mechanic")
		guiEditSetReadOnly ( setJobOccupation, true )
		elseif selectedItem == "Paramedic" then
		guiSetText(setJobOccupation, "Paramedic")
		guiEditSetReadOnly ( setJobOccupation, true )
		elseif selectedItem == "Pilot" then
		guiSetText(setJobOccupation, "Pilot")
		guiEditSetReadOnly ( setJobOccupation, true )
		elseif selectedItem == "Trucker" then
		guiSetText(setJobOccupation, "Trucker")
		guiEditSetReadOnly ( setJobOccupation, true )
		elseif selectedItem == "Trucker" then
		guiSetText(setJobOccupation, "Trucker")
		guiEditSetReadOnly ( setJobOccupation, true )
		elseif selectedItem == "Taxi Driver" then
		guiSetText(setJobOccupation, "Taxi Driver")
		guiEditSetReadOnly ( setJobOccupation, true )
		elseif selectedItem == "Criminal" then
		guiSetText(setJobOccupation, "Criminal")
		guiEditSetReadOnly ( setJobOccupation, true )
		else
		guiSetText(setJobOccupation, "")
		guiEditSetReadOnly ( setJobOccupation, true )
		end
	end
end
addEventHandler ( "onClientGUIClick", setJobGrid, setOccupation )

addEventHandler("onClientGUIClick", setJobButton, function()
local selectedItem = guiGridListGetItemText ( setJobGrid, guiGridListGetSelectedItem ( setJobGrid ), 1 )
local getPlayer = guiGetText ( setJobUser )
local getOccupation = guiGetText ( setJobOccupation )
	if selectedItem then 
		if ( getPlayerFromName(getPlayer) ) then
			if getOccupation == "" or getOccupation == " " then
				outputChatBox("Occupation not vaild!", 225, 0, 0)
			else
				triggerServerEvent("setTheJob", localPlayer, selectedItem, getPlayer, getOccupation)
				guiSetVisible(setJobWindow, false) showCursor(false) guiSetText(setJobOccupation, "") guiSetText(setJobUser, "")
				outputChatBox("You moved " .. getPlayer .. " to the " .. selectedItem .." job!", 0, 225, 0)
			end
		else
			outputChatBox("Player doesn't exist!", 225, 0, 0)
		end		
	end
end, false)
