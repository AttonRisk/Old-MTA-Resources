function setTheJob (theJob, thePlayer, theOccupation)
	if (getTeamName(getPlayerTeam(source)) == "Staff") and getElementData(source, "isPlayerStaff") then
		if theJob == "SWAT" then
			local playerID = exports.server:playerID( source )
			setElementData(getPlayerFromName(thePlayer), "Occupation", theOccupation)
			setPlayerTeam(getPlayerFromName(thePlayer), getTeamFromName("SWAT"))
			setElementModel(getPlayerFromName(thePlayer), 285 )
			exports.DENvehicles:reloadFreeVehicleMarkers(getPlayerFromName(thePlayer), true)
			outputChatBox("You have been moved to the SWAT job by ".. getPlayerName(source) .."", getPlayerFromName(thePlayer), 225, 0, 0)
			local playerID = exports.server:playerID( source )
			local updateMysqlSkin = exports.DENmysql:exec( "UPDATE accounts SET jobskin =? WHERE id = " .. playerID, 285)
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." changed the job of ".. thePlayer .." to SWAT" )
			
			elseif theJob == "Military Forces" then
			setElementData(getPlayerFromName(thePlayer), "Occupation", theOccupation)
			setPlayerTeam(getPlayerFromName(thePlayer), getTeamFromName("Military Forces"))
			setElementModel(getPlayerFromName(thePlayer), 287 )
			exports.DENvehicles:reloadFreeVehicleMarkers(getPlayerFromName(thePlayer), true)
			outputChatBox("You have been moved to the Military Forces job by ".. getPlayerName(source) .."", getPlayerFromName(thePlayer), 225, 0, 0)
			local playerID = exports.server:playerID( source )
			local updateMysqlSkin = exports.DENmysql:exec( "UPDATE accounts SET jobskin =? WHERE id = " .. playerID, 287)
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." changed the job of ".. thePlayer .." to Military Forces" )
			
			elseif theJob == "Police" then
			setElementData(getPlayerFromName(thePlayer), "Occupation", theOccupation)
			setPlayerTeam(getPlayerFromName(thePlayer), getTeamFromName("Police"))
			setElementModel(getPlayerFromName(thePlayer), 280 )
			exports.DENvehicles:reloadFreeVehicleMarkers(getPlayerFromName(thePlayer), true)
			outputChatBox("You have been moved to the Police job by ".. getPlayerName(source) .."", getPlayerFromName(thePlayer), 225, 0, 0)
			local playerID = exports.server:playerID( source )
			local updateMysqlSkin = exports.DENmysql:exec( "UPDATE accounts SET jobskin =? WHERE id = " .. playerID, 280)
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." changed the job of ".. thePlayer .." to Police" )
			
			elseif theJob == "Mechanic" then
			setElementData(getPlayerFromName(thePlayer), "Occupation", theOccupation)
			setPlayerTeam(getPlayerFromName(thePlayer), getTeamFromName("Civilian Workers"))
			setElementModel(getPlayerFromName(thePlayer), 268 )
			exports.DENvehicles:reloadFreeVehicleMarkers(getPlayerFromName(thePlayer), true)
			outputChatBox("You have been moved to the Mechanic job by ".. getPlayerName(source) .."", getPlayerFromName(thePlayer), 225, 0, 0)
			local playerID = exports.server:playerID( source )
			local updateMysqlSkin = exports.DENmysql:exec( "UPDATE accounts SET jobskin =? WHERE id = " .. playerID, 268)
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." changed the job of ".. thePlayer .." to Mechanic" )
			
			elseif theJob == "Hooker" then
			setElementData(getPlayerFromName(thePlayer), "Occupation", theOccupation)
			setPlayerTeam(getPlayerFromName(thePlayer), getTeamFromName("Civilian Workers"))
			setElementModel(getPlayerFromName(thePlayer), 257 )
			exports.DENvehicles:reloadFreeVehicleMarkers(getPlayerFromName(thePlayer), true)
			outputChatBox("You have been moved to the Hooker job by ".. getPlayerName(source) .."", getPlayerFromName(thePlayer), 225, 0, 0)
			local playerID = exports.server:playerID( source )
			local updateMysqlSkin = exports.DENmysql:exec( "UPDATE accounts SET jobskin =? WHERE id = " .. playerID, 257)
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." changed the job of ".. thePlayer .." to Hooker" )
			
			elseif theJob == "Paramedic" then
			setElementData(getPlayerFromName(thePlayer), "Occupation", theOccupation)
			setPlayerTeam(getPlayerFromName(thePlayer), getTeamFromName("Paramedics"))
			setElementModel(getPlayerFromName(thePlayer), 275 )
			exports.DENvehicles:reloadFreeVehicleMarkers(getPlayerFromName(thePlayer), true)
			outputChatBox("You have been moved to the Paramedic job by ".. getPlayerName(source) .."", getPlayerFromName(thePlayer), 225, 0, 0)
			local playerID = exports.server:playerID( source )
			local updateMysqlSkin = exports.DENmysql:exec( "UPDATE accounts SET jobskin =? WHERE id = " .. playerID, 275)
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." changed the job of ".. thePlayer .." to Paramedic" )
			
			elseif theJob == "Pilot" then
			setElementData(getPlayerFromName(thePlayer), "Occupation", theOccupation)
			setPlayerTeam(getPlayerFromName(thePlayer), getTeamFromName("Civilian Workers"))
			setElementModel(getPlayerFromName(thePlayer), 255 )
			exports.DENvehicles:reloadFreeVehicleMarkers(getPlayerFromName(thePlayer), true)
			outputChatBox("You have been moved to the Pilot job by ".. getPlayerName(source) .."", getPlayerFromName(thePlayer), 225, 0, 0)
			local playerID = exports.server:playerID( source )
			local updateMysqlSkin = exports.DENmysql:exec( "UPDATE accounts SET jobskin =? WHERE id = " .. playerID, 255)
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." changed the job of ".. thePlayer .." to Pilot" )
			
			elseif theJob == "Trucker" then
			setElementData(getPlayerFromName(thePlayer), "Occupation", theOccupation)
			setPlayerTeam(getPlayerFromName(thePlayer), getTeamFromName("Civilian Workers"))
			setElementModel(getPlayerFromName(thePlayer), 261 )
			exports.DENvehicles:reloadFreeVehicleMarkers(getPlayerFromName(thePlayer), true)
			outputChatBox("You have been moved to the Trucker job by ".. getPlayerName(source) .."", getPlayerFromName(thePlayer), 225, 0, 0)
			local playerID = exports.server:playerID( source )
			local updateMysqlSkin = exports.DENmysql:exec( "UPDATE accounts SET jobskin =? WHERE id = " .. playerID, 261)
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." changed the job of ".. thePlayer .." to Trucker" )
			
			elseif theJob == "Taxi Driver" then
			setElementData(getPlayerFromName(thePlayer), "Occupation", theOccupation)
			setPlayerTeam(getPlayerFromName(thePlayer), getTeamFromName("Civilian Workers"))
			setElementModel(getPlayerFromName(thePlayer), 307 )
			exports.DENvehicles:reloadFreeVehicleMarkers(getPlayerFromName(thePlayer), true)
			outputChatBox("You have been moved to the Taxi Driver job by ".. getPlayerName(source) .."", getPlayerFromName(thePlayer), 225, 0, 0)
			local playerID = exports.server:playerID( source )
			local updateMysqlSkin = exports.DENmysql:exec( "UPDATE accounts SET jobskin =? WHERE id = " .. playerID, 307)
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." changed the job of ".. thePlayer .." to Taxi Driver" )
			
			elseif theJob == "Criminal" then
			local playerID = exports.server:playerID( getPlayerFromName(thePlayer) )
			local crimCheck = exports.DENmysql:querySingle( "SELECT * FROM accounts WHERE id = '" .. playerID .. "'" )
			setElementData(getPlayerFromName(thePlayer), "Occupation", theOccupation)
			setPlayerTeam(getPlayerFromName(thePlayer), getTeamFromName("Criminals"))
			setElementModel(getPlayerFromName(thePlayer), crimCheck.skin )
			exports.DENvehicles:reloadFreeVehicleMarkers(getPlayerFromName(thePlayer), true)
			outputChatBox("You have been moved to the Criminal job by ".. getPlayerName(source) .."", getPlayerFromName(thePlayer), 225, 0, 0)
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." changed the job of ".. thePlayer .." to Criminal" )
			
			triggerEvent( "onPlayerTeamChange", source, oldTeam, nil )
		end
	end
end
addEvent("setTheJob", true)
addEventHandler("setTheJob", root, setTheJob )