eventMarker = {}
eventMarkerBlip = {}

function theeventmarker(thePlayer)
	StaffTeam = getTeamFromName("Staff")
	playerteam = getPlayerTeam(thePlayer)
	if (playerteam == StaffTeam) then
		if not (eventMarker[thePlayer]) then 
			local x,y,z = getElementPosition(thePlayer)
			eventMarker[thePlayer] = createMarker(x, y, z)
			setMarkerColor(eventMarker[thePlayer], 0, 0, 255, 0)
			eventMarkerBlip[thePlayer] = createBlipAttachedTo(eventMarker[thePlayer], 49)
			setElementDimension( eventMarker[thePlayer], getElementDimension( thePlayer ) )
			setElementDimension( eventMarkerBlip[thePlayer], getElementDimension( thePlayer ) )
			outputChatBox("EVENT: An event marker is placed!",getRootElement(), 0, 255, 0)
		else 
			outputChatBox("There is already a marker",thePlayer, 255, 0, 0)
		end
	end
end
addCommandHandler("eventmarker", theeventmarker)

function destroymarker(thePlayer)
theMarkerData =	getElementData(thePlayer, "temp.marker")
if eventMarker[thePlayer] then
	destroyElement(eventMarker[thePlayer])
	destroyElement(eventMarkerBlip[thePlayer])
	eventMarker[thePlayer] = nil
	eventMarkerBlip[thePlayer] = nill
else
	outputChatBox("There are no marker!", thePlayer, 255,0,0)
	end
end
addCommandHandler("destroymarker", destroymarker)