function nickChangeHandler(oldNick, newNick)
	if ( string.len ( newNick ) < 19 ) then
	local theTeam = getTeamFromName("Staff")
	local teamPlayers = getPlayersInTeam(theTeam)
		for i, playerValue in ipairs(teamPlayers) do
			local reportChange = exports.killmessages:outputMessage("".. oldNick .. " is now known as ".. newNick .."", playerValue, 225, 0, 0)
		end
	end
end
addEventHandler("onPlayerChangeNick", root, nickChangeHandler)

function outputMessageForStaff ( theMessage, r, g, b )
	local theTeam = getTeamFromName("Staff")
	local teamPlayers = getPlayersInTeam(theTeam)
	for i, playerValue in ipairs(teamPlayers) do
		exports.killmessages:outputMessage( theMessage, playerValue, r, g, b )
	end
end

addEventHandler( "onPlayerWasted", root,
function ( ammo, attacker, weapon, bodypart )
	local x, y, z = getElementPosition( source )
	if ( attacker ) and ( isElement( attacker ) ) and not ( attacker == source ) then
		if ( getElementType ( attacker ) == "vehicle" ) then if ( getVehicleController( attacker ) ) then attacker = getVehicleController( attacker ) else attacker = false end end
		if ( getPlayerTeam( attacker ) ) and ( getPlayerTeam( source ) ) then
			if not ( getZoneName( x, y, z, true ) == "Las Venturas" ) and not ( getTeamName( getPlayerTeam( attacker ) ) == "Staff" ) then
				if ( getTeamName( getPlayerTeam( attacker ) ) == "SWAT" ) or ( getTeamName( getPlayerTeam( attacker ) ) == "Police" ) or ( getTeamName( getPlayerTeam( attacker ) ) == "Military Forces" ) or ( getTeamName( getPlayerTeam( attacker ) ) == "Department of Defense" ) then
					if ( getElementData( source, "wantedPoints" ) < 9 ) then
						outputMessageForStaff( "".. getPlayerName( attacker ) .. " possibly deathmatched ".. getPlayerName( source ) .."", 225, 0, 0 )
					end
				elseif ( getTeamName( getPlayerTeam( attacker ) ) == "Criminals" ) then
					if ( getTeamName( getPlayerTeam( source ) ) == "Civilian Workers" ) or ( getTeamName( getPlayerTeam( source ) ) == "Unoccupied" ) or ( getTeamName( getPlayerTeam( source ) ) == "Paramedics" ) or ( getTeamName( getPlayerTeam( source ) ) == "Unemployed" ) then
						outputMessageForStaff( "".. getPlayerName( attacker ) .. " possibly deathmatched ".. getPlayerName( source ) .."", 225, 0, 0 )
					end
				elseif ( getTeamName( getPlayerTeam( attacker ) ) == "Civilian Workers" ) or ( getTeamName( getPlayerTeam( attacker ) ) == "Unoccupied" ) or ( getTeamName( getPlayerTeam( attacker ) ) == "Paramedics" ) or ( getTeamName( getPlayerTeam( attacker ) ) == "Unemployed" ) then
					outputMessageForStaff( "".. getPlayerName( attacker ) .. " possibly deathmatched ".. getPlayerName( source ) .."", 225, 0, 0 )
				end
			end
		end
	end
end
)