function stopDamage ( attacker, weapon, bodypart, loss )
	if ( getPlayerTeam ( source ) ) then
		if ( getTeamName ( getPlayerTeam ( source ) ) == "Staff" ) then
			cancelEvent()
		end
		
		if ( attacker ) then
			if ( getPlayerTeam ( attacker ) ) then
				if ( attacker ~= source ) and not ( getTeamName ( getPlayerTeam ( attacker ) ) == "Staff" ) then
					setElementHealth( attacker, getElementHealth( attacker ) -loss )
				end
			end
		end
    end
end
addEventHandler ( "onClientPlayerDamage", localPlayer, stopDamage )

txd2 = engineLoadTXD ( "staffskin/wfyclot.txd" )
engineImportTXD ( txd2,211)

txd = engineLoadTXD ( "staffskin/wmyclot.txd" )
engineImportTXD ( txd,217)
dff = engineLoadDFF ( "staffskin/wmyclot.dff",217)
engineReplaceModel ( dff,217)