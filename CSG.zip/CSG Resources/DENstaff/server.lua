function onPlayerEnterStaffJob ( thePlayer )
	local rankTable = { [1]="Assistant Staff", [2]="New Staff", [3]="Loyal Staff", [4]="Experienced Staff", [5]="Important Staff", [6]="Leading Staff" }
	
	if ( getTeamName( getPlayerTeam( thePlayer ) ) == "Staff" ) then staff = 1 else staff = 0 end
	
	local oldOccupation = getElementData( thePlayer, "Occupation" )
	local playerID = exports.server:playerID( thePlayer )
	local staffCheck = exports.DENmysql:querySingle( "SELECT * FROM staff WHERE userid = ?", playerID )
	if ( staffCheck ) and ( rankTable[tonumber(staffCheck.level)] ) then
		local oldTeam = getTeamName(getPlayerTeam(thePlayer))
	
		setPlayerTeam ( thePlayer, getTeamFromName("Staff") )
		setElementData( thePlayer, "Occupation", rankTable[tonumber(staffCheck.level)], true )
			
		exports.DENlogging:writeStaffLog( thePlayer, getPlayerName( thePlayer ).." enterd the staff job with ".. getPlayerWantedLevel( thePlayer ) .." stars" )
			
		if ( tonumber(staffCheck.gender) == 0 ) then
			setElementModel ( thePlayer, 217 )
			MySQL = exports.DENmysql:exec( "UPDATE accounts SET jobskin = 217 WHERE id = " .. playerID)
			
		elseif ( tonumber(staffCheck.gender) == 1 ) then
			setElementModel ( thePlayer, 211 )
			MySQL = exports.DENmysql:exec( "UPDATE accounts SET jobskin = 211 WHERE id = " .. playerID)
		end
			
		setElementHealth ( thePlayer, 100 )
		setPlayerWantedLevel ( thePlayer, 0 )
		setElementData(thePlayer, "wantedPoints", 0)
		exports.DENvehicles:reloadFreeVehicleMarkers(thePlayer, true)
			
		if ( "Staff" ~= oldTeam ) then
			triggerEvent( "onPlayerTeamChange", thePlayer, oldTeam, "Staff" )
		end
		
		triggerEvent( "onPlayerJobChange", thePlayer, rankTable[tonumber(staffCheck.level)], oldOccupation, getPlayerTeam( thePlayer ) )

		if ( staff == 0 ) then
			exports.DENhelp:createNewHelpMessageForPlayer(thePlayer, "You have entered the staff job!", 0, 200, 0)
		end
	end
end
addCommandHandler ( "staff", onPlayerEnterStaffJob )

function onStaffInvisable( thePlayer )
	if ( getTeamName( getPlayerTeam( thePlayer ) ) == "Staff" ) and ( exports.server:isPlayerStaff( thePlayer ) ) then
		if getElementAlpha( thePlayer ) == 255 then
			setPlayerNametagShowing(thePlayer, false)
			setElementAlpha(thePlayer, 0)
			exports.DENlogging:writeStaffLog( thePlayer, getPlayerName( thePlayer ).." enterd the staffinvis job" )
		else
			setPlayerNametagShowing(thePlayer, true)
			setElementAlpha(thePlayer, 255)
		end
	end
end
addCommandHandler ( "invis", onStaffInvisable )

function onStaffNote ( thePlayer, _, ... )
	if ( exports.server:isPlayerStaff( thePlayer ) ) then
		local text = table.concat( {...}, " " )
		local name = getPlayerName( thePlayer )
		local accName = getAccountName ( getPlayerAccount ( thePlayer ) )
		for _, v in pairs(getElementsByType("player")) do
			outputChatBox ("#FF0000(NOTE) "..tostring( name )..": #FFFFFF"..tostring( text ), v, 255, 255, 255, true)
		end
		triggerEvent( "onServerNote", thePlayer, tostring( text ) )
		exports.DENlogging:writeChatlog(thePlayer, "Notes", text)
    end
end
addCommandHandler( "note", onStaffNote )

function onStaffDamageProofCar ( thePlayer )
	if (getTeamName(getPlayerTeam(thePlayer)) == "Staff") then
		local vehicle = getPedOccupiedVehicle (thePlayer)
		if ( vehicle ) then
			if ( isVehicleDamageProof(vehicle) == false ) then
				setVehicleDamageProof(vehicle, true)
				outputChatBox("Vehicle is now made damage proof!", thePlayer, 0, 225, 0, false)
				local staffName = getPlayerName ( thePlayer )
				exports.DENlogging:writeStaffLog( thePlayer, getPlayerName( thePlayer ).." made his vehicle damageproof" )
			else
				setVehicleDamageProof(vehicle, false)
				outputChatBox("Vehicle is no longer damage proof!", thePlayer, 225, 0, 0, false)

			end
		else
			outputChatBox("You are not in a vehicle, failed to make vehicle damage proof!", thePlayer, 225, 0, 0, false)
		end
	end
end
addCommandHandler( "dmgproof", onStaffDamageProofCar )

function adminChat( thePlayer,_,... )
	if ( exports.server:isPlayerStaff( thePlayer ) ) then
		local text = table.concat( {...}, " " )
		local name = getPlayerName( thePlayer )
		local time = getRealTime()
		for _,v in pairs( getOnlineStaffPlayers() ) do
			outputChatBox ("#FF0000(CSG) "..tostring( name )..": #FFFFFF"..tostring( text ), v, 255, 255, 255, true)
			exports.DENadmin:onStaffChatMessage( v, thePlayer, tostring( text ), time.timestamp )
		end
		exports.DENlogging:writeChatlog(thePlayer, "CSG", text)
	end
end
addCommandHandler( "csg", adminChat )
addCommandHandler( "staffchat", adminChat )
   
function getOnlineStaffPlayers ()
    local Table = { }
    for k, thePlayer in pairs( getElementsByType( "player" ) ) do
        if ( exports.server:isPlayerStaff( thePlayer ) ) then
            table.insert( Table, thePlayer )    
        end
    end
    return Table
end

function minigunCommand (thePlayer)
	if ( exports.server:isPlayerStaff( thePlayer ) ) then
		local playerID = exports.server:playerID( thePlayer )
		local staffCheck = exports.DENmysql:querySingle( "SELECT * FROM staff WHERE userid = '" .. playerID .. "'" )
		if staffCheck then
			if (getTeamName(getPlayerTeam(thePlayer)) == "Staff") then
				if tonumber(staffCheck.level) == 5 or tonumber(staffCheck.level) == 6 then
					giveWeapon (thePlayer, 38, 1500, true)
					local staffName = getPlayerName ( thePlayer )
					exports.DENlogging:writeStaffLog( thePlayer, getPlayerName( thePlayer ).." gave himself a minigun with the /minigun command" )
				end
			end
		end
	end
end
addCommandHandler("minigun",minigunCommand)

function deleteMinigun ()
	if not (getTeamName(getPlayerTeam(source)) == "Staff") then
		if ( takeWeapon ( source, 38 ) ) then
			outputChatBox("Your minigun is deleted due possible abuse, you can only use it in staff job!", source, 225, 0, 0, false)
		end
	end
end
addEventHandler ( "onPlayerWeaponSwitch", getRootElement(), deleteMinigun )

function kickPlayerHandler ( sourcePlayer, commandname, reason )
	if ( exports.server:isPlayerStaff( sourcePlayer ) ) then
		if not reason then
			outputChatBox ("WARNING: Use /kickall [Reason] (1= Server restart, 2= Please connect again)", sourcePlayer, 225,0,0)
		else
			local playerID = exports.server:playerID( sourcePlayer )
			local staffCheck = exports.DENmysql:querySingle( "SELECT * FROM staff WHERE userid = '" .. playerID .. "'" )
			if staffCheck then
				if (getTeamName(getPlayerTeam(sourcePlayer)) == "Staff") then
					if tonumber(staffCheck.level) == 6 then
					local players = getElementsByType ( "player" )
						for theKey,thePlayer in ipairs(players) do		
							if tonumber(reason) == 1 then
								kickPlayer ( thePlayer, "Server", "The server is being restarted, come back in 30 secs." )
							end
							
							if tonumber(reason) == 2 then
								kickPlayer ( thePlayer, "Server", "Disconnected, try to connect again." )
							else
								outputChatBox ("WARNING: Use /kickall [Reason] (1= Server restart, 2= Please connect again)", sourcePlayer, 225,0,0)
							end
						end
					end
				end
			end
		end
	end
end
addCommandHandler ( "kickall", kickPlayerHandler )