-----------------------------------

       Mod Shop v1.4.2 by 50p

-----------------------------------


INSTALLATION:
--------------
1. To install it on your server, just copy and place this zip file to "$server/resources" (where $server is your server's directory)
2. Start your server
3. Type "/start modshop" (in chatbox in-game) or "start modshop" (in server console or console in-game) (without " ", of course)
4. The only one thing left, which is: enjoy!



Note: You can change all the prices to whatever you like.