addEventHandler ( "onResourceStart", getResourceRootElement(getThisResource()),
	function ()
		for _,weaponSkill in ipairs({"poor","std","pro"}) do
			-- MP5 move, aim and fire at the same time and crouching when aim
			setWeaponProperty ( "mp5", weaponSkill, "flags", 0x002000 )
			setWeaponProperty ( "mp5", weaponSkill, "flags", 0x000020 )
			setWeaponProperty ( "mp5", weaponSkill, "flags", 0x000010 )
			-- AK47 move, aim and fire at the same time and crouching when aim
			setWeaponProperty ( "ak47", weaponSkill, "flags", 0x002000 )
			setWeaponProperty ( "ak47", weaponSkill, "flags", 0x000020 )
			setWeaponProperty ( "ak47", weaponSkill, "flags", 0x000010 )
			-- SHOTGUN move, aim and fire at the same time
			setWeaponProperty ( "shotgun", weaponSkill, "flags", 0x000020 )
			setWeaponProperty ( "shotgun", weaponSkill, "flags", 0x000010 )
			-- UZI move, aim and fire at the same time
			setWeaponProperty ( "uzi", weaponSkill, "flags", 0x002000 )
			setWeaponProperty ( "uzi", weaponSkill, "flags", 0x000020 )
			setWeaponProperty ( "uzi", weaponSkill, "flags", 0x000010 )
			-- TEC9 move, aim and fire at the same time
			setWeaponProperty ( "tec9", weaponSkill, "flags", 0x002000 )
			setWeaponProperty ( "tec9", weaponSkill, "flags", 0x000020 )
			setWeaponProperty ( "tec9", weaponSkill, "flags", 0x000010 )
			-- DESSERT EAGLE move, aim and fire at the same time
			setWeaponProperty ( "desert_eagle", weaponSkill, "flags", 0x002000 )
			setWeaponProperty ( "desert_eagle", weaponSkill, "flags", 0x000020 )
			setWeaponProperty ( "desert_eagle", weaponSkill, "flags", 0x000010 )
			-- SPAS move, aim and fire at the same time
			setWeaponProperty ( "spas12_shotgun", weaponSkill, "flags", 0x000020 )
			setWeaponProperty ( "spas12_shotgun", weaponSkill, "flags", 0x000010 )
			-- SAWNOFF move, aim and fire at the same time
			setWeaponProperty ( "sawnoff_shotgun", weaponSkill, "flags", 0x000020 )
			setWeaponProperty ( "sawnoff_shotgun", weaponSkill, "flags", 0x000010 )    
			-- PISTOL move, aim and fire at the same time and crouching when aim
			setWeaponProperty ( "pistol", weaponSkill, "flags", 0x002000 )
			setWeaponProperty ( "pistol", weaponSkill, "flags", 0x000020 )    
			setWeaponProperty ( "pistol", weaponSkill, "flags", 0x000010 )    
			-- SILENCED move, aim and fire at the same time and crouching when aim
			setWeaponProperty ( "silenced_pistol", weaponSkill, "flags", 0x002000 ) 
		end
	end
)