addEvent ( "enterCriminalJob", true )
function setPlayerCriminal ( thePlayer )
	local thePlayer = thePlayer or source
	local playerID = exports.server:playerID( thePlayer )
	local oldTeam = getPlayerTeam( thePlayer )
	local playerData = exports.DENmysql:querySingle( "SELECT * FROM accounts WHERE id=? LIMIT 1", playerID )
	if ( playerData ) then
		setElementData( thePlayer, "Occupation", "Criminal", true )
		setPlayerTeam ( thePlayer, getTeamFromName ( "Criminals" ) )
		setElementModel ( thePlayer, tonumber( playerData.skin ) )
		
		if ( tonumber( playerData.skin ) == 0 ) then
			local CJCLOTTable = fromJSON( tostring( playerData.cjskin ) )
			if CJCLOTTable then
				for theType, index in pairs( CJCLOTTable ) do
					local texture, model = getClothesByTypeIndex ( theType, index )
					addPedClothes ( thePlayer, texture, model, theType )
				end
			end
		end
		
		if ( getTeamName( oldTeam ) ~= "Criminals" ) then
			triggerEvent( "onPlayerTeamChange", thePlayer, oldTeam, getTeamFromName ( "Criminals" ) )
		end
		
		triggerEvent( "onPlayerJobChange", thePlayer, "Criminal", getTeamFromName ( "Criminals" ) )
		
		exports.DENvehicles:reloadFreeVehicleMarkers( thePlayer, true )
		exports.DENhelp:createNewHelpMessageForPlayer( thePlayer, "You are now a criminal!", 200, 0, 0 )
		return true
	else
		return false
	end
end
addEventHandler ( "enterCriminalJob", root, setPlayerCriminal )

function givePlayerCJClothes ( thePlayer )
	local playerID = exports.server:playerID( thePlayer )
	local playerData = exports.DENmysql:querySingle( "SELECT * FROM accounts WHERE id=? LIMIT 1", playerID )
	if ( playerData ) then
		setElementModel ( thePlayer, 0 )
			
		local CJCLOTTable = fromJSON( tostring( playerData.cjskin ) )
		if CJCLOTTable then
			for theType, index in pairs( CJCLOTTable ) do
				local texture, model = getClothesByTypeIndex ( theType, index )
				addPedClothes ( thePlayer, texture, model, theType )
			end
		end
		return true
	else
		return false
	end
end