local lastSync = nil

addEvent ("onSetClientPlayerStats", true)
function onSetClientPlayerStats ( statsTable )
	playerStats = statsTable
end
addEventHandler ("onSetClientPlayerStats", root, onSetClientPlayerStats)

function getPlayerStats ( theStat )
	if ( isElement( localPlayer ) ) then
		if ( playerStats ) and ( playerStats[theStat] ) then
			return playerStats[theStat]
		else
			return false
		end
	else
		return false
	end
end

function forcePlayerStatsSync ()
	if ( lastSync ) and ( getTickCount()-lastSync < 10000 ) then
		return false
	else
		triggerServerEvent( "onForcePlayerStatsSync", localPlayer )
		lastSync = getTickCount()
		return true
	end
end