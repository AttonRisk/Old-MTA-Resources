local playerStats = {}

addEventHandler("onServerPlayerLogin", root,
function()
	local playerID = exports.server:playerID( source )
    local theStats = exports.DENmysql:querySingle( "SELECT * FROM playerstats WHERE userid = '" .. playerID .. "'" )
	if ( theStats ) then
		playerStats[source] = theStats
		syncPlayerStats ( source, true )
	else
		onCreateStatsTable( source )
	end
end
)

function onCreateStatsTable( source )
	if not ( playerStats[source] ) then
		local playerID = exports.server:playerID( source )
		local createTable = exports.DENmysql:exec("INSERT INTO playerstats SET userid='" .. playerID .. "'")
		if ( createTable ) then
			local theStats = exports.DENmysql:querySingle( "SELECT * FROM playerstats WHERE userid = '" .. playerID .. "'" )
			playerStats[source] = theStats
			syncPlayerStats ( source, true )
		end
	end
end

addEventHandler("onPlayerQuit", root,
function()
	if ( playerStats[source] ) then
		local playerID = exports.server:playerID( source )
		local updateStats = exports.DENmysql:exec("UPDATE playerstats SET weaponskills=?, arrests=?, arrestpoints=?, pilot=?, paramedic=?, firefighter=?, wastecollector=?, busdriver=?, busdriverstat=?, mechanic=?, hooker=?, trucker=?, electrician=?, fishstat=? WHERE userid=?"
			,playerStats[source].weaponskills
			,playerStats[source].arrests
			,playerStats[source].arrestpoints
			,playerStats[source].pilot
			,playerStats[source].paramedic
			,playerStats[source].firefighter
			,playerStats[source].wastecollector
			,playerStats[source].busdriver
			,playerStats[source].busdriverstat
			,playerStats[source].mechanic
			,playerStats[source].hooker
			,playerStats[source].trucker
			,playerStats[source].electrician
			,playerStats[source].fishstat
			,playerID 
		)
		if ( updateStats ) then
			playerStats[source] = {}
		end
	end
end
)

function updatePlayerStats ( thePlayer, theStat, theValue, sync )
	if ( isElement( thePlayer ) ) then
		if ( playerStats[thePlayer] ) and ( playerStats[thePlayer][theStat] ) then
			if ( theValue ) then
				playerStats[thePlayer][theStat] = playerStats[thePlayer][theStat] +tonumber(theValue)
				syncPlayerStats ( thePlayer, sync )
				return true
			else
				return false
			end
		else
			return false
		end
	else
		return false
	end
end

function getPlayerStats ( thePlayer, theStat )
	if ( isElement( thePlayer ) ) then
		if ( playerStats[thePlayer] ) and ( playerStats[thePlayer][theStat] ) then
			if ( theStat == "weaponskills" ) then
				return fromJSON(playerStats[thePlayer][theStat])
			else
				return playerStats[thePlayer][theStat]
			end
		else
			return false
		end
	else
		return false
	end
end

function setPlayerStats ( thePlayer, theStat, theValue, sync )
	if ( isElement( thePlayer ) ) then
		if ( playerStats[thePlayer] ) and ( playerStats[thePlayer][theStat] ) then
			if ( theValue ) then
				playerStats[thePlayer][theStat] = theValue
				syncPlayerStats ( thePlayer, sync )
				return true
			else
				return false
			end
		else
			return false
		end
	else
		return false
	end
end

function syncPlayerStats ( thePlayer, sync )
	if ( isElement( thePlayer ) ) then
		if ( playerStats[thePlayer] ) then
			if ( sync == nil ) or ( sync == true ) or ( sync ) then
				triggerClientEvent( thePlayer, "onSetClientPlayerStats", thePlayer, playerStats[thePlayer] )
			end
		end
	end
end

addEvent ("onForcePlayerStatsSync", true)
function onForcePlayerStatsSync ()
	syncPlayerStats ( source, true )
end
addEventHandler ("onForcePlayerStatsSync", root, onForcePlayerStatsSync)