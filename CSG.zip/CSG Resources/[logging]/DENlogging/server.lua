-- Player account log, saved with date, serial and nickname
function writePlayerLog(thePlayer, text)
	if ( thePlayer ) and ( text ) then
		local theAccountName = exports.server:getPlayerAccountName(thePlayer)
		if ( theAccountName ) then theAccountName = theAccountName else theAccountName = "Error while retrieving!" end
		if not fileExists("logs/accountlogs/"..theAccountName..".log") then fileCreate("logs/accountlogs/"..theAccountName..".log") end
		
		local log = fileOpen("logs/accountlogs/"..theAccountName..".log")
		if ( log ) then
			local time = getRealTime()
			fileSetPos(log,fileGetSize(log))
			fileWrite(log,timestampConvert(time.timestamp),text," (SERIAL: "..getPlayerSerial(thePlayer)..")"," (NICK: "..getPlayerName(thePlayer)..")","\r\n")
			fileFlush(log)
			fileClose(log)
		end
	end
end

-- Staff log
function writeStaffLog(thePlayer, text)
	if ( thePlayer ) and ( text ) then
		local theAccountName = exports.server:getPlayerAccountName(thePlayer)
		if ( theAccountName ) then theAccountName = theAccountName else theAccountName = "Error while retrieving!" end
		if not fileExists("logs/stafflogs/staffactions/"..theAccountName..".log") then fileCreate("logs/stafflogs/staffactions/"..theAccountName..".log") end
		
		local log = fileOpen("logs/stafflogs/staffactions/"..theAccountName..".log")
		if ( log ) then
			local time = getRealTime()
			fileSetPos(log,fileGetSize(log))
			fileWrite(log,timestampConvert(time.timestamp),text," (SERIAL: "..getPlayerSerial(thePlayer)..")","\r\n")
			fileFlush(log)
			fileClose(log)
		end
	end
end

-- Joinquit loga
function writeMiscLogMessage( text, logType )
	if ( text ) then
		-- The current time data
		local time = getRealTime(timeStamp)
		local year = time.year + 1900
		local month = time.month + 1
		local day = time.monthday
		local hour = time.hour
		local minute = time.minute
		
		local daysTable = {"1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"}
		local monthsTable = {"January","February","March","April","May","June","July","August","September","October","November","December"}
		local theDay = daysTable[day]
		local theMonth = monthsTable[month]
	
		-- Write the data
		local filePath = "logs/"..tostring(logType).."/"..tostring(year).."/"..tostring(theMonth).."/"..tostring(theDay).."/"..tostring(hour) ..";00/"..tostring(logType)..".log"
		
		if not fileExists(filePath) then fileCreate(filePath) end
		
		local log = fileOpen(filePath)
		if ( log ) then
			local time = getRealTime()
			fileSetPos(log,fileGetSize(log))
			fileWrite(log,timestampConvert(time.timestamp),text,"\r\n")
			fileFlush(log)
			fileClose(log)
		end
	end
end

function writeKillMessageLog ( ammo, attacker, weapon, bodypart )
	if ( attacker ) and ( source ) and ( getPlayerTeam ( source ) ) then
		-- The current time data
		local time = getRealTime(timeStamp)
		local year = time.year + 1900
		local month = time.month + 1
		local day = time.monthday
		local hour = time.hour
		local minute = time.minute
		
		local daysTable = {"1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"}
		local monthsTable = {"January","February","March","April","May","June","July","August","September","October","November","December"}
		local theDay = daysTable[day]
		local theMonth = monthsTable[month]
	
		-- Write the data
		local filePath = "logs/killmessages/"..tostring(year).."/"..tostring(theMonth).."/"..tostring(theDay).."/"..tostring(hour) ..";00.log"
		
		if not fileExists(filePath) then fileCreate(filePath) end
		
		if ( getElementType ( attacker ) == "player" ) and ( getPlayerTeam ( attacker ) ) then		
			tempString = getPlayerName ( attacker ).." (" .. getTeamName ( getPlayerTeam ( attacker ) ) ..") killed "..getPlayerName ( source ).." (" .. getTeamName ( getPlayerTeam ( source ) ) ..") ("..getWeaponNameFromID ( weapon )..")"
		elseif ( getElementType ( attacker ) == "vehicle" ) and ( getVehicleController ( attacker ) ) and ( getPlayerTeam ( getVehicleController ( attacker ) ) ) then
			tempString = getPlayerName ( getVehicleController ( attacker ) ).." (" .. getTeamName ( getPlayerTeam ( getVehicleController ( attacker ) ) ) ..") killed "..getPlayerName ( source ).." (" .. getTeamName ( getPlayerTeam ( source ) ) ..") ("..getWeaponNameFromID ( weapon )..")"
		else
			tempString = false
		end
		
		if ( tempString ) then
			local log = fileOpen(filePath)
			if ( log ) then
				local time = getRealTime()
				fileSetPos(log,fileGetSize(log))
				fileWrite(log,timestampConvert(time.timestamp),tempString,"\r\n")
				fileFlush(log)
				fileClose(log)
			end
		else
			return
		end
	end
end
addEventHandler ( "onPlayerWasted", root, writeKillMessageLog )

-- Player account log, saved with date, serial and nickname
function writeChatlog(thePlayer, chatType, text, group)
	-- The current time data
	local time = getRealTime(timeStamp)
	local year = time.year + 1900
	local month = time.month + 1
	local day = time.monthday
	local hour = time.hour
	local minute = time.minute

	if ( thePlayer ) and ( chatType ) and ( text ) then
		local theAccountName = exports.server:getPlayerAccountName( thePlayer )
		if ( theAccountName ) then theAccountName = theAccountName else theAccountName = "Error while retrieving!" end
		local thePlayerNick = getPlayerName ( thePlayer )
		
		local daysTable = {"1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"}
		local monthsTable = {"January","February","March","April","May","June","July","August","September","October","November","December"}
		local theDay = daysTable[day]
		local theMonth = monthsTable[month]
		
		local filePath = "logs/chatlogs/"..tostring(chatType).."/"..tostring(year).."/"..tostring(theMonth).."/"..tostring(theDay).."/"..tostring(hour) ..";00.log"
		
		if ( group ) then
			filePath = "logs/chatlogs/"..tostring(chatType).."/"..tostring(group).."/"..tostring(year).."/"..tostring(theMonth).."/"..tostring(theDay).."/"..tostring(hour) ..";00.log"
		elseif ( chatType == "Localchat" ) then
			filePath = "logs/chatlogs/"..tostring(chatType).."/"..tostring(year).."/"..tostring(theMonth).."/"..tostring(theDay).."/"..tostring(hour) ..";00.log"
		elseif ( chatType == "SMS" ) then
			filePath = "logs/chatlogs/"..tostring(chatType).."/"..tostring(year).."/"..tostring(theMonth).."/"..tostring(theDay).."/"..tostring(hour) ..";00/"..tostring(theAccountName)..".log"
		elseif ( chatType == "CSG" ) then
			filePath = "logs/stafflogs/staffchat/"..tostring(chatType).."/"..tostring(year).."/"..tostring(theMonth).."/"..tostring(theDay).."/"..tostring(hour) ..";00.log"
		elseif ( chatType == "Notes" ) then
			filePath = "logs/stafflogs/staffnotes/"..tostring(chatType).."/"..tostring(year).."/"..tostring(theMonth).."/"..tostring(theDay).."/"..tostring(hour) ..";00.log"
		end
		
		if not fileExists(filePath) then fileCreate(filePath) end
		
		local log = fileOpen(filePath)
		if ( log ) then
			local time = getRealTime()
			fileSetPos(log,fileGetSize(log))
			fileWrite(log,timestampConvert(time.timestamp), thePlayerNick, " "..text," (SERIAL: "..getPlayerSerial(thePlayer)..")"," (ACCOUNT: "..theAccountName..")","\r\n")
			fileFlush(log)
			fileClose(log)
		end
	end
end

-- Convert a timestamp to a proper date
function timestampConvert ( timeStamp )
	local time = getRealTime(timeStamp)
	local year = time.year + 1900
	local month = time.month + 1
	local day = time.monthday
	local hour = time.hour
	local minute = time.minute
	return "" .. day .."/" .. month .."/" .. year .." " .. hour ..":" .. minute .." - "
end