local groupChatSpam = {}

function onGroupChat(player,_,...)
	if ( exports.server:getPlayerAccountName ( player ) ) then
		local sourceGroup = getElementData( player, "Group" )
		local message = table.concat({...}, " ")
		if not ( sourceGroup ) then
			exports.DENhelp:createNewHelpMessageForPlayer( player, "You are not in a group!",200,0,0,true)
		elseif message:match("^%s*$") then
			exports.DENhelp:createNewHelpMessageForPlayer( player, "You didnt enter a message!", 200, 0, 0)
		elseif ( groupChatSpam[player] ) and ( getTickCount()-groupChatSpam[player] < 1000 ) then
			exports.DENhelp:createNewHelpMessageForPlayer( player, "You are typing to fast! The limit is one message each second.", 200, 0, 0)
		elseif ( exports.DENadmin:onAdminIsPlayerMuted( player, "global" ) ) then
			exports.DENhelp:createNewHelpMessageForPlayer( player, "You are muted!", 236, 201, 0)
		else
			groupChatSpam[player] = getTickCount()
			local message, nonFilterdMessage = exports.server:cleanStringFromBadWords( message )
			local nick = getPlayerName( player )
			local playertable = getElementsByType("player")
			local groupPlayerTable = {}
			local thePlayerGroup = getElementData( player, "Group" )
	  
			for i,v in ipairs(playertable ) do
				local playersGroup = getElementData( v, "Group" )
				if sourceGroup == playersGroup then
					table.insert(groupPlayerTable , v)
				end
			end
			
			local thePlayer = player
			
			for _,v in ipairs(groupPlayerTable ) do
				if ( getElementData( v, "chatOutputGroupchat" ) ) then
					outputChatBox("(GROUP) "..nick..": #ffffff"..message,v,200,0,0,true)
				end
				triggerClientEvent( v, "onChatSystemMessageToClient", v, thePlayer, message, "Groupchat" )
			end
			exports.DENlogging:writeChatlog(player, "Groupchat", nonFilterdMessage, thePlayerGroup)
		end
	end
end
addCommandHandler( "group", onGroupChat )
addCommandHandler( "gc", onGroupChat )
addCommandHandler( "groupchat", onGroupChat )

-- Output a message to all group members, such as notes etc
function outPutGroupMessage (groupname, message)
	local message, nonFilterdMessage = exports.server:cleanStringFromBadWords( message )
	local playertable = getElementsByType("player")
	local groupPlayerTable = {}
  
	for i,v in ipairs(playertable ) do
		local playersGroup = getElementData( v, "Group" )
		if groupname == playersGroup then
			table.insert(groupPlayerTable , v)
		end
	end
		
	for _,v in ipairs(groupPlayerTable ) do
		outputChatBox(message,v,200,0,0,true)
	end
end

-- Output message thats send by a player
function outPutGroupMessageByPlayer (thePlayer, message)
	local sourceGroup = getElementData( thePlayer, "Group" )
	if message:match("^%s*$") then
		exports.DENhelp:createNewHelpMessageForPlayer(thePlayer, "You didnt enter a message!", 200, 0, 0)
	else
	
	local message, nonFilterdMessage = exports.server:cleanStringFromBadWords( message )
	local nick = getPlayerName(thePlayer)
	local playertable = getElementsByType("player")
	local groupPlayerTable = {}
  
	for i,v in ipairs(playertable ) do
		local playersGroup = getElementData( v, "Group" )
			if sourceGroup == playersGroup then
				table.insert(groupPlayerTable , v)
			end
		end
		
		for _,v in ipairs(groupPlayerTable ) do
			outputChatBox(message,v,200,0,0,true)
		end
	end
end