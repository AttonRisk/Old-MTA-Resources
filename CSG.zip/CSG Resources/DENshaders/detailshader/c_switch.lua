addEvent( "onClientSwitchDetail", true )

addEventHandler( "onClientSwitchDetail", resourceRoot,
function ( bOn )
	if bOn then
		enableDetail()
	else
		disableDetail()
	end
end )
