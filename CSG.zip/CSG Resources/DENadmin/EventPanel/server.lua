---- Event vehicles
local eventVehicleMarker = {}
local markerData = {}
local markerCreator = {}
local eventVehicles = {}
local createTick = nil

-- Create a marker with vehicles
addEvent( "onCreateEventVehicleMarker", true )
function createEventVehicleMarker ( theVehicleName )
	local creatorAccount = exports.server:getPlayerAccountName( source )
    if not ( getVehicleModelFromName( theVehicleName ) ) then 
		exports.DENhelp:createNewHelpMessageForPlayer( source, "There is no vehicle found with this name!", 225, 0, 0 )
	elseif ( creatorAccount ) then
		if ( isElement( eventVehicleMarker[creatorAccount] ) ) then destroyElement( eventVehicleMarker[creatorAccount] ) end
        local x, y, z = getElementPosition( source )
        eventVehicleMarker[creatorAccount] = createMarker( x, y, z - 1, "cylinder", 1.5, 21,27,141, 100 )
		setElementDimension( eventVehicleMarker[creatorAccount], getElementDimension( source ) )
        local theVehicleModel = getVehicleModelFromName( theVehicleName )
        if not ( theVehicleModel ) then 
			exports.DENhelp:createNewHelpMessageForPlayer( source, "There is no vehicle found with this name!", 225, 0, 0 )
		else
			createTick = getTickCount()
			markerData[eventVehicleMarker[creatorAccount]] = theVehicleModel
			markerCreator[eventVehicleMarker[creatorAccount]] = creatorAccount
			setElementInterior( eventVehicleMarker[creatorAccount], getElementInterior( source ) )	
			addEventHandler( "onMarkerHit", eventVehicleMarker[creatorAccount], onEventVehicleMarkerHit )
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." created a event vehicle marker (VEHICLE: " .. theVehicleName .. ")" )
		end
	end
end
addEventHandler( "onCreateEventVehicleMarker", root, createEventVehicleMarker )

-- Delete all the vehicles create by a marker
addEvent( "onDestroyEventVehicles", true )
function destroyEventMarkerVehicles ( theCreator )
	if ( eventVehicles[theCreator] ) then
		for i, theElement in ipairs ( eventVehicles[theCreator] ) do
			if ( isElement( theElement ) ) then
				destroyElement( theElement )
			end
		end
		exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." deleted all event vehicles" )
	end
	eventVehicles[theCreator] = {}
end
addEventHandler( "onDestroyEventVehicles", root, destroyEventMarkerVehicles )

-- Destroy the marker
addEvent( "onDestroyEventVehicleMarker", true )
function destroyEventMarkerVehicleMarker ( theCreator )
	if ( isElement( eventVehicleMarker[theCreator] ) ) then 
		removeEventHandler( "onMarkerHit", eventVehicleMarker[theCreator], onEventVehicleMarkerHit ) 
		destroyElement( eventVehicleMarker[theCreator] )
		exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." deleted the event vehicle marker" )
	end
	if ( eventVehicleMarker[theCreator] ) then eventVehicleMarker[theCreator] = {} end
end
addEventHandler( "onDestroyEventVehicleMarker", root, destroyEventMarkerVehicleMarker )

-- When the player hits a marker for vehicles
function onEventVehicleMarkerHit ( theElement, matchingDimension )
	if ( matchingDimension ) then
		if ( createTick ) and ( getTickCount()-createTick < 3000 ) then
			return
		else
			if ( getElementType ( theElement ) == "player" ) and not ( isPedInVehicle( theElement ) ) then
				local theModel = markerData[source]
				local theCreator = markerCreator[source]
				if ( theModel ) and ( theCreator ) then
					local x, y, z = getElementPosition( source )
					local theVehicle = createVehicle( theModel, x, y, z +2 )
					setElementDimension( theVehicle, getElementDimension( source ) )					
					setElementInterior( theVehicle, getElementInterior( source ) )				
					warpPedIntoVehicle( theElement, theVehicle )
					if not ( eventVehicles[theCreator] ) then eventVehicles[theCreator] = {} end
					table.insert( eventVehicles[theCreator], theVehicle )
					exports.DENlogging:writePlayerLog ( theElement, getPlayerName(theElement).." picked a " .. getVehicleNameFromModel ( theModel ) .." from a event marker (EVENT PANEL)")
				end
			end
		end
	end
end

-- Warp function
local thePlayers = {}
local x, y, z, int, dim = 0, 0, 0, 0, 0
local isEvent = false
local warpLimit = 0
local warps = 0
local frozen = true

addEvent( "onCreateWarpEvent", true )
function createWarpEvent ( theLimit, theDimension, theInterior, eventName )
	if ( unfreezeEventPlayer () ) then
		if ( isEvent ) then
			exports.DENhelp:createNewHelpMessageForPlayer( source, "There is already a event going, please wait till this event ends or destroy it!", 225, 0, 0 )
		else
			setElementDimension( source, theDimension )
			local px, py, pz = getElementPosition( source )
			
			if ( getElementInterior( source ) ~= theInterior ) then
				setElementInterior( source, theInterior, px, py, pz )
			end
			
			x = px
			y = py
			z = pz
			int = tonumber(theInterior)
			dim = tonumber(theDimension)
			isEvent = true
			frozen = true
			warpLimit = tonumber(theLimit)
			warps = 0	
			thePlayers = {}
			outputChatBox( "[EVENT] " .. eventName .. " (LIMIT: " .. theLimit .. ") (BY: " .. getPlayerName( source ) .. ") Use /eventwarp to participate!", root, 0, 225, 0 )
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." created a event: (NAME: " .. eventName .. ") (LIMIT: " .. theLimit .. ")" )
		end
	end
end
addEventHandler( "onCreateWarpEvent", root, createWarpEvent )

addCommandHandler("eventwarp", 
function ( thePlayer )
	if ( isEvent ) then
		if ( getElementData ( thePlayer, "isPlayerArrested" ) ) or ( getElementData ( thePlayer, "isPlayerRobbing" ) ) or ( getElementData ( thePlayer, "isPlayerJailed" ) ) or ( isPedInVehicle( thePlayer ) ) then
			exports.DENhelp:createNewHelpMessageForPlayer( thePlayer, "You can't warp while arrested, jailed or when driving a vehicle!", 225, 0, 0 )
		else
			if ( getElementInterior( thePlayer ) == int ) then
				setElementPosition( thePlayer, x, y, z )
			else
				setElementInterior( thePlayer, int, x, y, z )
			end
				
			setElementDimension( thePlayer, dim )
				
			if ( frozen ) then
				setElementFrozen( thePlayer, true )
			end
			
			if not ( thePlayers[thePlayer] ) then
				thePlayers[thePlayer] = thePlayer
				warps = warps + 1
			end
				
			if ( warps >= warpLimit ) then 
				isEvent = false
				outputChatBox( "The event is now full!", root, 0, 225, 0 )
			end
		end
	else
		exports.DENhelp:createNewHelpMessageForPlayer( thePlayer, "There is no event or the current event is full!", 225, 0, 0 )
	end
end
)

addEvent( "onUnfreezeEventPlayers", true )
function unfreezeEventPlayer ()
	local msg = false
	if ( thePlayers ) then
		for i, k in pairs ( thePlayers ) do
			if ( isElement( i ) ) then
				setElementFrozen( i, false )
				exports.DENhelp:createNewHelpMessageForPlayer( i, "You are now unfrozen!", 225, 0, 0 )
				msg = true
			end
		end
		if ( msg ) then
			exports.DENhelp:createNewHelpMessageForPlayer( source, "All players are now unfrozen!", 225, 0, 0 )
		end
	end
	thePlayers = {}
	frozen = false
	return true
end
addEventHandler( "onUnfreezeEventPlayers", root, unfreezeEventPlayer )

addEvent( "onDestroyEvent", true )
function destroyAdminEvent ()
	if ( isEvent ) then
		if ( unfreezeEventPlayer () ) then
			isEvent = false
			outputChatBox( "Warping to the event is no longer available!", root, 0, 225, 0 )
			exports.DENhelp:createNewHelpMessageForPlayer( source, "Event is destroyed and all players are unfrozen!", 225, 0, 0 )
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." destroyed the event" )
		end
	end
end
addEventHandler( "onDestroyEvent", root, destroyAdminEvent )

-- Send money
addEvent( "onSendEventMoney", true )
function givePlayerEventMoney ( thePlayer, theMoney )
	if ( isElement ( thePlayer ) ) then
		if ( theMoney > 100000 ) then
			exports.DENhelp:createNewHelpMessageForPlayer( source, "Server refused to give more the %100,000 a report has been send to a L6 staff!", 225, 0, 0 )
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." wanted to send $" .. theMoney .. " to " .. getPlayerName( thePlayer ) .. " server refused" )
		else
			givePlayerMoney( thePlayer, theMoney )
			exports.DENhelp:createNewHelpMessageForPlayer( source, "You sended $" .. theMoney .. " to "..getPlayerName( thePlayer ), 225, 0, 0 )
			exports.DENhelp:createNewHelpMessageForPlayer( thePlayer, "You recieved $" .. theMoney .. " from a event! By: "..getPlayerName( source ), 225, 0, 0 )
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." has sent $" .. theMoney .. " to " .. getPlayerName( thePlayer ) .. " (EVENT PANEL)" )
			exports.DENlogging:writePlayerLog ( thePlayer, getPlayerName(thePlayer).." recieved $".. theMoney .." from ".. getPlayerName(source) .." (EVENT PANEL)")
		end
	end
end
addEventHandler( "onSendEventMoney", root, givePlayerEventMoney )

-- Give weapon
addEvent( "onSendWeapon", true )
function givePlayerEventWeapon ( thePlayer, theWeapon )
	if ( isElement ( thePlayer ) ) then
		local theWeaponID = getWeaponIDFromName ( theWeapon )
		giveWeapon( thePlayer, theWeaponID, 500, true )
		exports.DENhelp:createNewHelpMessageForPlayer( source, "You sended a " .. theWeapon .. " to "..getPlayerName( thePlayer ), 225, 0, 0 )
		exports.DENhelp:createNewHelpMessageForPlayer( thePlayer, "You recieved a " .. theWeapon .. " from a event! By: "..getPlayerName( source ), 225, 0, 0 )
		exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." has sent a " .. theWeapon .. " to " .. getPlayerName( thePlayer ) .. " (EVENT PANEL)" )
		exports.DENlogging:writePlayerLog ( thePlayer, getPlayerName(thePlayer).." recieved a ".. theWeapon .." from ".. getPlayerName(source) .." (EVENT PANEL)")
	end
end
addEventHandler( "onSendWeapon", root, givePlayerEventWeapon )

-- Create pickup
local eventPickups = {}

addEvent( "onCreateEventPickup", true )
function createEventPickup ( theType )
	local creatorAccount = exports.server:getPlayerAccountName( source )
	if ( isElement ( source ) ) and ( creatorAccount ) then
		local x, y, z = getElementPosition( source )
		if ( string.lower(theType) == "health" ) then
			if ( eventPickups[creatorAccount] ) and ( isElement( eventPickups[creatorAccount] ) ) then destroyElement( eventPickups[creatorAccount] ) eventPickups[creatorAccount] = {} end
			eventPickups[creatorAccount] = createPickup ( x, y, z, 0, 100, 0 )
			setElementDimension( eventPickups[creatorAccount], getElementDimension( source ) )
			setElementInterior( eventPickups[creatorAccount], getElementInterior( source ) )
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." created a health pickup (EVENT PANEL)" )
		elseif ( string.lower(theType) == "armor" ) then
			if ( eventPickups[creatorAccount] ) and ( isElement( eventPickups[creatorAccount] ) ) then destroyElement( eventPickups[creatorAccount] ) eventPickups[creatorAccount] = {} end
			eventPickups[creatorAccount] = createPickup ( x, y, z, 1, 100, 0 )
			setElementDimension( eventPickups[creatorAccount], getElementDimension( source ) )
			setElementInterior( eventPickups[creatorAccount], getElementInterior( source ) )
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." created a armor pickup (EVENT PANEL)" )
		else
			exports.DENhelp:createNewHelpMessageForPlayer( thePlayer, "Wrong pickup model! (Use: health or armor)", 225, 0, 0 )
		end
	end
end
addEventHandler( "onCreateEventPickup", root, createEventPickup )

-- Destroy pickup
addEvent( "onDestroyEventPickup", true )
function destroyEventPickup ()
	local creatorAccount = exports.server:getPlayerAccountName( source )
	if ( isElement ( source ) ) and ( creatorAccount ) then
		if ( eventPickups[creatorAccount] ) and ( isElement( eventPickups[creatorAccount] ) ) then 
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." destroyed a pickup (EVENT PANEL)" )
			destroyElement( eventPickups[creatorAccount] ) 
			eventPickups[creatorAccount] = {} 
		end
	end
end
addEventHandler( "onDestroyEventPickup", root, destroyEventPickup )