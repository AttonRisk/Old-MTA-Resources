local TheCSGAdminACL = {
-- 1=L1,2=L2,3=L3,4=L4,5=L5,6=L6
-- Tabs
{"Mainpanel", 1},
{"Bans", 3},
{"Event Manager Panel", 6},
{"Notes", 1},
-- Functions
{"Kick", 1},
{"Ban", 3},
{"Mute", 1},
{"Jail", 1},
{"Freeze", 1},
{"Slap", 1},
{"Spectate", 1},
{"Send Message", 2},
{"Set Nick", 3},
{"Set Health", 4},
{"Set Armor", 4},
{"Set Skin", 4},
{"Set Money", 6},
{"Set Job", 3},
{"Set Dimension", 3},
{"Set Interior", 3},
{"Warp to player", 1},
{"Warp player to...", 2},
{"Give Weapon", 5},
{"Give Vehicle", 5},
{"Set Drugs", 4},
{"Get Punishments", 1},
{"Get other status", 1},
{"Fix Vehicle", 2},
{"Destroy Vehicle", 1},
{"Output information in console", 1}
}

function getAdminACL ()
	return TheCSGAdminACL
end