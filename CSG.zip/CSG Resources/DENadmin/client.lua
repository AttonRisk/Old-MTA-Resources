--------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------- CSG STAFF PANEL! COPYRIGHT UNION / DENNIS ----------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------

-- Bind the key to open the admin panel
bindKey( "0", "down", 
function ()
	if (getElementData(localPlayer, "isPlayerStaff")) then
		if isAdminPanelShowing() then
			setAdminPanelWindowEnabled ( false )
			onCloseAllAdminPanelWindows ()
		else	
			guiSetInputMode("no_binds_when_editing")
			setAdminPanelWindowEnabled ( true )
		end
	end
end )

-- Convert a timeStamp to a date
function timestampConvert ( timeStamp )
	local time = getRealTime(timeStamp)
	local year = time.year + 1900
	local month = time.month + 1
	local day = time.monthday
	local hour = time.hour
	local minute = time.minute
	return "" .. hour ..":" .. minute ..""
end

-- Chat message for staffchat
addEvent ("onStaffChatMessage", true)
function onStaffChatMessage ( messageSender, message, timestamp )
	local row = guiGridListAddRow ( adminPanelTabTwoChatGrid )
	guiGridListSetItemText ( adminPanelTabTwoChatGrid, row, timeColumn, timestampConvert (timestamp), false, false )
	guiGridListSetItemText ( adminPanelTabTwoChatGrid, row, senderColumn, getPlayerName ( messageSender ), false, false )
	guiGridListSetItemText ( adminPanelTabTwoChatGrid, row, messageColumn, message, false, false )
end
addEventHandler ("onStaffChatMessage", root, onStaffChatMessage)

-- Clear the staffchat
function onClearStaffChatGrid ()
	guiGridListClear ( adminPanelTabTwoChatGrid )
end

-- Send staffchat message via the gui
function onSendStaffChatMessage ()
	if getGuiElementText(adminPanelTabTwoChatField) == "" or getGuiElementText(adminPanelTabTwoChatField) == " " then
		outputChatBox ("You didnt enter a message", 225,0,0)
	else
		triggerServerEvent ( "onSendStaffChatMessage", localPlayer, getGuiElementText(adminPanelTabTwoChatField) )
		guiSetText ( adminPanelTabTwoChatField, "" )
	end	
end

-- Slap player
function onSlapPlayer ()
	local thePlayer = getPlayerFromName(guiGridListGetItemText(adminPanelTabOneUserGrid, guiGridListGetSelectedItem(adminPanelTabOneUserGrid), 1))
	if ( isElement(thePlayer) ) then
		triggerServerEvent( "onSlapPlayer", localPlayer, thePlayer )
	end
end

-- Jail player
function onAdminJailPlayer (thePlayerName, theTime, isCustomReason, theReasonEdit, theReasonGrid, isRemovePunishment)
	local thePlayer = getPlayerFromName( thePlayerName )
	if ( isElement(thePlayer) ) then
		if string.match(theTime,'^%d+$') then
			if ( isRemovePunishment ) then
					triggerServerEvent ( "onAdminRemovePunishment", localPlayer, thePlayer, tonumber(theTime) )
					setJailWindowVisable()
			elseif ( isCustomReason ) then
				if not ( theReasonEdit:find("^%s*$") ) then
					triggerServerEvent ( "onAdminJailPlayer", localPlayer, thePlayer, tonumber(theTime), theReasonEdit )
					setJailWindowVisable()
				else
					outputChatBox("You didn't enter a reason!", 225, 0, 0)
				end
			else
				if ( theReasonGrid ) then
					triggerServerEvent ( "onAdminJailPlayer", localPlayer, thePlayer, tonumber(theTime), theReasonGrid )
					setJailWindowVisable()
				else
					outputChatBox("No reason reason selected!", 225, 0, 0)
				end
			end
		else
			outputChatBox("You didn't enter a time!", 225, 0, 0)
		end
	end
end

function onShowJailWindow ()
	local thePlayerName, thePlayerElement = getSelectedGridPlayer()
	if ( isElement( thePlayerElement ) ) then
		setJailWindowVisable()
		showCursor(true,true)
	end
end

-- Mute player
function onAdminMutePlayer (thePlayerName, theTime, isCustomReason, theReasonEdit, theReasonGrid, isRemovePunishment, isLowerPunishment, isMuteGlobal )
	local thePlayer = getPlayerFromName( thePlayerName )
	if ( isMuteGlobal ) then theType = "global" else theType = "" end
	if ( isElement(thePlayer) ) then
		if string.match(theTime,'^%d+$') then
			if ( isRemovePunishment ) then
				triggerServerEvent ( "onAdminRemoveMutePunishment", localPlayer, thePlayer, tonumber(theTime) )
				setMuteWindowVisable()
			elseif ( isLowerPunishment ) then
				triggerServerEvent ( "onAdminLowerMutePunishment", localPlayer, thePlayer, tonumber(theTime) )
				setMuteWindowVisable()
			elseif ( isCustomReason ) then
				if not ( theReasonEdit:find("^%s*$") ) then
					triggerServerEvent ( "onAdminMutePlayer", localPlayer, thePlayer, tonumber(theTime), theReasonEdit, theType )
					setMuteWindowVisable()
				else
					outputChatBox("You didn't enter a reason!", 225, 0, 0)
				end
			else
				if ( theReasonGrid ) then
					triggerServerEvent ( "onAdminMutePlayer", localPlayer, thePlayer, tonumber(theTime), theReasonGrid, theType)
					setMuteWindowVisable()
				else
					outputChatBox("No reason reason selected!", 225, 0, 0)
				end
			end
		else
			outputChatBox("You didn't enter a time!", 225, 0, 0)
		end
	end
end

function onShowMuteWindow ()
	local thePlayerName, thePlayerElement = getSelectedGridPlayer()
	if ( isElement( thePlayerElement ) ) then
		setMuteWindowVisable()
		showCursor(true,true)
	end
end

-- Ban player
function onAdminBanPlayer (thePlayer, punishTime, isCustomReason, theReasonEdit, theReasonGrid, isAccountBan, isSerialBan, isHourTime, isDaysTime )
	if ( isElement(thePlayer) ) then
		if string.match(punishTime,'^%d+$') and tonumber(punishTime) > 0 or tonumber(punishTime) == 0 then
			if ( isHourTime ) or ( isDaysTime ) then
				if ( isSerialBan ) or ( isAccountBan ) then
					if ( isHourTime ) and ( tonumber( punishTime ) > 24 ) then
							outputChatBox("Use the day ban option for a ban longer then 24h!", 225, 0, 0)
					elseif ( isDaysTime ) and ( tonumber( punishTime ) == 1 ) then
						outputChatBox("Use the hour ban option for a ban shorten than 1 day!", 225, 0, 0)
					else
						if ( isHourTime ) then theTime = ( tonumber(punishTime) * 3600 ) elseif ( isDaysTime ) then theTime = ( tonumber(punishTime) * 86400 ) end
						if ( isAccountBan ) then theType = "accountban" else theType = "serialban" end
						if ( isCustomReason ) then
							if not ( theReasonEdit:find("^%s*$") ) then
								triggerServerEvent ( "onAdminBanPlayer", localPlayer, thePlayer, tonumber(theTime), theReasonEdit, theType )
								setBanWindowVisable()
							else
								outputChatBox("You didn't enter a reason!", 225, 0, 0)
							end
						else
							if ( theReasonGrid ) then
								triggerServerEvent ( "onAdminBanPlayer", localPlayer, thePlayer, tonumber(theTime), theReasonGrid, theType )
								setBanWindowVisable()
							else
								outputChatBox("No reason reason selected!", 225, 0, 0)
							end
						end
					end
				else
					outputChatBox("You didn't select a ban option!", 225, 0, 0)
				end
			else
				outputChatBox("You didn't select a time option!", 225, 0, 0)
			end
		else
			outputChatBox("You didn't enter a time!", 225, 0, 0)
		end
	end
end

function onShowBanWindow ()
	local thePlayerName, thePlayerElement = getSelectedGridPlayer()
	if ( isElement( thePlayerElement ) ) then
		setBanWindowVisable()
		showCursor(true,true)
	end
end

-- Kick player
function onShowKickWindow ()
	local thePlayerName, thePlayerElement = getSelectedGridPlayer()
	if ( isElement( thePlayerElement ) ) then
		setKickWindowVisable()
		showCursor(true,true)
	end
end