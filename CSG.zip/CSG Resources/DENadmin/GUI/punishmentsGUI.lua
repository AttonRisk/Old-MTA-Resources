-- Punishment reasons
local punishReasons = {
[0] = {"#0 Testing punishment"},
[1] = {"#1 Deathmatching"},
[2] = {"#2 Using trainers or cheats"},
[3] = {"#3 Insulting players"},
[4] = {"#4 Annoying staff"},
[5] = {"#5 Avoiding punishment"},
[6] = {"#6 Advertising"},
[7] = {"#7 Sharing illegal content"},
[8] = {"#8 Blackmailing people"},
[9] = {"#9 Non-English"},
[10] = {"#10 Camping"},
[11] = {"#11 Spamming"},
[12] = {"#12 Selling in-game contents"},
[13] = {"#13 Use a normal nickname"},
[14] = {"#14 Not listening to staff"},
}

function createPunishMentWindows ()
-- Jail player window
adminPanelJailWindow = guiCreateWindow(575,221,295,388,"CSG ~ Jail a player",false)
adminPanelJailLabel1 = guiCreateLabel(9,25,279,16,"You are about to jail: [NAME]",false,adminPanelJailWindow)
adminPanelJailLabel2 = guiCreateLabel(10,319,163,18,"Punishment time: (Seconds):",false,adminPanelJailWindow)
adminPanelJailGrid = guiCreateGridList(9,43,277,205,false,adminPanelJailWindow)
local culumnJail1 = guiGridListAddColumn(adminPanelJailGrid,"#Rule",0.2)
local culumnJail2 = guiGridListAddColumn(adminPanelJailGrid,"Reason:",0.7)
adminPanelJailCheckbox1 = guiCreateCheckBox(9,257,17,18,"",false,false,adminPanelJailWindow)
adminPanelJailReasonEdit = guiCreateEdit(30,253,256,24,"Custom Reason",false,adminPanelJailWindow)
adminPanelJailCheckbox2 = guiCreateCheckBox(9,288,277,19,"Tick this box to remove punishment time",false,false,adminPanelJailWindow)
adminPanelJailTimeEdit = guiCreateEdit(177,316,109,24,"",false,adminPanelJailWindow)
adminPanelJailConfirmButton = guiCreateButton(9,353,137,24,"Jail player",false,adminPanelJailWindow)
adminPanelJailCancelButton = guiCreateButton(149,353,137,24,"Cancel",false,adminPanelJailWindow)
guiGridListSetSelectionMode(adminPanelJailGrid,0)
guiSetFont(adminPanelJailLabel1,"default-bold-small")
onCenterWindow ( adminPanelJailWindow )
guiSetVisible( adminPanelJailWindow, false )
guiWindowSetSizable ( adminPanelJailWindow, false )

-- Mute player window
adminPanelMuteWindow = guiCreateWindow(575,221,295,447,"CSG ~ Mute a player",false)
adminPanelMuteLabel1 = guiCreateLabel(9,25,279,16,"You are about to mute: [NAME]",false,adminPanelMuteWindow)
guiSetFont(adminPanelMuteLabel1,"default-bold-small")
adminPanelMuteGrid = guiCreateGridList(9,43,277,205,false,adminPanelMuteWindow)
local culumnMute1 = guiGridListAddColumn(adminPanelMuteGrid,"#Rule",0.2)
local culumnMute2 = guiGridListAddColumn(adminPanelMuteGrid,"Reason:",0.7)
guiGridListSetSelectionMode(adminPanelMuteGrid,0)
adminPanelMuteReasonEdit = guiCreateEdit(30,253,256,24,"Custom Reason",false,adminPanelMuteWindow)
adminPanelMuteCheckbox1 = guiCreateCheckBox(9,257,17,18,"",false,false,adminPanelMuteWindow)
adminPanelMuteCheckbox2 = guiCreateCheckBox(9,288,277,19,"Tick this box to remove the mute",false,false,adminPanelMuteWindow)
adminPanelMuteCheckbox3 = guiCreateCheckBox(9,320,277,19,"Tick this box to lower the mute time",false,false,adminPanelMuteWindow)
adminPanelMuteCheckbox4 = guiCreateCheckBox(9,351,107,21,"Global mute",false,false,adminPanelMuteWindow)
adminPanelMuteLabel2 = guiCreateLabel(10,382,120,16,"Mute time (seconds):",false,adminPanelMuteWindow)
adminPanelMuteTimeEdit = guiCreateEdit(132,379,154,22,"",false,adminPanelMuteWindow)
adminPanelMuteConfirmButton = guiCreateButton(9,413,140,23,"Mute player",false,adminPanelMuteWindow)
adminPanelMuteCancelButton = guiCreateButton(152,413,134,23,"Cancel",false,adminPanelMuteWindow)
onCenterWindow ( adminPanelMuteWindow )
guiSetVisible( adminPanelMuteWindow, false )
guiWindowSetSizable ( adminPanelMuteWindow, false )

-- Ban player window
adminPanelBanWindow = guiCreateWindow(575,221,295,377,"CSG ~ Ban a player",false)
adminPanelBanLabel = guiCreateLabel(9,25,279,16,"You are about to ban: [NAME]",false,adminPanelBanWindow)
guiSetFont(adminPanelBanLabel,"default-bold-small")
adminPanelBanGrid = guiCreateGridList(9,43,277,205,false,adminPanelBanWindow)
local culumnBan1 = guiGridListAddColumn(adminPanelBanGrid,"#Rule",0.2)
local culumnBan2 = guiGridListAddColumn(adminPanelBanGrid,"Reason:",0.7)
guiGridListSetSelectionMode(adminPanelBanGrid,2)
adminPanelBanReasonEdit = guiCreateEdit(30,253,256,24,"Custom Reason",false,adminPanelBanWindow)
adminPanelBanCheckbox1 = guiCreateCheckBox(9,257,17,18,"",false,false,adminPanelBanWindow)
adminPanelBanCheckbox2 = guiCreateRadioButton(9,288,107,21,"Account ban",false,adminPanelBanWindow)
adminPanelBanCheckbox3 = guiCreateRadioButton(131,289,107,21,"Serial ban",false,adminPanelBanWindow)
adminPanelBanCheckbox4 = guiCreateCheckBox(9,319,57,18,"Hours",false,false,adminPanelBanWindow)
adminPanelBanCheckbox5 = guiCreateCheckBox(64,319,57,18,"Days",false,false,adminPanelBanWindow)
adminPanelBanTimeEdit = guiCreateEdit(115,316,171,22,"Ban time",false,adminPanelBanWindow)
adminPanelBanConfirmButton = guiCreateButton(9,346,140,23,"Ban player",false,adminPanelBanWindow)
adminPanelBanCancelButton = guiCreateButton(154,346,132,23,"Cancel",false,adminPanelBanWindow)
onCenterWindow ( adminPanelBanWindow )
guiSetVisible( adminPanelBanWindow, false )
guiWindowSetSizable ( adminPanelBanWindow, false )

-- Kick player window
adminPanelKickWindow = guiCreateWindow(314,366,364,98,"CSG ~ Kick player",false)
adminPanelKickReasonEdit = guiCreateEdit(9,24,346,32,"",false,adminPanelKickWindow)
adminPanelKickPunishButton = guiCreateButton(10,58,176,30,"Kick player",false,adminPanelKickWindow)
adminPanelKickCancelButton = guiCreateButton(190,58,165,30,"Cancel",false,adminPanelKickWindow)
onCenterWindow ( adminPanelKickWindow )
guiSetVisible( adminPanelKickWindow, false )
guiWindowSetSizable ( adminPanelKickWindow, false )

-- Punishments windows
punishlogWindow = guiCreateWindow(407,203,719,494,"Community of Social Gaming ~ Player punishments",false)
punishlogTabPanel = guiCreateTabPanel(9,23,701,494,false,punishlogWindow)
-- Account Punishments
punishlogTab1 = guiCreateTab("Account punishments",punishlogTabPanel)
accountPunishGrid = guiCreateGridList(1,3,699,393,false,punishlogTab1)
guiGridListSetSelectionMode(accountPunishGrid,0)
column1 = guiGridListAddColumn( accountPunishGrid, "Date:", 0.24 )
column2 = guiGridListAddColumn( accountPunishGrid, "Punishment:", 0.73 )
-- Serial Punishments
punishlogTab2 = guiCreateTab("Serial punishments",punishlogTabPanel)
serialPunishGrid = guiCreateGridList(1,3,699,393,false,punishlogTab2)
guiGridListSetSelectionMode(serialPunishGrid,0)
column3 = guiGridListAddColumn( serialPunishGrid, "Date:", 0.24 )
column4 = guiGridListAddColumn( serialPunishGrid, "Punishment:", 0.73 )
-- Others
punishlogButton1 = guiCreateButton(532,404,162,25,"Close window",false,punishlogTab1)
punishlogButton2 = guiCreateButton(365,404,162,25,"Delete punishment",false,punishlogTab1)
punishlogButton3 = guiCreateButton(532,404,162,25,"Close window",false,punishlogTab2)
punishlogButton4 = guiCreateButton(365,404,162,25,"Delete punishment",false,punishlogTab2)
punishlogLabel1 = guiCreateLabel(6,407,271,16,"Red punishments are 'removed' and not visable for the player",false,punishlogTab1)
punishlogLabel2 = guiCreateLabel(6,407,271,16,"Red punishments are 'removed' and not visable for the player",false,punishlogTab2)
guiSetFont(punishlogLabel1,"default-bold-small")
guiSetFont(punishlogLabel2,"default-bold-small")
onCenterWindow ( punishlogWindow )
guiSetVisible( punishlogWindow, false )
guiWindowSetSizable ( punishlogWindow, false )

-- Warpto window
warpToWindow = guiCreateWindow(555,320,236,324,"Warp player to...",false)
warpToEdit = guiCreateEdit(9,23,218,25,"",false,warpToWindow)
warpToGrid = guiCreateGridList(9,49,218,238,false,warpToWindow)
warpGrid = guiGridListAddColumn( warpToGrid, "Players:", 0.8 )
guiGridListSetSelectionMode(warpToGrid,0)
warpToButton1 = guiCreateButton(9,289,112,26,"Warp",false,warpToWindow)
warpToButton2 = guiCreateButton(123,289,104,26,"Close",false,warpToWindow)
onCenterWindow ( warpToWindow )
guiSetVisible( warpToWindow, false )
guiWindowSetSizable ( warpToWindow, false )

-- Warp handlers
addEventHandler ("onClientGUIClick", warpToButton2, onCloseWarpWindow, false)
addEventHandler ("onClientGUIClick", warpToButton1, onWarpPlayerTo, false)
addEventHandler( "onClientGUIDoubleClick", warpToGrid, onWarpPlayerTo, false )
addEventHandler	("onClientGUIChanged", warpToEdit, onSearchWarpToPlayer, false)

-- Punishmenthandlers
addEventHandler ("onClientGUIClick", punishlogButton1, setPunishWindowVisable, false)
addEventHandler ("onClientGUIClick", punishlogButton3, setPunishWindowVisable, false)
addEventHandler ("onClientGUIClick", punishlogButton2, onDeleteAccountPunishLogRow, false)
addEventHandler ("onClientGUIClick", punishlogButton4, onDeleteSerialPunishLogRow, false)

-- Ban handlers
addEventHandler ("onClientGUIClick", adminPanelBanCancelButton, setBanWindowVisable, false)
addEventHandler ("onClientGUIClick", adminPanelBanConfirmButton, 
function () 
	local thePlayerName, thePlayerElement = getSelectedGridPlayer()
	local theTime = guiGetText(adminPanelBanTimeEdit)
	local theReasonGrid = guiGridListGetItemText(adminPanelBanGrid, guiGridListGetSelectedItem(adminPanelBanGrid), 2 )
	local theReasonEdit = guiGetText(adminPanelBanReasonEdit)
	local theCheckbox1 = guiCheckBoxGetSelected( adminPanelBanCheckbox1 )
	local theCheckbox2 = guiRadioButtonGetSelected( adminPanelBanCheckbox2 )
	local theCheckbox3 = guiRadioButtonGetSelected( adminPanelBanCheckbox3 )
	local theCheckbox4 = guiCheckBoxGetSelected( adminPanelBanCheckbox4 )
	local theCheckbox5 = guiCheckBoxGetSelected( adminPanelBanCheckbox5 )
	onAdminBanPlayer(thePlayerElement, theTime, theCheckbox1, theReasonEdit, theReasonGrid, theCheckbox2, theCheckbox3, theCheckbox4, theCheckbox5)
end, false)
-- Mute handlers
addEventHandler ("onClientGUIClick", adminPanelMuteCancelButton, setMuteWindowVisable, false)
addEventHandler ("onClientGUIClick", adminPanelMuteConfirmButton, 
function () 
	local thePlayerName, thePlayerElement = getSelectedGridPlayer()
	local theTime = guiGetText(adminPanelMuteTimeEdit)
	local theReasonGrid = guiGridListGetItemText(adminPanelMuteGrid, guiGridListGetSelectedItem(adminPanelMuteGrid), 2 )
	local theReasonEdit = guiGetText(adminPanelMuteReasonEdit)
	local theCheckbox1 = guiCheckBoxGetSelected( adminPanelMuteCheckbox1 )
	local theCheckbox2 = guiCheckBoxGetSelected( adminPanelMuteCheckbox2 )
	local theCheckbox3 = guiCheckBoxGetSelected( adminPanelMuteCheckbox3 )
	local theCheckbox4 = guiCheckBoxGetSelected( adminPanelMuteCheckbox4 )
	onAdminMutePlayer(thePlayerName, theTime, theCheckbox1, theReasonEdit, theReasonGrid, theCheckbox2, theCheckbox3, theCheckbox4)
end, false)
-- Jail handlers
addEventHandler ("onClientGUIClick", adminPanelJailCancelButton, setJailWindowVisable, false)
addEventHandler ("onClientGUIClick", adminPanelJailConfirmButton, 
function () 
	local thePlayerName, thePlayerElement = getSelectedGridPlayer()
	local theTime = guiGetText(adminPanelJailTimeEdit)
	local theReasonGrid = guiGridListGetItemText(adminPanelJailGrid, guiGridListGetSelectedItem(adminPanelJailGrid), 2 )
	local theReasonEdit = guiGetText(adminPanelJailReasonEdit)
	local theCheckbox1 = guiCheckBoxGetSelected( adminPanelJailCheckbox1 )
	local theCheckbox2 = guiCheckBoxGetSelected( adminPanelJailCheckbox2 )
	onAdminJailPlayer(thePlayerName, theTime, theCheckbox1, theReasonEdit, theReasonGrid, theCheckbox2)
end, false)
-- Kick handlers
addEventHandler ("onClientGUIClick", adminPanelKickCancelButton, setKickWindowVisable, false)
addEventHandler ("onClientGUIClick", adminPanelKickPunishButton, 
function () 
	local thePlayerName, thePlayerElement = getSelectedGridPlayer()
	local theReasonEdit = guiGetText( adminPanelKickReasonEdit )
	triggerServerEvent ( "onAdminKickPlayer", localPlayer, thePlayerElement, theReasonEdit)
	setKickWindowVisable()
end, false)

	for i=0,#punishReasons do
		local theReason = punishReasons[i][1]
		
		local theJailRow = guiGridListAddRow ( adminPanelJailGrid )
		local theMuteRow = guiGridListAddRow ( adminPanelMuteGrid )
		local theBanRow = guiGridListAddRow ( adminPanelBanGrid )
		
		guiGridListSetItemText ( adminPanelJailGrid, theJailRow, 1, i, false, true )
		guiGridListSetItemText ( adminPanelJailGrid, theJailRow, 2, theReason, false, false )
		guiGridListSetItemText ( adminPanelMuteGrid, theMuteRow, 1, i, false, true )
		guiGridListSetItemText ( adminPanelMuteGrid, theMuteRow, 2, theReason, false, false )
		guiGridListSetItemText ( adminPanelBanGrid, theBanRow, 1, i, false, true )
		guiGridListSetItemText ( adminPanelBanGrid, theBanRow, 2, theReason, false, false )
	end

end

-- Function close all screens
function onCloseAllAdminPanelWindows ()
	guiSetVisible( adminPanelJailWindow, false )
	guiSetVisible( adminPanelMuteWindow, false )
	guiSetVisible( adminPanelBanWindow, false )
	guiSetVisible( adminPanelKickWindow, false )
	guiSetVisible( punishlogWindow, false )
	guiSetVisible( warpToWindow, false )
end

-- Create the windows onResourceStart
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), 
	function ()
		createPunishMentWindows()
	end
)

-- For centering the windows
function onCenterWindow ( theWindow )
	local screenW,screenH=guiGetScreenSize()
	local windowW,windowH=guiGetSize(theWindow,false)
	local x,y = (screenW-windowW)/2,(screenH-windowH)/2
	guiSetPosition(theWindow,x,y,false)
end

-- Set jail windows enabled
function setJailWindowVisable()
	if not ( guiGetVisible (adminPanelJailWindow) ) then
		guiSetVisible( adminPanelJailWindow, true )
		guiBringToFront ( adminPanelJailWindow )
		local thePlayerName, thePlayerElement = getSelectedGridPlayer()
		guiSetText(adminPanelJailLabel1, "You are about to jail: " .. thePlayerName .. "")
	else
		guiSetVisible( adminPanelJailWindow, false )
		guiSetText(adminPanelJailReasonEdit, "Custom Reason")
		guiSetText(adminPanelJailTimeEdit, "")
		guiCheckBoxSetSelected ( adminPanelJailCheckbox1, false )
		guiCheckBoxSetSelected ( adminPanelJailCheckbox2, false )
	end
end

-- Set kick windows enabled
function setKickWindowVisable()
	if not ( guiGetVisible (adminPanelKickWindow) ) then
		guiSetVisible( adminPanelKickWindow, true )
		local thePlayerName, thePlayerElement = getSelectedGridPlayer()
		guiSetText(adminPanelKickWindow, "CSG ~ Kick player (" .. thePlayerName .. ")")
		guiBringToFront ( adminPanelKickWindow )
	else
		guiSetVisible( adminPanelKickWindow, false )
		guiSetText(adminPanelKickReasonEdit, "")
	end
end

-- Set mute window enabled
function setMuteWindowVisable()
	if not ( guiGetVisible (adminPanelMuteWindow) ) then
		guiSetVisible( adminPanelMuteWindow, true )
		guiBringToFront ( adminPanelMuteWindow )
		local thePlayerName, thePlayerElement = getSelectedGridPlayer()
		guiSetText(adminPanelMuteLabel1, "You are about to mute: " .. thePlayerName .. "")
	else
		guiSetVisible( adminPanelMuteWindow, false )
		guiSetText(adminPanelMuteReasonEdit, "Custom Reason")
		guiSetText(adminPanelMuteTimeEdit, "")
		guiCheckBoxSetSelected ( adminPanelMuteCheckbox1, false )
		guiCheckBoxSetSelected ( adminPanelMuteCheckbox2, false )
		guiCheckBoxSetSelected ( adminPanelMuteCheckbox3, false )
		guiCheckBoxSetSelected ( adminPanelMuteCheckbox4, false )
	end
end

-- Set ban window enabled
function setBanWindowVisable()
	if not ( guiGetVisible (adminPanelBanWindow) ) then
		guiSetVisible( adminPanelBanWindow, true )
		guiBringToFront ( adminPanelBanWindow )
		local thePlayerName, thePlayerElement = getSelectedGridPlayer()
		guiSetText(adminPanelBanLabel, "You are about to ban: " .. thePlayerName .. "")
	else
		guiSetVisible( adminPanelBanWindow, false )
		guiSetText(adminPanelBanReasonEdit, "Custom Reason")
		guiSetText(adminPanelBanTimeEdit, "")
		guiCheckBoxSetSelected ( adminPanelBanCheckbox1, false )
		guiRadioButtonSetSelected ( adminPanelBanCheckbox2, false )
		guiRadioButtonSetSelected ( adminPanelBanCheckbox3, false )
		guiCheckBoxSetSelected ( adminPanelBanCheckbox4, false )
		guiCheckBoxSetSelected ( adminPanelBanCheckbox5, false )
	end
end

-- Close punishments
function setPunishWindowVisable ()
	guiSetVisible( punishlogWindow, false )
end

-- Punishments
addEvent ("onShowPunishmentsScreen", true)
addEventHandler ("onShowPunishmentsScreen", root,
	function ( thePlayer, serialPunishments, accountPunishments )
		guiSetText( punishlogWindow, "Punishments from "..getPlayerName( thePlayer ) )
		guiGridListClear ( serialPunishGrid )
		guiGridListClear ( accountPunishGrid )
		
		if ( accountPunishments ) then
			for key, punish in ipairs( accountPunishments ) do
				local row = guiGridListAddRow ( accountPunishGrid )
				guiGridListSetItemText ( accountPunishGrid, row, 1, punish.datum, false, false )
				guiGridListSetItemText ( accountPunishGrid, row, 2, punish.punishment, false, false )
				guiGridListSetItemData ( accountPunishGrid, row, 1, punish.uniqueid..","..punish.punisher )
				
				if ( punish.active == 0 ) then
					guiGridListSetItemColor ( accountPunishGrid, row, 1, 225, 0, 0 )
					guiGridListSetItemColor ( accountPunishGrid, row, 2, 225, 0, 0 )
				end
			end
		end
		
		if ( serialPunishments ) then
			for key, punish in ipairs( serialPunishments ) do
				local row = guiGridListAddRow ( serialPunishGrid )
				guiGridListSetItemText ( serialPunishGrid, row, 1, punish.datum, false, false )
				guiGridListSetItemText ( serialPunishGrid, row, 2, punish.punishment, false, false )
				guiGridListSetItemData ( serialPunishGrid, row, 1, punish.uniqueid..","..punish.punisher )
				
				if ( punish.active == 0 ) then
					guiGridListSetItemColor ( serialPunishGrid, row, 1, 225, 0, 0 )
					guiGridListSetItemColor ( serialPunishGrid, row, 2, 225, 0, 0 )
				end
			end
		end		
		
		guiSetVisible(punishlogWindow, true) showCursor(true,true) guiBringToFront( punishlogWindow )
	end
)

function onDeleteAccountPunishLogRow ()
	local row, column = guiGridListGetSelectedItem ( accountPunishGrid )
	if ( tostring( row ) ~= "-1" ) then
		local rowData = guiGridListGetItemData ( accountPunishGrid, row, 1 )
		local rowDataTable = exports.server:stringExplode( rowData, "," )
		local uniqueID, punisher = rowDataTable[1], rowDataTable[2]
		local r, g, b, a = guiGridListGetItemColor ( accountPunishGrid, row, 1 )
		if ( r == 225 ) then
			outputChatBox( "This punishment is already 'removed'!", 225, 0, 0 )
		elseif ( punisher == exports.server:getPlayerAccountName( localPlayer ) ) or ( getElementData( localPlayer, "thePlayerStaffLevel" ) >= 4 ) then
			local thePlayerName, thePlayerElement = getSelectedGridPlayer()
			triggerServerEvent( "onRemovePlayerPunishlogRow", localPlayer, uniqueID, thePlayerElement )
			guiGridListSetItemColor ( accountPunishGrid, row, 1, 225, 0, 0 )
			guiGridListSetItemColor ( accountPunishGrid, row, 2, 225, 0, 0 )
		else
			outputChatBox( "You are only allowed to 'remove' punishments made by you!", 225, 0, 0 )
		end
	else
		outputChatBox( "Please select a item!", 225, 0, 0 )
	end
end

function onDeleteSerialPunishLogRow ()
	local row, column = guiGridListGetSelectedItem ( serialPunishGrid )
	if ( tostring( row ) ~= "-1" ) then
		local rowData = guiGridListGetItemData ( serialPunishGrid, row, 1 )
		local rowDataTable = exports.server:stringExplode( rowData, "," )
		local uniqueID, punisher = rowDataTable[1], rowDataTable[2]
		local r, g, b, a = guiGridListGetItemColor ( serialPunishGrid, row, 1 )
		if ( r == 225 ) then
			outputChatBox( "This punishment is already 'removed'!", 225, 0, 0 )
		elseif ( punisher == exports.server:getPlayerAccountName( localPlayer ) ) or ( getElementData( localPlayer, "thePlayerStaffLevel" ) >= 4 ) then
			local thePlayerName, thePlayerElement = getSelectedGridPlayer()
			triggerServerEvent( "onRemovePlayerPunishlogRow", localPlayer, uniqueID, thePlayerElement )
			guiGridListSetItemColor ( serialPunishGrid, row, 1, 225, 0, 0 )
			guiGridListSetItemColor ( serialPunishGrid, row, 2, 225, 0, 0 )
		else
			outputChatBox( "You are only allowed to remove your own made punishments!", 225, 0, 0 )
		end
	else
		outputChatBox( "Please select a item!", 225, 0, 0 )
	end
end

-- warp to
function loadPlayersInToWarp ()
	guiGridListClear( warpToGrid )
	for id, player in ipairs(getElementsByType("player")) do
		if ( getElementData( player, "accountUserID" ) ) then
			local row = guiGridListAddRow ( warpToGrid )
			guiGridListSetItemText ( warpToGrid, row, 1, getPlayerName ( player ), false, false )
		end
	end
end

function guiGetSelectedWarpPlayer ()
	local thePlayer = guiGridListGetItemText(warpToGrid, guiGridListGetSelectedItem(warpToGrid), 1)
	if ( isElement( getPlayerFromName( thePlayer ) ) ) then
		return thePlayer, getPlayerFromName( thePlayer )
	else
		return false
	end
end

function onShowWarpToWindow ()
	if ( guiGetVisible( warpToWindow ) ) then
		guiSetVisible( warpToWindow, false )
	else
		if ( getSelectedGridPlayer () ) then
			loadPlayersInToWarp ()
			guiSetVisible(warpToWindow, true) 
			showCursor(true,true)
			guiBringToFront( warpToWindow )
		end
	end
end

function onCloseWarpWindow ()
	guiSetVisible( warpToWindow, false )
end

function onWarpPlayerTo ()
	if ( getSelectedGridPlayer () ) and ( guiGetSelectedWarpPlayer () ) then
		if ( isElement( getPlayerFromName(getSelectedGridPlayer () ) ) ) and ( isElement( getPlayerFromName(guiGetSelectedWarpPlayer () ) ) ) then
			triggerServerEvent( "onAdminWarpPlayer", localPlayer, getPlayerFromName(getSelectedGridPlayer () ), getPlayerFromName(guiGetSelectedWarpPlayer () ), true ) 
			guiSetVisible( warpToWindow, false )
		end
	end
end

function onSearchWarpToPlayer()
	guiGridListClear(warpToGrid)
	local name = guiGetText(warpToEdit)
	for id, player in ipairs(getElementsByType("player")) do
		if ( getElementData( player, "accountUserID" ) ) then
			if string.find(getPlayerName(player):lower(), name:lower()) then
				local playerTeam = getPlayerTeam( player )
				if ( playerTeam ) then
					local r, g, b = getTeamColor ( playerTeam )
					local row = guiGridListAddRow ( warpToGrid )
					guiGridListSetItemText ( warpToGrid, row, 1, getPlayerName ( player ), false, false )
				end
			end
		end
	end
end