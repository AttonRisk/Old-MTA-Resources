function createAdminPanelWindow ()	
	-- Staff Panel Window
	adminPanelWindow = guiCreateWindow(507,82,739,609,"",false)	
	adminPanelTabbar = guiCreateTabPanel(9,20,721,580,false,adminPanelWindow)
	-- Staff Panel Tab
	adminPanelTabOne = guiCreateTab("Staff Panel",adminPanelTabbar)
	adminPanelTabOneUserSearch = guiCreateEdit(4,5,174,22,"",false,adminPanelTabOne)
	adminPanelTabOneUserGrid = guiCreateGridList(4,30,173,520,false,adminPanelTabOne)
	guiGridListSetSortingEnabled ( adminPanelTabOneUserGrid, false )
	playersColumn = guiGridListAddColumn( adminPanelTabOneUserGrid, "Players:", 0.85 )
	guiGridListSetSelectionMode(adminPanelTabOneUserGrid,0)
	adminPanelTabOneSpectate = guiCreateButton(522,91,95,24,"Spectate",false,adminPanelTabOne)
	adminPanelTabOneFreeze = guiCreateButton(522,63,95,24,"Freeze",false,adminPanelTabOne)
	adminPanelTabOneMute = guiCreateButton(522,35,95,24,"Mute",false,adminPanelTabOne)
	adminPanelTabOneKick = guiCreateButton(522,7,95,24,"Kick",false,adminPanelTabOne)
	adminPanelTabOneBan = guiCreateButton(621,7,95,24,"Ban",false,adminPanelTabOne)
	adminPanelTabOneJail = guiCreateButton(621,35,95,24,"Jail",false,adminPanelTabOne)
	adminPanelTabOneSlap = guiCreateButton(621,63,95,24,"Slap",false,adminPanelTabOne)
	adminPanelTabOneWarning = guiCreateButton(621,90,95,24,"Send message",false,adminPanelTabOne)
	adminPanelTabOneSetNick = guiCreateButton(521,135,95,24,"Set nick",false,adminPanelTabOne)
	adminPanelTabOneSetArmor = guiCreateButton(521,163,95,24,"Set Armor",false,adminPanelTabOne)
	adminPanelTabOneSetMoney = guiCreateButton(522,191,95,24,"Set Money",false,adminPanelTabOne)
	adminPanelTabOneSetDimension = guiCreateButton(522,219,95,24,"Set Dimension",false,adminPanelTabOne)
	adminPanelTabOneWarpTo = guiCreateButton(522,262,194,24,"Warp to player",false,adminPanelTabOne)
	adminPanelTabOneWarpPlayerTo = guiCreateButton(522,290,194,24,"Warp player to...",false,adminPanelTabOne)
	adminPanelTabOneGiveWeapon = guiCreateButton(522,318,194,24,"Give Weapon",false,adminPanelTabOne)
	adminPanelTabOneGiveVehicle = guiCreateButton(522,346,194,24,"Give Vehicle",false,adminPanelTabOne)
	adminPanelTabOneSetDrugs = guiCreateButton(522,374,194,24,"Set Drugs",false,adminPanelTabOne)
	adminPanelTabOneGetPunishments = guiCreateButton(522,402,194,24,"Get Punishments",false,adminPanelTabOne)
	adminPanelTabOneGetOtherStats = guiCreateButton(522,429,194,24,"Get other status",false,adminPanelTabOne)
	adminPanelTabOneFixVehicle = guiCreateButton(522,473,194,24,"Fix Vehicle",false,adminPanelTabOne)
	adminPanelTabOneDestroyVehicle = guiCreateButton(522,500,194,24,"Destroy Vehicle",false,adminPanelTabOne)
	adminPanelTabOneConsoleInfoButton = guiCreateButton(522,527,194,24,"Output information in console",false,adminPanelTabOne)
	adminPanelTabOneSetHealth = guiCreateButton(621,135,95,24,"Set Health",false,adminPanelTabOne)
	adminPanelTabOneSetSkin = guiCreateButton(621,163,95,24,"Set Skin",false,adminPanelTabOne)
	adminPanelTabOneSetJob = guiCreateButton(622,191,95,24,"Set Job",false,adminPanelTabOne)
	adminPanelTabOneSetInterior = guiCreateButton(622,219,95,24,"Set Interior",false,adminPanelTabOne)
	adminPanelTabOneLabel1 = guiCreateLabel(186,30,268,16,"Player General Information:",false,adminPanelTabOne)
	guiLabelSetColor(adminPanelTabOneLabel1,255,165,0)
	guiSetFont(adminPanelTabOneLabel1,"default-bold-small")
	adminPanelTabOneNameLabel = guiCreateLabel(186,52,314,16,"Player name:",false,adminPanelTabOne)
	adminPanelTabOneAccountLabel = guiCreateLabel(186,73,314,16,"Account name:",false,adminPanelTabOne)
	adminPanelTabOneSerialLabel = guiCreateLabel(186,92,314,16,"Serial:",false,adminPanelTabOne)
	adminPanelTabOneIpLabel = guiCreateLabel(186,113,314,16,"IP adress:",false,adminPanelTabOne)
	adminPanelTabOnePingLabel = guiCreateLabel(186,133,314,16,"Ping:",false,adminPanelTabOne)
	adminPanelTabOneLabel2 = guiCreateLabel(185,174,268,16,"Game Information:",false,adminPanelTabOne)
	guiLabelSetColor(adminPanelTabOneLabel2,255,165,0)
	guiSetFont(adminPanelTabOneLabel2,"default-bold-small")
	adminPanelTabOneXLabel = guiCreateLabel(186,198,314,16,"X:",false,adminPanelTabOne)
	adminPanelTabOneYLabel = guiCreateLabel(186,218,314,16,"Y:",false,adminPanelTabOne)	
	adminPanelTabOneZLabel = guiCreateLabel(186,238,314,16,"Z:",false,adminPanelTabOne)
	adminPanelTabOneDimensionLabel = guiCreateLabel(186,258,134,16,"Dimension:",false,adminPanelTabOne)
	adminPanelTabOneInteriorLabel = guiCreateLabel(334,258,134,16,"Interior:",false,adminPanelTabOne)
	adminPanelTabOneHealthLabel = guiCreateLabel(186,277,134,16,"Health:",false,adminPanelTabOne)
	adminPanelTabOneArmorLabel = guiCreateLabel(334,277,134,16,"Armor:",false,adminPanelTabOne)
	adminPanelTabOneJobLabel = guiCreateLabel(186,298,314,16,"Occupation:",false,adminPanelTabOne)
	adminPanelTabOneTeamLabel = guiCreateLabel(186,318,314,16,"Team:",false,adminPanelTabOne)
	adminPanelTabOneGroupLabel = guiCreateLabel(186,337,314,16,"Group:",false,adminPanelTabOne)
	adminPanelTabOneMoneyLabel = guiCreateLabel(186,356,134,16,"Money:",false,adminPanelTabOne)
	adminPanelTabOneBankMoneyLabel = guiCreateLabel(334,358,134,16,"Bank Money:",false,adminPanelTabOne)
	adminPanelTabOneWeaponLabel = guiCreateLabel(186,377,314,16,"Current Weapon:",false,adminPanelTabOne)
	adminPanelTabOneSkinLabel = guiCreateLabel(186,397,134,16,"Skin:",false,adminPanelTabOne)
	adminPanelTabOneFightingStyleLabel = guiCreateLabel(334,399,134,16,"Fightingstyle:",false,adminPanelTabOne)
	adminPanelTabOneLabel3 = guiCreateLabel(185,429,268,16,"Vehicle Information:",false,adminPanelTabOne)
	guiLabelSetColor(adminPanelTabOneLabel3,255,165,0)
	guiSetFont(adminPanelTabOneLabel3,"default-bold-small")
	adminPanelTabOneVehicleLabel = guiCreateLabel(186,452,314,16,"Current Vehicle:",false,adminPanelTabOne)
	adminPanelTabOneVehicleHealthLabel = guiCreateLabel(186,473,314,16,"Vehicle Health:",false,adminPanelTabOne)
	adminPanelTabOneVehicleTypeLabel = guiCreateLabel(186,494,314,16,"Vehicle Type:",false,adminPanelTabOne)
	adminPanelTabOneWarnLabel = guiCreateLabel(185,532,327,15,"",false,adminPanelTabOne)
	guiLabelSetColor(adminPanelTabOneWarnLabel,225,0,0)
	guiSetFont(adminPanelTabOneWarnLabel,"default-bold-small")
	-- Staff Chat Tab
	adminPanelTabTwo = guiCreateTab("Admin Chat",adminPanelTabbar)
	adminPanelTabTwoChatLabel = guiCreateLabel(7,10,181,17,"Admin Chat:",false,adminPanelTabTwo)
	guiSetFont(adminPanelTabTwoChatLabel,"default-bold-small")	
	adminPanelTabTwoChatGrid = guiCreateGridList(4,33,713,482,false,adminPanelTabTwo)
	timeColumn = guiGridListAddColumn( adminPanelTabTwoChatGrid, "Time:", 0.15 )
	senderColumn = guiGridListAddColumn( adminPanelTabTwoChatGrid, "Sender:", 0.25 )
	messageColumn = guiGridListAddColumn( adminPanelTabTwoChatGrid, "Message:", 0.55 )
	adminPanelTabTwoChatField = guiCreateEdit(4,517,597,35,"",false,adminPanelTabTwo)
	adminPanelTabTwoChatSend = guiCreateButton(603,518,114,33,"Send",false,adminPanelTabTwo)
	adminPanelTabTwoChatClear = guiCreateButton(611,5,105,25,"Clear Chat",false,adminPanelTabTwo)
	-- Event manager panel
	adminEmTab = guiCreateTab("Event Manager Panel",adminPanelTabbar)
	adminEmLabel1 = guiCreateLabel(8,8,136,19,"Select player from list:",false,adminEmTab)
	guiSetFont(adminEmLabel1,"default-bold-small")
	adminEmPlayerGrid = guiCreateGridList(5,47,235,266,false,adminEmTab)
	playersColumn2 = guiGridListAddColumn( adminEmPlayerGrid, "Players:", 0.9 )
	guiGridListSetSelectionMode(adminEmPlayerGrid,0)
	adminEmPlayerSearch = guiCreateEdit(5,25,236,20,"",false,adminEmTab)
	adminEmMoneyTransfer = guiCreateButton(260,288,218,25,"Transfer money to player",false,adminEmTab)
	adminEmLabel2 = guiCreateLabel(263,247,169,19,"Send player money: (Amount)",false,adminEmTab)
	guiSetFont(adminEmLabel2,"default-bold-small")
	adminEmMoneyEdit = guiCreateEdit(261,264,218,20,"",false,adminEmTab)
	adminEmLabel3 = guiCreateLabel(250,8,10,307,"|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n",false,adminEmTab)
	adminEmLabel4 = guiCreateLabel(264,8,230,19,"Create vehicle spawner: (Vehicle name)",false,adminEmTab)
	guiSetFont(adminEmLabel4,"default-bold-small")
	adminEmVehicleEdit = guiCreateEdit(261,25,129,20,"",false,adminEmTab)
	adminEmVehicleCreate = guiCreateButton(391,26,106,19,"Create",false,adminEmTab)
	adminEmVehicleDestroyVehicles = guiCreateButton(607,26,111,19,"Destroy Vehicles",false,adminEmTab)
	adminEmVehicleDestroyMarker = guiCreateButton(499,26,106,19,"Destroy Marker",false,adminEmTab)
	adminEmLabel5 = guiCreateLabel(261,50,453,14,"-----------------------------------------------------------------------------------------------------------------",false,adminEmTab)
	adminEmLabel6 = guiCreateLabel(264,70,282,19,"Create health or armor pickup: (Health or Armor)",false,adminEmTab)
	guiSetFont(adminEmLabel6,"default-bold-small")
	adminEmPickupEdit = guiCreateEdit(261,88,236,20,"",false,adminEmTab)
	adminEmPickupCreate = guiCreateButton(499,88,106,19,"Create",false,adminEmTab)
	adminEmPickupDestroy = guiCreateButton(607,88,111,19,"Destroy",false,adminEmTab)
	adminEmLabel7 = guiCreateLabel(261,117,453,14,"-----------------------------------------------------------------------------------------------------------------",false,adminEmTab)
	adminEmLabel8 = guiCreateLabel(264,139,299,19,"Create eventwarp to current position: (Event name)",false,adminEmTab)
	guiSetFont(adminEmLabel8,"default-bold-small")
	adminEmWarpsTitle = guiCreateEdit(261,159,452,21,"",false,adminEmTab)
	adminEmLabel9 = guiCreateLabel(264,188,69,19,"Warp limit:",false,adminEmTab)
	guiSetFont(adminEmLabel9,"default-bold-small")
	adminEmWarpsLimit = guiCreateEdit(328,186,163,21,"",false,adminEmTab)
	adminEmWarpsCreate = guiCreateButton(263,211,156,19,"Create event",false,adminEmTab)
	adminEmWarpsUnfreeze = guiCreateButton(422,211,146,19,"Unfreeze players",false,adminEmTab)
	adminEmWarpsDestroy = guiCreateButton(570,211,149,19,"Destroy event",false,adminEmTab)
	adminEmLabel11 = guiCreateLabel(261,236,453,14,"-----------------------------------------------------------------------------------------------------------------",false,adminEmTab)
	adminEmLabel12 = guiCreateLabel(6,315,705,14,"-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------",false,adminEmTab)
	adminEmLabel13 = guiCreateLabel(481,247,235,19,"Give weapon: (Weapon name) (Ex: AK-47)",false,adminEmTab)
	guiSetFont(adminEmLabel13,"default-bold-small")
	adminEmWeaponEdit = guiCreateEdit(479,264,237,20,"",false,adminEmTab)
	adminEmWeaponGive = guiCreateButton(481,288,234,25,"Give player weapon",false,adminEmTab)
	adminEmLabel14 = guiCreateLabel(7,329,169,19,"Notes:",false,adminEmTab)
	guiSetFont(adminEmLabel14,"default-bold-small")
	adminEmNotes = guiCreateMemo(5,344,712,208,"",false,adminEmTab)
	adminEmLabel15 = guiCreateLabel(496,188,62,19,"Dimension:",false,adminEmTab)
	guiSetFont(adminEmLabel15,"default-bold-small")
	adminEmWarpsDimension = guiCreateEdit(559,186,159,21,"0",false,adminEmTab)
	-- Notes tab
	adminNotesTab = guiCreateTab("Notes",adminPanelTabbar)
	adminNotesMemo = guiCreateMemo(1,2,719,518,"",false,adminNotesTab)
	adminNotesButton = guiCreateButton(1,522,473,31,"Update the notes",false,adminNotesTab)
	adminNotesCheckbox = guiCreateCheckBox(479,522,231,34,"Notify other staff about the change",false,false,adminNotesTab)
	guiSetFont(adminNotesCheckbox,"default-bold-small")
	
	-- NNOTES HANDLERS
	addEventHandler	("onClientGUIClick", adminNotesButton, onClientUpdateAdminNotes, false)
	
	-- EVENT MANAGER HANDLERS
	addEventHandler	("onClientGUIChanged", adminEmPlayerSearch, onClientSearchPlayerFromEmGrid, false)
	addEventHandler	("onClientGUIClick", adminEmVehicleCreate, onClientEventCreateVehicleMarker, false)
	addEventHandler	("onClientGUIClick", adminEmVehicleDestroyMarker, onClientEventDestroyVehicleMarker, false)
	addEventHandler	("onClientGUIClick", adminEmVehicleDestroyVehicles, onClientEventDestroyVehicles, false)
	addEventHandler	("onClientGUIClick", adminEmWarpsCreate, onClientCreateEvent, false)
	addEventHandler	("onClientGUIClick", adminEmWarpsUnfreeze, onClientUnfeezeEvent, false)
	addEventHandler	("onClientGUIClick", adminEmWarpsDestroy, onClientDestroyEvent, false)	
	addEventHandler	("onClientGUIClick", adminEmWeaponGive, onClientGiveEventMoney, false)
	addEventHandler ("onClientGUIClick", adminEmMoneyTransfer, onClientGiveEventWeapon, false)
	addEventHandler ("onClientGUIClick", adminEmPickupCreate, onClientCreateEventPickup, false)
	addEventHandler ("onClientGUIClick", adminEmPickupDestroy, onClientDestroyEventPickup, false)
	-- OTHERS
	addEventHandler	("onClientGUIChanged", adminPanelTabOneUserSearch, onClientSearchPlayerFromGrid, false)
	addEventHandler	("onClientGUIClick", adminPanelTabOneUserGrid, onClickPlayerFromList, false)
	addEventHandler ("onClientGUIClick", adminPanelTabTwoChatSend, onSendStaffChatMessage, false)
	addEventHandler ("onClientGUIClick", adminPanelTabTwoChatClear, onClearStaffChatGrid, false)
	addEventHandler ("onClientGUIClick", adminPanelTabOneBan, onShowBanWindow, false)
	addEventHandler ("onClientGUIClick", adminPanelTabOneJail, onShowJailWindow, false)
	addEventHandler ("onClientGUIClick", adminPanelTabOneMute, onShowMuteWindow, false)
	addEventHandler ("onClientGUIClick", adminPanelTabOneSlap, onSlapPlayer, false)
	addEventHandler ("onClientGUIClick", adminPanelTabOneKick, onShowKickWindow, false)
	addEventHandler ("onClientGUIClick", adminPanelTabOneFreeze, onFreezeThePlayer, false)
	addEventHandler ("onClientGUIClick", adminPanelTabOneConsoleInfoButton, onOutputConsoleInfo, false)
	addEventHandler ("onClientGUIClick", adminPanelTabOneGetPunishments, requestPunishments, false)
	addEventHandler ("onClientGUIClick", adminPanelTabOneSpectate, onPlayerSpecate, false)
	addEventHandler ("onClientGUIClick", adminPanelTabOneWarpTo, onWarpToPlayer, false )
	addEventHandler ("onClientGUIClick", adminPanelTabOneWarpPlayerTo, function () onShowWarpToWindow () end, false )
	addEventHandler ("onClientGUIClick", adminPanelTabOneFixVehicle, onAdminDoVehicleFix, false )
	addEventHandler ("onClientGUIClick", adminPanelTabOneDestroyVehicle, onDestroyAdminVehicle, false )
	
	local screenW,screenH=guiGetScreenSize()
	local windowW,windowH=guiGetSize(adminPanelWindow,false)
	local x,y = (screenW-windowW)/2,(screenH-windowH)/2
	guiSetPosition(adminPanelWindow,x,y,false)	
	guiSetVisible( adminPanelWindow, false )
end

-- Create the window onResourceStart
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), 
	function ()
		createAdminPanelWindow()
	end
)

function applyACL ()
	-- Apply acl
	local staffLevel = getElementData( localPlayer, "thePlayerStaffLevel" )
	local CSGAdminACL = getAdminACL()
	for i=1,#CSGAdminACL do
		if ( staffLevel < CSGAdminACL[i][2] ) then
			if ( CSGAdminACL[i][1] == "Mainpanel" ) then
				-- Nothing
			end
			if ( CSGAdminACL[i][1] == "Event Manager Panel" ) then
				if not ( getElementData( localPlayer, "isPlayerEventManager" ) ) then
					guiSetEnabled( adminEmTab, false )
				end
			end
			if ( CSGAdminACL[i][1] == "Bans" ) then
				-- Nothing
			end
			if ( CSGAdminACL[i][1] == "Notes" ) then
				-- Nothing
			end
			if ( CSGAdminACL[i][1] == "Kick" ) then
				guiSetEnabled( adminPanelTabOneKick, false )
			end
			if ( CSGAdminACL[i][1] == "Ban" ) then
				guiSetEnabled( adminPanelTabOneBan, false )
			end
			if ( CSGAdminACL[i][1] == "Mute" ) then
				guiSetEnabled( adminPanelTabOneMute, false )
			end
			if ( CSGAdminACL[i][1] == "Jail" ) then
				guiSetEnabled( adminPanelTabOneJail, false )
			end
			if ( CSGAdminACL[i][1] == "Freeze" ) then
				guiSetEnabled( adminPanelTabOneFreeze, false )
			end
			if ( CSGAdminACL[i][1] == "Slap" ) then
				guiSetEnabled( adminPanelTabOneSlap, false )
			end
			if ( CSGAdminACL[i][1] == "Spectate" ) then
				guiSetEnabled( adminPanelTabOneSpectate, false )
			end
			if ( CSGAdminACL[i][1] == "Send Message" ) then
				guiSetEnabled( adminPanelTabOneWarning, false )
			end
			if ( CSGAdminACL[i][1] == "Set Nick" ) then
				guiSetEnabled( adminPanelTabOneSetNick, false )
			end
			if ( CSGAdminACL[i][1] == "Set Health" ) then
				guiSetEnabled( adminPanelTabOneSetHealth, false )
			end
			if ( CSGAdminACL[i][1] == "Set Armor" ) then
				guiSetEnabled( adminPanelTabOneSetArmor, false )
			end
			if ( CSGAdminACL[i][1] == "Set Skin" ) then
				guiSetEnabled( adminPanelTabOneSetSkin, false )
			end
			if ( CSGAdminACL[i][1] == "Set Money" ) then
				guiSetEnabled( adminPanelTabOneSetMoney, false )
			end
			if ( CSGAdminACL[i][1] == "Set Job" ) then
				guiSetEnabled( adminPanelTabOneSetJob, false )
			end
			if ( CSGAdminACL[i][1] == "Set Dimension" ) then
				guiSetEnabled( adminPanelTabOneSetDimension, false )
			end
			if ( CSGAdminACL[i][1] == "Set Interior" ) then
				guiSetEnabled( adminPanelTabOneSetInterior, false )
			end
			if ( CSGAdminACL[i][1] == "Warp to player" ) then
				guiSetEnabled( adminPanelTabOneWarpTo, false )
			end
			if ( CSGAdminACL[i][1] == "Warp player to..." ) then
				guiSetEnabled( adminPanelTabOneWarpPlayerTo, false )
			end
			if ( CSGAdminACL[i][1] == "Give Weapon" ) then
				guiSetEnabled( adminPanelTabOneGiveWeapon, false )
			end
			if ( CSGAdminACL[i][1] == "Give Vehicle" ) then
				guiSetEnabled( adminPanelTabOneGiveVehicle, false )
			end
			if ( CSGAdminACL[i][1] == "Set Drugs" ) then
				guiSetEnabled( adminPanelTabOneSetDrugs, false )
			end
			if ( CSGAdminACL[i][1] == "Get Punishments" ) then
				guiSetEnabled( adminPanelTabOneGetPunishments, false )
			end
			if ( CSGAdminACL[i][1] == "Get other status" ) then
				guiSetEnabled( adminPanelTabOneGetOtherStats, false )
			end
			if ( CSGAdminACL[i][1] == "Fix Vehicle" ) then
				guiSetEnabled( adminPanelTabOneFixVehicle, false )
			end
			if ( CSGAdminACL[i][1] == "Destroy Vehicle" ) then
				guiSetEnabled( adminPanelTabOneDestroyVehicle, false )
			end
			if ( CSGAdminACL[i][1] == "Output information in console" ) then
				guiSetEnabled( adminPanelTabOneConsoleInfoButton, false )
			end
		end
	end
end

-- Set the adminpanel visable or not
function setAdminPanelWindowEnabled ( state )
	if ( state ) then
		loadUsersIntoGridlist ()
		guiSetVisible( adminPanelWindow, true )
		guiWindowSetSizable ( adminPanelWindow, false )
		applyACL ()
		showCursor(true,true)
		addEventHandler ("onClientRender", root, onClientRenderUpdateInformation )
		triggerServerEvent( "onLoadAdminNotes", localPlayer )
		return true
	else
		removeEventHandler ("onClientRender", root, onClientRenderUpdateInformation )
		guiSetVisible( adminPanelWindow, false )
		guiSetText(adminPanelTabOneFreeze, "Freeze")
		guiSetText( adminPanelTabOneWarnLabel, "" )
		showCursor(false,false)
		return false
	end
end

-- Function that checks if the GUI is visable or not
function isAdminPanelShowing ()
	if guiGetVisible (adminPanelWindow) then
		return true
	else
		return false
	end
end

-- Function that gets the selected player
function getSelectedGridPlayer ()
	local thePlayer = guiGridListGetItemText(adminPanelTabOneUserGrid, guiGridListGetSelectedItem(adminPanelTabOneUserGrid), 1)
	if guiGetVisible (adminPanelWindow) then
		if ( isElement( getPlayerFromName( thePlayer ) ) ) then
			return thePlayer, getPlayerFromName( thePlayer )
		else
			return false
		end
	else
		return false
	end
end

-- Get the data from a GUI element
function getGuiElementText ( theGUI )
	local guiText = guiGetText ( theGUI )
	if ( guiText ) then
		return guiText
	else
		return false
	end
end

-- onClientRender update all the player information
function onClientRenderUpdateInformation ()
	if guiGetVisible (adminPanelWindow) then
		local thePlayer = getPlayerFromName(guiGridListGetItemText(adminPanelTabOneUserGrid, guiGridListGetSelectedItem(adminPanelTabOneUserGrid), 1))
		if ( isElement(thePlayer) ) then
			local x, y, z = getElementPosition ( thePlayer )
			guiSetText(adminPanelTabOneXLabel, "X: "..x)
			guiSetText(adminPanelTabOneYLabel, "Y: "..y)
			guiSetText(adminPanelTabOneZLabel, "Z: "..z)
			guiSetText(adminPanelTabOnePingLabel, "Ping: "..getPlayerPing(thePlayer))
			guiSetText(adminPanelTabOneHealthLabel, "Health: "..math.floor(getElementHealth(thePlayer)).."%")
			guiSetText(adminPanelTabOneArmorLabel, "Armor: "..math.floor(getPedArmor(thePlayer)))
			local theVehicle = getPedOccupiedVehicle ( thePlayer )
			if ( theVehicle ) then
				guiSetText(adminPanelTabOneVehicleLabel, "Current Vehicle: "..getVehicleName(theVehicle))
				guiSetText(adminPanelTabOneVehicleHealthLabel, "Vehicle Health: "..math.floor(getElementHealth(theVehicle)).."%")
			else
				guiSetText(adminPanelTabOneVehicleLabel, "Current Vehicle: Foot")
				guiSetText(adminPanelTabOneVehicleHealthLabel, "Vehicle Health: N/A")
			end
		end
	end
end

-- Load all the users in de gridlist with team color
function loadUsersIntoGridlist ()
	guiGridListClear ( adminPanelTabOneUserGrid )
	guiGridListClear ( adminEmPlayerGrid )
	for id, player in ipairs(getElementsByType("player")) do
		local playerTeam = getPlayerTeam( player )
		if ( playerTeam ) then
			local r, g, b = getTeamColor ( playerTeam )
			local row = guiGridListAddRow ( adminPanelTabOneUserGrid )
			guiGridListSetItemText ( adminPanelTabOneUserGrid, row, 1, getPlayerName ( player ), false, false )
			guiGridListSetItemColor ( adminPanelTabOneUserGrid, row, 1, r, g, b )
			
			local row2 = guiGridListAddRow ( adminEmPlayerGrid )
			guiGridListSetItemText ( adminEmPlayerGrid, row2, 1, getPlayerName ( player ), false, false )
			guiGridListSetItemColor ( adminEmPlayerGrid, row2, 1, r, g, b )
		end
	end
end

-- Change user nick in the grid
function onPlayerChangeNick(oldNick, newNick)
	if guiGetVisible (adminPanelWindow) then
	    for k, v in ipairs({adminPanelTabOneUserGrid}) do
			for row=0, guiGridListGetRowCount(v)-1 do
				if (guiGridListGetItemText(v, row, 1) == oldNick) then
					guiGridListSetItemText(v, row, 1, newNick, false, false)
				end
			end
		end
	end
end
addEventHandler("onClientPlayerChangeNick", root, onPlayerChangeNick)

-- Delete the player from the grid when he quit
function onPlayerQuit()
	if guiGetVisible (adminPanelWindow) then
	    for k, v in ipairs({adminPanelTabOneUserGrid}) do
			for row=0, guiGridListGetRowCount(v)-1 do
				if (guiGridListGetItemText(v, row, 1) == getPlayerName(source)) then
					guiGridListRemoveRow(v, row)
				end
			end
		end
	end
end
addEventHandler("onClientPlayerQuit", root, onPlayerQuit)

-- When player gets in a new team change the color in the grid
addEventHandler ( "onClientElementDataChange", root,
function ( dataName )
	if getElementType ( source ) == "player" and dataName == "Occupation" then
		if guiGetVisible (adminPanelWindow) then
			local playerTeam = getPlayerTeam( source )
			if ( playerTeam ) then
				local r, g, b = getTeamColor ( playerTeam )
				for k, v in ipairs({adminPanelTabOneUserGrid}) do
					for row=0, guiGridListGetRowCount(v)-1 do
						if (guiGridListGetItemText(v, row, 1) == getPlayerName(source)) then
							guiGridListSetItemColor ( v, row, playersColumn, r, g, b )
						end
					end
				end
			end
		end
	end
end )

-- Search for player
function onClientSearchPlayerFromGrid()
guiGridListClear(adminPanelTabOneUserGrid)
guiGridListClear(adminEmPlayerGrid)
local name = guiGetText(adminPanelTabOneUserSearch)
	for id, player in ipairs(getElementsByType("player")) do
        if string.find(getPlayerName(player):lower(), name:lower()) then
			local playerTeam = getPlayerTeam( player )
			if ( playerTeam ) then
				local r, g, b = getTeamColor ( playerTeam )
				local row = guiGridListAddRow ( adminPanelTabOneUserGrid )
				guiGridListSetItemText(adminPanelTabOneUserGrid, row, 1, getPlayerName(player), false, false)
				guiGridListSetItemColor ( adminPanelTabOneUserGrid, row, 1, r, g, b )
			end
		end
	end
end

-- Search for player
function onClientSearchPlayerFromEmGrid()
guiGridListClear(adminEmPlayerGrid)
local name = guiGetText(adminEmPlayerSearch)
	for id, player in ipairs(getElementsByType("player")) do
        if string.find(getPlayerName(player):lower(), name:lower()) then
			local playerTeam = getPlayerTeam( player )
			if ( playerTeam ) then
				local r, g, b = getTeamColor ( playerTeam )				
				local row = guiGridListAddRow ( adminEmPlayerGrid )
				guiGridListSetItemText(adminEmPlayerGrid, row, 1, getPlayerName(player), false, false)
				guiGridListSetItemColor ( adminEmPlayerGrid, row, 1, r, g, b )
			end
		end
	end
end


-- When the staf member clicked a member
function onClickPlayerFromList ()
	if guiGetVisible (adminPanelWindow) then
		local thePlayer = getPlayerFromName(guiGridListGetItemText(adminPanelTabOneUserGrid, guiGridListGetSelectedItem(adminPanelTabOneUserGrid), 1))
		if ( isElement(thePlayer) ) then
			triggerServerEvent ( "onClickPlayerFromList", localPlayer, thePlayer )
			if ( getElementData ( thePlayer, "isPlayerMuted" ) ) then guiSetText( adminPanelTabOneWarnLabel, "WARNING: This player is muted!" ) end
		end
	end
end

-- Update the label data
addEvent ("setLabelData", true)
function setLabelData ( thePlayer, playername, accountname, serial, ip, dimension, interior, job, money, bankmoney, weapon, skin, fightingstyle, team, group )
	local staffLevelSelected = tonumber(getElementData ( thePlayer, "staffLevel" ))
	local staffLevelSelector = tonumber(getElementData ( source, "staffLevel" ))
	
	if ( staffLevelSelected ) then 
		if ( staffLevelSelected > 4 ) and ( staffLevelSelector < 4 ) then 
			ip = "Hidden" 
			serial = "Hidden" 
		end 
	end 	
	
	guiSetText(adminPanelTabOneNameLabel, "Player name: "..playername)
	guiSetText(adminPanelTabOneAccountLabel, "Account name: "..accountname)
	guiSetText(adminPanelTabOneSerialLabel, "Serial: "..serial)
	guiSetText(adminPanelTabOneIpLabel, "IP adress: "..ip)
	guiSetText(adminPanelTabOneDimensionLabel, "Dimension: "..dimension)
	guiSetText(adminPanelTabOneInteriorLabel, "Interior: "..interior)
	guiSetText(adminPanelTabOneJobLabel, "Occupation: "..job)
	guiSetText(adminPanelTabOneMoneyLabel, "Money: "..exports.server:convertNumber(money))
	guiSetText(adminPanelTabOneBankMoneyLabel, "Bank Money: "..exports.server:convertNumber(bankmoney))
	guiSetText(adminPanelTabOneWeaponLabel, "Current Weapon: "..weapon)
	guiSetText(adminPanelTabOneSkinLabel, "Skin: "..skin)
	guiSetText(adminPanelTabOneFightingStyleLabel, "Fightingstyle: "..fightingstyle)
	guiSetText(adminPanelTabOneTeamLabel, "Team: "..team)
	guiSetText(adminPanelTabOneGroupLabel, "Group: "..group)
end
addEventHandler ("setLabelData", root, setLabelData)

-- Output data to the console
function onOutputConsoleInfo ()
	local thePlayerName, thePlayerElement = getSelectedGridPlayer()
	if ( isElement( thePlayerElement ) ) then
		local x, y, z = getElementPosition ( thePlayerElement )
		outputChatBox ( "Information outputted in console!", 0, 225, 0 )
		outputConsole ( "Nickname:" .. thePlayerName .. " Accountname:" .. getElementData( thePlayerElement, "playerAccount" ) .. " X:" .. x .. " Y:" .. y .. " Z:" .. z .. " IP:" .. getElementData( thePlayerElement, "playerIP" ) .. "", localPlayer )
	end
end

-- onFreezePlayer
function onFreezeThePlayer ()
	local thePlayerName, thePlayerElement = getSelectedGridPlayer()
	if ( isElement( thePlayerElement ) ) then
		triggerServerEvent ( "onAdminFreezePlayer", localPlayer, thePlayerElement )
	end
end

addEvent ("freezeButtonCheck", true)
function freezeButtonCheck ( thePlayer ) if ( isElementFrozen ( thePlayer ) ) then guiSetText(adminPanelTabOneFreeze, "Unfreeze") else guiSetText(adminPanelTabOneFreeze, "Freeze") end end
addEventHandler ("freezeButtonCheck", root, freezeButtonCheck)

-- Put the bans in the gridlist
addEvent ("onAddBansIntoGridlist", true)
function onAddBansIntoGridlist ( theTable )
	guiGridListClear ( adminPanelTabTreeBansGrid )
	for i=1,#theTable do
		local row = guiGridListAddRow ( adminPanelTabTreeBansGrid )
		guiGridListSetItemText ( adminPanelTabTreeBansGrid, row, 1, theTable[i].banstamp, false, true )
		guiGridListSetItemText ( adminPanelTabTreeBansGrid, row, 2, theTable[i].account, false, true )
		guiGridListSetItemText ( adminPanelTabTreeBansGrid, row, 3, theTable[i].serial, false, true )
		guiGridListSetItemText ( adminPanelTabTreeBansGrid, row, 4, theTable[i].bannedby, false, true )
	end
end
addEventHandler ("onAddBansIntoGridlist", root, onAddBansIntoGridlist)

function requestPunishments () 
	triggerServerEvent( "onGetPlayerPunishments", localPlayer, getSelectedGridPlayer () )
end

-- Spectate
local spectating = nil
local sx, sy = guiGetScreenSize ()
local randomButton = guiCreateButton ( sx / 2 - 100, sy - 50, 110, 30, "Random Player", false )
local backButton = guiCreateButton ( sx / 2 + 15,  sy - 50, 110, 30, "Back", false )
guiSetVisible( backButton, false )
guiSetVisible( randomButton, false )

local oldDim = 0
local oldInt = 0

function onStopSpectating ()
	removeEventHandler( "onClientPreRender", root, spectateRender )
	local x, y, z = getElementPosition( localPlayer )
	setElementPosition( localPlayer, x, y, z +1 )
	guiSetVisible( backButton, false )
	guiSetVisible( randomButton, false )
	setAdminPanelWindowEnabled ( false )
	setElementInterior(localPlayer, oldInt)
	setElementDimension(localPlayer, oldDim)
	setCameraTarget ( localPlayer )
	spectating = nil
	showCursor( true )
end
addEventHandler ( "onClientGUIClick", backButton, onStopSpectating )

function randomSpectatePlayer ()
	local allPlayers = getElementsByType ( "player" )
	thePlayer = allPlayers[math.random(1,#allPlayers)]
	if not ( thePlayer == localPlayer ) then
		oldDim = getElementInterior(localPlayer)
		oldInt = getElementDimension(localPlayer)
		spectating = thePlayer
		setCameraTarget ( thePlayer )
		setElementInterior(localPlayer, getElementInterior(thePlayer))
		setElementDimension(localPlayer, getElementDimension(thePlayer))
		showCursor( false )
	else
		randomSpectatePlayer ()
	end
end
addEventHandler ( "onClientGUIClick", randomButton, randomSpectatePlayer )

function onPlayerSpecate ()
	if ( getSelectedGridPlayer () ) then
		local thePlayer = getPlayerFromName ( getSelectedGridPlayer () )
		if ( isElement( thePlayer ) ) then
			if not ( thePlayer == localPlayer ) then
				oldDim = getElementInterior(localPlayer)
				oldInt = getElementDimension(localPlayer)
				setCameraTarget ( thePlayer )
				guiSetVisible( backButton, true )
				guiSetVisible( randomButton, true )
				setAdminPanelWindowEnabled ( false )
				setElementInterior(localPlayer, getElementInterior(thePlayer))
				setElementDimension(localPlayer, getElementDimension(thePlayer))
				showCursor( false )
				spectating = thePlayer
				addEventHandler( "onClientPreRender", root, spectateRender )
			else
				exports.DENhelp:createNewHelpMessage("You can't spectate yourself!", 225, 0, 0)
			end
		end
	end
end

addEventHandler( "onClientPlayerQuit", root, 
function ()
	if ( spectating ) then
		if ( spectating == source ) then
			guiSetVisible( backButton, false )
			guiSetVisible( randomButton, false )
			setAdminPanelWindowEnabled ( true )
			local x, y, z = getElementPosition( localPlayer )
			setElementPosition( localPlayer, x, y, z +1 )
			setElementInterior(localPlayer, oldInt)
			setElementDimension(localPlayer, oldDim)
			setCameraTarget ( localPlayer )
			spectating = nil
			showCursor( true )
			removeEventHandler( "onClientPreRender", root, spectateRender )
		end
	end
end
)

function spectateRender ()
	if ( spectating ) then
		dxDrawText ( "Spectating: "..getPlayerName ( spectating ), sx - 170, 200, sx - 170, 200, tocolor ( 255, 255, 255, 255 ), 1 )
	end
end

-- Warp
function onWarpToPlayer ()
	if ( getSelectedGridPlayer () ) then
		local thePlayer = getPlayerFromName( getSelectedGridPlayer () )
		if ( thePlayer ) then
			if ( isElement( thePlayer ) ) then
				triggerServerEvent( "onAdminWarpPlayer", localPlayer, localPlayer, getPlayerFromName(getSelectedGridPlayer ()) ) 
				setAdminPanelWindowEnabled ( false )
			end
		end
	end
end

-- Vehicle Fixing
function onAdminDoVehicleFix ()
	if ( getSelectedGridPlayer () ) then
		local thePlayer = getPlayerFromName( getSelectedGridPlayer () )
		if ( thePlayer ) then
			if ( isElement( thePlayer ) ) then
				triggerServerEvent( "onAdminFixvehicle", localPlayer, getPlayerFromName(getSelectedGridPlayer ()) ) 			
			end
		end
	end
end

-- Destroy veh
function onDestroyAdminVehicle ()
	if ( getSelectedGridPlayer () ) then
		local thePlayer = getPlayerFromName( getSelectedGridPlayer () )
		if ( thePlayer ) then
			if ( isElement( thePlayer ) ) then
				triggerServerEvent( "onAdminDestroyVehicle", localPlayer, getPlayerFromName(getSelectedGridPlayer ()) ) 			
			end
		end
	end
end

-- EM create vehicle
function onClientEventCreateVehicleMarker ()
	local theVehicle = guiGetText( adminEmVehicleEdit )
	if ( theVehicle ) and not ( theVehicle == "" ) and not ( theVehicle == " " ) then
		triggerServerEvent( "onCreateEventVehicleMarker", localPlayer, theVehicle )
	else
		exports.DENhelp:createNewHelpMessage( "There is no vehicle found with this name!", 225, 0, 0 )
	end
end

function onClientEventDestroyVehicleMarker ()
	triggerServerEvent( "onDestroyEventVehicleMarker", localPlayer, exports.server:getPlayerAccountName() )
end

function onClientEventDestroyVehicles ()
	triggerServerEvent( "onDestroyEventVehicles", localPlayer, exports.server:getPlayerAccountName() )
end
	
-- EM
function onClientCreateEvent ()
	local warpLimit = guiGetText( adminEmWarpsLimit )
	local warpInt = getElementInterior( localPlayer )
	local warpDim = guiGetText( adminEmWarpsDimension )
	local eventName = guiGetText( adminEmWarpsTitle )
	if ( string.match( warpLimit ,'^%d+$' ) ) and ( string.match( warpInt ,'^%d+$' ) ) and ( string.match( warpDim ,'^%d+$' ) ) then
		triggerServerEvent( "onCreateWarpEvent", localPlayer, warpLimit, warpDim, warpInt, eventName )
	else
		exports.DENhelp:createNewHelpMessage( "Not all fields are filled in right!", 225, 0, 0 )
	end
end

function onClientUnfeezeEvent ()
	triggerServerEvent( "onUnfreezeEventPlayers", localPlayer )
end

function onClientDestroyEvent ()
	triggerServerEvent( "onDestroyEvent", localPlayer )
end

-- EM give
function onClientGiveEventWeapon ()
	local thePlayer = guiGridListGetItemText(adminEmPlayerGrid, guiGridListGetSelectedItem(adminEmPlayerGrid), 1)
	if ( isElement( getPlayerFromName( thePlayer ) ) ) then
		local theMoney = guiGetText( adminEmMoneyEdit )
		if ( string.match( theMoney ,'^%d+$' ) ) then
			triggerServerEvent( "onSendEventMoney", localPlayer, getPlayerFromName( thePlayer ), tonumber(theMoney) )
		else
			exports.DENhelp:createNewHelpMessage( "The money amount must be a number!", 225, 0, 0 )
		end
	else
		exports.DENhelp:createNewHelpMessage( "You didn't select a player!", 225, 0, 0 )
	end
end

function onClientGiveEventMoney ()
	local thePlayer = guiGridListGetItemText(adminEmPlayerGrid, guiGridListGetSelectedItem(adminEmPlayerGrid), 1)
	if ( isElement( getPlayerFromName( thePlayer ) ) ) then
		local theWeapon = guiGetText( adminEmWeaponEdit )
		if ( theWeapon == "" ) or ( theWeapon == " " ) or not ( getWeaponIDFromName ( theWeapon ) ) then
			exports.DENhelp:createNewHelpMessage( "You didn't enter a vaild weapon!", 225, 0, 0 )
		else
			triggerServerEvent( "onSendWeapon", localPlayer, getPlayerFromName( thePlayer ), theWeapon )
		end
	else
		exports.DENhelp:createNewHelpMessage( "You didn't select a player!", 225, 0, 0 )
	end
end

-- Pickup
function onClientCreateEventPickup ()
	local pickupType = guiGetText( adminEmPickupEdit )
	if ( string.lower( pickupType ) == "health" ) or ( string.lower( pickupType ) == "armor" ) then
		triggerServerEvent( "onCreateEventPickup", localPlayer, pickupType )
	else
		exports.DENhelp:createNewHelpMessage( "Wrong pickup model! (Use: health or armor)", 225, 0, 0 )
	end
end

-- Notes
function onClientUpdateAdminNotes ()
	local notes = guiGetText( adminNotesMemo )
	triggerServerEvent( "onUpdateAdminNotes", localPlayer, notes, guiCheckBoxGetSelected( adminNotesCheckbox ) )
	outputChatBox( "Notes are updated!", 0, 225, 0 )
end

-- Update notes
addEvent ("onSetStaffNoteMemoData", true)
addEventHandler ( "onSetStaffNoteMemoData", root, 
	function ( notes )
		guiSetText( adminNotesMemo, notes )
	end
)

function onClientDestroyEventPickup ()
	triggerServerEvent( "onDestroyEventPickup", localPlayer )
end