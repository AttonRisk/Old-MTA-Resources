-----------------------------------------------------------------------------------
----------------------------------- STAFF CHAT ------------------------------------
-----------------------------------------------------------------------------------

function onStaffChatMessage ( thePlayer, messageSender, message, timestamp )
	-- Load all staff messages in the adminchat gridlist
	triggerClientEvent ( thePlayer, "onStaffChatMessage", thePlayer, messageSender, message, timestamp )
end

addEvent ("onSendStaffChatMessage", true)
function onSendStaffChatMessage ( message )
	-- Send new staff message
	executeCommandHandler ( "csg", source, message )
end
addEventHandler ("onSendStaffChatMessage", root, onSendStaffChatMessage)

-----------------------------------------------------------------------------------
------------------------------------- LOGGING -------------------------------------
-----------------------------------------------------------------------------------

function addPunishlogRow ( thePlayer, reason, serial, theStaff )
	local playerID = exports.server:playerID( thePlayer )
	if ( isElement( theStaff ) ) then theStaff = exports.server:getPlayerAccountName( theStaff ) else theStaff = "CSGMTA" end
	if ( serial ) then
		local createRow = exports.DENmysql:exec("INSERT INTO punishlog SET userid=?, serial=?, punishment=?, punisher=?", tonumber( playerID ), serial, reason, theStaff )
	else
		local createRow = exports.DENmysql:exec("INSERT INTO punishlog SET userid=?, punishment=?, punisher=?", tonumber( playerID ), reason, theStaff )
	end
end

-----------------------------------------------------------------------------------
--------------------------------- TOGGLE CONTROLS ---------------------------------
-----------------------------------------------------------------------------------

function togglePlayerControls ( thePlayer, state )
    toggleControl ( thePlayer, "accelerate", state )
    toggleControl ( thePlayer, "enter_exit", state ) 
    toggleControl ( thePlayer, "brake_reverse", state )
	toggleControl ( thePlayer, "vehicle_fire", state )	
	toggleControl ( thePlayer, "fire", state )
    toggleControl ( thePlayer, "aim_weapon", state ) 
    toggleControl ( thePlayer, "forwards", state )
	toggleControl ( thePlayer, "backwards  ", state )
	toggleControl ( thePlayer, "left", state )
	toggleControl ( thePlayer, "right", state )
	toggleControl ( thePlayer, "jump", state )
	toggleControl ( thePlayer, "crouch", state )
	toggleControl ( thePlayer, "walk", state )
end

-----------------------------------------------------------------------------------
----------------------------------- PLAYER DATA -----------------------------------
-----------------------------------------------------------------------------------

addEvent ( "onServerPlayerLogin" )
addEventHandler( "onServerPlayerLogin", root,
function()
	local playerID = exports.server:playerID( source )
    local adminData = exports.DENmysql:querySingle( "SELECT * FROM staff WHERE userid = '" .. playerID .. "'" )
	if ( adminData ) then
		setElementData( source, "isPlayerStaff", true )	
		
		if ( tonumber(adminData.developer) == 1 ) then
			setElementData( source, "isPlayerDeveloper", true )
		end
		
		if ( tonumber(adminData.eventmanager) == 1 ) then
			setElementData( source, "isPlayerEventManager", true )
		end
		
		local theLevel = tonumber(adminData.level)
		setElementData( source, "thePlayerStaffLevel", theLevel )
	end
end
)

addEvent ("onClickPlayerFromList", true)
function onClickPlayerFromList ( thePlayer )
	local playername = getPlayerName ( thePlayer )
	local accountname = exports.server:getPlayerAccountName( thePlayer )
	local serial = getPlayerSerial ( thePlayer )
	local ip = getPlayerIP ( thePlayer )
	local dimension = getElementDimension ( thePlayer )
	local interior = getElementInterior ( thePlayer )
	local job = exports.server:getPlayerOccupation( thePlayer )
	local money = getPlayerMoney ( thePlayer )
	local bankmoney = exports.server:getPlayerBankBalance( thePlayer )
	local weapon = getPlayersWeapons ( thePlayer )
	local skin = getElementModel ( thePlayer )
	local fightingstyle = getPedFightingStyle ( thePlayer )
	local group = getElementData( thePlayer, "Group" )
	local team = getTeamName(getPlayerTeam ( thePlayer ))
	if ( group ) then group = group else group = "None" end
	triggerClientEvent ( source, "setLabelData", source, thePlayer, playername, accountname, serial, ip, dimension, interior, job, money, bankmoney, weapon, skin, fightingstyle, team, group )
end
addEventHandler ("onClickPlayerFromList", root, onClickPlayerFromList)

function getPlayersWeapons ( thePlayer )
		local weaponName = getWeaponNameFromID(getPedWeapon(thePlayer))
		local ammo = getPedTotalAmmo(thePlayer)
		local clip = getPedAmmoInClip(thePlayer)
		local total = (ammo-clip)
	return ("" .. weaponName .. ", Ammo in clip: " ..clip.. ", Total ammo: "..total.. "")
end

-----------------------------------------------------------------------------------
----------------------------------- PUNISHMENTS -----------------------------------
-----------------------------------------------------------------------------------

-- Slap player
addEvent ("onSlapPlayer", true)
function onSlapPlayer ( thePlayer )
	if isElement ( thePlayer ) then
		if isPedInVehicle ( thePlayer ) then local theVehicle = getPedOccupiedVehicle (thePlayer) if ( vehicle ) then setElementFrozen ( vehicle, false ) end end
		togglePlayerControls ( thePlayer, true )
		setElementFrozen ( thePlayer, false )
		killPed ( thePlayer )
		outputChatBox("You have been slapped by ".. getPlayerName(source) ..". (100HP)", thePlayer, 225, 0, 0)
		addPunishlogRow (thePlayer, "".. getPlayerName(thePlayer) .." has been slapped by ".. getPlayerName(source) .." (100HP)", source )
		exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." slapped ".. getPlayerName( thePlayer ) .." (100HP)" )
	end
end
addEventHandler ("onSlapPlayer", root, onSlapPlayer)

-- Kick player
addEvent ("onAdminKickPlayer", true)
function onAdminKickPlayer ( thePlayer, reason )
	if isElement ( thePlayer ) then
		if ( reason:find("^%s*$") ) then
			outputChatBox("You didn't enter a reason!", source, 225, 0, 0)
		else
			outputChatBox("You have kicked ".. getPlayerName(thePlayer) .." (" .. reason .. ")", source, 0, 225, 0)
			outputChatBox("".. getPlayerName(source) .." kicked ".. getPlayerName(thePlayer) .." (" .. reason .. ")", root, 225, 0, 0)
			addPunishlogRow (thePlayer, "".. getPlayerName(source) .." has kicked ".. getPlayerName(thePlayer) .." (".. reason ..")", source )
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." kicked ".. getPlayerName( thePlayer ) .." (".. reason ..")" )
			kickPlayer ( thePlayer, source, reason )
		end
	end
end
addEventHandler ("onAdminKickPlayer", root, onAdminKickPlayer)

-- Jail player
addEvent ("onAdminJailPlayer", true)
function onAdminJailPlayer ( thePlayer, time, reason )
	if isElement ( thePlayer ) then
		local jailThePlayer = exports.DENlaw:onSetPlayerJailed( thePlayer, tonumber(time), false, source, reason, true )
		addPunishlogRow (thePlayer, "".. getPlayerName(thePlayer) .." was jailed by ".. getPlayerName(source) .." for ".. time .." seconds (".. reason ..")", getPlayerSerial(thePlayer), source )
		exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." jailed ".. getPlayerName( thePlayer ) .." for ".. time .." seconds (".. reason ..")" )
	end
end
addEventHandler ("onAdminJailPlayer", root, onAdminJailPlayer)

addEvent ("onAdminRemovePunishment", true)
function onAdminRemovePunishment ( thePlayer, time )
	if isElement ( thePlayer ) then
		if getElementData ( thePlayer, "isPlayerJailed" ) then
			local jailThePlayer = exports.DENlaw:onSetPlayerJailed( thePlayer, tonumber(time) )
			outputChatBox( "".. getPlayerName(source) .." lowerd your jail punishment to ".. time .." seconds", thePlayer, 0, 225, 0 )
			outputChatBox( "You lowerd ".. getPlayerName(thePlayer) .." his jail punishment to ".. time .." seconds", source, 0, 225, 0 )
			addPunishlogRow ( thePlayer, "".. getPlayerName(source) .." lowerd jail punishment from ".. getPlayerName(thePlayer) .." to ".. time .." seconds", getPlayerSerial(thePlayer), source )
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." lowerd the jailtime from ".. getPlayerName( thePlayer ) .." to ".. time .." seconds" )
		else
			outputChatBox("This player isn't jailed!", source, 225, 0, 0 )
		end
	end
end
addEventHandler ("onAdminRemovePunishment", root, onAdminRemovePunishment)

-- Freeze player
addEvent("onAdminFreezePlayer", true)
function onAdminFreezePlayer ( thePlayer )
	local currentFreezeStatus = isElementFrozen ( thePlayer )
	local newFreezeStatus = not currentFreezeStatus
	local playerVehicle = getPedOccupiedVehicle (thePlayer)
	if ( playerVehicle ) then
		setElementFrozen ( thePlayer, newFreezeStatus )
		setElementFrozen ( playerVehicle, newFreezeStatus )
	else
		setElementFrozen ( thePlayer, newFreezeStatus )
	end

	triggerClientEvent (source, "freezeButtonCheck", source, thePlayer)
	if newFreezeStatus == true then
		outputChatBox("You have been frozen by ".. getPlayerName(source) ..".", thePlayer, 225, 0, 0)
		outputChatBox("You have Frozen ".. getPlayerName(thePlayer) ..".", source, 225, 0, 0)
		addPunishlogRow (thePlayer, "".. getPlayerName(source) .." has frozen ".. getPlayerName(thePlayer) .."", source )
		exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." has frozen ".. getPlayerName( thePlayer ) .."" )
		togglePlayerControls ( thePlayer, false )
	else
		outputChatBox("You have been unfrozen by ".. getPlayerName(source) ..".", thePlayer, 0, 225, 0)
		outputChatBox("You have unfrozen ".. getPlayerName(thePlayer) ..".", source, 0, 225, 0)
		togglePlayerControls ( thePlayer, true )
	end
end
addEventHandler("onAdminFreezePlayer", root, onAdminFreezePlayer)

-- Mute player
addEvent ("onAdminMutePlayer", true)
function onAdminMutePlayer ( thePlayer, time, reason, theType )
	if isElement ( thePlayer ) then
		local mutePlayer = onAdminSetPlayerMuted ( source, thePlayer, theType, time, reason, false, false )
		if ( theType == "global" ) then
			addPunishlogRow (thePlayer, "".. getPlayerName(thePlayer) .." was global muted by ".. getPlayerName(source) .." for ".. time .." seconds (".. reason ..")", getPlayerSerial(thePlayer), source )
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." global muted ".. getPlayerName( thePlayer ) .." for ".. time .." seconds (".. reason ..")" )
			triggerEvent( "onServerPlayerMute", thePlayer, reason, time, source, true )
		else
			addPunishlogRow (thePlayer, "".. getPlayerName(thePlayer) .." was muted by ".. getPlayerName(source) .." for ".. time .." seconds (".. reason ..")", getPlayerSerial(thePlayer), source )
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." muted ".. getPlayerName( thePlayer ) .." for ".. time .." seconds (".. reason ..")" )
			triggerEvent( "onServerPlayerMute", thePlayer, reason, time, source, false )
		end
	end
end
addEventHandler ("onAdminMutePlayer", root, onAdminMutePlayer)

addEvent ("onAdminLowerMutePunishment", true)
function onAdminLowerMutePunishment ( thePlayer, time, theType )
	if isElement ( thePlayer ) then
		local mutePlayer = onAdminSetPlayerMuted ( false, thePlayer, theType, time, 0, false, true )
		addPunishlogRow (thePlayer, "".. getPlayerName(thePlayer) .." changed the mutetime of ".. getPlayerName(source) .." to ".. time .." seconds", getPlayerSerial(thePlayer), source )
		exports.DENlogging:writeStaffLog( thePlayer, getPlayerName( thePlayer ).." changed the mutetime of ".. getPlayerName(source) .." to ".. time .." seconds" )
	end
end
addEventHandler ("onAdminLowerMutePunishment", root, onAdminLowerMutePunishment)

addEvent ("onAdminRemoveMutePunishment", true)
function onAdminRemoveMutePunishment ( thePlayer )
	if isElement ( thePlayer ) then
		local mutePlayer = onAdminSetPlayerMuted ( false, thePlayer, 0, 0, 0, true, false )
	end
end
addEventHandler ("onAdminRemoveMutePunishment", root, onAdminRemoveMutePunishment)

-- Ban player
addEvent ("onAdminBanPlayer", true)
function onAdminBanPlayer ( thePlayer, theTime, theReason, theType )
	if isElement ( thePlayer ) and ( theTime ) and ( theReason ) then
		local time = getRealTime()
		local theBanTime = ( time.timestamp + theTime )
		if ( theTime <= 86400 ) then banTimeInfo = (theTime / 3600).." hours" else banTimeInfo = (theTime / 86400).." days" end
		if ( theType == "accountban" ) then
			if ( theTime == 0 ) then
				local banPlayer = exports.DENmysql:exec("INSERT INTO bans SET account=?, reason=?, banstamp=?, bannedby=?", exports.server:getPlayerAccountName(thePlayer), theReason, 0, getPlayerName(source))
				outputChatBox(getPlayerName(source).." permanently account banned " .. getPlayerName(thePlayer) .. " (" .. theReason .. ")", root, 225, 0, 0)
				addPunishlogRow (thePlayer, "".. getPlayerName(source) .." permanently account banned " .. getPlayerName(thePlayer) .. " (" .. theReason .. ")", getPlayerSerial(thePlayer), source )
				exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." permanently account banned " .. getPlayerName(thePlayer) .. " (" .. theReason .. ")" )
				kickPlayer ( thePlayer, "You are banned from this server! Reason: "..theReason )
				triggerEvent( "onServerPlayerBan", thePlayer, theReason, theTime, source )
			else
				local banPlayer = exports.DENmysql:exec("INSERT INTO bans SET account=?, reason=?, banstamp=?, bannedby=?", exports.server:getPlayerAccountName(thePlayer), theReason, theBanTime, getPlayerName(source))
				outputChatBox(getPlayerName(source).." banned " .. getPlayerName(thePlayer) .. " for " .. banTimeInfo  .. " (" .. theReason .. ")", root, 225, 0, 0)
				addPunishlogRow (thePlayer, "".. getPlayerName(source) .." banned ".. getPlayerName(thePlayer) .." for " .. banTimeInfo  .. " (".. theReason ..")", getPlayerSerial(thePlayer), source )
				exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." account banned ".. getPlayerName(thePlayer) .." " .. banTimeInfo  .. " (".. theReason ..")" )
				kickPlayer ( thePlayer, "You are banned from this server! Reason: "..theReason )
				triggerEvent( "onServerPlayerBan", thePlayer, theReason, theTime, source )
			end
		elseif ( theType == "serialban" ) then
			if ( theTime == 0 ) then
				local banPlayer = exports.DENmysql:exec("INSERT INTO bans SET serial=?, account=?, reason=?, banstamp=?, bannedby=?", getPlayerSerial(thePlayer), exports.server:getPlayerAccountName(thePlayer), theReason, 0, getPlayerName(source))
				outputChatBox(getPlayerName(source).." permanently banned " .. getPlayerName(thePlayer) .. " (" .. theReason .. ")", root, 225, 0, 0)
				addPunishlogRow (thePlayer, "".. getPlayerName(source) .." permanently banned " .. getPlayerName(thePlayer) .. " (" .. theReason .. ")", getPlayerSerial(thePlayer), source )
				exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." permanently banned " .. getPlayerName(thePlayer) .. " (" .. theReason .. ")" )
				kickPlayer ( thePlayer, "You are banned from this server! Reason: "..theReason )
				triggerEvent( "onServerPlayerBan", thePlayer, theReason, theTime, source )
			else
				local banPlayer = exports.DENmysql:exec("INSERT INTO bans SET serial=?, account=?, reason=?, banstamp=?, bannedby=?", getPlayerSerial(thePlayer), exports.server:getPlayerAccountName(thePlayer), theReason, theBanTime, getPlayerName(source))
				outputChatBox(getPlayerName(source).." banned " .. getPlayerName(thePlayer) .. " for " .. banTimeInfo  .. " (" .. theReason .. ")", root, 225, 0, 0)
				addPunishlogRow (thePlayer, "".. getPlayerName(source) .." banned ".. getPlayerName(thePlayer) .." for " .. banTimeInfo  .. " (".. theReason ..")", getPlayerSerial(thePlayer), source )
				exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." serial banned ".. getPlayerName(thePlayer) .." for " .. banTimeInfo  .. " (".. theReason ..")" )
				kickPlayer ( thePlayer, "You are banned from this server! Reason: "..theReason )
				triggerEvent( "onServerPlayerBan", thePlayer, theReason, theTime, source )
			end
		end
	end
end
addEventHandler ("onAdminBanPlayer", root, onAdminBanPlayer)

-- Get player punishments
addEvent ("onGetPlayerPunishments", true)
function onGetPlayerPunishments ( thePlayer )
	if ( thePlayer ) and ( getPlayerFromName( thePlayer) ) then
		local serialTable, accountTable = exports.DENpunishments:getPlayerPunishlog ( getPlayerFromName( thePlayer ), true )
		triggerClientEvent( source, "onShowPunishmentsScreen", source, getPlayerFromName( thePlayer), serialTable, accountTable )
	else
		exports.DENhelp:createNewHelpMessageForPlayer(source, "There was something wrong while loading punishments!", 225, 0, 0)
	end
end
addEventHandler ("onGetPlayerPunishments", root, onGetPlayerPunishments)

-- warp
addEvent ("onAdminWarpPlayer", true)
function onAdminWarpPlayer ( thePlayer, toPlayer, warpTo )
	local thePlayer = thePlayer or source
	if ( isElement( thePlayer ) ) and ( isElement( toPlayer ) ) then
		if ( isPedInVehicle( thePlayer ) ) then removePedFromVehicle( thePlayer ) end
		if ( isPedInVehicle ( toPlayer ) ) then
			local vehicle = getPedOccupiedVehicle ( toPlayer )
			local occupants = getVehicleOccupants( vehicle )
			local seats = getVehicleMaxPassengers( vehicle )
			local x, y, z = getElementPosition ( vehicle )
			local isWarped = false
			for seat = 0, seats do
				local occupant = occupants[seat] 
				if not ( occupant ) then
					setTimer ( warpPedIntoVehicle, 1000, 1, thePlayer, vehicle, seat )
					fadeCamera ( thePlayer, false, 1, 0, 0, 0 )
					setTimer ( fadeCamera, 1000, 1, thePlayer, true, 1 )
					setElementDimension ( thePlayer, getElementDimension ( toPlayer ) )
					setElementInterior ( thePlayer, getElementInterior ( toPlayer ) )
					isWarped = true
					return
				end
				if not ( isWarped ) then
					setTimer ( setElementPosition, 1000, 1, thePlayer, x, y, z +1 )
					fadeCamera ( thePlayer, false, 1, 0, 0, 0 )
					setTimer ( fadeCamera, 1000, 1, thePlayer, true, 1 )
					setElementDimension ( thePlayer, getElementDimension ( toPlayer ) )
					setElementInterior ( thePlayer, getElementInterior ( toPlayer ) )
				end
			end
		else				
			local x, y, z = getElementPosition ( toPlayer )
			local r = getPedRotation ( toPlayer )
			x = x - math.sin ( math.rad ( r ) ) * 2
			y = y + math.cos ( math.rad ( r ) ) * 2
			setTimer ( setElementPosition, 1000, 1, thePlayer, x, y, z + 1 )
			fadeCamera ( thePlayer, false, 1, 0, 0, 0 )
			setElementDimension ( thePlayer, getElementDimension ( toPlayer ) )
			setElementInterior ( thePlayer, getElementInterior ( toPlayer ) )
			setTimer ( fadeCamera, 1000, 1, thePlayer, true, 1 )
		end
		if ( warpTo ) then
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." warped ".. getPlayerName(thePlayer) .." to ".. getPlayerName(toPlayer) .."" )
		else
			exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." warped to ".. getPlayerName(toPlayer) .."" )
		end
	end
end
addEventHandler ( "onAdminWarpPlayer", root, onAdminWarpPlayer )

-- Vehicle fix
addEvent ("onAdminFixvehicle", true)
function onAdminFixvehicle ( thePlayer )
	if ( isPedInVehicle(thePlayer) ) then
		local vehicle = getPedOccupiedVehicle( thePlayer )
		fixVehicle ( vehicle )
		local rx, ry, rz = getVehicleRotation ( vehicle )
		if ( rx > 110 ) and ( rx < 250 ) then
			local x, y, z = getElementPosition ( vehicle )
			setVehicleRotation ( vehicle, rx + 180, ry, rz )
			setElementPosition ( vehicle, x, y, z + 2 )
		end
		setElementFrozen ( vehicle, false )
		exports.DENhelp:createNewHelpMessageForPlayer(source, "You fixed the vehicle from ".. getPlayerName( thePlayer ), 0, 200, 0)
		exports.DENhelp:createNewHelpMessageForPlayer(thePlayer, getPlayerName( source ).." fixed your vehicle!", 0, 200, 0)
		exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." fixed the vehicle from ".. getPlayerName( thePlayer ) .."" )
	else
		exports.DENhelp:createNewHelpMessageForPlayer(source, "This player is not in a vehicle!", 225, 0, 0)
	end
end
addEventHandler ( "onAdminFixvehicle", root, onAdminFixvehicle )

-- Hide vehicle
addEvent ("onAdminDestroyVehicle", true)
function onAdminDestroyVehicle ( thePlayer )
	if ( thePlayer ) then
		if ( isPedInVehicle(thePlayer) ) then
			local vehicle = getPedOccupiedVehicle( thePlayer )
			if ( getElementData(vehicle, "vehicleType" ) == "playerVehicle" ) then
				exports.DENhelp:createNewHelpMessageForPlayer(source, "You can't despawn player owned vehicles ATM!", 225, 0, 0)
			else
				destroyElement( vehicle )
				exports.DENhelp:createNewHelpMessageForPlayer(source, "You destroyed the vehicle from ".. getPlayerName( thePlayer ), 0, 200, 0)
				exports.DENhelp:createNewHelpMessageForPlayer(thePlayer, getPlayerName( source ).." destroyed your vehicle!", 0, 200, 0)
				exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." destroyed the vehicle from ".. getPlayerName( thePlayer ) .."" )
			end
		else
			exports.DENhelp:createNewHelpMessageForPlayer(source, "This player is not in a vehicle!", 225, 0, 0)
		end
	end
end
addEventHandler ( "onAdminDestroyVehicle", root, onAdminDestroyVehicle )

-- Update notes
addEvent ("onUpdateAdminNotes", true)
addEventHandler ( "onUpdateAdminNotes", root, 
	function ( notes, notify )
		local theFile = xmlLoadFile ( "adminNotes.xml" )
		if not ( theFile ) then
			theFile = xmlCreateFile( "adminNotes.xml", "adminNotes" )
			xmlCreateChild( theFile, "notes" )
			local theNode = xmlFindChild( theFile, "notes", 0 )
			xmlNodeSetValue( theNode, notes )
			xmlSaveFile( theFile )
		else
			local theNode = xmlFindChild( theFile, "notes", 0 )
			xmlNodeSetValue( theNode, notes )
			xmlSaveFile( theFile )
		end
		
		if ( notify ) then
			for k, i in ipairs( getElementsByType( "player" ) ) do
				if ( exports.server:isPlayerStaff( i ) ) then
					onLoadAdminNotes ( i )
					outputChatBox( getPlayerName( source ).." updated the staff notes! Check them out.", i, 225, 0, 0 )
				end
			end
		end
	end
)

-- Update the notes for a player
addEvent ("onLoadAdminNotes", true)
function onLoadAdminNotes ( thePlayer )
	local thePlayer = thePlayer or source
	local theFile = xmlLoadFile ( "adminNotes.xml" )
	if ( theFile ) then
		local theNode = xmlFindChild( theFile, "notes", 0 )
		if ( theNode ) then
			local theNodeValue = xmlNodeGetValue ( theNode )
			if ( theNodeValue ) then
				triggerClientEvent( thePlayer, "onSetStaffNoteMemoData", thePlayer, theNodeValue )
			end
		end
	end
end
addEventHandler ( "onLoadAdminNotes", root, onLoadAdminNotes )

-- Remove a punishlog row
addEvent ("onRemovePlayerPunishlogRow", true)
addEventHandler ( "onRemovePlayerPunishlogRow", root,
	function ( uniqueID, thePlayer )
		exports.DENmysql:exec( "UPDATE punishlog SET active=? WHERE uniqueid=?", 0, uniqueID )
		outputChatBox( getPlayerName( source ).." removed a punishment row from your log with ID: "..uniqueID, thePlayer, 0, 225, 0 )
		exports.DENlogging:writeStaffLog( source, getPlayerName( source ).." deleted a punishlog row from ".. getPlayerName( thePlayer ) .." with ID: "..uniqueID )
	end
)