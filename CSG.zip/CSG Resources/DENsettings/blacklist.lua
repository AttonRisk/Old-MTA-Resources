local theFile = xmlLoadFile ( "blacklist.xml" )
if not ( theFile ) then
	theFile = xmlCreateFile( "blacklist.xml","blacklist" )
end
xmlSaveFile( theFile )

addEvent( "getBlacklistedPlayers", true )
function getBlacklistedPlayers ( )
	local friendsTable = {} 
	local theFriends = xmlNodeGetChildren( theFile )
    for i, theNode in ipairs( theFriends ) do
		if ( getThePlayerFromID ( xmlNodeGetValue( theNode ) ) ) then
			table.insert(friendsTable,getThePlayerFromID ( xmlNodeGetValue( theNode ) ) )
		end
    end
	return friendsTable
end
addEventHandler( "getBlacklistedPlayers", root, getBlacklistedPlayers )

function getThePlayerFromID ( theID )
	for i, player in ipairs(getElementsByType("player")) do
		if ( (getElementData( player, "accountUserID" ) == tonumber(theID) ) ) then 
			return getPlayerName( player )
		end
	end
	return false
end

function addPlayerBlacklisted ( thePlayer )
	local nodeExists = false
	local playerID = getElementData( thePlayer, "accountUserID" )
	if ( thePlayer ) and ( playerID ) then
		local theFriends = xmlNodeGetChildren( theFile ) 
		if #theFriends >=1 then 
			for i, theNode in ipairs( theFriends ) do
				if ( xmlNodeGetValue( theNode ) == tostring(playerID) ) then 
					nodeExists = true
				end
			end
			if not nodeExists then 
				xmlNodeSetValue( xmlCreateChild( theFile, "userid" ), tostring ( playerID ) )
				xmlSaveFile( theFile )
				return true
			else
				return false
			end
		else
			xmlNodeSetValue( xmlCreateChild( theFile, "userid" ), tostring ( playerID ) )
			xmlSaveFile( theFile )
			return true
		end
	end
end

function removePlayerBlacklisted ( thePlayer )
	local playerID = getElementData( thePlayer, "accountUserID" )
	if ( thePlayer ) and ( playerID ) then
		local theFriends = xmlNodeGetChildren( theFile )
		for i, theNode in ipairs( theFriends ) do
			if ( xmlNodeGetValue( theNode ) == tostring(playerID) ) then 
				xmlDestroyNode ( theNode )
			end
		end
	end
end
