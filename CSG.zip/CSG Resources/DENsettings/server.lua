addEvent( "getPlayerBlacklistedPlayers", true )
function getPlayerBlacklistedPlayers( thePlayer, fromTrigger, theTable )
	if ( fromTrigger ) then
		outputChatBox("!")
		return theTable
	else
		triggerClientEvent( thePlayer, "getBlacklistedPlayers", thePlayer, true )
	end
end
addEventHandler( "getPlayerBlacklistedPlayers", root, getPlayerBlacklistedPlayers )