local data = {
	{["name"]="Four Dragons Casino",px=1953.76,py=1018.31,pz=992.46,pr=270,skin=171,int=10,dim=0},
}
local markers = {}
local peds = {}
function start()
	for k,v in pairs(data) do
		local ped = createPed(v.skin,v.px,v.py,v.pz,v.pr)
		setElementFrozen(ped,true)
		setElementDimension(ped,v.dim)
		setElementInterior(ped,v.int)
		table.insert(peds,ped)
		local marker = createMarker(v.px,v.py,v.pz,"cylinder",1,255,255,0,60)
		setElementDimension(marker,v.dim)
		setElementInterior(marker,v.int)
		attachElements(marker,ped,0,2,0)
	end
end
start()