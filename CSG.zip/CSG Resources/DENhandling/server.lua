-- Make the rhino less powerfull for military forces
addEventHandler ( "onResourceStart", root,
function ()
	-- TODO
end 
)