carTestRoute = {}
carTestRoute[1] = { 1279.77, -1822.18, 13.26 }
carTestRoute[2] = { 1266.73, -1843.11, 13.27 }
carTestRoute[3] = { 1412.87, -1874.82, 13.25 }
carTestRoute[4] = { 1581.04, -1874.69, 13.25 }
carTestRoute[5] = { 1703.94, -1814.85, 13.24 }
carTestRoute[6] = { 1808.69, -1834.88, 13.25 }
carTestRoute[7] = { 1836.34, -1754.72, 13.25 }
carTestRoute[8] = { 1938.62, -1772.17, 13.25 }
carTestRoute[9] = { 1984.26, -1814.71, 13.25 }
carTestRoute[10] = { 2085.81, -1787.08, 13.25 }
carTestRoute[11] = { 2115.09, -1603.18, 24.67 }
carTestRoute[12] = { 2130.76, -1398.74, 23.7 }
carTestRoute[13] = { 2169.15, -1349.02, 23.7 }
carTestRoute[14] = { 2201.29, -1303.69, 23.7 }
carTestRoute[15] = { 2268.56, -1370.94, 23.7 }
carTestRoute[16] = { 2305.96, -1356.27, 23.73 }
carTestRoute[17] = { 2305.67, -1166.05, 26.4 }
carTestRoute[18] = { 2191.77, -1121.21, 24.75 }
carTestRoute[19] = { 1877.5, -1045.67, 23.56 }
carTestRoute[20] = { 1841.12, -1178.39, 23.51 }
carTestRoute[21] = { 1652.79, -1158.81, 23.69 }
carTestRoute[22] = { 1657.29, -1135.2, 23.78 }
carTestRoute[23] = { 1657.85, -1080.09, 23.77 }
carTestRoute[24] = { 1608.59, -1009.28, 23.78 }
carTestRoute[25] = { 1634.84, -1146.17, 23.78 }
carTestRoute[26] = { 1452.66, -1425.78, 13.25 }
carTestRoute[27] = { 1378.37, -1392.69, 13.32 }
carTestRoute[28] = { 1059.69, -1419.71, 13.25 }
carTestRoute[29] = { 931.54, -1486.63, 13.24 }
carTestRoute[30] = { 914.98, -1557.8, 13.24 }
carTestRoute[31] = { 789.6, -1597.41, 13.25 }
carTestRoute[32] = { 809.66, -1631.33, 13.25 }
carTestRoute[33] = { 901.27, -1574.48, 13.25 }
carTestRoute[34] = { 1116.72, -1574.62, 13.26 }
carTestRoute[35] = { 1147.68, -1625.64, 13.65 }
carTestRoute[36] = { 1172.56, -1777.31, 13.27 }
carTestRoute[37] = { 1242.3, -1835.52, 13.26 }

testVehicle = { [436]=true } -- Car the player get for the test

local blip = nil
local marker = nil

local drivingLicenceShops = { 
[1]={1214.22, -1813.1, 15.59}, -- Car drivers licence you should get in LS
}

function carLicenceWindow ()
-- Window when you hit the licence school marker
carLicenceScreen = guiCreateWindow(531,281,412,276,"CSG ~ Driving School",false)
carLicenceMemo = guiCreateMemo(10,24,393,163,"Before you can drive cars you need to pass a car driving exam. This is a pratical exam, meaning you will have to drive through several checkpoints around Los Santos. Here at the driving school you can start a driving test. When you pass the driving test you can drive all vehicles which we commonly call cars and trucks.\n\nOne exam costs 1500$. If you fail you need to pay again. When you press buy exam you get all the info you need to start the exam.",false,carLicenceScreen)
guiMemoSetReadOnly(carLicenceMemo, true)
carLicenceLabel1 = guiCreateLabel(13,206,151,17,"Buy driving exam ($1500)",false,carLicenceScreen)
guiLabelSetColor(carLicenceLabel1,0,225,0)
guiSetFont(carLicenceLabel1,"default-bold-small")
carLicenceBuyExam = guiCreateButton(11,229,152,34,"Buy Exam",false,carLicenceScreen)
carLicenceLabel2 = guiCreateLabel(246,206,156,17,"Pickup your drivers licence",false,carLicenceScreen)
guiLabelSetColor(carLicenceLabel2,0,225,0)
guiSetFont(carLicenceLabel2,"default-bold-small")
carLicenceWindowTake = guiCreateButton(244,229,152,34,"Take licence",false,carLicenceScreen)
carLicenceWindowClose = guiCreateButton(175,229,59,34,"Close",false,carLicenceScreen)

local screenW,screenH=guiGetScreenSize()
local windowW,windowH=guiGetSize(carLicenceScreen,false)
local x,y = (screenW-windowW)/2,(screenH-windowH)/2
guiSetPosition(carLicenceScreen,x,y,false)

guiWindowSetMovable (carLicenceScreen, true)
guiWindowSetSizable (carLicenceScreen, false)
guiSetVisible (carLicenceScreen, false)

addEventHandler("onClientGUIClick", carLicenceWindowClose, function() guiSetVisible(carLicenceScreen, false) showCursor(false,false) end, false)
addEventHandler ( "onClientGUIClick", carLicenceWindowTake, takeVehicleDrivingLicence, false )
addEventHandler ( "onClientGUIClick", carLicenceBuyExam, buyVehicleDrivingTest, false )
end

function carLicenceInformationWindowOnStart ()
-- Information you get when you spawn the vehicle
informationWindowAtStart = guiCreateWindow(531,281,522,360,"CSG ~ Driving School",false)
informationMemoAtStart = guiCreateMemo(10,24,503,294,"You decided to go for your drivers licence! Thats good, because you can't drive vehicles without having a driver's licence. If you see this screen that means you have bought the driving exam. Here we will explain how you can pass it.\n\nBefore you get your licence you need to complete the whole test. As you can see your now in the vehicle on which you can do the test with. Never leave this vehicle, if you do the test will stop and you dont get the licence. Also if you die or your vehicle blows up, the test will stop and you need to start again.\n\nBehind this vehicle you can see a big marker, if you drive in this marker you activate the test. Then you see a new marker. After you hit the marker a new marker will show up. Keep driving in the markers that will show up until you get back at the driving school.\n\nYou passed the test when, you didnt blow your car, you didnt drive to other players or when your vehicle has AT LEAST 95% health.\n\nIf you failed the test you can always start again. Good luck and drive safely!",false,informationWindowAtStart)
closeInformationWindowAtStart = guiCreateButton(460,322,53,29,"Close",false,informationWindowAtStart)
guiMemoSetReadOnly(informationMemoAtStart, true)

local screenW,screenH=guiGetScreenSize()
local windowW,windowH=guiGetSize(informationWindowAtStart,false)
local x,y = (screenW-windowW)/2,(screenH-windowH)/2
guiSetPosition(informationWindowAtStart,x,y,false)

guiWindowSetMovable (informationWindowAtStart, true)
guiWindowSetSizable (informationWindowAtStart, false)
guiSetVisible (informationWindowAtStart, false)

addEventHandler("onClientGUIClick", closeInformationWindowAtStart, function() guiSetVisible(informationWindowAtStart, false) showCursor(false,false) end, false)
end

-- On resource start, load the guis
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), 
	function ()
		carLicenceWindow()
		carLicenceInformationWindowOnStart()
	end
)

function takeVehicleDrivingLicence ()
	if getElementData( localPlayer, "carLicence" ) then
		exports.DENhelp:createNewHelpMessage("You already have a car drivers licence!", 225, 0, 0)
	elseif getElementData(localPlayer, "passedCarDrivingtest") then
		triggerServerEvent ( "givePlayerCarLicence", localPlayer )
	else
		exports.DENhelp:createNewHelpMessage("You didn't pass for your car licence yet!", 225, 0, 0)
	end
end

function buyVehicleDrivingTest ()
	if getElementData(localPlayer, "passedCarDrivingtest") or getElementData(localPlayer, "carLicence") then
		exports.DENhelp:createNewHelpMessage("You already have a licence for driving cars!", 225, 0, 0)
	elseif getElementData(localPlayer, "isDoingCarDrivingTest") then
		exports.DENhelp:createNewHelpMessage("You already started a car driving test!", 225, 0, 0)
	elseif getPlayerMoney (localPlayer) < 1500 then
		exports.DENhelp:createNewHelpMessage("You don't have enough money for the driving test!", 225, 0, 0)
	else
		local x, y, z = carTestRoute[1][1], carTestRoute[1][2], carTestRoute[1][3]
		blip = createBlip(x, y, z, 41, 2, 0, 255, 0, 255)
		marker = createMarker(x, y, z, "checkpoint", 4, 0, 255, 0, 150) -- start marker.
		addEventHandler("onClientMarkerHit", marker, startCarDrivingExam)
		setElementData(localPlayer, "isDoingCarDrivingTest", true, true)
		
		-- Marker for driving test vehicle
		carExamVehicleMarker = createMarker (1279.01, -1812.54, 12.38, "cylinder",2.0, 0, 102, 31, 225)
		addEventHandler("onClientMarkerHit", carExamVehicleMarker, givePlayerVehicleForCarExam)
		guiSetVisible (carLicenceScreen, false)
		showCursor(false,false)
	end
end

function givePlayerVehicleForCarExam (hitPlayer, matchingDimension)
	if hitPlayer == localPlayer then
		destroyElement(carExamVehicleMarker)
		guiSetVisible(informationWindowAtStart,true)
		showCursor(true,true)
		triggerServerEvent ( "givePlayerExamCar", localPlayer )
	end
end

function onCarLicenceShopMarkerHit( hitElement, matchingDimension )
	if hitElement == localPlayer then
		if not isPedInVehicle(localPlayer) then
			guiSetVisible(carLicenceScreen,true)
			showCursor(true,true)
		end
	end
end

for ID in pairs(drivingLicenceShops) do 
local x, y, z = drivingLicenceShops[ID][1], drivingLicenceShops[ID][2], drivingLicenceShops[ID][3] 
createBlip ( x, y, z, 43, 2, 0, 0, 0, 0, 0, 270)
local carLicenceShopMarker = createMarker(x,y,z,"cylinder",2.0, 0, 102, 31, 225)
addEventHandler("onClientMarkerHit", carLicenceShopMarker, onCarLicenceShopMarkerHit)
end

function startCarDrivingExam(theElement)
	if theElement == localPlayer then
		local vehicle = getPedOccupiedVehicle(localPlayer)
		local id = getElementModel(vehicle)
		if not (testVehicle[id]) then
			if isPedInVehicle(localPlayer) then
				exports.DENhelp:createNewHelpMessage("This is not the car you got from the driving school!", 255, 0, 0, true ) -- Wrong car type
			else
				exports.DENhelp:createNewHelpMessage("Spawn the vehicle first, then drive in this marker!", 255, 0, 0, true )
			end
		else
			destroyElement(blip)
			destroyElement(marker)
			
			setElementData(localPlayer, "drivingTest.marker", 2, false)

			local x1,y1,z1 = nil -- Setup the first checkpoint
			x1 = carTestRoute[2][1]
			y1 = carTestRoute[2][2]
			z1 = carTestRoute[2][3]

			setElementData(localPlayer, "drivingTest.checkmarkers", 37, false)
			blip = createBlip(x1, y1 , z1, 41, 2, 255, 0, 255, 255)
			marker = createMarker( x1, y1,z1 , "checkpoint", 4, 255, 0, 255, 150)
				
			addEventHandler("onClientMarkerHit", marker, UpdateCheckpoints)				
		end
	end
end

function UpdateCheckpoints(element)
	if (element == localPlayer) then
		local vehicle = getPedOccupiedVehicle(localPlayer)
		local id = getElementModel(vehicle)
		if not (testVehicle[id]) then
			exports.DENhelp:createNewHelpMessage("This is not the car where u should do your driving test with!", 255, 0, 0) -- Wrong car type.
		else
			destroyElement(blip)
			destroyElement(marker)
			blip = nil
			marker = nil
				
			local m_number = getElementData(localPlayer, "drivingTest.marker")
			local max_number = getElementData(localPlayer, "drivingTest.checkmarkers")
			
			if (tonumber(max_number-1) == tonumber(m_number)) then -- if the next checkpoint is the final checkpoint.
				exports.DENhelp:createNewHelpMessage("You are almost finished, park the car at the driving school to finish the test.", 255, 194, 14, true)
				
				local newnumber = m_number+1
				setElementData(localPlayer, "drivingTest.marker", newnumber, false)
					
				local x2, y2, z2 = nil
				x2 = carTestRoute[newnumber][1]
				y2 = carTestRoute[newnumber][2]
				z2 = carTestRoute[newnumber][3]
				
				marker = createMarker( x2, y2, z2, "checkpoint", 4, 255, 0, 255, 150)
				blip = createBlip( x2, y2, z2, 53, 2, 255, 0, 255, 255)
				
				
				addEventHandler("onClientMarkerHit", marker, endCarDrivingExam)
			else
				local newnumber = m_number+1
				setElementData(localPlayer, "drivingTest.marker", newnumber, false)
						
				local x3, y3, z3 = nil
				x3 = carTestRoute[newnumber][1]
				y3 = carTestRoute[newnumber][2]
				z3 = carTestRoute[newnumber][3]
						
				marker = createMarker( x3, y3, z3, "checkpoint", 4, 255, 0, 255, 150)
				blip = createBlip( x3, y3, z3, 41, 2, 255, 0, 255, 255)
				
				addEventHandler("onClientMarkerHit", marker, UpdateCheckpoints)
			end
		end
	end
end

function endCarDrivingExam (element)
	if (element == localPlayer) then
		local vehicle = getPedOccupiedVehicle(localPlayer)
		local id = getElementModel(vehicle)
		if not (testVehicle[id]) then
			exports.DENhelp:createNewHelpMessage("This is not the car where u should do your driving test with!", 255, 0, 0)
		else
			local vehicleHealth = getElementHealth ( vehicle )
			if (vehicleHealth >= 950) then
				exports.DENhelp:createNewHelpMessage("You passed the exam, get your licence at the driving school!", 255, 194, 14)
				setElementData(localPlayer, "passedCarDrivingtest", true, true)
				triggerServerEvent ( "destroyPlayerExamCar", localPlayer )
				setElementData(localPlayer, "isDoingCarDrivingTest", false, true)
			else
				exports.DENhelp:createNewHelpMessage("Your vehicle is to damaged, please drive better the next time!", 255, 194, 14)
				triggerServerEvent ( "destroyPlayerExamCar", localPlayer )
				setElementData(localPlayer, "isDoingCarDrivingTest", false, true)
			end
			
			destroyElement(blip)
			destroyElement(marker)
			blip = nil
			marker = nil
		end
	end
end

addEventHandler("onClientVehicleExit", getRootElement(),
    function(thePlayer, seat)
        if thePlayer == localPlayer and seat == 0 then
			if getElementData(localPlayer, "isDoingCarDrivingTest") then
				exports.DENhelp:createNewHelpMessage("You leaved the car and failed the test! Next time better.", 225, 0, 0)
				triggerServerEvent ( "destroyPlayerExamCar", localPlayer )
				destroyElement(blip)
				destroyElement(marker)
				blip = nil
				marker = nil
			end
        end
    end
)

addEventHandler ( "onClientPlayerWasted", getLocalPlayer(), 
	function (killer, weapon, bodypart)
	    if source == localPlayer then
			if getElementData(localPlayer, "isDoingCarDrivingTest") then
				exports.DENhelp:createNewHelpMessage("You leaved the car and failed the test! Next time better.", 225, 0, 0)
				triggerServerEvent ( "destroyPlayerExamCar", localPlayer )
				destroyElement(blip)
				destroyElement(marker)
				blip = nil
				marker = nil
			end
        end
	end
)

