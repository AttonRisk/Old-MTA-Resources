planeTestRoute = {}
planeTestRoute[1] = { -1629.98, -137.57, 12.33, 315.8974609375 }
planeTestRoute[2] = { -1524.99, -32.56, 12.32, 314.50549316406 }
planeTestRoute[3] = { -1396.48, 92.68, 45.97, 316 }
planeTestRoute[4] = { -1169.42, 321.37, 83.41, 315.64834594727 }
planeTestRoute[5] = { -932.45, 562.31, 87, 315.56045532227 }
planeTestRoute[6] = { -698.35, 801.16, 100.15, 315.56045532227 }
planeTestRoute[7] = { -396.8, 975.41, 105.64, 277.93405151367 }
planeTestRoute[8] = { 30.67, 874.31, 111.34, 233.36264038086 }
planeTestRoute[9] = { -43.74, 356.91, 107.73,149.23077392578 }
planeTestRoute[10] = { -414.86, 286.55, 124.42,79.252746582031 }
planeTestRoute[11] = { -869.87, 364.35, 103.34,79.9560546875 }
planeTestRoute[12] = { -1310.01, 406.5, 94.88, 82.681304931641 }
planeTestRoute[13] = { -1711.52, 222.83, 94.97, 128.13186645508 }
planeTestRoute[14] = { -1819.99, -62.53, 91.64, 192.39559936523 }
planeTestRoute[15] = { -1662.36, -162.1, 57.9, 315.91207885742 }
planeTestRoute[16] = { -1548.77, -57.38, 24.94, 317.1428527832 }
planeTestRoute[17] = { -1400.88, 90.77, 12.32, 314.32968139648 }
planeTestRoute[18] = { -1351.7, 30.83, 12.32, 137.62637329102 }
planeTestRoute[19] = { -1308.91, -193, 12.34, 135.69229125977 }
planeTestRoute[20] = { -1358.2, -243.6, 12.32, 135.9560546875 }

testPlane = { [593]=true } -- plane the player get for the test

local blip = nil
local marker = nil

local planeLicenceShops = { 
[1]={-1679.43, -163.7, 13.14}, -- plane drivers licence you should get in LS
}

function planeLicenceWindow ()
-- Window when you hit the licence school marker
planeLicenceScreen = guiCreateWindow(531,281,412,276,"CSG ~ Plane flying School",false)
planeLicenceMemo = guiCreateMemo(10,24,393,163,"Before you can pilot Airplanes, you need to pass a flying exam. This is a pratical exam, meaning you will have to pilot a Dodo through several checkpoints around San Fierro. Here at the flying school you can start a flying exam. When you pass the exam you can pilot all airplanes in the server.\n\nOne exam costs 1500$. If you fail you need to pay again.\n\nWhen you press buy exam you get all the information you need to start the exam.",false,planeLicenceScreen)
guiMemoSetReadOnly(planeLicenceMemo, true)
planeLicenceLabel1 = guiCreateLabel(13,206,151,17,"Buy plane exam ($1500)",false,planeLicenceScreen)
guiLabelSetColor(planeLicenceLabel1,0,225,0)
guiSetFont(planeLicenceLabel1,"default-bold-small")
planeLicenceBuyExam = guiCreateButton(11,229,152,34,"Buy Exam",false,planeLicenceScreen)
planeLicenceLabel2 = guiCreateLabel(246,206,156,17,"Pickup your plane licence",false,planeLicenceScreen)
guiLabelSetColor(planeLicenceLabel2,0,225,0)
guiSetFont(planeLicenceLabel2,"default-bold-small")
planeLicenceWindowTake = guiCreateButton(244,229,152,34,"Take licence",false,planeLicenceScreen)
planeLicenceWindowClose = guiCreateButton(175,229,59,34,"Close",false,planeLicenceScreen)

local screenW,screenH=guiGetScreenSize()
local windowW,windowH=guiGetSize(planeLicenceScreen,false)
local x,y = (screenW-windowW)/2,(screenH-windowH)/2
guiSetPosition(planeLicenceScreen,x,y,false)

guiWindowSetMovable (planeLicenceScreen, true)
guiWindowSetSizable (planeLicenceScreen, false)
guiSetVisible (planeLicenceScreen, false)

addEventHandler("onClientGUIClick", planeLicenceWindowClose, function() guiSetVisible(planeLicenceScreen, false) showCursor(false,false) end, false)
addEventHandler ( "onClientGUIClick", planeLicenceWindowTake, takePlaneDrivingLicence, false )
addEventHandler ( "onClientGUIClick", planeLicenceBuyExam, buyPlaneDrivingTest, false )
end

function planeLicenceInformationWindowOnStart ()
-- Information you get when you spawn the vehicle
informationPlaneWindowAtStart = guiCreateWindow(531,281,522,360,"CSG ~ Plane flying School",false)
informationMemoAtStart = guiCreateMemo(10,24,503,294,"You decided to go for your Airplane licence! That's good, because you can't fly Airplanes without having this licence. If you see this screen that means you have bought the flying exam. Here we will explain how you can pass it.\n\nBefore you get your licence you need to complete the whole test. As you can see your now in the Airplane on which you can do the test with. Never leave this vehicle. If you do, the test will stop and you don't get the licence. Also if you die or your vehicle blows up, the test will stop and you need to start again.\n\nYou can now see a big marker. If you drive in this marker you activate the test. Then you see a a ring. After you hit the ring a new ring will show up and so on. Keep flying in the rings that will show up until you get back at the San Fierro airport.\n\nYou passed the test when, you didnt blow your Airplane, you didnt fly into other players or when your vehicle has AT LEAST 95% health.\n\nIf you failed the test you can always start again. Good luck and fly safely!",false,informationPlaneWindowAtStart)
closeInformationWindowAtStart = guiCreateButton(460,322,53,29,"Close",false,informationPlaneWindowAtStart)
guiMemoSetReadOnly(informationMemoAtStart, true)

local screenW,screenH=guiGetScreenSize()
local windowW,windowH=guiGetSize(informationPlaneWindowAtStart,false)
local x,y = (screenW-windowW)/2,(screenH-windowH)/2
guiSetPosition(informationPlaneWindowAtStart,x,y,false)

guiWindowSetMovable (informationPlaneWindowAtStart, true)
guiWindowSetSizable (informationPlaneWindowAtStart, false)
guiSetVisible (informationPlaneWindowAtStart, false)

addEventHandler("onClientGUIClick", closeInformationWindowAtStart, function() guiSetVisible(informationPlaneWindowAtStart, false) showCursor(false,false) end, false)
end

-- On resource start, load the guis
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), 
	function ()
		planeLicenceWindow()
		planeLicenceInformationWindowOnStart()
	end
)

function takePlaneDrivingLicence ()
	if getElementData( localPlayer, "planeLicence" ) then
		exports.DENhelp:createNewHelpMessage("You already have a plane drivers licence!", 225, 0, 0)
	elseif getElementData(localPlayer, "passedPlaneDrivingtest") then
		triggerServerEvent ( "givePlayerPlaneLicence", localPlayer )
	else
		exports.DENhelp:createNewHelpMessage("You didn't pass for your plane licence yet!", 225, 0, 0)
	end
end

function buyPlaneDrivingTest ()
	if getElementData(localPlayer, "passedPlaneDrivingtest") or getElementData(localPlayer, "planeLicence") then
		exports.DENhelp:createNewHelpMessage("You already have a licence for flying planes!", 225, 0, 0)
	elseif getElementData(localPlayer, "isDoingPlaneDrivingTest") then
		exports.DENhelp:createNewHelpMessage("You already started a plane driving test!", 225, 0, 0)
	elseif getPlayerMoney (localPlayer) < 1500 then
		exports.DENhelp:createNewHelpMessage("You don't have enough money for the driving test!", 225, 0, 0)
	else
		local x, y, z = planeTestRoute[1][1], planeTestRoute[1][2], planeTestRoute[1][3]
		blip = createBlip(x, y, z, 41, 2, 0, 255, 0, 255)
		marker = createMarker(x, y, z, "checkpoint", 4, 0, 255, 0, 150) -- start marker.
		addEventHandler("onClientMarkerHit", marker, startPlaneDrivingExam)
		setElementData(localPlayer, "isDoingPlaneDrivingTest", true, true)
		
		-- Marker for driving test vehicle
		planeExamVehicleMarker = createMarker (-1657.71, -165.09, 13.14, "cylinder",2.0, 0, 102, 31, 225)
		addEventHandler("onClientMarkerHit", planeExamVehicleMarker, givePlayerVehicleForPlaneExam)
		guiSetVisible (planeLicenceScreen, false)
		showCursor(false,false)
	end
end

function givePlayerVehicleForPlaneExam (hitPlayer, matchingDimension)
	if hitPlayer == localPlayer then
		destroyElement(planeExamVehicleMarker)
		guiSetVisible(informationPlaneWindowAtStart,true)
		showCursor(true,true)
		triggerServerEvent ( "givePlayerExamPlane", localPlayer )
	end
end

function onplaneLicenceShopMarkerHit( hitElement, matchingDimension )
	if hitElement == localPlayer then
		if not isPedInVehicle(localPlayer) then
			guiSetVisible(planeLicenceScreen,true)
			showCursor(true,true)
		end
	end
end

for ID in pairs(planeLicenceShops) do 
	local x, y, z = planeLicenceShops[ID][1], planeLicenceShops[ID][2], planeLicenceShops[ID][3] 
	createBlip ( x, y, z, 43, 2, 0, 0, 0, 0, 0, 270)
	local planeLicenceShopMarker = createMarker(x,y,z,"cylinder",2.0, 0, 102, 31, 225)
	addEventHandler("onClientMarkerHit", planeLicenceShopMarker, onplaneLicenceShopMarkerHit)
end

function startPlaneDrivingExam(theElement)
	if theElement == localPlayer then
		local vehicle = getPedOccupiedVehicle(localPlayer)
		local id = getElementModel(vehicle)
		if not (testPlane[id]) then
			if isPedInVehicle(localPlayer) then
				exports.DENhelp:createNewHelpMessage("This is not the plane you got from the driving school!", 255, 0, 0 ) -- Wrong plane type
			else
				exports.DENhelp:createNewHelpMessage("Spawn the vehicle first, then fly in this marker!", 255, 0, 0 )
			end
		else
			destroyElement(blip)
			destroyElement(marker)
			
			setElementData(localPlayer, "drivingTest.marker", 2, false)

			local x1,y1,z1 = nil -- Setup the first checkpoint
			x1 = planeTestRoute[2][1]
			y1 = planeTestRoute[2][2]
			z1 = planeTestRoute[2][3]

			a1 = planeTestRoute[3][1]
			a2 = planeTestRoute[3][2]
			a3 = planeTestRoute[3][3]

			setElementData(localPlayer, "drivingTest.checkmarkers", 20, false)
			blip = createBlip(x1, y1 , z1, 41, 2, 255, 0, 255, 255)
			marker = createMarker( x1, y1,z1 +1, "cylinder", 8, 255, 0, 255, 150)
			setMarkerTarget ( marker, a1, a2, a3 )
				
			addEventHandler("onClientMarkerHit", marker, UpdatePlaneCheckpoints)				
		end
	end
end

function UpdatePlaneCheckpoints(element)
	if (element == localPlayer) then
		local vehicle = getPedOccupiedVehicle(localPlayer)
		local id = getElementModel(vehicle)
		if not (testPlane[id]) then
			exports.DENhelp:createNewHelpMessage("This is not the plane where u should do your driving test with!", 255, 0, 0) -- Wrong plane type.
		else
			destroyElement(blip)
			destroyElement(marker)
			blip = nil
			marker = nil
				
			local m_number = getElementData(localPlayer, "drivingTest.marker")
			local max_number = getElementData(localPlayer, "drivingTest.checkmarkers")
			
			if (tonumber(max_number-1) == tonumber(m_number)) then -- if the next checkpoint is the final checkpoint.
				exports.DENhelp:createNewHelpMessage("You almost finished the exam, now land the plane sefely!", 255, 194, 14)
				
				local newnumber = m_number+1
				setElementData(localPlayer, "drivingTest.marker", newnumber, false)
					
				local x2, y2, z2 = nil
				x2 = planeTestRoute[newnumber][1]
				y2 = planeTestRoute[newnumber][2]
				z2 = planeTestRoute[newnumber][3]
				
				a1 = planeTestRoute[newnumber][1]
				a2 = planeTestRoute[newnumber][2]
				a3 = planeTestRoute[newnumber][3]
				
				local markerType = "ring"
				if ( newnumber == 17 ) or ( newnumber == 18 ) or ( newnumber == 19 ) or ( newnumber == 20 ) or ( newnumber == 1 ) then markerType = "cylinder" else markerType = "ring" end
				
				marker = createMarker( x2, y2, z2 +1, markerType, 8, 255, 0, 255, 150)
				setMarkerTarget ( marker, a1, a2, a3 )
				blip = createBlip( x2, y2, z2, 53, 2, 255, 0, 255, 255)
				
				
				addEventHandler("onClientMarkerHit", marker, endPlaneDrivingExam)
			else
				local newnumber = m_number+1
				local newnumber2 = m_number+2
				setElementData(localPlayer, "drivingTest.marker", newnumber, false)
						
				local x3, y3, z3 = nil
				x3 = planeTestRoute[newnumber][1]
				y3 = planeTestRoute[newnumber][2]
				z3 = planeTestRoute[newnumber][3]

				b1 = planeTestRoute[newnumber2][1]
				b2 = planeTestRoute[newnumber2][2]
				b3 = planeTestRoute[newnumber2][3]
				
				local markerType = "ring"
				if ( newnumber == 17 ) or ( newnumber == 18 ) or ( newnumber == 19 ) or ( newnumber == 20 ) or ( newnumber == 1 ) then markerType = "cylinder" else markerType = "ring" end
				
				marker = createMarker( x3, y3, z3 +1, markerType, 8, 255, 0, 255, 150)
				setMarkerTarget ( marker, b1, b2, b3 )
				blip = createBlip( x3, y3, z3, 41, 2, 255, 0, 255, 255)
				
				addEventHandler("onClientMarkerHit", marker, UpdatePlaneCheckpoints)
			end
		end
	end
end

function endPlaneDrivingExam (element)
	if (element == localPlayer) then
		local vehicle = getPedOccupiedVehicle(localPlayer)
		local id = getElementModel(vehicle)
		if not (testPlane[id]) then
			outputChatBox("You are not in the correct plane for this exam!", 255, 0, 0)
		else
			local vehicleHealth = getElementHealth ( vehicle )
			if (vehicleHealth >= 950) then
				exports.DENhelp:createNewHelpMessage("You passed the exam, get your licence at the flying school!", 255, 194, 14)
				setElementData(localPlayer, "passedPlaneDrivingtest", true, true)
				triggerServerEvent ( "destroyPlayerExamPlane", localPlayer )
				setElementData(localPlayer, "isDoingPlaneDrivingTest", false, true)
			else
				exports.DENhelp:createNewHelpMessage("Your plane is to damaged, you didn't pass the test.", 255, 194, 14)
				triggerServerEvent ( "destroyPlayerExamPlane", localPlayer )
				setElementData(localPlayer, "isDoingPlaneDrivingTest", false, true)
			end
			
			destroyElement(blip)
			destroyElement(marker)
			blip = nil
			marker = nil
		end
	end
end

addEventHandler("onClientVehicleExit", getRootElement(),
    function(thePlayer, seat)
        if thePlayer == localPlayer and seat == 0 then
			if getElementData(localPlayer, "isDoingPlaneDrivingTest") then
				exports.DENhelp:createNewHelpMessage("You leaved your plane and failed the test, try again.", 225, 0, 0)
				triggerServerEvent ( "destroyPlayerExamPlane", localPlayer )
				destroyElement(blip)
				destroyElement(marker)
				blip = nil
				marker = nil
			end
        end
    end
)

addEventHandler ( "onClientPlayerWasted", getLocalPlayer(), 
	function (killer, weapon, bodypart)
	    if source == localPlayer then
			if getElementData(localPlayer, "isDoingPlaneDrivingTest") then
				exports.DENhelp:createNewHelpMessage("You died while doing the plane exam and failed the test, try again.", 225, 0, 0)
				triggerServerEvent ( "destroyPlayerExamPlane", localPlayer )
				destroyElement(blip)
				destroyElement(marker)
				blip = nil
				marker = nil
			end
        end
	end
)

