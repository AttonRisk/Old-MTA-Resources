boatTestRoute = {}
boatTestRoute[1] = { 2340.18, -2383, -0.36 }
boatTestRoute[2] = { 2473.72, -2305.98, -0.33 }
boatTestRoute[3] = { 2679.3, -2291.51, -0.31 }
boatTestRoute[4] = { 2814.47, -2356.82, -0.35 }
boatTestRoute[5] = { 2815.05, -2524.79, -0.3 }
boatTestRoute[6] = { 2734.94, -2624.15, -0.35 }
boatTestRoute[7] = { 2603.81, -2698.36, -0.3 }
boatTestRoute[8] = { 2518.56, -2731.43, -0.35 }
boatTestRoute[9] = { 2434.57, -2757.12, -0.34 }
boatTestRoute[10] = { 2346.5, -2726.11, -0.35 }
boatTestRoute[11] = { 2343.03, -2595.43, -0.35 }
boatTestRoute[12] = { 2323.58, -2399.47, -0.35 }

testBoat = { [453]=true } -- boat the player get for the test

local blip = nil
local marker = nil

local boatLicenceShops = { 
[1]={2313.42, -2390.34, 2}, -- boat drivers licence you should get in LS
}

function boatLicenceWindow ()
-- Window when you hit the licence school marker
boatLicenceScreen = guiCreateWindow(531,281,412,276,"CSG ~ Boat driving School",false)
boatLicenceMemo = guiCreateMemo(10,24,393,163,"Before you can drive boats you need to pass a boat driving exam. This is a pratical exam, meaning you will have to drive your boat through several checkpoints in the sea around Los Santos. Here at the Boat driving school you can start an exam. When you pass the exam you will be able to drive all boats in the server.\n\nOne exam costs 1500$. If you fail you need to pay again. When you press buy exam you get all the information you need to start the exam.",false,boatLicenceScreen)
guiMemoSetReadOnly(boatLicenceMemo, true)
boatLicenceLabel1 = guiCreateLabel(13,206,151,17,"Buy boat exam ($1500)",false,boatLicenceScreen)
guiLabelSetColor(boatLicenceLabel1,0,225,0)
guiSetFont(boatLicenceLabel1,"default-bold-small")
boatLicenceBuyExam = guiCreateButton(11,229,152,34,"Buy Exam",false,boatLicenceScreen)
boatLicenceLabel2 = guiCreateLabel(246,206,156,17,"Pickup your boat licence",false,boatLicenceScreen)
guiLabelSetColor(boatLicenceLabel2,0,225,0)
guiSetFont(boatLicenceLabel2,"default-bold-small")
boatLicenceWindowTake = guiCreateButton(244,229,152,34,"Take licence",false,boatLicenceScreen)
boatLicenceWindowClose = guiCreateButton(175,229,59,34,"Close",false,boatLicenceScreen)

local screenW,screenH=guiGetScreenSize()
local windowW,windowH=guiGetSize(boatLicenceScreen,false)
local x,y = (screenW-windowW)/2,(screenH-windowH)/2
guiSetPosition(boatLicenceScreen,x,y,false)

guiWindowSetMovable (boatLicenceScreen, true)
guiWindowSetSizable (boatLicenceScreen, false)
guiSetVisible (boatLicenceScreen, false)

addEventHandler("onClientGUIClick", boatLicenceWindowClose, function() guiSetVisible(boatLicenceScreen, false) showCursor(false,false) end, false)
addEventHandler ( "onClientGUIClick", boatLicenceWindowTake, takeBoatDrivingLicence, false )
addEventHandler ( "onClientGUIClick", boatLicenceBuyExam, buyBoatDrivingTest, false )
end

function boatLicenceInformationWindowOnStart ()
-- Information you get when you spawn the vehicle
informationBoatWindowAtStart = guiCreateWindow(531,281,522,360,"CSG ~ Boat driving School",false)
informationMemoAtStart = guiCreateMemo(10,24,503,294,"Now, you must go through each checkpoint until the end of the exam. If the durability of your boat goes down from 95%, you will fail the exam and will have to buy another one.",false,informationBoatWindowAtStart)
closeInformationWindowAtStart = guiCreateButton(460,322,53,29,"Close",false,informationBoatWindowAtStart)
guiMemoSetReadOnly(informationMemoAtStart, true)

local screenW,screenH=guiGetScreenSize()
local windowW,windowH=guiGetSize(informationBoatWindowAtStart,false)
local x,y = (screenW-windowW)/2,(screenH-windowH)/2
guiSetPosition(informationBoatWindowAtStart,x,y,false)

guiWindowSetMovable (informationBoatWindowAtStart, true)
guiWindowSetSizable (informationBoatWindowAtStart, false)
guiSetVisible (informationBoatWindowAtStart, false)

addEventHandler("onClientGUIClick", closeInformationWindowAtStart, function() guiSetVisible(informationBoatWindowAtStart, false) showCursor(false,false) end, false)
end

-- On resource start, load the guis
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), 
	function ()
		boatLicenceWindow()
		boatLicenceInformationWindowOnStart()
	end
)

function takeBoatDrivingLicence ()
	if getElementData( localPlayer, "boatLicence" ) then
		exports.DENhelp:createNewHelpMessage("You already have a boat drivers licence!", 225, 0, 0)
	elseif getElementData(localPlayer, "passedBoatDrivingtest") then
		triggerServerEvent ( "givePlayerBoatLicence", localPlayer )
	else
		exports.DENhelp:createNewHelpMessage("You didn't pass for your boat licence yet!", 225, 0, 0)
	end
end

function buyBoatDrivingTest ()
	if getElementData(localPlayer, "passedBoatDrivingtest") or getElementData(localPlayer, "boatLicence") then
		exports.DENhelp:createNewHelpMessage("You already have a licence for flying boats!", 225, 0, 0)
	elseif getElementData(localPlayer, "isDoingBoatDrivingTest") then
		exports.DENhelp:createNewHelpMessage("You already started a boat driving test!", 225, 0, 0)
	elseif getPlayerMoney (localPlayer) < 1500 then
		exports.DENhelp:createNewHelpMessage("You don't have enough money for the driving test!", 225, 0, 0)
	else
		local x, y, z = boatTestRoute[1][1], boatTestRoute[1][2], boatTestRoute[1][3]
		blip = createBlip(x, y, z, 41, 2, 0, 255, 0, 255)
		marker = createMarker(x, y, z, "checkpoint", 4, 0, 255, 0, 150) -- start marker.
		addEventHandler("onClientMarkerHit", marker, startBoatDrivingExam)
		setElementData(localPlayer, "isDoingBoatDrivingTest", true, true)
		
		-- Marker for driving test vehicle
		boatExamVehicleMarker = createMarker (2318.44, -2395.2, 2, "cylinder",2.0, 0, 102, 31, 225)
		addEventHandler("onClientMarkerHit", boatExamVehicleMarker, givePlayerVehicleForBoatExam)
		guiSetVisible (boatLicenceScreen, false)
		showCursor(false,false)
	end
end

function givePlayerVehicleForBoatExam (hitPlayer, matchingDimension)
	if hitPlayer == localPlayer then
		destroyElement(boatExamVehicleMarker)
		guiSetVisible(informationBoatWindowAtStart,true)
		showCursor(true,true)
		triggerServerEvent ( "givePlayerExamBoat", localPlayer )
	end
end

function onboatLicenceShopMarkerHit( hitElement, matchingDimension )
	if hitElement == localPlayer then
		if not isPedInVehicle(localPlayer) then
			guiSetVisible(boatLicenceScreen,true)
			showCursor(true,true)
		end
	end
end

for ID in pairs(boatLicenceShops) do 
local x, y, z = boatLicenceShops[ID][1], boatLicenceShops[ID][2], boatLicenceShops[ID][3] 
createBlip ( x, y, z, 43, 2, 0, 0, 0, 0, 0, 270)
local boatLicenceShopMarker = createMarker(x,y,z,"cylinder",2.0, 0, 102, 31, 225)
addEventHandler("onClientMarkerHit", boatLicenceShopMarker, onboatLicenceShopMarkerHit)
end

function startBoatDrivingExam(theElement)
	if theElement == localPlayer then
		local vehicle = getPedOccupiedVehicle(localPlayer)
		local id = getElementModel(vehicle)
		if not (testBoat[id]) then
			if isPedInVehicle(localPlayer) then
				exports.DENhelp:createNewHelpMessage("This is not the boat you got from the driving school!", 255, 0, 0, true ) -- Wrong boat type
			else
				exports.DENhelp:createNewHelpMessage("Spawn the vehicle first, then fly in this marker!", 255, 0, 0, true )
			end
		else
			destroyElement(blip)
			destroyElement(marker)
			
			setElementData(localPlayer, "drivingTest.marker", 2, false)

			local x1,y1,z1 = nil -- Setup the first checkpoint
			x1 = boatTestRoute[2][1]
			y1 = boatTestRoute[2][2]
			z1 = boatTestRoute[2][3]

			setElementData(localPlayer, "drivingTest.checkmarkers", 12, false)
			blip = createBlip(x1, y1 , z1, 41, 2, 255, 0, 255, 255)
			marker = createMarker( x1, y1,z1 , "checkpoint", 4, 255, 0, 255, 150)
				
			addEventHandler("onClientMarkerHit", marker, UpdateBoatCheckpoints)				
		end
	end
end

function UpdateBoatCheckpoints(element)
	if (element == localPlayer) then
		local vehicle = getPedOccupiedVehicle(localPlayer)
		local id = getElementModel(vehicle)
		if not (testBoat[id]) then
			exports.DENhelp:createNewHelpMessage("This is not the boat where u should do your driving test with!", 255, 0, 0) -- Wrong boat type.
		else
			destroyElement(blip)
			destroyElement(marker)
			blip = nil
			marker = nil
				
			local m_number = getElementData(localPlayer, "drivingTest.marker")
			local max_number = getElementData(localPlayer, "drivingTest.checkmarkers")
			
			if (tonumber(max_number-1) == tonumber(m_number)) then -- if the next checkpoint is the final checkpoint.
				exports.DENhelp:createNewHelpMessage("You almost finished the exam, now park the boat safe.", 255, 194, 14, true)
				
				local newnumber = m_number+1
				setElementData(localPlayer, "drivingTest.marker", newnumber, false)
					
				local x2, y2, z2 = nil
				x2 = boatTestRoute[newnumber][1]
				y2 = boatTestRoute[newnumber][2]
				z2 = boatTestRoute[newnumber][3]
				
				marker = createMarker( x2, y2, z2, "checkpoint", 4, 255, 0, 255, 150)
				blip = createBlip( x2, y2, z2, 53, 2, 255, 0, 255, 255)
				
				
				addEventHandler("onClientMarkerHit", marker, endBoatDrivingExam)
			else
				local newnumber = m_number+1
				setElementData(localPlayer, "drivingTest.marker", newnumber, false)
						
				local x3, y3, z3 = nil
				x3 = boatTestRoute[newnumber][1]
				y3 = boatTestRoute[newnumber][2]
				z3 = boatTestRoute[newnumber][3]
						
				marker = createMarker( x3, y3, z3, "checkpoint", 4, 255, 0, 255, 150)
				blip = createBlip( x3, y3, z3, 41, 2, 255, 0, 255, 255)
				
				addEventHandler("onClientMarkerHit", marker, UpdateBoatCheckpoints)
			end
		end
	end
end

function endBoatDrivingExam (element)
	if (element == localPlayer) then
		local vehicle = getPedOccupiedVehicle(localPlayer)
		local id = getElementModel(vehicle)
		if not (testBoat[id]) then
			exports.DENhelp:createNewHelpMessage("You are not in the correct boat for this exam!", 255, 0, 0)
		else
			local vehicleHealth = getElementHealth ( vehicle )
			if (vehicleHealth >= 950) then
				exports.DENhelp:createNewHelpMessage("You passed the exam, get your licence at the driving school!", 255, 194, 14)
				setElementData(localPlayer, "passedBoatDrivingtest", true, true)
				triggerServerEvent ( "destroyPlayerExamBoat", localPlayer )
				setElementData(localPlayer, "isDoingBoatDrivingTest", false, true)
			else
				exports.DENhelp:createNewHelpMessage("Your boat is to damaged, you didn't pass the test.", 255, 194, 14)
				triggerServerEvent ( "destroyPlayerExamBoat", localPlayer )
				setElementData(localPlayer, "isDoingBoatDrivingTest", false, true)
			end
			setElementPosition(localPlayer, 2320.46, -2392.78, 3)
			setElementRotation(localPlayer, 0, 0, 130.39047241211)
			destroyElement(blip)
			destroyElement(marker)
			blip = nil
			marker = nil
		end
	end
end

addEventHandler("onClientVehicleExit", getRootElement(),
    function(thePlayer, seat)
        if thePlayer == localPlayer and seat == 0 then
			if getElementData(localPlayer, "isDoingBoatDrivingTest") then
				exports.DENhelp:createNewHelpMessage("You leaved your boat and failed the test, try again.", 225, 0, 0)
				triggerServerEvent ( "destroyPlayerExamBoat", localPlayer )
				destroyElement(blip)
				destroyElement(marker)
				blip = nil
				marker = nil
				setElementPosition(localPlayer, 2320.46, -2392.78, 3)
				setElementRotation(localPlayer, 0, 0, 130.39047241211)
			end
        end
    end
)

addEventHandler ( "onClientPlayerWasted", getLocalPlayer(), 
	function (killer, weapon, bodypart)
	    if source == localPlayer then
			if getElementData(localPlayer, "isDoingBoatDrivingTest") then
				exports.DENhelp:createNewHelpMessage("You died while doing the boat exam and failed the test, try again.", 225, 0, 0)
				triggerServerEvent ( "destroyPlayerExamBoat", localPlayer )
				destroyElement(blip)
				destroyElement(marker)
				blip = nil
				marker = nil
				setElementPosition(localPlayer, 2320.46, -2392.78, 3)
				setElementRotation(localPlayer, 0, 0, 130.39047241211)
			end
        end
	end
)