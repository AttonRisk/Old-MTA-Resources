local examVehicle = {}

-- Driving test for cars
function givePlayerExamCar ()
	if isElement(examVehicle[source]) then destroyElement(examVehicle[source]) end
    examVehicle[source] = createVehicle ( 436, 1279.01, -1812.54, 14.38 )
    warpPedIntoVehicle ( source, examVehicle[source] ) 
	setVehicleLocked ( examVehicle[source], true )
	exports.DENlogging:writePlayerLog ( source, getPlayerName(source).." bought a car exam for $1500")
	takePlayerMoney( source, 1500 )
end
addEvent("givePlayerExamCar", true)
addEventHandler("givePlayerExamCar", root, givePlayerExamCar)

function destroyPlayerExamCar ()
    destroyElement(examVehicle[source])
	setElementData(source, "isDoingCarDrivingTest", false)
end
addEvent("destroyPlayerExamCar", true)
addEventHandler("destroyPlayerExamCar", root, destroyPlayerExamCar)

function givePlayerCarLicence ()
	if not ( getElementData( source, "carLicence" ) ) then
		local playerID = exports.server:playerID( source )
		giveCarLicence = exports.DENmysql:exec( "UPDATE accounts SET carlicence = ? WHERE id = ?", 1, playerID)
		setElementData( source, "carLicence", true )
		outputChatBox("Another driver on the road! "..getPlayerName(source).." earned his car licence.", root, 0, 225, 0)
	end
end
addEvent("givePlayerCarLicence", true)
addEventHandler("givePlayerCarLicence", root, givePlayerCarLicence)

-- Chopper test
function givePlayerExamChopper ()
	if isElement(examVehicle[source]) then destroyElement(examVehicle[source]) end
    examVehicle[source] = createVehicle ( 487, 1990.87, -2246.33, 13.54, 0, 0, 95.612731933594 )
    warpPedIntoVehicle ( source, examVehicle[source] ) 
	setVehicleLocked ( examVehicle[source], true )
	exports.DENlogging:writePlayerLog ( source, getPlayerName(source).." bought a chopper exam for $1500")
	takePlayerMoney( source, 1500 )
end
addEvent("givePlayerExamChopper", true)
addEventHandler("givePlayerExamChopper", root, givePlayerExamChopper)

function destroyPlayerExamChopper ()
    destroyElement(examVehicle[source])
	setElementData(source, "isDoingChopperDrivingTest", false)
end
addEvent("destroyPlayerExamChopper", true)
addEventHandler("destroyPlayerExamChopper", root, destroyPlayerExamChopper)

function givePlayerChopperLicence ()
	if not ( getElementData( source, "chopperLicence" ) ) then
		local playerID = exports.server:playerID( source )
		giveCarLicence = exports.DENmysql:exec( "UPDATE accounts SET chopperlicence = ? WHERE id = ?", 1, playerID)
		setElementData( source, "chopperLicence", true )
		outputChatBox("Another chopper pilot in the air! "..getPlayerName(source).." earned his chopper licence.", root, 0, 225, 0)
	end
end
addEvent("givePlayerChopperLicence", true)
addEventHandler("givePlayerChopperLicence", root, givePlayerChopperLicence)

-- bike test
function givePlayerExamBike ()
	if isElement(examVehicle[source]) then destroyElement(examVehicle[source]) end
    examVehicle[source] = createVehicle ( 522, -2266.55, 208.63, 36.16, 0, 0, 91.163208007812 )
    warpPedIntoVehicle ( source, examVehicle[source] ) 
	setVehicleLocked ( examVehicle[source], true )
	exports.DENlogging:writePlayerLog ( source, getPlayerName(source).." bought a bike exam for $1500")
	takePlayerMoney( source, 1500 )
end
addEvent("givePlayerExamBike", true)
addEventHandler("givePlayerExamBike", root, givePlayerExamBike)

function destroyPlayerExamBike ()
    destroyElement(examVehicle[source])
	setElementData(source, "isDoingBikeDrivingTest", false)
end
addEvent("destroyPlayerExamBike", true)
addEventHandler("destroyPlayerExamBike", root, destroyPlayerExamBike)

function givePlayerBikeLicence ()
	if not ( getElementData( source, "bikeLicence" ) ) then
		local playerID = exports.server:playerID( source )
		giveCarLicence = exports.DENmysql:exec( "UPDATE accounts SET bikelicence = ? WHERE id = ?", 1, playerID)
		setElementData( source, "bikeLicence", true )
		outputChatBox("Another driver on the road! "..getPlayerName(source).." earned his bike licence.", root, 0, 225, 0)
	end
end
addEvent("givePlayerBikeLicence", true)
addEventHandler("givePlayerBikeLicence", root, givePlayerBikeLicence)

-- Boat test
function givePlayerExamBoat ()
	if isElement(examVehicle[source]) then destroyElement(examVehicle[source]) end
    examVehicle[source] = createVehicle ( 453, 2330.45, -2402.47, 2.56, 0, 0, 303.25750732422 )
    warpPedIntoVehicle ( source, examVehicle[source] ) 
	setVehicleLocked ( examVehicle[source], true )
	exports.DENlogging:writePlayerLog ( source, getPlayerName(source).." bought a boat exam for $1500")
	takePlayerMoney( source, 1500 )
end
addEvent("givePlayerExamBoat", true)
addEventHandler("givePlayerExamBoat", root, givePlayerExamBoat)

function destroyPlayerExamBoat ()
    destroyElement(examVehicle[source])
	setElementData(source, "isDoingBoatDrivingTest", false)
end
addEvent("destroyPlayerExamBoat", true)
addEventHandler("destroyPlayerExamBoat", root, destroyPlayerExamBoat)

function givePlayerBoatLicence ()
	if not ( getElementData( source, "boatLicence" ) ) then
		local playerID = exports.server:playerID( source )
		giveCarLicence = exports.DENmysql:exec( "UPDATE accounts SET boatlicence = ? WHERE id = ?", 1, playerID)
		setElementData( source, "boatLicence", true )
		outputChatBox("Another boat driver in San Andreas! "..getPlayerName(source).." earned his boat licence.", root, 0, 225, 0)
	end
end
addEvent("givePlayerBoatLicence", true)
addEventHandler("givePlayerBoatLicence", root, givePlayerBoatLicence)

-- Plane licence
function givePlayerExamPlane ()
	if isElement(examVehicle[source]) then destroyElement(examVehicle[source]) end
    examVehicle[source] = createVehicle ( 593, -1657.71, -165.09, 14.14, 0, 0, 312.93661499023 )
    warpPedIntoVehicle ( source, examVehicle[source] ) 
	setVehicleLocked ( examVehicle[source], true )
	exports.DENlogging:writePlayerLog ( source, getPlayerName(source).." bought a plane exam for $1500")
	takePlayerMoney( source, 1500 )
end
addEvent("givePlayerExamPlane", true)
addEventHandler("givePlayerExamPlane", root, givePlayerExamPlane)

function destroyPlayerExamPlane ()
    destroyElement(examVehicle[source])
	setElementData(source, "isDoingPlaneDrivingTest", false)
end
addEvent("destroyPlayerExamPlane", true)
addEventHandler("destroyPlayerExamPlane", root, destroyPlayerExamPlane)

function givePlayerPlaneLicence ()
	if not ( getElementData( source, "planeLicence" ) ) then
		local playerID = exports.server:playerID( source )
		giveCarLicence = exports.DENmysql:exec( "UPDATE accounts SET planelicence = ? WHERE id = ?", 1, playerID)
		setElementData( source, "planeLicence", true )
		outputChatBox("Another plane pilot in the air! "..getPlayerName(source).." earned his plane licence.", root, 0, 225, 0)
	end
end
addEvent("givePlayerPlaneLicence", true)
addEventHandler("givePlayerPlaneLicence", root, givePlayerPlaneLicence)

addEventHandler( "onPlayerQuit", root,
function ()
	if ( isElement(examVehicle[source] )) then
		destroyElement(examVehicle[source])
	end
end
)