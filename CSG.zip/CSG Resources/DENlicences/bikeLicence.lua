bikeTestRoute = {}
bikeTestRoute[1] = { -2263.91, 168.01, 34.72 }
bikeTestRoute[2] = { -2232.9, 318.11, 34.73 }
bikeTestRoute[3] = { -2020.97, 317.91, 34.58 }
bikeTestRoute[4] = { -2000.51, 587.12, 34.57 }
bikeTestRoute[5] = { -1999.69, 713.09, 44.85 }
bikeTestRoute[6] = { -2124.18, 733.45, 68.97 }
bikeTestRoute[7] = { -2138.13, 884.86, 79.45 }
bikeTestRoute[8] = { -2123.53, 916.12, 79.54 }
bikeTestRoute[9] = { -2101.5, 940.11, 73.21 }
bikeTestRoute[10] = { -2087.52, 917.84, 67.83 }
bikeTestRoute[11] = { -2063.61, 945.09, 59.45 }
bikeTestRoute[12] = { -2054.48, 914.09, 55.49 }
bikeTestRoute[13] = { -2041.38, 944.99, 50.3 }
bikeTestRoute[14] = { -1977.41, 915.73, 44.85 }
bikeTestRoute[15] = { -1903.35, 866.91, 34.58 }
bikeTestRoute[16] = { -1986, 609.72, 34.58 }
bikeTestRoute[17] = { -2074.74, 569.64, 34.58 }
bikeTestRoute[18] = { -2147.09, 519.82, 34.57 }
bikeTestRoute[19] = { -2148.73, 332.88, 34.73 }
bikeTestRoute[20] = { -2254.76, 306.54, 34.73 }
bikeTestRoute[21] = { -2263.11, 168.73, 34.73 }
bikeTestRoute[22] = { -2266.58, 188.95, 34.73 }

testBike = { [522]=true } -- bike the player get for the test

local blip = nil
local marker = nil

local bikeLicenceShops = { 
[1]={-2266.33, 216.45, 34.16}, -- bike drivers licence you should get in LS
}

function bikeLicenceWindow ()
-- Window when you hit the licence school marker
bikeLicenceScreen = guiCreateWindow(531,281,412,276,"CSG ~ Bike Driving School",false)
bikeLicenceMemo = guiCreateMemo(10,24,393,163,"Before you can drive bikes you need to pass a bike driving exam. This is a pratical exam, meaning you will have to drive through several checkpoints around San Fierro.Here at the bike school you can start a driving test. When you pass the driving test you can drive all bikes in the server.\n\nOne exam costs 1500$. If you fail you need to pay again. When you press buy exam you get all the info you need to start the exam.",false,bikeLicenceScreen)
guiMemoSetReadOnly(bikeLicenceMemo, true)
bikeLicenceLabel1 = guiCreateLabel(13,206,151,17,"Buy bike exam ($1500)",false,bikeLicenceScreen)
guiLabelSetColor(bikeLicenceLabel1,0,225,0)
guiSetFont(bikeLicenceLabel1,"default-bold-small")
bikeLicenceBuyExam = guiCreateButton(11,229,152,34,"Buy Exam",false,bikeLicenceScreen)
bikeLicenceLabel2 = guiCreateLabel(246,206,156,17,"Pickup your bike licence",false,bikeLicenceScreen)
guiLabelSetColor(bikeLicenceLabel2,0,225,0)
guiSetFont(bikeLicenceLabel2,"default-bold-small")
bikeLicenceWindowTake = guiCreateButton(244,229,152,34,"Take licence",false,bikeLicenceScreen)
bikeLicenceWindowClose = guiCreateButton(175,229,59,34,"Close",false,bikeLicenceScreen)

local screenW,screenH=guiGetScreenSize()
local windowW,windowH=guiGetSize(bikeLicenceScreen,false)
local x,y = (screenW-windowW)/2,(screenH-windowH)/2
guiSetPosition(bikeLicenceScreen,x,y,false)

guiWindowSetMovable (bikeLicenceScreen, true)
guiWindowSetSizable (bikeLicenceScreen, false)
guiSetVisible (bikeLicenceScreen, false)

addEventHandler("onClientGUIClick", bikeLicenceWindowClose, function() guiSetVisible(bikeLicenceScreen, false) showCursor(false,false) end, false)
addEventHandler ( "onClientGUIClick", bikeLicenceWindowTake, takebikeDrivingLicence, false )
addEventHandler ( "onClientGUIClick", bikeLicenceBuyExam, buybikeDrivingTest, false )
end

function bikeLicenceInformationWindowOnStart ()
-- Information you get when you spawn the vehicle
informationbikeWindowAtStart = guiCreateWindow(531,281,522,360,"CSG ~ Bike Driving School",false)
informationMemoAtStart = guiCreateMemo(10,24,503,294,"You decided to go for your bike licence!Thats good, because you can't drive bikes without having a bike licence.If you see this screen that means you have bought the driving test.Here we will explain how you can pass the driving test.\n\nBefore you get your licence you need to complete the whole test.As you can see your now in the bike which you can do the test with.Never leave this bike because doing so will stop the test and you don't get the licence.Also if you die or your bike blows the test, will stop and you need to start again.\n\nAt your left you can see a big marker. If you drive in this marker you activate the test. Then you see a new marker. After you hit the marker a new marker will show up and so on. Keep driving in the marker till you get back at the bike school.\n\nYou passed the test when, you didn't blow your bike, you didn't drive to other players or when your bike has AT LEAST 95% health.\n\nIf you failed the test you can always start again. Good luck! And drive safely!",false,informationbikeWindowAtStart)
closeInformationWindowAtStart = guiCreateButton(460,322,53,29,"Close",false,informationbikeWindowAtStart)
guiMemoSetReadOnly(informationMemoAtStart, true)

local screenW,screenH=guiGetScreenSize()
local windowW,windowH=guiGetSize(informationbikeWindowAtStart,false)
local x,y = (screenW-windowW)/2,(screenH-windowH)/2
guiSetPosition(informationbikeWindowAtStart,x,y,false)

guiWindowSetMovable (informationbikeWindowAtStart, true)
guiWindowSetSizable (informationbikeWindowAtStart, false)
guiSetVisible (informationbikeWindowAtStart, false)

addEventHandler("onClientGUIClick", closeInformationWindowAtStart, function() guiSetVisible(informationbikeWindowAtStart, false) showCursor(false,false) end, false)
end

-- On resource start, load the guis
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), 
	function ()
		bikeLicenceWindow()
		bikeLicenceInformationWindowOnStart()
	end
)

function takebikeDrivingLicence ()
	if getElementData( localPlayer, "bikeLicence" ) then
		exports.DENhelp:createNewHelpMessage("You already have a bike drivers licence!", 225, 0, 0)
	elseif getElementData(localPlayer, "passedBikeDrivingTest") then
		triggerServerEvent ( "givePlayerBikeLicence", localPlayer )
	else
		exports.DENhelp:createNewHelpMessage("You didn't pass for your bike licence yet!", 225, 0, 0)
	end
end

function buybikeDrivingTest ()
	if getElementData(localPlayer, "passedBikeDrivingTest") or getElementData(localPlayer, "bikeLicence") then
		exports.DENhelp:createNewHelpMessage("You already have a licence for driving bikes!", 225, 0, 0)
	elseif getElementData(localPlayer, "isDoingBikeDrivingTest") then
		exports.DENhelp:createNewHelpMessage("You already started a bike driving test!", 225, 0, 0)
	elseif getPlayerMoney (localPlayer) < 1500 then
		exports.DENhelp:createNewHelpMessage("You don't have enough money for the driving test!", 225, 0, 0)
	else
		local x, y, z = bikeTestRoute[1][1], bikeTestRoute[1][2], bikeTestRoute[1][3]
		blip = createBlip(x, y, z, 41, 2, 0, 255, 0, 255)
		marker = createMarker(x, y, z, "checkpoint", 4, 0, 255, 0, 150) -- start marker.
		addEventHandler("onClientMarkerHit", marker, startbikeDrivingExam)
		setElementData(localPlayer, "isDoingBikeDrivingTest", true, true)
		
		-- Marker for driving test vehicle
		bikeExamVehicleMarker = createMarker ( -2266.55, 208.63, 34.16, "cylinder",2.0, 0, 102, 31, 225)
		addEventHandler("onClientMarkerHit", bikeExamVehicleMarker, givePlayerVehicleForBikeExam)
		guiSetVisible (bikeLicenceScreen, false)
		showCursor(false,false)
	end
end

function givePlayerVehicleForBikeExam (hitPlayer, matchingDimension)
	if hitPlayer == localPlayer then
		destroyElement(bikeExamVehicleMarker)
		guiSetVisible(informationbikeWindowAtStart,true)
		showCursor(true,true)
		triggerServerEvent ( "givePlayerExamBike", localPlayer )
	end
end

function onBikeLicenceShopMarkerHit( hitElement, matchingDimension )
	if hitElement == localPlayer then
		if not isPedInVehicle(localPlayer) then
		guiSetVisible(bikeLicenceScreen,true)
		showCursor(true,true)
		end
	end
end

for ID in pairs(bikeLicenceShops) do 
local x, y, z = bikeLicenceShops[ID][1], bikeLicenceShops[ID][2], bikeLicenceShops[ID][3] 
createBlip ( x, y, z, 43, 2, 0, 0, 0, 0, 0, 270)
local bikeLicenceShopMarker = createMarker(x,y,z,"cylinder",2.0, 0, 102, 31, 225)
addEventHandler("onClientMarkerHit", bikeLicenceShopMarker, onBikeLicenceShopMarkerHit)
end

function startbikeDrivingExam(theElement)
	if theElement == localPlayer then
		local vehicle = getPedOccupiedVehicle(localPlayer)
		local id = getElementModel(vehicle)
		if not (testBike[id]) then
			if isPedInVehicle(localPlayer) then
				exports.DENhelp:createNewHelpMessage("This is not the bike you got from the driving school!", 255, 0, 0, true ) -- Wrong bike type
			else
				exports.DENhelp:createNewHelpMessage("Spawn the vehicle first, then drive in this marker!", 255, 0, 0, true )
			end
		else
			destroyElement(blip)
			destroyElement(marker)
			
			setElementData(localPlayer, "drivingTest.marker", 2, false)

			local x1,y1,z1 = nil -- Setup the first checkpoint
			x1 = bikeTestRoute[2][1]
			y1 = bikeTestRoute[2][2]
			z1 = bikeTestRoute[2][3]

			setElementData(localPlayer, "drivingTest.checkmarkers", 22, false)
			blip = createBlip(x1, y1 , z1, 41, 2, 255, 0, 255, 255)
			marker = createMarker( x1, y1,z1 , "checkpoint", 4, 255, 0, 255, 150)
				
			addEventHandler("onClientMarkerHit", marker, UpdateBikeCheckpoints)				
		end
	end
end

function UpdateBikeCheckpoints(element)
	if (element == localPlayer) then
		local vehicle = getPedOccupiedVehicle(localPlayer)
		local id = getElementModel(vehicle)
		if not (testBike[id]) then
			exports.DENhelp:createNewHelpMessage("This is not the bike where u should do your driving test with!", 255, 0, 0) -- Wrong bike type.
		else
			destroyElement(blip)
			destroyElement(marker)
			blip = nil
			marker = nil
				
			local m_number = getElementData(localPlayer, "drivingTest.marker")
			local max_number = getElementData(localPlayer, "drivingTest.checkmarkers")
			
			if (tonumber(max_number-1) == tonumber(m_number)) then -- if the next checkpoint is the final checkpoint.
				exports.DENhelp:createNewHelpMessage("You almost finished the exam, now park the bike safe.", 255, 194, 14, true)
				
				local newnumber = m_number+1
				setElementData(localPlayer, "drivingTest.marker", newnumber, false)
					
				local x2, y2, z2 = nil
				x2 = bikeTestRoute[newnumber][1]
				y2 = bikeTestRoute[newnumber][2]
				z2 = bikeTestRoute[newnumber][3]
				
				marker = createMarker( x2, y2, z2, "checkpoint", 4, 255, 0, 255, 150)
				blip = createBlip( x2, y2, z2, 53, 2, 255, 0, 255, 255)
				
				
				addEventHandler("onClientMarkerHit", marker, endbikeDrivingExam)
			else
				local newnumber = m_number+1
				setElementData(localPlayer, "drivingTest.marker", newnumber, false)
						
				local x3, y3, z3 = nil
				x3 = bikeTestRoute[newnumber][1]
				y3 = bikeTestRoute[newnumber][2]
				z3 = bikeTestRoute[newnumber][3]
						
				marker = createMarker( x3, y3, z3, "checkpoint", 4, 255, 0, 255, 150)
				blip = createBlip( x3, y3, z3, 41, 2, 255, 0, 255, 255)
				
				addEventHandler("onClientMarkerHit", marker, UpdateBikeCheckpoints)
			end
		end
	end
end

function endbikeDrivingExam (element)
	if (element == localPlayer) then
		local vehicle = getPedOccupiedVehicle(localPlayer)
		local id = getElementModel(vehicle)
		if not (testBike[id]) then
			exports.DENhelp:createNewHelpMessage("You are not in the correct bike for this exam!", 255, 0, 0)
		else
			local vehicleHealth = getElementHealth ( vehicle )
			if (vehicleHealth >= 950) then
				exports.DENhelp:createNewHelpMessage("You passed the exam, get your licence at the driving school!", 255, 194, 14)
				setElementData(localPlayer, "passedBikeDrivingTest", true, true)
				triggerServerEvent ( "destroyPlayerExamBike", localPlayer )
				setElementData(localPlayer, "isDoingBikeDrivingTest", false, true)
			else
				exports.DENhelp:createNewHelpMessage("Your bike is to damaged, you didn't pass the test.", 255, 194, 14)
				triggerServerEvent ( "destroyPlayerExamBike", localPlayer )
				setElementData(localPlayer, "isDoingBikeDrivingTest", false, true)
			end
			
			destroyElement(blip)
			destroyElement(marker)
			blip = nil
			marker = nil
		end
	end
end

addEventHandler("onClientVehicleExit", getRootElement(),
    function(thePlayer, seat)
        if thePlayer == localPlayer and seat == 0 then
			if getElementData(localPlayer, "isDoingBikeDrivingTest") then
				exports.DENhelp:createNewHelpMessage("You leaved your bike and failed the test, try again.", 225, 0, 0)
				triggerServerEvent ( "destroyPlayerExamBike", localPlayer )
				destroyElement(blip)
				destroyElement(marker)
				blip = nil
				marker = nil
			end
        end
    end
)

addEventHandler ( "onClientPlayerWasted", getLocalPlayer(), 
	function (killer, weapon, bodypart)
	    if source == localPlayer then
			if getElementData(localPlayer, "isDoingBikeDrivingTest") then
				exports.DENhelp:createNewHelpMessage("You died while doing the bike exam and failed the test, try again.", 225, 0, 0)
				triggerServerEvent ( "destroyPlayerExamBike", localPlayer )
				destroyElement(blip)
				destroyElement(marker)
				blip = nil
				marker = nil
			end
        end
	end
)

