chopperTestRoute = {}
chopperTestRoute[1] = {1957.6, -2301.06, 21.77, 154.85711669922}
chopperTestRoute[2] = {1916.75, -2378.49, 47.48, 151.16485595703}
chopperTestRoute[3] = {1769.86, -2474.63, 70.06, 94.285705566406}
chopperTestRoute[4] = {1563.88, -2388.25, 92.51, 56.571441650391}
chopperTestRoute[5] = {1394.23, -2197.6, 112.54, 30.02197265625}
chopperTestRoute[6] = {1251.57, -1672.64, 93.24, 347.73626708984}
chopperTestRoute[7] = {1333.66, -1559.42, 95.58, 322.76922607422}
chopperTestRoute[8] = {1407.34, -1507.4, 108.65, 295.78021240234}
chopperTestRoute[9] = {1701.5, -1508.94, 94.68, 270.28570556641}
chopperTestRoute[10] = {1927.93, -1589, 77.7, 239.95603942871}
chopperTestRoute[11] = {1977.4, -1671.82, 69.74, 205.58241271973}
chopperTestRoute[12] = {1960.59, -1872.33, 80.81, 169.80218505859}
chopperTestRoute[13] = {1949.74, -2181.15, 55.04, 179.29669189453}
chopperTestRoute[14] = {1960.23, -2308.83, 32.1, 197.75823974609}
chopperTestRoute[15] = {1986.5, -2379.16, 13.72, 230.37362670898}

testChopper = { [487]=true } -- chopper the player get for the test

local blip = nil
local marker = nil

local chopperLicenceShops = { 
[1]={2003.04, -2269.31, 12.54}, -- chopper flyrs licence you should get in LS
}

function chopperLicenceWindow ()
-- Window when you hit the licence school marker
chopperLicenceScreen = guiCreateWindow(531,281,412,276,"CSG ~ Chopper flying School",false)
chopperLicenceMemo = guiCreateMemo(10,24,393,163,"Before you can pilot Helicopters, you need to pass a flying exam. This is a pratical exam, meaning you will have to pilot a Helicopter through several checkpoints around Los Santos. Here at the flying school you can start a flying exam. When you pass the exam you can buy and pilot all Helicopters in the server.\n\nOne exam costs 1500$. If you fail you need to pay again.\n\nWhen you press buy exam you get all the information you need to start the exam.",false,chopperLicenceScreen)
guiMemoSetReadOnly(chopperLicenceMemo, true)
chopperLicenceLabel1 = guiCreateLabel(13,206,151,17,"Buy chopper exam ($1500)",false,chopperLicenceScreen)
guiLabelSetColor(chopperLicenceLabel1,0,225,0)
guiSetFont(chopperLicenceLabel1,"default-bold-small")
chopperLicenceBuyExam = guiCreateButton(11,229,152,34,"Buy Exam",false,chopperLicenceScreen)
chopperLicenceLabel2 = guiCreateLabel(246,206,156,17,"Pickup your chopper licence",false,chopperLicenceScreen)
guiLabelSetColor(chopperLicenceLabel2,0,225,0)
guiSetFont(chopperLicenceLabel2,"default-bold-small")
chopperLicenceWindowTake = guiCreateButton(244,229,152,34,"Take licence",false,chopperLicenceScreen)
chopperLicenceWindowClose = guiCreateButton(175,229,59,34,"Close",false,chopperLicenceScreen)

local screenW,screenH=guiGetScreenSize()
local windowW,windowH=guiGetSize(chopperLicenceScreen,false)
local x,y = (screenW-windowW)/2,(screenH-windowH)/2
guiSetPosition(chopperLicenceScreen,x,y,false)

guiWindowSetMovable (chopperLicenceScreen, true)
guiWindowSetSizable (chopperLicenceScreen, false)
guiSetVisible (chopperLicenceScreen, false)

addEventHandler("onClientGUIClick", chopperLicenceWindowClose, function() guiSetVisible(chopperLicenceScreen, false) showCursor(false,false) end, false)
addEventHandler ( "onClientGUIClick", chopperLicenceWindowTake, takeChopperDrivingLicence, false )
addEventHandler ( "onClientGUIClick", chopperLicenceBuyExam, buyChopperDrivingTest, false )
end

function chopperLicenceInformationWindowOnStart ()
-- Information you get when you spawn the vehicle
informationChopperWindowAtStart = guiCreateWindow(531,281,522,360,"CSG ~ Chopper flying School",false)
informationMemoAtStart = guiCreateMemo(10,24,503,294,"You decided to go for your Helicopter licence! That's good, because you can't fly Helicopters without having this licence. If you see this screen that means you have bought the flying exam. Here we will explain how you can pass it.\n\nBefore you get your licence you need to complete the whole test. As you can see your now in the Helicopter on which you can do the test with. Never leave this vehicle. If you do the test will stop and you don't get the licence. Also if you die or your vehicle blows up, the test will stop and you need to start again.\n\nYou can now see a big ring. If you fly in this marker you activate the test. Then you see a new marker. After you hit the ring a new ring will show up and so on. Keep flying in the rings that will show up until you get back at the Helicopter school.\n\nYou passed the test when, you didnt blow your helicopter, you didnt fly into other players or when your vehicle has AT LEAST 95% health.\n\nIf you failed the test you can always start again. Good luck and fly safely!",false,informationChopperWindowAtStart)
closeInformationWindowAtStart = guiCreateButton(460,322,53,29,"Close",false,informationChopperWindowAtStart)
guiMemoSetReadOnly(informationMemoAtStart, true)

local screenW,screenH=guiGetScreenSize()
local windowW,windowH=guiGetSize(informationChopperWindowAtStart,false)
local x,y = (screenW-windowW)/2,(screenH-windowH)/2
guiSetPosition(informationChopperWindowAtStart,x,y,false)

guiWindowSetMovable (informationChopperWindowAtStart, true)
guiWindowSetSizable (informationChopperWindowAtStart, false)
guiSetVisible (informationChopperWindowAtStart, false)

addEventHandler("onClientGUIClick", closeInformationWindowAtStart, function() guiSetVisible(informationChopperWindowAtStart, false) showCursor(false,false) end, false)
end

-- On resource start, load the guis
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), 
	function ()
		chopperLicenceWindow()
		chopperLicenceInformationWindowOnStart()
	end
)

function takeChopperDrivingLicence ()
	if getElementData( localPlayer, "chopperLicence" ) then
		exports.DENhelp:createNewHelpMessage("You already have a chopper flyrs licence!", 225, 0, 0)
	elseif getElementData(localPlayer, "passedChopperDrivingtest") then
		triggerServerEvent ( "givePlayerChopperLicence", localPlayer )
	else
		exports.DENhelp:createNewHelpMessage("You didn't pass for your chopper licence yet!", 225, 0, 0)
	end
end

function buyChopperDrivingTest ()
	if getElementData(localPlayer, "passedChopperDrivingtest") or getElementData(localPlayer, "chopperLicence") then
		exports.DENhelp:createNewHelpMessage("You already have a licence for flying choppers!", 225, 0, 0)
	elseif getElementData(localPlayer, "isDoingChopperDrivingTest") then
		exports.DENhelp:createNewHelpMessage("You already started a chopper driving test!", 225, 0, 0)
	elseif getPlayerMoney (localPlayer) < 1500 then
		exports.DENhelp:createNewHelpMessage("You don't have enough money for the driving test!", 225, 0, 0)
	else
		local x, y, z = chopperTestRoute[1][1], chopperTestRoute[1][2], chopperTestRoute[1][3]
		blip = createBlip(x, y, z, 41, 2, 0, 255, 0, 255)
		marker = createMarker(x, y, z, "checkpoint", 4, 0, 255, 0, 150) -- start marker.
		addEventHandler("onClientMarkerHit", marker, startChopperDrivingExam)
		setElementData(localPlayer, "isDoingChopperDrivingTest", true, true)
		
		-- Marker for driving test vehicle
		chopperExamVehicleMarker = createMarker (1986.8, -2262.08, 12.73, "cylinder",2.0, 0, 102, 31, 225)
		addEventHandler("onClientMarkerHit", chopperExamVehicleMarker, givePlayerVehicleForChopperExam)
		guiSetVisible (chopperLicenceScreen, false)
		showCursor(false,false)
	end
end

function givePlayerVehicleForChopperExam (hitPlayer, matchingDimension)
	if hitPlayer == localPlayer then
		destroyElement(chopperExamVehicleMarker)
		guiSetVisible(informationChopperWindowAtStart,true)
		showCursor(true,true)
		triggerServerEvent ( "givePlayerExamChopper", localPlayer )
	end
end

function onchopperLicenceShopMarkerHit( hitElement, matchingDimension )
	if hitElement == localPlayer then
		if not isPedInVehicle(localPlayer) then
			guiSetVisible(chopperLicenceScreen,true)
			showCursor(true,true)
		end
	end
end

for ID in pairs(chopperLicenceShops) do 
	local x, y, z = chopperLicenceShops[ID][1], chopperLicenceShops[ID][2], chopperLicenceShops[ID][3] 
	createBlip ( x, y, z, 43, 2, 0, 0, 0, 0, 0, 270)
	local chopperLicenceShopMarker = createMarker(x,y,z,"cylinder",2.0, 0, 102, 31, 225)
	addEventHandler("onClientMarkerHit", chopperLicenceShopMarker, onchopperLicenceShopMarkerHit)
end

function startChopperDrivingExam(theElement)
	if theElement == localPlayer then
		local vehicle = getPedOccupiedVehicle(localPlayer)
		local id = getElementModel(vehicle)
		if not (testChopper[id]) then
			if isPedInVehicle(localPlayer) then
				exports.DENhelp:createNewHelpMessage("This is not the chopper you got from the driving school!", 255, 0, 0 ) -- Wrong chopper type
			else
				exports.DENhelp:createNewHelpMessage("Spawn the vehicle first, then fly in this marker!", 255, 0, 0 )
			end
		else
			destroyElement(blip)
			destroyElement(marker)
			
			setElementData(localPlayer, "drivingTest.marker", 2, false)

			local x1,y1,z1 = nil -- Setup the first checkpoint
			x1 = chopperTestRoute[2][1]
			y1 = chopperTestRoute[2][2]
			z1 = chopperTestRoute[2][3]
			
			a1 = chopperTestRoute[3][1]
			a2 = chopperTestRoute[3][2]
			a3 = chopperTestRoute[3][3]

			setElementData(localPlayer, "drivingTest.checkmarkers", 15, false)
			blip = createBlip(x1, y1 , z1, 41, 2, 255, 0, 255, 255)
			marker = createMarker( x1, y1,z1 , "ring", 8, 255, 0, 255, 150)
			setMarkerTarget ( marker, a1, a2, a3 )
				
			addEventHandler("onClientMarkerHit", marker, UpdateChopperCheckpoints)				
		end
	end
end

function UpdateChopperCheckpoints(element)
	if (element == localPlayer) then
		local vehicle = getPedOccupiedVehicle(localPlayer)
		local id = getElementModel(vehicle)
		if not (testChopper[id]) then
			exports.DENhelp:createNewHelpMessage("This is not the chopper where u should do your driving test with!", 255, 0, 0) -- Wrong chopper type.
		else
			destroyElement(blip)
			destroyElement(marker)
			blip = nil
			marker = nil
				
			local m_number = getElementData(localPlayer, "drivingTest.marker")
			local max_number = getElementData(localPlayer, "drivingTest.checkmarkers")
			
			if (tonumber(max_number-1) == tonumber(m_number)) then -- if the next checkpoint is the final checkpoint.
				exports.DENhelp:createNewHelpMessage("You almost finished the exam, now land the chopper sefely!", 255, 194, 14)
				
				local newnumber = m_number+1
				setElementData(localPlayer, "drivingTest.marker", newnumber, false)
					
				local x2, y2, z2 = nil
				x2 = chopperTestRoute[newnumber][1]
				y2 = chopperTestRoute[newnumber][2]
				z2 = chopperTestRoute[newnumber][3]
				
				a1 = chopperTestRoute[newnumber][1]
				a2 = chopperTestRoute[newnumber][2]
				a3 = chopperTestRoute[newnumber][3]
				
				local markerType = "ring"
				if ( newnumber == 15 ) then markerType = "cylinder" else markerType = "ring" end
				
				marker = createMarker( x2, y2, z2, markerType, 8, 255, 0, 255, 150)
				setMarkerTarget ( marker, a1, a2, a3 ) 
				blip = createBlip( x2, y2, z2, 53, 2, 255, 0, 255, 255)
					
				addEventHandler("onClientMarkerHit", marker, endChopperDrivingExam)
			else
				local newnumber = m_number+1
				local newnumber2 = m_number+2
				setElementData(localPlayer, "drivingTest.marker", newnumber, false)
						
				local x3, y3, z3 = nil
				x3 = chopperTestRoute[newnumber][1]
				y3 = chopperTestRoute[newnumber][2]
				z3 = chopperTestRoute[newnumber][3]
				
				b1 = chopperTestRoute[newnumber2][1]
				b2 = chopperTestRoute[newnumber2][2]
				b3 = chopperTestRoute[newnumber2][3]
				
				local markerType = "ring"
				if ( newnumber == 15 ) then markerType = "cylinder" else markerType = "ring" end
				
				marker = createMarker( x3, y3, z3, markerType, 8, 255, 0, 255, 150)
				setMarkerTarget ( marker, b1, b2, b3 )
				blip = createBlip( x3, y3, z3, 41, 2, 255, 0, 255, 255)
				
				addEventHandler("onClientMarkerHit", marker, UpdateChopperCheckpoints)
			end
		end
	end
end

function endChopperDrivingExam (element)
	if (element == localPlayer) then
		local vehicle = getPedOccupiedVehicle(localPlayer)
		local id = getElementModel(vehicle)
		if not (testChopper[id]) then
			createNewHelpMessage("You are not in the correct chopper for this exam!", 255, 0, 0)
		else
			local vehicleHealth = getElementHealth ( vehicle )
			if (vehicleHealth >= 950) then
				exports.DENhelp:createNewHelpMessage("You passed the exam, get your licence at the flying school!", 255, 194, 14)
				setElementData(localPlayer, "passedChopperDrivingtest", true, true)
				triggerServerEvent ( "destroyPlayerExamChopper", localPlayer )
				setElementData(localPlayer, "isDoingChopperDrivingTest", false, true)
			else
				createNewHelpMessage("Your chopper is to damaged, you didn't pass the test.", 255, 194, 14)
				triggerServerEvent ( "destroyPlayerExamChopper", localPlayer )
				setElementData(localPlayer, "isDoingChopperDrivingTest", false, true)
			end
			
			destroyElement(blip)
			destroyElement(marker)
			blip = nil
			marker = nil
		end
	end
end

addEventHandler("onClientVehicleExit", getRootElement(),
    function(thePlayer, seat)
        if thePlayer == localPlayer and seat == 0 then
			if getElementData(localPlayer, "isDoingChopperDrivingTest") then
				exports.DENhelp:createNewHelpMessage("You leaved your chopper and failed the test, try again.", 225, 0, 0)
				triggerServerEvent ( "destroyPlayerExamChopper", localPlayer )
				destroyElement(blip)
				destroyElement(marker)
				blip = nil
				marker = nil
			end
        end
    end
)

addEventHandler ( "onClientPlayerWasted", getLocalPlayer(), 
	function (killer, weapon, bodypart)
	    if source == localPlayer then
			if getElementData(localPlayer, "isDoingChopperDrivingTest") then
				exports.DENhelp:createNewHelpMessage("You died while doing the chopper exam and failed the test, try again.", 225, 0, 0)
				triggerServerEvent ( "destroyPlayerExamChopper", localPlayer )
				destroyElement(blip)
				destroyElement(marker)
				blip = nil
				marker = nil
			end
        end
	end
)

