function createNewBankingTransAction ( playerid, transaction )
	if ( playerid ) and ( transaction ) then
		exports.DENmysql:exec( "INSERT INTO banking_transactions SET userid = ?, transaction = ?", playerid, transaction)
	end
end

addEvent ("onBankMarkerHit", true)
function onBankMarkerHit ()
	local playerID = exports.server:playerID( source )
	local balanceCheck = exports.DENmysql:querySingle( "SELECT * FROM banking WHERE userid = ?", playerID )
	if not balanceCheck then
		exports.DENhelp:createNewHelpMessageForPlayer(source, "Seems you didn't had a back account, we created one for you!", 200,0,0)
		local makeBankAccount = exports.DENmysql:exec("INSERT INTO banking SET userid = ?", playerID)
	else
		triggerClientEvent (source, "showBankingGui", source, balanceCheck.balance)
		triggerClientEvent (source, "updateBalanceLabel", source, balanceCheck.balance)
	end
end
addEventHandler ("onBankMarkerHit", root, onBankMarkerHit)

addEvent ("withdrawMoney", true)
function withdrawMoney (value)
	local playerID = exports.server:playerID( source )
	local balanceCheck = exports.DENmysql:querySingle( "SELECT * FROM banking WHERE userid = ?", playerID )
	local playerMoney = getPlayerMoney ( source )

	local totalGive = value
	local totalNewBalance = (balanceCheck.balance - value)

	if tonumber(value) > tonumber(balanceCheck.balance) or balanceCheck.balance == 0 then
		exports.DENhelp:createNewHelpMessageForPlayer(source, "You dont have enough money on your bank account!", 200,0,0)
	else
		givePlayerMoney (source, totalGive)
		local updateBank = exports.DENmysql:exec( "UPDATE banking SET balance = ? WHERE userid = ?", totalNewBalance, playerID)
		createNewBankingTransAction ( playerID, "Withdrawn $".. value .."" )
		triggerClientEvent (source, "updateBalanceLabel", source, totalNewBalance)
	end
end
addEventHandler ("withdrawMoney", root, withdrawMoney)

addEvent ("depositMoney", true)
function depositMoney(value)
	local playerID = exports.server:playerID( source )
	local balanceCheck = exports.DENmysql:querySingle( "SELECT * FROM banking WHERE userid = ?", playerID )
	local playerMoney = getPlayerMoney ( source )

	local totalTake = value
	local totalNewBalance = (balanceCheck.balance + value)

	if tonumber(value) > tonumber(playerMoney) or playerMoney == 0 then
		exports.DENhelp:createNewHelpMessageForPlayer(source, "You can't deposit this much money, because you dont have it!", 200,0,0)
	else
		takePlayerMoney (source, totalTake)
		updateBank = exports.DENmysql:exec( "UPDATE banking SET balance = ? WHERE userid = ?", totalNewBalance, playerID)
		createNewBankingTransAction ( playerID, "Deposited $".. value .."" )
		triggerClientEvent (source, "updateBalanceLabel", source, totalNewBalance)
	end
end
addEventHandler ("depositMoney", root, depositMoney)

addEvent ("requestTransactions", true)
function requestTransactions ()
	local playerID = exports.server:playerID( source )
	local transactionsCheck = exports.DENmysql:querySingle( "SELECT * FROM banking_transactions WHERE userid = ?", playerID )
	local transactions = exports.DENmysql:query( "SELECT * FROM banking_transactions WHERE userid = ? ORDER BY datum DESC, datum ASC LIMIT 15", playerID )
	if not transactionsCheck then
		exports.DENhelp:createNewHelpMessageForPlayer(source, "You dont have recent transactions.", 0, 200, 0)
	elseif transactions and #transactions > 0 then
		for key, transaction in ipairs( transactions ) do
			triggerClientEvent ( source, "insertTransactions", source, transaction.datum, transaction.transaction )		
		end
	end
end
addEventHandler ("requestTransactions", root, requestTransactions)

addEvent ("buyCreditcard", true)
function buyCreditcard ()
	local playerID = exports.server:playerID( source )
	if ( getPlayerMoney( source ) < 1000 ) then
		exports.DENhelp:createNewHelpMessageForPlayer(source, "You dont have enough cash for a creditcard!", 0,200,0)
	elseif ( getElementData( source, "creditcard" ) == 1 ) then
		exports.DENhelp:createNewHelpMessageForPlayer(source, "You already have a creditcard!", 0,200,0)
	else
		local giveTheCard = exports.DENmysql:exec( "UPDATE banking SET creditcard = ? WHERE userid = ?", 1, playerID)
		exports.DENhelp:createNewHelpMessageForPlayer(source, "You have bought a creditcard for $1000", 0,200,0)
		setElementData(source, "creditcard", 1)
		takePlayerMoney( source, 1000 )
	end
end
addEventHandler ("buyCreditcard", root, buyCreditcard)

addEvent ("sendPlayerMoney", true)
function sendPlayerMoney (reciever, money, localPlayerMoney)
	if not ( reciever ) then
		exports.DENhelp:createNewHelpMessageForPlayer(source, "The reciever you enterd does not exist or is not online!", 200,0,0)
	elseif ( reciever == source ) then
		exports.DENhelp:createNewHelpMessageForPlayer(source, "You can't transfer money to yourself!", 200,0,0)
	elseif tonumber(money) > tonumber(localPlayerMoney) or localPlayerMoney == 0 then
		exports.DENhelp:createNewHelpMessageForPlayer(source, "You can't transfer this much money, because you dont have it!", 200,0,0)
	elseif ( reciever ) then
		local playerID = exports.server:playerID( reciever )
		local playerID2 = exports.server:playerID( source )
		local recieverCheck = exports.DENmysql:querySingle( "SELECT * FROM banking WHERE userid = ?", playerID )
		if recieverCheck then
			local senderCheck = exports.DENmysql:querySingle( "SELECT * FROM banking WHERE userid = ?", playerID2 )
			local totalNewBalance = (recieverCheck.balance + money)
			local takerNewBalance = (senderCheck.balance - money)	
			exports.DENmysql:exec( "UPDATE banking SET balance = ? WHERE userid = ?",totalNewBalance, playerID)
			exports.DENmysql:exec( "UPDATE banking SET balance = ? WHERE userid = ?",takerNewBalance, playerID2)
	
			createNewBankingTransAction ( playerID, "".. getPlayerName(source) .." sended you $".. money .."" )
			createNewBankingTransAction ( playerID2, "Sended $".. money .."" .. " to ".. getPlayerName(reciever) .."" )
	
			triggerClientEvent (source, "updateBalanceLabel", source, takerNewBalance)
	
			exports.DENhelp:createNewHelpMessageForPlayer(source, "You sended ".. getPlayerName(reciever) .." $".. money .."", 0,200,0)
			exports.DENhelp:createNewHelpMessageForPlayer(reciever, "".. getPlayerName(source) .." sended you $".. money .."", 0,200,0)
		end
	else
		exports.DENhelp:createNewHelpMessageForPlayer(source, "The player you want to send money dont have a bank account.", 200,0,0)
	end
end
addEventHandler ("sendPlayerMoney", root, sendPlayerMoney)

local atmHackSpam = {}

addEvent ("onPlayerHackedATM", true)
function onPlayerHackedATM ()
	if ( isElement ( source ) ) then
		if ( atmHackSpam[getPlayerSerial(source)] ) and ( getTickCount()-atmHackSpam[getPlayerSerial(source)] < 300000 ) then
			exports.DENhelp:createNewHelpMessageForPlayer(source, "You can only hack a ATM once every 5 minutes!", 255, 0, 0)
		else
			local reward = math.random(400,1200)
			local wanted = math.random(0.4,2.0)
			local passed = math.random(100,500)
			if ( passed > 200 ) then
				exports.DENhelp:createNewHelpMessageForPlayer(source, "Pro hacker! You hacked this ATM and stole $" .. reward .. "", 0, 225, 0)
				givePlayerMoney( source, reward )
				exports.server:givePlayerWantedPoints( source, wanted )
				atmHackSpam[getPlayerSerial(source)] = getTickCount()
			else
				exports.DENhelp:createNewHelpMessageForPlayer(source, "This ATM had a good anti virus, you failed hacking it!", 255, 0, 0)
				exports.server:givePlayerWantedPoints( source, wanted )
				atmHackSpam[getPlayerSerial(source)] = getTickCount()
			end
		end
	end
end
addEventHandler ("onPlayerHackedATM", root, onPlayerHackedATM)