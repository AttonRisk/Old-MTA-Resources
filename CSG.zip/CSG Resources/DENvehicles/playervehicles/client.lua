-- Personal vehicles system
vehicleManagementWindow = guiCreateWindow(479,233,265,481,"CSG ~ Vehicle Management",false)
vehicleManagementLabel1 = guiCreateLabel(93,21,83,14,"Your vehicles:",false,vehicleManagementWindow)
guiSetFont(vehicleManagementLabel1,"default-bold-small")
vehicleManagementGrid = guiCreateGridList(9,37,247,272,false,vehicleManagementWindow)
guiGridListSetSelectionMode(vehicleManagementGrid,0)
vehicleManagementLabel2 = guiCreateLabel(89,314,89,14,"Vehicle options:",false,vehicleManagementWindow)
guiSetFont(vehicleManagementLabel2,"default-bold-small")
vehicleManagementSpawn = guiCreateButton(9,335,122,29,"Spawn Vehicle",false,vehicleManagementWindow)
vehicleManagementHide = guiCreateButton(135,335,121,29,"Hide Vehicle",false,vehicleManagementWindow)
vehicleManagementSell = guiCreateButton(9,370,122,29,"Sell Vehicle",false,vehicleManagementWindow)
vehicleManagementRecover = guiCreateButton(135,370,121,29,"Recover Vehicle",false,vehicleManagementWindow)
vehicleManagementMark = guiCreateButton(9,405,122,29,"Mark Vehicle",false,vehicleManagementWindow)
vehicleManagementLock = guiCreateButton(135,405,121,29,"Lock Vehicle",false,vehicleManagementWindow)
vehicleManagementCloseScreen = guiCreateButton(9,446,247,25,"Close Vehicle Management",false,vehicleManagementWindow)
guiGridListSetSortingEnabled ( vehicleManagementGrid, false )

local column1 = guiGridListAddColumn( vehicleManagementGrid, " Vehicle:", 0.65 )
local column2 = guiGridListAddColumn( vehicleManagementGrid, "Health:", 0.20 )

local screenW,screenH=guiGetScreenSize()
local windowW,windowH=guiGetSize(vehicleManagementWindow,false)
local x,y = (screenW-windowW)/2,(screenH-windowH)/2
guiSetPosition(vehicleManagementWindow,x,y,false)

guiWindowSetMovable (vehicleManagementWindow, true)
guiWindowSetSizable (vehicleManagementWindow, false)
guiSetVisible (vehicleManagementWindow, false)

addEventHandler("onClientGUIClick", vehicleManagementCloseScreen, function() guiSetVisible(vehicleManagementWindow, false) showCursor(false) end, false)
addEventHandler("onClientGUIClick", vehicleManagementLock, function () triggerServerEvent( "lockVehicleButton" ,localPlayer ) end, false)

-- Warning window
vehicleWarningWindow = guiCreateWindow(596,381,253,120,"CSG ~ Vehicle Management",false)
vehicleWarningLabel1 = guiCreateLabel(8,25,237,16,"Warning:",false,vehicleWarningWindow)
guiLabelSetColor(vehicleWarningLabel1,225,0,0)
guiLabelSetHorizontalAlign(vehicleWarningLabel1,"center",false)
guiSetFont(vehicleWarningLabel1,"default-bold-small")
vehicleWarningLabel2 = guiCreateLabel(8,43,239,41,"Are you sure you want to sell this vehicle? \nYou get 95% of the original price back.",false,vehicleWarningWindow)
guiLabelSetColor(vehicleWarningLabel2,238	,154	,0)
guiLabelSetHorizontalAlign(vehicleWarningLabel2,"center",false)
guiSetFont(vehicleWarningLabel2,"default-bold-small")
vehicleWarningSellButton = guiCreateButton(9,86,117,25,"Sell vehicle",false,vehicleWarningWindow)
vehicleWarningCancelButton = guiCreateButton(130,86,114,25,"Cancel",false,vehicleWarningWindow)

addEventHandler("onClientGUIClick", vehicleWarningCancelButton, function() guiSetVisible(vehicleWarningWindow, false) end, false)
addEventHandler("onClientGUIClick", vehicleManagementSell, function()
local selectedVehicle = guiGridListGetItemText ( vehicleManagementGrid, guiGridListGetSelectedItem ( vehicleManagementGrid ), 1 )
	if selectedVehicle == "" or selectedVehicle == " " then
		guiSetVisible(vehicleWarningWindow, false)
		outputChatBox("You didn't select a vehicle!", 225 ,0 ,0)
	else
		guiSetVisible(vehicleWarningWindow, true) 
		guiBringToFront(vehicleWarningWindow) 
	end
end, false)

local screenW,screenH=guiGetScreenSize()
local windowW,windowH=guiGetSize(vehicleWarningWindow,false)
local x,y = (screenW-windowW)/2,(screenH-windowH)/2
guiSetPosition(vehicleWarningWindow,x,y,false)

guiWindowSetMovable (vehicleWarningWindow, true)
guiWindowSetSizable (vehicleWarningWindow, false)
guiSetVisible (vehicleWarningWindow, false)

addEvent("updateVehicleTable", true)
function updateVehicleTable ( theTable )
	if ( theTable ) then
		if theTable and #theTable > 0 then
			vehiclesTable = theTable
		else
			vehiclesTable = false
		end
	end
end
addEventHandler("updateVehicleTable", root, updateVehicleTable )

addEvent("insertVehicles", true)
function insertVehicles ( activeVehicleID, activeVehicle )
guiGridListClear ( vehicleManagementGrid )
	if vehiclesTable and #vehiclesTable > 0 then
		for i=1,#vehiclesTable do
			if ( activeVehicleID ) and ( activeVehicleID == vehiclesTable[i].uniqueid ) then
				local row = guiGridListAddRow ( vehicleManagementGrid )
				guiGridListSetItemText ( vehicleManagementGrid, row, column1, getVehicleNameFromModel ( tonumber ( vehiclesTable[i].vehicleid )) , false, false )
				guiGridListSetItemData ( vehicleManagementGrid, row, column1, vehiclesTable[i].uniqueid)
				guiGridListSetItemText ( vehicleManagementGrid, row, column2, "  "..math.floor(getElementHealth(activeVehicle)/ 10).."%", false, false )
				guiGridListSetItemColor ( vehicleManagementGrid, row, column1, 72, 61, 139 ) 
			else
				local row = guiGridListAddRow ( vehicleManagementGrid )
				guiGridListSetItemText ( vehicleManagementGrid, row, column1, getVehicleNameFromModel ( tonumber ( vehiclesTable[i].vehicleid )) , false, false )
				guiGridListSetItemData ( vehicleManagementGrid, row, column1, vehiclesTable[i].uniqueid)
				guiGridListSetItemText ( vehicleManagementGrid, row, column2, "  "..math.floor(vehiclesTable[i].vehiclehealth/ 10).."%", false, false )
			end
		end
	end
end
addEventHandler("insertVehicles", root, insertVehicles )

function showVehiclesGUI ()
	if ( getElementData ( localPlayer, "isPlayerLoggedin" ) ) then
		if guiGetVisible(vehicleManagementWindow) then
			guiSetVisible(vehicleManagementWindow, false)
			showCursor(false,false)
		else
			if vehiclesTable and #vehiclesTable > 0 then
				triggerServerEvent("loadActiveVehicle", localPlayer)
				guiSetVisible(vehicleManagementWindow,true)
				showCursor(true,true)
				guiSetInputMode("no_binds_when_editing")
			else
				triggerServerEvent("updateVehicleTable", localPlayer)
				triggerServerEvent("loadActiveVehicle", localPlayer)
				guiSetVisible(vehicleManagementWindow,true)
				showCursor(true,true)
				guiSetInputMode("no_binds_when_editing")
			end
		end
	end
end
bindKey ( "F3", "down", showVehiclesGUI ) 

function spawnVehicle ()
local selectedVehicle = guiGridListGetItemText ( vehicleManagementGrid, guiGridListGetSelectedItem ( vehicleManagementGrid ), 1 )
	if selectedVehicle == "" or selectedVehicle == " " then
		outputChatBox("You didn't select a vehicle!", 225 ,0 ,0)
	else
		local selectedRow, selectedColumn = guiGridListGetSelectedItem(vehicleManagementGrid)
		local uniqueID = guiGridListGetItemData ( vehicleManagementGrid, selectedRow, selectedColumn )
		triggerServerEvent ( "spawnTheVehicle", localPlayer, uniqueID)
	end
end
addEventHandler("onClientGUIClick", vehicleManagementSpawn, spawnVehicle, false)

function hideVehicle ()
local selectedVehicle = guiGridListGetItemText ( vehicleManagementGrid, guiGridListGetSelectedItem ( vehicleManagementGrid ), 1 )
	if selectedVehicle == "" or selectedVehicle == " " then
		outputChatBox("You didn't select a vehicle!", 225 ,0 ,0)
	else
		local selectedRow, selectedColumn = guiGridListGetSelectedItem(vehicleManagementGrid)
		local uniqueID = guiGridListGetItemData ( vehicleManagementGrid, selectedRow, selectedColumn )
		triggerServerEvent ( "hideTheVehicle", localPlayer, uniqueID)
	end
end
addEventHandler("onClientGUIClick", vehicleManagementHide, hideVehicle, false)

function markVehicle ()
local selectedVehicle = guiGridListGetItemText ( vehicleManagementGrid, guiGridListGetSelectedItem ( vehicleManagementGrid ), 1 )
	if selectedVehicle == "" or selectedVehicle == " " then
		outputChatBox("You didn't select a vehicle!", 225 ,0 ,0)
	else
		local selectedRow, selectedColumn = guiGridListGetSelectedItem(vehicleManagementGrid)
		local uniqueID = guiGridListGetItemData ( vehicleManagementGrid, selectedRow, selectedColumn )
		triggerServerEvent ( "markTheVehicles", localPlayer, uniqueID)
	end
end
addEventHandler("onClientGUIClick", vehicleManagementMark, markVehicle, false)

function sellVehicle ()
local selectedVehicle = guiGridListGetItemText ( vehicleManagementGrid, guiGridListGetSelectedItem ( vehicleManagementGrid ), 1 )
	if selectedVehicle == "" or selectedVehicle == " " then
		outputChatBox("You didn't select a vehicle!", 225 ,0 ,0)
	else
		local selectedRow, selectedColumn = guiGridListGetSelectedItem(vehicleManagementGrid)
		local uniqueID = guiGridListGetItemData ( vehicleManagementGrid, selectedRow, selectedColumn )
		triggerServerEvent ( "sellTheVehicle", localPlayer, uniqueID, selectedRow)
		guiSetVisible(vehicleWarningWindow, false)
	end
end
addEventHandler("onClientGUIClick", vehicleWarningSellButton, sellVehicle, false)

function recoverVehicle ()
local selectedVehicle = guiGridListGetItemText ( vehicleManagementGrid, guiGridListGetSelectedItem ( vehicleManagementGrid ), 1 )
	if selectedVehicle == "" or selectedVehicle == " " then
		outputChatBox("You didn't select a vehicle!", 225 ,0 ,0)
	else
		local selectedRow, selectedColumn = guiGridListGetSelectedItem(vehicleManagementGrid)
		local uniqueID = guiGridListGetItemData ( vehicleManagementGrid, selectedRow, selectedColumn )
		triggerServerEvent ( "recoverTheVehicle", localPlayer, uniqueID)
	end
end
addEventHandler("onClientGUIClick", vehicleManagementRecover, recoverVehicle, false)

function deleteRow (theRow)
	guiGridListRemoveRow ( vehicleManagementGrid, theRow )
end
addEvent("deleteRow", true)
addEventHandler("deleteRow", root, deleteRow )

addEvent("setRowColor", true)
function setRowColor (mode)
	local selectedRow, selectedColumn = guiGridListGetSelectedItem(vehicleManagementGrid)
	if ( mode ) then
		guiGridListSetItemColor ( vehicleManagementGrid, selectedRow, selectedColumn, 72, 61, 139 )
	else
		guiGridListSetItemColor ( vehicleManagementGrid, selectedRow, selectedColumn, 225, 225, 225 )
	end
end
addEventHandler("setRowColor", root, setRowColor )