local notLockableVehicles = { [594] = true, [606] = true, [607] = true, [611] = true, [584] = true, [608] = true,
[435] = true, [450] = true, [591] = true, [539] = true, [441] = true, [464] = true, [501] = true, [465] = true,
[564] = true, [472] = true, [473] = true, [493] = true, [595] = true, [484] = true, [430] = true, [453] = true,
[452] = true, [446] = true, [454] = true, [581] = true, [509] = true, [481] = true, [462] = true, [521] = true,
[463] = true, [510] = true, [522] = true,[461] = true, [448] = true, [468] = true, [586] = true, [425] = true, [520] = true, [523] = true }
-- On enter
addEventHandler ( "onVehicleStartEnter", root,
	function ( player, seat, jacked )
		if ( seat == 0 ) then
			if ( getElementData(source, "theFreeVehicleType") == "freeVehicle" ) and not ( getElementData( source, "isVehicleBikeVehicle" ) ) then
				if ( getTeamName( getPlayerTeam ( player ) ) == "Staff" ) then
					setVehicleLocked( source, false )
					-- Enter is allowed
				elseif ( jacked ) and ( isElement( getVehicleOccupant ( source, 0 ) ) ) and (getTeamName(getPlayerTeam(player)) == "SWAT") or (getTeamName(getPlayerTeam(player)) == "Military Forces") or (getTeamName(getPlayerTeam(player)) == "Police") or (getTeamName(getPlayerTeam(player)) == "Department of Defense") then
					if ( isElement( getVehicleOccupant ( source, 0 ) ) ) and ( getPlayerWantedLevel ( getVehicleOccupant ( source, 0 ) ) >= 1 ) or ( getPlayerTeam( getVehicleOccupant ( source, 0 ) ) == getPlayerTeam( player ) ) then
						setVehicleLocked( source, false )
						-- Enter is allowed
					else
						exports.DENhelp:createNewHelpMessageForPlayer(player, "You are not allowed to enter this vehicle!", 0, 200, 0)
						cancelEvent()
						return
					end
				else
					if ( getTeamName( getPlayerTeam ( player ) ) == "SWAT" ) and ( getElementData(source, "vehicleTeam") == "SWAT" ) or ( getElementData(source, "vehicleTeam") == "Police" ) then
						-- Enter is allowed
					elseif ( getTeamName( getPlayerTeam ( player ) ) == "Department of Defense" ) and ( getElementData(source, "vehicleTeam") == "Department of Defense" ) or ( getElementData(source, "vehicleTeam") == "Police" ) then
						-- Enter is allowed
					elseif ( getTeamName( getPlayerTeam ( player ) ) == "Military Forces" ) and ( getElementData(source, "vehicleTeam") == "Military Forces" ) or ( getElementData(source, "vehicleTeam") == "Police" ) then
						-- Enter is allowed
					elseif ( getTeamName( getPlayerTeam ( player ) ) == "Police" ) and ( getElementData(source, "vehicleTeam") == "Police" ) then
						-- Enter is allowed
					elseif ( getTeamName( getPlayerTeam ( player ) ) == "Criminals" ) and ( getElementData(source, "vehicleTeam") == "Criminals" ) then
						-- Enter is allowed
					elseif ( getTeamName( getPlayerTeam ( player ) ) == "Paramedics" ) and ( getElementData(source, "vehicleTeam") == "Paramedics" ) then
						-- Enter is allowed
					elseif ( getTeamName( getPlayerTeam ( player ) ) == "Civilian Workers" ) and ( getElementData(player, "Occupation" ) == getElementData(source, "vehicleOccupation") ) then
						-- Enter is allowed
					elseif ( getTeamName( getPlayerTeam ( player ) ) == "Firefighters" ) and ( getElementData(player, "Occupation" ) == getElementData(source, "vehicleOccupation") ) then
						-- Enter is allowed
					else
						exports.DENhelp:createNewHelpMessageForPlayer(player, "You are not allowed to enter this vehicle!", 0, 200, 0)
						cancelEvent()
						return
					end
				end
			elseif ( getElementData( source, "isVehicleBikeVehicle" ) ) then
				if ( getElementData( player, "wantedPoints" ) >= 10 ) then
					exports.DENhelp:createNewHelpMessageForPlayer(player, "You can't use this vehicle while wanted!", 225, 0, 0)
					cancelEvent()
					return
				end
			end	
		end
	 
		if ( notLockableVehicles[getElementModel(source)] ) and ( getElementData( source, "vehicleLocked" ) ) then
			if (getTeamName(getPlayerTeam(player)) == "Staff") then
				-- nothing 
			elseif (getTeamName(getPlayerTeam(player)) == "SWAT") or (getTeamName(getPlayerTeam(player)) == "Military Forces") or (getTeamName(getPlayerTeam(player)) == "Police") or (getTeamName(getPlayerTeam(player)) == "Department of Defense") then
				if isElement(getVehicleController ( source )) then
					local driverWantedLevel = getPlayerWantedLevel ( getVehicleController ( source ) )
					if driverWantedLevel > 0 then
						-- nothing
					else
						cancelEvent()
						exports.DENhelp:createNewHelpMessageForPlayer(player, "You cant enter this vehicle its locked!", 0, 200, 0)
					end
				else
					cancelEvent()
					exports.DENhelp:createNewHelpMessageForPlayer(player, "You cant enter this vehicle its locked!", 0, 200, 0)
				end
			else
				cancelEvent()
				exports.DENhelp:createNewHelpMessageForPlayer(player, "You cant enter this vehicle its locked!", 0, 200, 0)
			end
		elseif isVehicleLocked(source) then
			if (getTeamName(getPlayerTeam(player)) == "Staff") then
				setVehicleLocked(source, false)
			elseif (getTeamName(getPlayerTeam(player)) == "SWAT") or (getTeamName(getPlayerTeam(player)) == "Military Forces") or (getTeamName(getPlayerTeam(player)) == "Police") or ( getElementData(source, "vehicleTeam") == "Department of Defense" ) and getPlayerWantedLevel(jacked) > 0 then
				setVehicleLocked(source, false)
			else
				exports.DENhelp:createNewHelpMessageForPlayer(player, "You cant enter this vehicle its locked!", 0, 200, 0)
			end
		end
	end
)

addEventHandler("onPlayerVehicleExit", root,
function(vehicle, seat, jacked)
	if ( seat == 0 ) then 
		if ( isElement( jacked ) ) then
			return
		else
			setVehicleEngineState(vehicle, false)
		end
	end
end
)

addEventHandler("onPlayerVehicleEnter", root,
function(vehicle, seat, jacked)
	if ( seat == 0 ) then 
		if ( getElementData( vehicle, "vehicleType" ) == "playerVehicle" ) then
			local vehicleOwner = getElementData( vehicle, "vehicleOwner" )
			if ( vehicleOwner ) and ( isElement( vehicleOwner ) ) then
				if ( vehicleOwner == source ) then
					return
				else
					if ( getPlayerName(vehicleOwner) ) then
						exports.DENhelp:createNewHelpMessageForPlayer(source, "This vehicle belongs to ".. getPlayerName(vehicleOwner) .."!", 0, 200, 0)
					end
				end
			
			
			end
		end
	end
end
)