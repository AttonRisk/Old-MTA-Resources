local animalTable = false

-- Create the custom models for the animals
addEventHandler("onClientResourceStart", getResourceRootElement( getThisResource() ),
	function ()
		txd = engineLoadTXD ( "horse.txd" )
		engineImportTXD ( txd, 21 )
		dff = engineLoadDFF ( "horse.dff", 21 )
		engineReplaceModel ( dff, 21 )
	end
)

-- Even whenever a new animal is created or updated
addEvent( "onSyncPlayerAnimals", true )
addEventHandler( "onSyncPlayerAnimals", root,
	function ( theTable )
		animalTable = theTable
	end
)

-- Make the animals follow the owners
addEventHandler( "onClientPreRender", root,
	function ()
		if ( animalTable ) then
			for theOwner, k in pairs ( animalTable ) do
				local theAnimal = animalTable[theOwner][1]
				local thePlayer = animalTable[theOwner][3]
				if ( isElement( thePlayer ) ) and ( isElement( theAnimal ) ) and ( getElementHealth( theAnimal ) > 0 ) then
					local playerX, playerY, playerZ = getElementPosition ( thePlayer )
					local playerInt, playerDim = getElementInterior( thePlayer ), getElementDimension( thePlayer )
					local dogX, dogY, dogZ = getElementPosition ( theAnimal )
					local distance = getDistanceBetweenPoints2D ( playerX, playerY, dogX, dogY )
					local playerRotation = ( 360 - math.deg ( math.atan2 ( ( playerX - dogX ), ( playerY - dogY ) ) ) ) % 360
					
					setPedRotation ( theAnimal, playerRotation )
					setElementInterior( theAnimal, playerInt )
					
					if ( isPedInVehicle( thePlayer ) ) then setElementDimension( theAnimal, 1000 ) else setElementDimension( theAnimal, playerDim ) end
					
					if ( distance > 25 ) then
						setPedControlState ( theAnimal, "sprint", false )
						setPedControlState ( theAnimal, "walk", true )
						setPedControlState ( theAnimal, "forwards", true )
						setElementPosition ( theAnimal, playerX + 1, playerY + 1, playerZ )
					elseif ( distance > 6 ) then
						setPedControlState ( theAnimal, "sprint", true )
						setPedControlState ( theAnimal, "walk", true )
						setPedControlState ( theAnimal, "forwards", true )
					elseif ( distance > 1.5 ) then
						setPedControlState ( theAnimal, "sprint", false )
						setPedControlState ( theAnimal, "walk", true )
						setPedControlState ( theAnimal, "forwards", true )
					elseif ( distance < 1.5 ) then
						setPedControlState ( theAnimal, "sprint", false )
						setPedControlState ( theAnimal, "walk", false )
						setPedControlState ( theAnimal, "forwards", false )
					end
				end
			end
		end
	end
)

-- The nametags for the animals
addEventHandler( "onClientRender", root,
	function(  )
		if ( animalTable ) then
			for theOwner, k in pairs ( animalTable ) do
				local theAnimal = animalTable[theOwner][1]
				local theName   = animalTable[theOwner][2]
				local thePlayer = animalTable[theOwner][3]
				if ( isElement( thePlayer ) ) and ( isElement( theAnimal ) ) then
					local x, y, z = getElementPosition( theAnimal )
					local px, py, pz = getElementPosition( localPlayer )
					if ( getDistanceBetweenPoints3D( x, y, z, px, py, pz ) < 40 ) and ( getElementDimension( theAnimal ) == getElementDimension( localPlayer ) ) then
						local X, Y = getScreenFromWorldPosition( x, y, z )
						if ( X ) and ( Y ) then
							local health = getElementHealth( theAnimal )
							local lineLength = 56 * ( health / 100 )
							local health = getElementHealth( theAnimal )
							health = math.max(health, 0)/10
							local p = -30*(health^2)
							local r,g = math.max(math.min(p + 255*health + 255, 255), 0), math.max(math.min(p + 765*health, 255), 0)
							
							dxDrawText ( "Name: "..theName, X - 50, Y - 44, 60, 10, tocolor ( 255, 255, 255, 255 ), 0.8, "default-bold-small" )
							dxDrawText ( "Owner: "..getPlayerName( thePlayer ), X - 50, Y - 32, 60, 10, tocolor ( 255, 255, 255, 255 ), 0.8, "default-bold-small" )
							dxDrawRectangle( X - 30, Y - 20, 60, 10, tocolor( 0, 0, 0, 120), false )
							dxDrawRectangle( X - 28, Y - 18, lineLength, 6, tocolor( r, g, 0, 100 ), false )
						end
					end
				end
			end
		end
	end
)