-- Table with animals
local animalTable = {}

-- Create a animal for a player
function onCreatePlayerAnimal ( thePlayer, theName, theSkin )
	if not ( isElement( thePlayer ) ) then
		return false
	elseif not ( theName ) or ( theName:match( "^%s*$" ) ) or ( string.len( theName ) > 10 ) then
		return false
	elseif ( animalTable[thePlayer] ) and ( isElement( animalTable[thePlayer][1] ) ) then
		return false
	else
		if not ( theSkin ) then theSkin = 21 end
		local x, y, z = getElementPosition ( thePlayer )
		local thePed = createPed ( theSkin, x +1, y +1, z +1 )
		if ( thePed ) then
			animalTable[thePlayer] = { thePed, theName, thePlayer }
			-- table.insert( animalTable[thePlayer], { thePed, theName, thePlayer } )
			setElementData( thePed, "animalOwner", thePlayer )
			triggerClientEvent ( "onSyncPlayerAnimals", root, animalTable )
			return true
		else
			return false
		end
	end
end

-- Get the owner of a animal
function getAnimalOwner ( theAnimal )
	if ( isElement( theAnimal ) ) then
		local theOwner = getElementData( source, "animalOwner" )
		if ( theOwner ) then
			return theOwner
		else
			return false
		end
	else
		return false
	end
end

-- Get a animal from the owner
function getPlayerAnimal ( thePlayer )
	if ( isElement( thePlayer ) ) and ( animalTable[thePlayer] )then
		local theAnimal = animalTable[thePlayer][1]
		if ( theAnimal ) and ( isElement( theAnimal ) ) then
			return theAnimal
		else
			return false
		end
	else
		return false
	end
end

-- Set the animal to follow someone else
function setAnimalFollowing ( theAnimal, thePlayer )
	if ( isElement( theAnimal ) ) and ( isElement( thePlayer ) ) then
		local theOwner = getElementData( theAnimal, "animalOwner" )
		if ( theOwner ) then
			animalTable[theOwner][3] = thePlayer
			triggerClientEvent ( "onSyncPlayerAnimals", root, animalTable )
			return true
		else
			return false
		end
	else
		return false
	end
end

-- Make the animal follow the orginal owner again
function resetAnimalFollowing ( theAnimal )
	if ( isElement( theAnimal ) ) then
		local theOwner = getElementData( theAnimal, "animalOwner" )
		if ( theOwner ) then
			animalTable[theOwner][3] = theOwner
			triggerClientEvent ( "onSyncPlayerAnimals", root, animalTable )
			return true
		else
			return false
		end
	else
		return false
	end
end

-- Delete the animal whenever the player who owns the animal quits
addEventHandler( "onPlayerQuit", root,
	function ()
		if ( animalTable[source] ) and ( isElement( animalTable[source][1] ) ) then
			destroyElement( animalTable[source][1] )
			animalTable[source] = {}
			triggerClientEvent ( "onSyncPlayerAnimals", root, animalTable )
		end
	end
)

-- Delete the animal whenever the player who owns the animal dies
addEventHandler( "onPlayerWasted", root,
	function ()
		if ( animalTable[source] ) and ( isElement( animalTable[source][1] ) ) then
			destroyElement( animalTable[source][1] )
			animalTable[source] = {}
			triggerClientEvent ( "onSyncPlayerAnimals", root, animalTable )
		end
	end
)

-- When a player login make sure he got the latest animals synced
addEvent( "onServerPlayerLogin" )
addEventHandler( "onServerPlayerLogin", root,
	function ()
		if ( animalTable ) then
			triggerClientEvent ( source, "onSyncPlayerAnimals", source, animalTable )
		end
	end
)

-- When a animial dies delete it
addEventHandler( "onPedWasted", root,
	function ( theAmmo, theKiller )
		local theOwner = getElementData( source, "animalOwner" )
		if ( animalTable[theOwner] ) and ( isElement( animalTable[theOwner][1] ) ) and ( theOwner ) then				
			if ( isElement( theKiller ) ) and ( getElementType ( theKiller ) == "vehicle" ) and ( getVehicleController ( theKiller ) ) then
				theKiller = getVehicleController ( theKiller )
			end
				
			if ( theOwner == theKiller ) then
				exports.DENhelp:createNewHelpMessageForPlayer( theOwner, "You murdered your very own pet!", 225, 0, 0 )
			elseif ( theOwner ~= theKiller ) and ( isElement( theKiller ) ) then
				exports.DENhelp:createNewHelpMessageForPlayer( theOwner, getPlayerName( theKiller ).. " murdered your pet!", 225, 0, 0 )
			else
				exports.DENhelp:createNewHelpMessageForPlayer( theOwner, "Your pet just died due his injuries!", 225, 0, 0 )
			end
			
			destroyElement( animalTable[theOwner][1] )
			animalTable[theOwner] = {}
			triggerClientEvent ( "onSyncPlayerAnimals", root, animalTable )
		end
	end
)

-- Remove the dog on a team or job change
addEvent( "onPlayerJobChange" )
addEvent( "onPlayerTeamChange" )
function onRemoveDogOnChange ()
	if ( animalTable[source] ) and ( isElement( animalTable[source][1] ) ) then
		destroyElement( animalTable[source][1] )
		animalTable[source] = {}
		triggerClientEvent ( "onSyncPlayerAnimals", root, animalTable )
	end
end
addEventHandler( "onPlayerJobChange", root, onRemoveDogOnChange )
addEventHandler( "onPlayerTeamChange", root, onRemoveDogOnChange )