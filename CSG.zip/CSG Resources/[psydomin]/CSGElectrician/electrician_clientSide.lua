﻿----------Start-- trigger this on take job
function startElectrician ()
	--if (exports.server:getPlayerOccupation() ~= "Electrician") then
		triggerWork(localPlayer)
	--end
end
-----------Arrest/kill handlers---------------------
function onPlayerDead ()
	if source == localPlayer and poleWindow and (guiGetVisible(poleWindow) == true) then
		guiSetVisible(poleWindow, false)
		showCursor(false)
		if t1 then
			killTimer(t1)
		else if t2 then
			killTimer(t2)
		end
		end
	end
end
addEventHandler("onClientPlayerWasted", root, onPlayerDead)

addEvent("onClientPlayerJobChange")
addEventHandler( "onClientPlayerJobChange", root,
	function ()
		if source == localPlayer and (guiGetVisible(poleWindow) == true) then
			guiSetVisible(poleWindow, false)
			showCursor(false)
			if t1 then
				killTimer(t1)
			else if t2 then
				killTimer(t2)
			end
			end
		end
	end
)

addEvent( "onClientPlayerArrested" )
addEventHandler( "onClientPlayerArrested", root,
	function ( theCop )
		if source == localPlayer and (guiGetVisible(poleWindow) == true) then
			guiSetVisible(poleWindow, false)
			showCursor(false)
			if t1 then
				killTimer(t1)
			else if t2 then
				killTimer(t2)
			end
			end
		end
	end
)
---------------------------------------------------------------------------------------------
function payment ()
if mForDistx and mForDisty and mForDistz and wx and wy and wz then
local distance = getDistanceBetweenPoints3D(wx, wy, wz, mForDistx, mForDisty, mForDistz)
setElementData(localPlayer, "Electrician:distance", distance)
end
end

function triggerWork(thePlayer)
if thePlayer == localPlayer then
	if (exports.server:getPlayChatZone() == "SF") then --and exports.server:getPlayerOccupation() == "Electrician" then
		local situation = math.random (1, #elecMarkersSF) 
		wx, wy, wz, isLight = elecMarkersSF[situation][1], elecMarkersSF[situation][2],elecMarkersSF[situation][3], elecMarkersSF[situation][4]
		if wx and wy and wz then
			payment()
			mForDistx, mForDisty, mForDistz = wx, wy, wz
			workMarker = createMarker(wx, wy, wz-1 , "Cylinder", 2, 255, 255, 0, 255, localPlayer)
			workBlip = createBlip(wx, wy, wz, blipType, 2, 255, 0, 0, 255, -1, localPlayer)	
			addEventHandler("onClientMarkerHit", workMarker, showPoleGUI)
			addEventHandler("onClientMarkerLeave", workMarker, onPlayerDead)
		end 
	elseif (exports.server:getPlayChatZone() == "LS") then --and exports.server:getPlayerOccupation() == "Electrician" then
		local situation = math.random (1, #elecMarkersLS) 
		wx, wy, wz, isLight = elecMarkersLS[situation][1], elecMarkersLS[situation][2],elecMarkersLS[situation][3], elecMarkersLS[situation][4]
		if wx and wy and wz then
			payment()
			mForDistx, mForDisty, mForDistz = wx, wy, wz
			workMarker = createMarker(wx, wy, wz-1 , "Cylinder", 2, 255, 255, 0, 255, localPlayer)
			workBlip = createBlip(wx, wy, wz, blipType, 2, 255, 0, 0, 255, -1, localPlayer)	
			addEventHandler("onClientMarkerHit", workMarker, showPoleGUI)
			addEventHandler("onClientMarkerLeave", workMarker, onPlayerDead)
		end
	end
end
end
addEvent("elec:startWork", true)
addEventHandler("elec:startWork", getRootElement(), triggerWork)
--------------Poles
function showPoleGUI(hitElement)
local vehicle = getPedOccupiedVehicle(localPlayer)
if hitElement == localPlayer then
	if not vehicle and not poleWindow then
		local screenWidth, screenHeight = guiGetScreenSize()
		local Width, Height = 637, 221
		local X = ( screenWidth/2 ) - ( Width/2 )
		local Y = ( screenHeight/2 ) - ( Height/2 )
		poleWindow = guiCreateWindow(X, Y, Width, Height, "Utility pole", false)
		checkButton = guiCreateButton(38, 40, 151, 42, "Check pole state", false, poleWindow)
		repairButton = guiCreateButton(475,50,117,45,"Repair pole",false,poleWindow)
		okButton = guiCreateButton(475,50,117,45,"Ok",false,poleWindow)
		guiSetVisible(okButton, false)
		cancelButton= guiCreateButton(475, 100, 117, 45, "Leave", false, poleWindow)
		stateLabel = guiCreateLabel(45,98,300,16,"Pole state:",false,poleWindow)
		detailsLabel = guiCreateLabel(44,117,300,16,"Details:",false,poleWindow)
		repairProgressBar = guiCreateProgressBar(41,156,555,59,false,poleWindow)
		showCursor(true)
		opt1 = guiCreateRadioButton(285,51,165,18,"Repair broken wire",false,poleWindow)
		opt2 = guiCreateRadioButton(285,82,177,18,"Replace burned transformer",false,poleWindow)
		opt3 = guiCreateRadioButton(285,117,177,18,"Replace defective fuse",false,poleWindow)
		if isLight and isLight == 1 then
			guiSetText(poleWindow, "Light pole")
			guiSetText(opt1, "Repair defective lamp")
		end
		guiSetEnabled(repairButton, false)
		guiSetEnabled(opt1, false)
		guiSetEnabled(opt2, false)
		guiSetEnabled(opt3, false)
		guiWindowSetSizable(poleWindow, false) 
		----------Triggers
		addEventHandler("onClientGUIClick", okButton, ok, false)
		addEventHandler("onClientGUIClick", repairButton, timer2, false)
		addEventHandler("onClientGUIClick", checkButton, timer1, false)
		addEventHandler("onClientGUIClick", cancelButton, closeGUI2, false)
	elseif not vehicle and poleWindow then
		if isLight and isLight == 1 then
			guiSetText(poleWindow, "Light pole")
			guiSetText(opt1, "Repair defective lamp")
		else
			guiSetText(poleWindow, "Utility pole")
			guiSetText(opt1, "Repair broken wire")
		end
		guiSetVisible(poleWindow, true) 
		showCursor(true)
		guiSetEnabled(checkButton, true)
		guiSetEnabled(repairButton, false)
		guiSetEnabled(opt1, false)
		guiSetEnabled(opt2, false)
		guiSetEnabled(opt3, false)
		guiSetText(stateLabel, "Pole state:") 
		guiSetText(detailsLabel, "Details:")
		guiProgressBarSetProgress(repairProgressBar, 0)
		guiSetVisible(repairButton, true)
		guiSetVisible(okButton, false)
		guiSetEnabled(cancelButton, true)
	end
	end
end	
function ok ()
showCursor(false)
guiSetVisible(poleWindow, false)
	if workMarker and isElement(workMarker) and isElement(workBlip) then
		destroyElement(workMarker)
		destroyElement(workBlip)
		triggerWork() 
	end
end

function closeGUI2 ()
	guiSetVisible(poleWindow, false)
	showCursor(false)
end
function timer1 ()
	setPedAnimation(localPlayer, "ped", "bomber", -1, true, false)
	t1 = setTimer(pBar1, 200, 0)
	guiProgressBarSetProgress(repairProgressBar, 0)
	guiSetEnabled(cancelButton, false)
	guiSetEnabled(checkButton, false)
end
function pBar1 ()
progress1 = guiProgressBarGetProgress(repairProgressBar)
guiProgressBarSetProgress(repairProgressBar, progress1 + 2)
	if progress1 == 100 then
		setPedAnimation(localPlayer)
		killTimer(t1)
		t1 = nil
		guiSetEnabled(opt1, true)
		guiSetEnabled(opt2, true)
		guiSetEnabled(opt3, true)
		guiSetEnabled(repairButton, true)
		guiSetEnabled(cancelButton, true)
		local damagePole = math.random(1,4)
		if (damagePole == 1) then
			guiSetText(stateLabel, "Pole state: Working properly.") 
			guiSetText(detailsLabel, "Details: No action required.")
			guiSetVisible(repairButton, false)
			guiSetEnabled(opt1, false)
			guiSetEnabled(opt2, false)
			guiSetEnabled(opt3, false)
			guiSetEnabled(cancelButton, false)
			guiSetVisible(okButton, true)
		elseif (damagePole == 2) then
			if isLight and isLight ~= 1 then
			guiSetText(stateLabel, "Pole state: Needs to be fixed.") 
			guiSetText(detailsLabel, "Details: There are problems with the wires.")
			else
			guiSetText(stateLabel, "Pole state: Needs to be fixed.") 
			guiSetText(detailsLabel, "Details: There is a defective lamp.")
			end
		elseif (damagePole == 3) then
			guiSetText(stateLabel, "Pole state: Needs to be fixed.") 
			guiSetText(detailsLabel, "Details: There is a burned transformer.")
		elseif (damagePole == 4) then
			guiSetText(stateLabel, "Pole state: Needs to be fixed.") 
			guiSetText(detailsLabel, "Details: There is a defective fuse.")
		end
	end
end
function timer2 ()
	setPedAnimation(localPlayer, "ped", "bomber", -1, true, false)
	t2 = setTimer(pBar2, 500, 0)
	guiProgressBarSetProgress(repairProgressBar, 0)
	guiSetEnabled(cancelButton, false)
	guiSetEnabled(repairButton, false)
	guiSetEnabled(opt1, false)
	guiSetEnabled(opt2, false)
	guiSetEnabled(opt3, false)
end
function pBar2 ()
	progress2 = guiProgressBarGetProgress(repairProgressBar)
	guiProgressBarSetProgress(repairProgressBar, progress2 + 2)
	if progress2 == 100 then
		setPedAnimation(getLocalPlayer())
		guiSetEnabled(cancelButton, true)
		killTimer(t2)
		t2 = nil
		if guiGetText(detailsLabel) == "Details: There are problems with the wires." or guiGetText(detailsLabel) == "Details: There is a defective lamp." and guiRadioButtonGetSelected(opt1) then
			triggerServerEvent("elec:payPlayer", localPlayer)
			guiSetVisible(poleWindow, false)
			showCursor(false)
			if workMarker and isElement(workMarker) and isElement(workBlip) then
				destroyElement(workMarker)
				destroyElement(workBlip)
				triggerWork()
			end
		elseif guiGetText(detailsLabel) == "Details: There is a burned transformer." and guiRadioButtonGetSelected(opt2) then
			triggerServerEvent("elec:payPlayer", localPlayer)
			guiSetVisible(poleWindow, false)
			showCursor(false)
			if workMarker and isElement(workMarker) and isElement(workBlip) then
				destroyElement(workMarker)
				destroyElement(workBlip)
				triggerWork()
			end
		elseif guiGetText(detailsLabel) == "Details: There is a defective fuse." and guiRadioButtonGetSelected(opt3) then
			triggerServerEvent("elec:payPlayer", localPlayer)
			guiSetVisible(poleWindow, false)
			showCursor(false)
			if workMarker and isElement(workMarker) and isElement(workBlip) then
				destroyElement(workMarker)
				destroyElement(workBlip)
				triggerWork()
			end
		else outputChatBox("You haven't fixed the pole!",231,0,0)
			guiSetVisible(poleWindow, false)
			showCursor(false)
			if workMarker and isElement(workMarker) and isElement(workBlip) then
				destroyElement(workMarker)
				destroyElement(workBlip)
				triggerWork()
			end
		end
	end
end
-------Testing
addCommandHandler("starttesting", startElectrician)