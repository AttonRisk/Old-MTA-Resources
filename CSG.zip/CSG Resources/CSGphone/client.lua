theFont = "Tahoma bold"
theFontSize = 1.3

exports.DENsettings:addPlayerSetting('phoneBackground', '1')

sW, sH = guiGetScreenSize()
relativeCaseWidth, relativeCaseHeight = 0.1777777777777778, 0.5566666666666667
caseWidth, caseHeight = relativeCaseWidth*1.34*sW, relativeCaseHeight*1.2*sH
caseX, caseY = math.floor(sW-caseWidth-10), math.floor(sH-caseHeight-10)

BGnumber = exports.DENsettings:getPlayerSetting('phoneBackground')

BGWidth, BGHeight = 0.8385609575*caseWidth, 0.6234012832642*caseHeight
BGX = (((30)/341.54000854492)*caseWidth)+caseX
BGY = (((122)/601.20001220703)*caseHeight)+caseY

homeX = caseX+(0.405*caseWidth)
homeY = caseY+(0.863*caseHeight)
homeWidth = 0.1844*caseWidth
homeHeight = 0.097*caseHeight

apps = { 
-- dock
{ nil, (0.02*BGWidth)+BGX, (0.85*BGHeight)+BGY, (0.2195)*BGWidth,(0.141)*BGHeight, "Phone Alt", false, false, false, false, "Phone" },
{ nil, (0.27*BGWidth)+BGX, (0.85*BGHeight)+BGY, (0.2195)*BGWidth,(0.141)*BGHeight, "Messages", false, false, false, false, "Messages" },
{ nil, (0.52*BGWidth)+BGX, (0.85*BGHeight)+BGY, (0.2195)*BGWidth,(0.141)*BGHeight, "iPod Alt", false, false, false, false, "iPod" },
{ nil, (0.77*BGWidth)+BGX, (0.85*BGHeight)+BGY, (0.2195)*BGWidth,(0.141)*BGHeight, "Settings", false, false, false, false, "Settings" },
-- First row
{ nil, (0.02*BGWidth)+BGX, (0.03*BGHeight)+BGY, (0.2195)*BGWidth,(0.141)*BGHeight, "Contacts Alt", false, false, false, false, "Contacts" },
{ nil, (0.27*BGWidth)+BGX, (0.03*BGHeight)+BGY, (0.2195)*BGWidth,(0.141)*BGHeight, "Clock", false, false, false, false, "Clock" },
{ nil, (0.52*BGWidth)+BGX, (0.03*BGHeight)+BGY, (0.2195)*BGWidth,(0.141)*BGHeight, "Notes", false, false, false, false, "Notes" },
{ nil, (0.77*BGWidth)+BGX, (0.03*BGHeight)+BGY, (0.2195)*BGWidth,(0.141)*BGHeight, "Weapons", false, false, false, false, "Weapons" },
-- Second row
{ nil, (0.02*BGWidth)+BGX, (0.23*BGHeight)+BGY, (0.2195)*BGWidth,(0.141)*BGHeight, "PocketMoney", false, false, false, false, "Money" },
{ nil, (0.27*BGWidth)+BGX, (0.23*BGHeight)+BGY, (0.2195)*BGWidth,(0.141)*BGHeight, "Maps", false, false, false, false, "Maps" },
{ nil, (0.52*BGWidth)+BGX, (0.23*BGHeight)+BGY, (0.2195)*BGWidth,(0.141)*BGHeight, "Minesweep", false, false, false, false, "Minesweeper", 2 },
{ nil, (0.77*BGWidth)+BGX, (0.23*BGHeight)+BGY, (0.2195)*BGWidth,(0.141)*BGHeight, "Puzzle", false, false, false, false, "Slide Puzzle", 2 }
}

movementSpeed = sH/(sH*0.075)
phoneImages = {}
appImages = {}
phoneVisible = false
fading = false

function createApps()

	for i,v in ipairs(apps) do
	
		v[1] = guiCreateStaticImage(v[2], sH+(v[3]-caseY), v[4], v[5], "icons\\" .. v[6] .. ".png", false ) 
		table.insert ( phoneImages, v[1] )
		guiSetProperty ( v[1], "AlwaysOnTop", "True" )
	end	

end

function createCase()

	local caseImage = guiCreateStaticImage(caseX, sH, caseWidth, caseHeight, "csgiphone.png", false )
	table.insert ( phoneImages, caseImage )
	local bgPNG = "background" .. BGnumber .. ".png"
	local BGImage = guiCreateStaticImage(BGX, sH+(BGY-caseY), BGWidth, BGHeight, "backgrounds\\" .. tostring(bgPNG), false )
	table.insert ( phoneImages, BGImage )
	local homeLabel = guiCreateLabel ( homeX, sH+(homeY-caseY), homeWidth, homeHeight, "", false )
	guiSetProperty ( homeLabel, "AlwaysOnTop", "True" )
	guiBringToFront(homeLabel)
	table.insert ( phoneImages, homeLabel )
	
end

function snapImages()

	guiSetPosition ( phoneImages[1], caseX, caseY, false )
	guiSetPosition ( phoneImages[2], BGX, BGY, false )

	for i, app in ipairs(apps) do

		if isElement(app[1])then

			guiSetPosition ( app[1], app[2], app[3], false )
				
		end

	end	

end

function togglePhone()

	if phoneVisible == false then
		if ( exports.server:isPlayerLoggedIn( localPlayer ) ) then
			if not fading then
			
				createCase()
				createApps()

				slide('up')
				showCursor(true)
				guiSetInputMode("no_binds_when_editing")
				
			end
		end
		
	elseif isElement(phoneImages[1]) then
	
		if not fading then

			slide('down')
			showCursor(false)
			for i, app in ipairs(apps) do
	
				if app[7] == true then
		
					app[9]()

				end

			 end	
			 closeApps()
		end	
		
	end
end

function hidePhone()

	for i, image in ipairs(phoneImages) do
		destroyElement(image)
	end
	for i, app in ipairs(apps) do
	
		if app[7] == true then
		
			app[9]()

		end

	end	
	phoneImages = {}
	appImages = {}
	fading = false
	phoneVisible = false

end

bindKey ( "n", "down", togglePhone )

function increaseHeight ()

	if isElement(phoneImages[1]) then

		local x,y = guiGetPosition(phoneImages[1],false)
		if (y - caseY) >= 10 then
			for i, image in ipairs(phoneImages) do
				local x,y = guiGetPosition(image,false)
				guiSetPosition ( image, x, math.floor(y-movementSpeed), false )
			end
		
		else
		
			snapImages()
			removeEventHandler ( 'onClientRender', root, increaseHeight )
			fading = false
			phoneVisible = true
			addEventHandler ( "onClientMouseEnter", root, onMouseEnter )
			addEventHandler ( "onClientMouseLeave", root, onMouseLeave )
			addEventHandler ( "onClientGUIClick", root, onMouseClick )
		
		end
		
	end	

end

function decreaseHeight ()

	if isElement(phoneImages[1]) then
	
		local x,y = guiGetPosition(phoneImages[1],false)
		
		if (sH - y) >= 10 then
	
			for i, image in ipairs(phoneImages) do
				local x,y = guiGetPosition(image,false)
				guiSetPosition ( image, x, math.floor(y+movementSpeed), false )
			end
		
		else

			removeEventHandler ( 'onClientRender', root, decreaseHeight )
			hidePhone()
		
		end
	end

end

function slide(direction)
fading = true

	if direction == 'up' then

		addEventHandler ( 'onClientRender', root, increaseHeight )
	
	else
	
		for i,v in ipairs(apps) do
		
			if isElement(v[1]) then
			
				guiSetPosition ( v[1], v[2], v[3], false )
				guiSetSize ( v[1], v[4], v[5], false )
				
			end

		end		
		
		removeEventHandler ( "onClientMouseEnter", root, onMouseEnter )
		removeEventHandler ( "onClientMouseLeave", root, onMouseLeave )
		for i, app in ipairs(apps) do
		
			if app[10] then
				removeEventHandler ( 'onClientRender', root, drawPopups )
				app[10] = false
			end
		end
			
		removeEventHandler ( "onClientGUIClick", root, onMouseClick )
	
		addEventHandler ( 'onClientRender', root, decreaseHeight )
		
	end

end

function onMouseEnter ()
		
	for i, v in ipairs(apps) do
			
		if v[1] == source then
				
			local image, X, Y, width, height = v[1], v[2], v[3], v[4], v[5]
			guiSetSize ( image, width+10, height+10, false )
			guiSetPosition ( image, X-5, Y-5, false )	
			if not v[10] then
				addEventHandler ( 'onClientRender', root, drawPopups )
				v[10] = true
			end
			
			
		end

	end

end

function drawPopups ()

	for i=1, #apps do
	
		if apps[i][10] == true then
		
			local image, X, Y, width, height = apps[i][1], apps[i][2], apps[i][3], apps[i][4], apps[i][5]
			local nWidth = 1.5
			if apps[i][12] then nWidth = apps[i][12] end 
			dxDrawRectangle ( X-(width*0.25),Y-(0.7*height), width*nWidth, height*0.4, tocolor ( 0, 0, 0, 220 ), true )
			dxDrawText ( apps[i][11], X-(width*0.25), Y-(0.7*height), X+(width*nWidth), (Y-(0.7*height))+(height*0.4), tocolor ( 255, 255, 255, 255 ), theFontSize, theFont, "center", "center", false, false, true )
			
		end

	end

end

function onMouseLeave ()
		
	for i, v in ipairs(apps) do
			
		if v[1] == source then
			local image, X, Y, width, height = v[1], v[2], v[3], v[4], v[5]
			
			guiSetSize ( image, width, height, false )
			guiSetPosition ( image, X, Y, false )			
			if v[10] then
				removeEventHandler ( 'onClientRender', root, drawPopups )
				v[10] = false
			end
			
		end

	end
	
end

function onMouseClick ()
appOpen = false

	for i=1, #apps do
	
		if apps[i][1] == source then

			if apps[i][8] then openApp(apps[i][11]) end
			
		end
		
		if source == phoneImages[3] then
	
			if apps[i][7] == true then
				appOpen = true
				apps[i][9]()
			end	
		end	
	guiBringToFront(apps[i][1])
	end
	
	if source == phoneImages[3] then
		closeApps()
		if not appOpen then

			if isElement(phoneImages[1]) then
	
				if not fading then

					slide('down')
					showCursor(false)
			
				end	
		
			end

		end
		
	end	

end

-- We moeten een systeem bedenken waarbij we makkelijk apps kunnen adden
-- is er al

function openApp(name)-- hier moet de achtergrond anders worden en de apps gehide worden ofzo
	
	guiStaticImageLoadImage ( phoneImages[2], "backgrounds\\appbackground.png" ) -- zo zou het goed moeten zijn, lol ik let wel op :D
	for i, app in ipairs(apps) do
		if isElement(app[1]) then -- [1] = settings bv? nee je heb een table per app, [1] in die tables is de GUI element
		-- [2] - [4] zijn de posities en grootes, en dan [6] is de naam bijv Settings, iPod Alt etc.
		
			guiSetVisible ( app[1], false )

		end
		
		if app[11] == name then
			
			app[8]()
		
		end	
		
		if app[10] then
			removeEventHandler ( 'onClientRender', root, drawPopups )
			app[10] = false
		end

	end

end

function closeApps()

local bgPNG = "background" .. BGnumber .. ".png"
guiStaticImageLoadImage ( phoneImages[2], "backgrounds\\" .. tostring(bgPNG) ) -- zo zou het goed moeten zijn, lol ik let wel op :D
	for i, app in ipairs(apps) do
		if isElement(app[1]) then -- [1] = settings bv? nee je heb een table per app, [1] in die tables is de GUI element
		-- [2] - [4] zijn de posities en grootes, en dan [6] is de naam bijv Settings, iPod Alt etc.
		
			guiSetVisible ( app[1],true )

		end
	end	
end
