local settingsTable
local phoneComboBox
local settingsGUI = {}

addEvent( "onSetPlayerSettings" )

addEventHandler ( 'onClientResourceStart', getResourceRootElement(getThisResource()), 
function () 
	settingsTable = {
	-- Row 1
	{nil, "blur", "false", BGX+(0.05*BGWidth),BGY+(0.05*BGHeight),110,20,"Blur"},
	{nil, "heathaze", "false", BGX+(0.05*BGWidth)+110+(0.01*BGWidth),BGY+(0.05*BGHeight),110,20,"Heat Haze"},
	-- Row 2
	{nil, "clouds", "true", BGX+(0.05*BGWidth),BGY+(0.1*BGHeight),110,20,"Clouds"},
	{nil, "fpsmeter", "false", BGX+(0.05*BGWidth)+110+(0.01*BGWidth),BGY+(0.1*BGHeight),110,20,"FPS Meter"},
	-- Row 3
	{nil, "chatbox", "true", BGX+(0.05*BGWidth),BGY+(0.15*BGHeight),110,20,"Chat Box"},
	{nil, "sms", "true", BGX+(0.05*BGWidth)+110+(0.01*BGWidth),BGY+(0.15*BGHeight),110,20,"SMS Output"},
	-- Row 4
	{nil, "speedmeter", "true", BGX+(0.05*BGWidth),BGY+(0.2*BGHeight),110,20,"Speedometer"},
	{nil, "damagemeter", "true", BGX+(0.05*BGWidth)+110+(0.01*BGWidth),BGY+(0.2*BGHeight),110,20,"Damage Meter"},	
	-- Row 5
	{nil, "fuelmeter", "true", BGX+(0.05*BGWidth),BGY+(0.25*BGHeight),110,20,"Fuel Meter"},
	{nil, "shaders", "false", BGX+(0.05*BGWidth)+110+(0.01*BGWidth),BGY+(0.25*BGHeight),110,20,"Toggle shaders"},
	}
	for i=1,#settingsTable do
		exports.DENsettings:addPlayerSetting(settingsTable[i][2], settingsTable[i][3])
	end
	
	exports.DENsettings:addPlayerSetting("phoneBackground", "1")
	
end
)

function onOpenSettingsApp ( ) 
	apps[4][7] = true
	
	settingsGUI[1] = guiCreateEdit(BGX+(0.05*BGWidth),BGY+(0.45*BGHeight), 0.90*BGWidth, 0.056704228520393*BGHeight,"New email",false) -- Email
	settingsGUI[2] = guiCreateEdit(BGX+(0.05*BGWidth),BGY+(0.52*BGHeight), 0.90*BGWidth, 0.056704228520393*BGHeight,"Current password",false) -- Current password
	settingsGUI[3] = guiCreateButton(BGX+(0.05*BGWidth),BGY+(0.59*BGHeight), 0.90*BGWidth, 0.056704228520393*BGHeight,"Change email",false) -- Change mail button
	
	settingsGUI[4] = guiCreateEdit(BGX+(0.05*BGWidth),BGY+(0.70*BGHeight), 0.90*BGWidth, 0.056704228520393*BGHeight,"New password",false) -- New pass
	settingsGUI[5] = guiCreateEdit(BGX+(0.05*BGWidth),BGY+(0.77*BGHeight), 0.90*BGWidth, 0.056704228520393*BGHeight,"Confirm new password",false) -- New pass confirm
	settingsGUI[6] = guiCreateEdit(BGX+(0.05*BGWidth),BGY+(0.84*BGHeight), 0.90*BGWidth, 0.056704228520393*BGHeight,"Current password",false) -- Old pass
	settingsGUI[7] = guiCreateButton(BGX+(0.05*BGWidth),BGY+(0.91*BGHeight), 0.90*BGWidth, 0.056704228520393*BGHeight,"Change password",false) -- Change pass button
	
	for i=1,#settingsGUI do
		guiSetProperty( settingsGUI[i], "AlwaysOnTop", "True" )
		guiSetVisible(settingsGUI[i],true)
	end	
	
	for i=1,#settingsTable do
		local state = exports.DENsettings:getPlayerSetting(settingsTable[i][2])
		settingsTable[i][1] = guiCreateCheckBox ( settingsTable[i][4], settingsTable[i][5], settingsTable[i][6], settingsTable[i][7], settingsTable[i][8], state, false )
		guiSetProperty ( settingsTable[i][1], "AlwaysOnTop", "True" )
	end
	
	phoneComboBox = guiCreateComboBox ( BGX+(0.05*BGWidth),BGY+(0.35*BGHeight), 0.90*BGWidth, 0.4*BGHeight, "Phone Background",false)
	
	guiSetProperty ( phoneComboBox, "AlwaysOnTop", "True" )
	for i=1,8 do
		guiComboBoxAddItem ( phoneComboBox, 'Background ' .. tostring(i))
	end
	
	exports.DENsettings:getPlayerSetting("phoneBackground" )
	addEventHandler( "onClientGUIClick", root, onSettingsClick )
	addEventHandler( "onClientGUIBlur", root, onSettingsComboAccept ) 
	
	addEventHandler( "onClientGUIClick", settingsGUI[3], onChangePlayerEmail )
	addEventHandler( "onClientGUIClick", settingsGUI[7], onChangePlayerPassword )
end 
apps[4][8] = onOpenSettingsApp


function onCloseSettingsApp ()

	for i=1,#settingsGUI do
		guiSetProperty( settingsGUI[i], "AlwaysOnTop", "True" )
		guiSetVisible(settingsGUI[i],false)
	end	

	removeEventHandler( "onClientGUIClick", root, onSettingsClick )
	removeEventHandler( "onClientGUIBlur", root, onSettingsComboAccept ) 
	removeEventHandler( "onClientGUIClick", settingsGUI[3], onChangePlayerEmail )
	
	for i, element in ipairs(settingsTable) do
	
		if isElement(element[1]) then
		
			destroyElement(element[1])
			
		end

	end
	
	destroyElement(phoneComboBox)
	
	apps[4][7] = false

end

function onSettingsClick()

	if ( source == settingsGUI[1] ) or ( source == settingsGUI[2] ) or ( source == settingsGUI[4] ) or ( source == settingsGUI[5] ) or ( source == settingsGUI[6] ) then
		guiSetText( source, "")
		if ( source == settingsGUI[2] ) or ( source == settingsGUI[4] ) or ( source == settingsGUI[5] ) or ( source == settingsGUI[6] ) then
			guiEditSetMasked( source, true)
		end
	end

	local setting
	local element

	for i=1,#settingsTable do

		if ( source == settingsTable[i][1] ) then
		
			setting = settingsTable[i][2]
			element = settingsTable[i][1]
			event = settingsTable[i][9]
		
		end
		
	end
	
	if setting then
		exports.DENsettings:setPlayerSetting(setting, tostring(guiCheckBoxGetSelected( source )) )
	end
end

function onSettingsComboAccept()
	onSetEditDataBack ()
	if source == phoneComboBox then
		local selectedBG = guiComboBoxGetItemText(phoneComboBox,guiComboBoxGetSelected(phoneComboBox)) 
		local selectedBG = string.sub(selectedBG, 12 )
		if ( selectedBG ~= "round" ) then
			BGnumber = selectedBG
			exports.DENsettings:setPlayerSetting("phoneBackground", selectedBG )
		end
	end
end

function onSetEditDataBack ()
	if ( string.match(guiGetText(source), "^%s*$") ) then
		if ( source == settingsGUI[1] ) then
			guiSetText( source, "New email")
		elseif ( source == settingsGUI[2] ) then
			guiEditSetMasked( source, false)
			guiSetText( source, "Current password")
		elseif ( source == settingsGUI[4] ) then
			guiEditSetMasked( source, false)
			guiSetText( source, "New password")
		elseif ( source == settingsGUI[5] ) then
			guiEditSetMasked( source, false)
			guiSetText( source, "Confirm new password")
		elseif ( source == settingsGUI[6] ) then
			guiEditSetMasked( source, false)
			guiSetText( source, "Current password")
		end
	end
end

addEvent( "resetSettingsEditFields", true )
function resetSettingsEditFields ()
	guiEditSetMasked( settingsGUI[1], false)
	guiEditSetMasked( settingsGUI[2], false)
	guiEditSetMasked( settingsGUI[4], false)
	guiEditSetMasked( settingsGUI[5], false)
	guiEditSetMasked( settingsGUI[6], false)
end
addEventHandler( "resetSettingsEditFields", root, resetSettingsEditFields )

function onChangePlayerEmail ()
	local theEmail = guiGetText(settingsGUI[1])
	local thePassword = guiGetText(settingsGUI[2])
	triggerServerEvent( "onPlayerEmailChange", localPlayer, theEmail, thePassword )
end

function onChangePlayerPassword ()
	local newPassword1 = guiGetText(settingsGUI[4])
	local newPassword2 = guiGetText(settingsGUI[5])
	local oldPassword = guiGetText(settingsGUI[6])
	triggerServerEvent( "onPlayerPasswordChange", localPlayer, newPassword1, newPassword2, oldPassword )
end

addEvent( "onSetPlayerSettings", true )
function onSetPlayerSettings ()
	for i=1,#settingsTable do
		local state = exports.DENsettings:getPlayerSetting(settingsTable[i][2])
		triggerEvent ( "onPlayerSettingChange", localPlayer, settingsTable[i][2], state, nil )
	end
end
addEventHandler( "onSetPlayerSettings", root, onSetPlayerSettings )

apps[4][9] = onCloseSettingsApp
