-- Call service with phone
addEvent( "onPhoneCallService", true )
function onPhoneCallService ( theOccupation, theTeam )
	if ( theOccupation ) and ( theTeam ) then
	adn = "" .. theOccupation .. ""
	if ( theOccupation == "SWAT" ) or ( theOccupation == "Military Forces" ) then adn = "" .. theOccupation .. " member" end
		if ( theTeam == "Civillian Workers" ) then
			for id, player in ipairs(getElementsByType("player")) do
				if ( getTeamName( getPlayerTeam( player ) ) == theTeam ) and ( getElementData( player, "Occupation" ) == theOccupation ) then
					if ( getElementData( player, "doesWantJobCalls" ) ) then
						outputChatBox( getPlayerName( source ).." is requesting a " .. adn .. " near " .. getElementZoneName ( source ) .. "!", player, 0, 225, 0 )
					end
				end
			end
		else
			for id, player in ipairs(getElementsByType("player")) do
				if ( getTeamName( getPlayerTeam( player ) ) == theTeam ) then
					if ( getElementData( player, "doesWantJobCalls" ) ) then
						outputChatBox( getPlayerName( source ).." is requesting a " .. adn .. " near " .. getElementZoneName ( source ) .. "!", player, 0, 225, 0 )
					end
				end
			end
		end
	end
end
addEventHandler( "onPhoneCallService", root, onPhoneCallService )

-- Event for change email
addEvent( "onPlayerEmailChange", true )
function onPlayerEmailChange ( theEmail, thePassword )
	if ( theEmail ) and ( thePassword ) then
		exports.server:updatePlayerEmail( source, theEmail, thePassword )
	end
end
addEventHandler( "onPlayerEmailChange", root, onPlayerEmailChange )

-- Event for change password
addEvent( "onPlayerPasswordChange", true )
function onPlayerPasswordChange ( newPassword, newPassword2, oldPassword )
	if ( newPassword ) and ( newPassword2 ) and ( oldPassword ) then
		exports.server:updatePlayerPassword( source, newPassword, newPassword2, oldPassword )
	end
end
addEventHandler( "onPlayerPasswordChange", root, onPlayerPasswordChange )

-- Event send money
addEvent( "onTransferMoneyToPlayer", true )
function onTransferMoneyToPlayer ( toPlayer, theMoney )
	if ( isElement( toPlayer ) ) then
		if ( getPlayerMoney( source ) >= tonumber(theMoney) ) then
			givePlayerMoney( toPlayer, tonumber(theMoney) )
			takePlayerMoney( source, tonumber(theMoney) )
			
			exports.DENhelp:createNewHelpMessageForPlayer( toPlayer, getPlayerName( source ).." sent you $ "..theMoney, 225, 0, 0 )
			exports.DENhelp:createNewHelpMessageForPlayer( source, "$ " .. theMoney .. " has been sent to"..getPlayerName( toPlayer), 225, 0, 0 )
			
			exports.DENlogging:writePlayerLog ( source, getPlayerName(source).." sent $".. theMoney .." to ".. getPlayerName(toPlayer) .." (IPHONE APP)")
			exports.DENlogging:writePlayerLog ( toPlayer, getPlayerName(toPlayer).." recieved $".. theMoney .." from ".. getPlayerName(source) .." (IPHONE APP)")
		else
			exports.DENhelp:createNewHelpMessageForPlayer( source, "You don't have enough money!", 225, 0, 0 )
		end
	end
end
addEventHandler( "onTransferMoneyToPlayer", root, onTransferMoneyToPlayer )