function startup()
	local file = xmlLoadFile("locations.xml")
	for k, v in ipairs(xmlNodeGetChildren(file)) do
		local pos = split(xmlNodeGetAttribute(v,"pos"),string.byte(","))
		local marker = createMarker(pos[1],pos[2],pos[3],"cylinder", 4, 190, 0, 0, 170)
		createBlipAttachedTo(marker,63,2,255,0,0,255,0,250)
		setElementData(marker,"pnsMarker",true)
		setGarageOpen(tonumber(xmlNodeGetAttribute(v,"garage")),true)
	end
	xmlUnloadFile(file)
end
addEventHandler("onResourceStart",getResourceRootElement(),startup)

function payNSpray(hitElement)
	if (getElementData(source,"pnsMarker") == true) then
		if (getElementType(hitElement) == "vehicle") then
			local driver = getVehicleOccupant(hitElement)
			if (getElementHealth(hitElement) > 999) then
			outputChatBox("Your vehicle don't need to be repaired!",driver,0,225,0)
				else
				if (getVehicleOccupant(hitElement)) then
					local charge = math.floor(1000-getElementHealth(hitElement))
						local money = getPlayerMoney(driver) 
						if (money < charge) then
						outputChatBox("The costs for a repair are $"..charge..", you need more money!",driver,255,0,0)
						else  
						outputChatBox("Your vehicle has been repaired for $"..charge..".",driver,0,255,0)
						fixVehicle(hitElement)
						takePlayerMoney(driver,charge)
						for k, v in ipairs({"accelerate","enter_exit","handbrake"}) do
							toggleControl(driver,v,false)
						end
						setControlState(driver,"handbrake",true)
						fadeCamera(driver,false,1)
						setTimer(restoreControl,1000,1,driver)

					end
				end
			end
		end
	end
end
addEventHandler("onMarkerHit",getRootElement(),payNSpray)

function restoreControl(driver)
	for k, v in ipairs({"accelerate","enter_exit","handbrake"}) do
		toggleControl(driver,v,true)
	end
	setControlState(driver,"handbrake",false)
	fadeCamera(driver,true)
end