-- Some tables
local moneyPickups = {}
local pickupTimer = {}

-- When a player dies create the pickups
addEventHandler( "onClientPlayerWasted", root,
	function ( theKiller, weapon, bodypart )
		if ( theKiller ) and ( isElement( theKiller ) ) then
			local x, y, z = getElementPosition( source )
			local thePickup = createPickup( x, y, z, 3, 1274 )
			
			moneyPickups[thePickup] = theKiller
			
			pickupTimer[thePickup] = setTimer( destroyElement, 60000, 1, thePickup )
			setElementDimension( thePickup, 125 )
		end
	end
)

-- When the player pickups the pickup give him the money
addEventHandler( "onClientPickupHit", root,
	function ( hitElement )
		if ( hitElement == localPlayer ) then
			if ( moneyPickups[source] == localPlayer ) then
				triggerServerEvent( "onGivePlayerMoneyForKill", hitElement )
				moneyPickups[source] = {}
				if ( pickupTimer[source] ) and ( isTimer( pickupTimer[source] ) ) then killTimer( pickupTimer[source] ) end
				destroyElement( source )
			end
		end
	end
)

-- Create a blip when the resource starts
addEventHandler( "onClientResourceStart", resourceRoot,
	function ()
		local theBlip = exports.customblips:createCustomBlip( 2669.51733, -1765.50916, 20, 20, "blip.png" )
		exports.customblips:setCustomBlipStreamRadius( theBlip, 250 )
	end
)

-- Event when a player enters the event and shows for the scoreboard
addEvent( "onPlayerStadiumEnter", true )
addEventHandler( "onPlayerStadiumEnter", root,
	function ( theTable )
		stadiumPlayers = theTable
	end
)

-- When the client player enters or leaves the stadium
addEvent( "onClientStadiumEnter", true )
addEventHandler( "onClientStadiumEnter", root,
	function ( state )
		if ( state ) then
			addEventHandler( "onClientRender", root, onClientRenderPlayerBoard )
		else
			removeEventHandler( "onClientRender", root, onClientRenderPlayerBoard )
		end
	end
)

-- Make a string with all the players
function playerString ()
	local theString = "" 
	local theNumber = 0
	
	for index, thePlayer in pairs( stadiumPlayers ) do 
		theNumber = theNumber +1
		if ( theString == "" ) then 
			theString = theNumber..". "..getPlayerName( thePlayer )
		else 
			theString = theString .. "\n" .. theNumber .. ". " .. getPlayerName( thePlayer ) 
		end 
	end

	return theString
end

-- On client render
local sW, sH = guiGetScreenSize()

function onClientRenderPlayerBoard ()
	if ( stadiumPlayers ) then
		dxDrawRectangle(sW*(1121.0/1440),sH*(205.0/900),sW*(248.0/1440),sH*(28.0/900)+(#stadiumPlayers*18),tocolor(0,0,0,100),false)
		dxDrawText("Other battelers:",sW*(1125.0/1440),sH*(209.0/900),sW*(1357.0/1440),sH*(227.0/900),tocolor(225,0,0,225),1.2,"default-bold","left","top",false,false,false,true)
		dxDrawText(playerString (),sW*(1125.0/1440),sH*(235.0/900),sW*(1359.0/1440), ( sH*(260.0/900) ) + ( 10*( #stadiumPlayers ) ) ,tocolor(255,255,255,255),0.9,"clear","left","top",false,false,false,true)
	end
end