local playerTable = {}
local arenaSpawns = {
	{2655.21313, -1628.11401, 120.64531},
	{2656.45825, -1661.76758, 120.64531},
	{2641.82397, -1755.28589, 121.01250},
	{2656.18115, -1782.07568, 120.35625},
	{2574.09302, -1702.90186, 131.70000},
	{2636.79980, -1626.69653, 131.70000},
	{2558.08203, -1633.01282 ,131.70000},
	{2528.68677, -1624.78589, 134.55937},
}

-- The marker to enter the stadium
local theMarker = createMarker( 2669.51733, -1765.50916, 12.84781, "arrow", 2, 250, 250, 250 )

-- The eventhandler that warps you into the arena
addEventHandler( "onMarkerHit", theMarker, 
	function ( hitElement, matchingDimension )
		if ( matchingDimension ) then
			if ( hitElement ) and ( getElementType( hitElement ) == "player" ) then
				if ( getPlayerMoney( hitElement ) < 800 ) then
					exports.DENhelp:createNewHelpMessageForPlayer( hitElement, "You don't have enough money to participate in this event!", 0, 225, 0 )
				else
					fadeCamera( hitElement, false )
					setTimer( fadeCamera, 1500, 1, hitElement, true )
					setTimer( setElementPosition, 1500, 1, hitElement, unpack(arenaSpawns[math.random(#arenaSpawns)]) )
					setElementDimension( hitElement, 125 )
					showPlayerHudComponent( hitElement, "radar", false )
					table.insert( playerTable, hitElement )
					exports.DENhelp:createNewHelpMessageForPlayer( hitElement, "You are now batteling against other players, good luck!", 0, 225, 0 )
					triggerClientEvent( "onPlayerStadiumEnter", root, playerTable )
					triggerClientEvent( hitElement, "onClientStadiumEnter", hitElement, true )
				end
			end
		end
	end
)

-- Remove a player from the table
function removePlayerFromTable ( thePlayer )
	for k, aPlayer in ipairs ( playerTable ) do
		if ( aPlayer == thePlayer ) then
			table.remove( playerTable, k )
			return true
		end
	end
	return false
end

-- The event that gives the money
addEvent("onGivePlayerMoneyForKill", true)
addEventHandler("onGivePlayerMoneyForKill", root,
	function ()
		local theMoney = math.random( 400, 800 )
		givePlayerMoney( source, theMoney )
		exports.DENhelp:createNewHelpMessageForPlayer( source, "You just found $" .. theMoney .. " for killing someone in the arena!", 0, 225, 0 )
	end
)

-- When a player dies
addEventHandler( "onPlayerWasted", root,
	function ( ammo, theKiller, weapon )
		if ( isElement( source ) ) then
			if ( isElement( source ) ) and ( getElementDimension( source ) == 125 ) and ( theKiller ) then
				local theMoney = math.random( 400, 800 )
				takePlayerMoney( source, theMoney )
				exports.DENhelp:createNewHelpMessageForPlayer( source, "You just got killed by " .. getPlayerName( theKiller ) .. " and lost $" .. theMoney .. "!", 0, 225, 0 )
			end
			
			showPlayerHudComponent( source, "all", true )
			removePlayerFromTable ( source )
			triggerClientEvent( "onPlayerStadiumEnter", root, playerTable )
			triggerClientEvent( source, "onClientStadiumEnter", source, false )
		end
	end
)

-- When a player disconnect while in the event
addEventHandler( "onPlayerQuit", root,
	function ( ammo, theKiller, weapon )
		if ( isElement( source ) ) and ( getElementDimension( source ) == 125 ) then
			exports.server:updatePlayerDatabasePosition ( source, 2663.03, -1771.43, 10.27, 0, 0 )
			removePlayerFromTable ( source )
			triggerClientEvent( "onPlayerStadiumEnter", root, playerTable )
		end
	end
)