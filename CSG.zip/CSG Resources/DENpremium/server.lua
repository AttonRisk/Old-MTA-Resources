-- Show the remaining hours or say that the player isn't premium
function getPremiumTime (thePlayer)
	local playerID = exports.server:playerID( thePlayer )
	local getPlayerPremiumTime = exports.DENmysql:querySingle( "SELECT * FROM accounts WHERE id = '" .. playerID .. "'" )
	if getPlayerPremiumTime then
		if getPlayerPremiumTime.premium == 0 then
			exports.DENhelp:createNewHelpMessageForPlayer(thePlayer, "You're not a premium member! Visit the forum for more information about the premium membership.", 225, 0, 0)
		elseif getPlayerPremiumTime.premium < 60 then
			exports.DENhelp:createNewHelpMessageForPlayer(thePlayer, "Premium time remaining: " .. getPlayerPremiumTime.premium .. " minutes.", 0, 225, 0)
		else
			local premiumtime = math.floor(getPlayerPremiumTime.premium/60)
			if premiumtime == 1 then
				exports.DENhelp:createNewHelpMessageForPlayer(thePlayer, "Premium time remaining: " .. premiumtime .. " hour", 0, 225, 0)
			else
				exports.DENhelp:createNewHelpMessageForPlayer(thePlayer, "Premium time remaining: " .. premiumtime .. " hours", 0, 225, 0)
			end
		end
	end
end
addCommandHandler("premium", getPremiumTime)

-- Update the premium time from all players and update it
function updatePremiumTimes ()
	for index , player in ipairs ( getElementsByType ( "player" ) ) do
		if not isGuestAccount ( getPlayerAccount ( player ) ) then
			if getElementData(player, "isPlayerPremium") then
				if (getPlayerIdleTime( player ) < 300000) then -- Check if the player is AFK for more then 5 min, if true then don't take premium time
			
					-- Take every 5 min 5 minutes premium time from the player his account
					local playerID = exports.server:playerID( player )
					local getPlayerData = exports.DENmysql:querySingle( "SELECT * FROM accounts WHERE id = '" .. playerID .. "'" )
				
					if getPlayerData.premium > 4 then
						convertedTime = getPlayerData.premium - 5
					elseif getPlayerData.premium == 4 then
						convertedTime = getPlayerData.premium - 4
					elseif getPlayerData.premium == 3 then
						convertedTime = getPlayerData.premium - 3
					elseif getPlayerData.premium == 2 then
						convertedTime = getPlayerData.premium - 2
					elseif getPlayerData.premium == 1 then
						convertedTime = getPlayerData.premium - 1
					end
				
					if convertedTime == 0 then
						setElementData(player, "isPlayerPremium", false)
						setElementData(player, "Premium", "No")
					end
				
					local updatHouse = exports.DENmysql:exec("UPDATE accounts SET premium=? WHERE id = '" .. playerID .. "'"
                                ,tonumber(convertedTime)
                        )
				end
			end
		end
	end
end
setTimer ( updatePremiumTimes , 300000, 0 )

-- Vehicle spawn function for premium members

local theVehicle = {}
local latestSpawn = {}
local theTimer = {}

addCommandHandler("pc", 
	function (thePlayer)
		if not isGuestAccount ( getPlayerAccount ( thePlayer ) ) then
			if getElementData(thePlayer, "isPlayerPremium") or getElementData(thePlayer, "canUsePremiumCar") and ( getElementInterior(thePlayer) == 0 ) then
				if ( latestSpawn[getPlayerSerial(thePlayer)] ) and ( getTickCount()-latestSpawn[getPlayerSerial(thePlayer)] < 600000 ) then
					exports.DENhelp:createNewHelpMessageForPlayer(thePlayer, "You can only use this feature once every 10 minutes!", 225, 0, 0)
				elseif ( exports.server:getPlayerWantedPoints(thePlayer) >= 10 ) then
					exports.DENhelp:createNewHelpMessageForPlayer(thePlayer, "You can't use this feature when having one or more wanted stars!", 225, 0, 0)
				else
					if not ( isPedInVehicle(thePlayer) ) then
						if ( isElement( theVehicle[thePlayer] ) ) then destroyElement( theVehicle[thePlayer] ) end
						latestSpawn[getPlayerSerial(thePlayer)] = getTickCount()
						local x, y, z = getElementPosition(thePlayer)
						local rx, ry, rz = getElementRotation(thePlayer)
						theVehicle[thePlayer] = createVehicle( 526, x, y, z, rx, ry, rz, "Premium" )
						warpPedIntoVehicle(thePlayer, theVehicle[thePlayer])
						setElementData(theVehicle[thePlayer], "vehicleType", "PremiumCar")
						setElementData(theVehicle[thePlayer], "vehicleOwner", thePlayer)
						local handlingTable = getVehicleHandling ( theVehicle[thePlayer] )
						local newVelocity = ( handlingTable["maxVelocity"] + ( handlingTable["maxVelocity"] / 100 * 40 ) )
						setVehicleHandling ( theVehicle[thePlayer], "numberOfGears", 5 )
						setVehicleHandling ( theVehicle[thePlayer], "driveType", 'awd' )
						setVehicleHandling ( theVehicle[thePlayer], "maxVelocity", newVelocity )
						setVehicleHandling ( theVehicle[thePlayer], "engineAcceleration", handlingTable["engineAcceleration"] +8 )
					end
				end
			end
		end
	end
)

addEventHandler ( "onPlayerQuit", root, 
function()
	if ( isElement( theVehicle[source] ) ) then 
		destroyElement( theVehicle[source] )
		theVehicle[source] = nil
	end
end
)

addEventHandler("onVehicleStartEnter", root, 
function ( player, seat, jacked )
	if ( getElementData(source, "vehicleType") == "PremiumCar" ) and ( seat == 0 ) then
		if ( exports.server:getPlayerWantedPoints( player ) < 10 ) then
			if ( player ~= getElementData(source, "vehicleOwner") ) then
				cancelEvent()
				exports.DENhelp:createNewHelpMessageForPlayer(player, "You can't enter this vehicle!", 225, 0, 0)
			end
		end
	end
end
)

addEventHandler("onVehicleExplode", root, 
function ()
	if ( getElementData(source, "vehicleType") == "PremiumCar" ) then
		local theOwner = getElementData(source, "vehicleOwner")
		theTimer[theOwner] = setTimer(destroyVehicle, 5000, 1, source, theOwner)
	end
end
)

function destroyVehicle ( vehicle, thePlayer  )
	theVehicle[thePlayer] = nil
	theTimer[thePlayer] = nil
	destroyElement(vehicle)
end