elgtx = engineLoadTXD ( "premiumSkins/supergt.txd" )
engineImportTXD ( elgtx, 526 )
elgdf = engineLoadDFF ( "premiumSkins/supergt.dff", 526 )
engineReplaceModel ( elgdf, 526 )