-- Skins are NOT made by CSG or CSG staff
-- Skins: 41, 52, 94, 183, 195

txd = engineLoadTXD ( "premiumSkins/premiumSkin1.txd" )
engineImportTXD ( txd,41)
dff = engineLoadDFF ( "premiumSkins/premiumSkin1.dff",41)
engineReplaceModel ( dff,41)

txd = engineLoadTXD ( "premiumSkins/premiumSkin2.txd" )
engineImportTXD ( txd,52)
dff = engineLoadDFF ( "premiumSkins/premiumSkin2.dff",52)
engineReplaceModel ( dff,52)

txd = engineLoadTXD ( "premiumSkins/premiumSkin3.txd" )
engineImportTXD ( txd,94)
dff = engineLoadDFF ( "premiumSkins/premiumSkin3.dff",94)
engineReplaceModel ( dff,94)