-- Medic panel
medicPanelWindow = guiCreateWindow(409,182,441,459,"CSG ~ Medic Panel",false)
medicPanelGrid = guiCreateGridList(9,23,423,249,false,medicPanelWindow)
guiGridListSetSelectionMode(medicPanelGrid,0)

local column1 = guiGridListAddColumn(medicPanelGrid," Playername:",0.45)
local column2 = guiGridListAddColumn(medicPanelGrid,"Health:",0.1)
local column3 = guiGridListAddColumn(medicPanelGrid,"Location:",0.4)

medicPanelButton1 = guiCreateButton(10,277,134,33,"Mark player",false,medicPanelWindow)
medicPanelButton2 = guiCreateButton(148,277,137,33,"Mark all players",false,medicPanelWindow)
medicPanelButton3 = guiCreateButton(290,277,141,33,"Delete blips",false,medicPanelWindow)

medicPanelRadio1 = guiCreateRadioButton(14,320,361,22,"Show all injured players",false,medicPanelWindow)
medicPanelRadio2 = guiCreateRadioButton(14,346,361,22,"Show only players with less then 80% health",false,medicPanelWindow)
medicPanelRadio3 = guiCreateRadioButton(14,372,361,22,"Show only players with less then 60% health",false,medicPanelWindow)
medicPanelRadio4 = guiCreateRadioButton(14,398,361,22,"Show only players with less then 40% health",false,medicPanelWindow)
medicPanelRadio5 = guiCreateRadioButton(14,424,361,22,"Show only players with less then 20% health",false,medicPanelWindow)

guiRadioButtonSetSelected(medicPanelRadio1,true)

local screenW,screenH=guiGetScreenSize()
local windowW,windowH=guiGetSize(medicPanelWindow,false)
local x,y = (screenW-windowW)/2,(screenH-windowH)/2
guiSetPosition(medicPanelWindow,x,y,false)

guiWindowSetMovable (medicPanelWindow, true)
guiWindowSetSizable (medicPanelWindow, false)
guiSetVisible (medicPanelWindow, false)

function showMedicPanel ()
	if ( getElementData ( localPlayer, "isPlayerLoggedin" ) ) and (getTeamName(getPlayerTeam(localPlayer)) == "Paramedics") then
		if guiGetVisible(medicPanelWindow) then
			guiSetVisible(medicPanelWindow, false)
			showCursor(false,false)
		else
			guiSetVisible(medicPanelWindow,true)
			loadInjuredPlayers()
			showCursor(true,true)
		end
	end
end
bindKey ( "F5", "down", showMedicPanel )

function onUserChangedMedicPanelSetting ()
	if ( source == medicPanelRadio1 ) or ( source == medicPanelRadio2 ) or ( source == medicPanelRadio3 ) or ( source == medicPanelRadio4 ) or ( source == medicPanelRadio5 ) then
		loadInjuredPlayers()
	end
end
addEventHandler ( "onClientGUIClick", root, onUserChangedMedicPanelSetting )

local doAutoUpdateBlips = false

setTimer ( function ()
	if ( doAutoUpdateBlips ) then
		onMarkAllPlayers()
	end
end, 10000, 0)

function onMarkSelectedPlayer ()
	local thePlayer = guiGridListGetItemText ( medicPanelGrid, guiGridListGetSelectedItem ( medicPanelGrid ), 1 )
	if thePlayer == "" or thePlayer == " " then
		outputChatBox("You didn't select a player!", 225 ,0 ,0)
	else
		if ( isElement( getPlayerFromName(thePlayer ) ) ) then
			local attachedElements = getAttachedElements ( getPlayerFromName(thePlayer) )
			if ( attachedElements ) then
				for ElementKey, ElementValue in ipairs ( attachedElements ) do
					if ( getElementType ( ElementValue ) == "blip" ) then
						if ( getBlipIcon ( ElementValue ) == 22 ) then
							return
						end
					end
				end
			end
			local theBlip = createBlipAttachedTo ( getPlayerFromName(thePlayer), 22 )
		end
	end
end
addEventHandler("onClientGUIClick", medicPanelButton1, onMarkSelectedPlayer, false)

function onMarkAllPlayers ()
	local healthSetting = 100
	if ( guiRadioButtonGetSelected( medicPanelRadio1 ) ) then healthSetting = 100 end
	if ( guiRadioButtonGetSelected( medicPanelRadio2 ) ) then healthSetting = 80  end
	if ( guiRadioButtonGetSelected( medicPanelRadio3 ) ) then healthSetting = 60  end
	if ( guiRadioButtonGetSelected( medicPanelRadio4 ) ) then healthSetting = 40  end
	if ( guiRadioButtonGetSelected( medicPanelRadio5 ) ) then healthSetting = 20  end
	
	onRemoveAllBlips()
	
	for id, player in ipairs(getElementsByType("player")) do
		if ( getElementHealth( player ) < tonumber(healthSetting) ) then
			if not ( player == localPlayer ) then
				local theBlip = createBlipAttachedTo ( player, 22 )
				doAutoUpdateBlips = true
			end
		end
	end
end
addEventHandler("onClientGUIClick", medicPanelButton2, onMarkAllPlayers, false)

function onRemoveAllBlips ()
	for id, player in ipairs(getElementsByType("player")) do
		local attachedElements = getAttachedElements ( player )
		if ( attachedElements ) then 
			for ElementKey, ElementValue in ipairs ( attachedElements ) do
				if ( getElementType ( ElementValue ) == "blip" ) then
					if ( getBlipIcon ( ElementValue ) == 22 ) then
						destroyElement( ElementValue )
						doAutoUpdateBlips = false
					end
				end
			end
		end
	end
end
addEventHandler("onClientGUIClick", medicPanelButton3, onRemoveAllBlips, false)

function loadInjuredPlayers()
	local healthSetting = 100
	if ( guiRadioButtonGetSelected( medicPanelRadio1 ) ) then healthSetting = 100 end
	if ( guiRadioButtonGetSelected( medicPanelRadio2 ) ) then healthSetting = 80  end
	if ( guiRadioButtonGetSelected( medicPanelRadio3 ) ) then healthSetting = 60  end
	if ( guiRadioButtonGetSelected( medicPanelRadio4 ) ) then healthSetting = 40  end
	if ( guiRadioButtonGetSelected( medicPanelRadio5 ) ) then healthSetting = 20  end
	
	local playersFound = false
	
	guiGridListClear ( medicPanelGrid )
	for id, player in ipairs(getElementsByType("player")) do
		if ( getElementHealth( player ) < tonumber(healthSetting) ) then
			if not ( player == localPlayer ) then
				playersFound = true
				local row = guiGridListAddRow ( medicPanelGrid )
				local x, y, z = getElementPosition ( player )
				guiGridListSetItemText ( medicPanelGrid, row, 1, getPlayerName ( player ), false, false )
				guiGridListSetItemText ( medicPanelGrid, row, 2, "  "..math.floor(getElementHealth ( player )).."%", false, false )
				guiGridListSetItemText ( medicPanelGrid, row, 3, "  "..getZoneName ( x, y, z ).." ("..exports.server:getPlayChatZone()..")", false, false )
				
				if ( math.floor(getElementHealth ( player ) ) < 30 ) then
					guiGridListSetItemColor ( medicPanelGrid, row, 2, 225, 0, 0 )
				elseif ( math.floor(getElementHealth ( player ) ) > 29 ) and  ( math.floor(getElementHealth ( player ) ) < 70 ) then
					guiGridListSetItemColor ( medicPanelGrid, row, 2, 225, 165, 0 )
				else
					guiGridListSetItemColor ( medicPanelGrid, row, 2, 0, 225, 0 )
				end
			end
		end
	end
	if not ( playersFound ) then
		local row = guiGridListAddRow ( medicPanelGrid )
		guiGridListSetItemText ( medicPanelGrid, row, 1, "No players found", false, false )
		guiGridListSetItemText ( medicPanelGrid, row, 2, "  N/A", false, false )
		guiGridListSetItemText ( medicPanelGrid, row, 3, "  N/A", false, false )
	end
end

addEvent( "onClientPlayerTeamChange" )
addEventHandler ( "onClientPlayerTeamChange", root,
function ()
	if ( source == localPlayer ) then
		onRemoveAllBlips ()
	end
end
)