function healedPlayer ( money, healedplayer, healVal )
	local x, y, z = getElementPosition(source)
	local x2, y2, z2 = getElementPosition(healedplayer)
	local health = getElementHealth(healedplayer)
	if getDistanceBetweenPoints3D(x, y, z, x2, y2, z2) < 5 then
		if getPedWeapon ( source ) == 41 then	
			if ( money ) then
				if getPlayerMoney(healedplayer) > money then
					setElementHealth ( healedplayer, health + healVal )
					givePlayerMoney ( healedplayer, money*-1 )
					givePlayerMoney ( source, money )
				else
					exports.DENhelp:createNewHelpMessageForPlayer ( source, "The player you want heal doesn't have enough money!", 225,0,0)
				end				
			else
				setElementHealth ( healedplayer, health + healVal )
				exports.DENhelp:createNewHelpMessageForPlayer( source, "No money for you! You attacked the patient before healing.", 225,0,0)
			end
		end
	end
end
addEvent ( "healedPlayer", true )
addEventHandler ( "healedPlayer", root, healedPlayer )

addEventHandler ( "onVehicleEnter", root, 
function ( thePlayer, seat, jacked )	
	local theMedic = getVehicleController ( source )
	if ( theMedic ) then
		if ( getTeamName ( getPlayerTeam ( theMedic ) ) == "Paramedics" ) and ( getElementModel(source) == 416 ) then
			local getPlayerHealth = getElementHealth (thePlayer)
			local theHealthFormule = ( 100 / getPlayerHealth )
			local healPrice = ( theHealthFormule * 40 / 10 )
			if ( getPlayerMoney( thePlayer ) < healPrice ) then
				exports.DENhelp:createNewHelpMessageForPlayer ( thePlayer, "You don't have enough money for a heal!", 225,0,0)
			else
				if ( math.floor(getPlayerHealth) < 100 ) then
					givePlayerMoney (theMedic, math.floor(healPrice))
					takePlayerMoney (thePlayer, math.floor(healPrice))
					setElementHealth (thePlayer, 100)
				end
			end
		end
	end
end
)