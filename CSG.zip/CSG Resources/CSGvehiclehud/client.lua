local sx,sy = guiGetScreenSize()

local enableVehicleHealth = true
local enableFuelHealth = true
local enableSpeedMeter = true

addEvent( "onClientSwitchDamageMeter" )
addEventHandler( "onClientSwitchDamageMeter", root,
	function ( state )
		enableVehicleHealth = state
	end
)

addEvent( "onClientSwitchFuelMeter" )
addEventHandler( "onClientSwitchFuelMeter", root,
	function ( state )
		enableFuelHealth = state
	end
)

addEvent( "onClientSwitchSpeedMeter" )
addEventHandler( "onClientSwitchSpeedMeter", root,
	function ( state )
		enableSpeedMeter = state
	end
)

addEventHandler( "onClientRender", root,
    function()
		local theVehicle = getPedOccupiedVehicle ( localPlayer ) 
		if ( theVehicle ) then
			local spx, spy, spz = getElementVelocity( theVehicle )  
			local mphSpeed = ( spx^2 + spy^2 + spz^2 ) ^ 0.5 * 100
			local kphSpeed = ( spx^2 + spy^2 + spz^2 ) ^ 0.5 * 1.61 * 100
			
			local vehicleHealth = ( getElementHealth( theVehicle ) )
			local vehicleFuel = getElementData( theVehicle, "vehicleFuel" )
			
			if ( enableVehicleHealth ) and ( enableFuelHealth ) and ( vehicleFuel ) then
				hx1, hy1, hx2, hy2 = sx*(1323.0/1440),sy*(859.0/900),sx*(113.0/1440),sy*(23.0/900)
				hx3, hy3, hx4, hy4 = sx*(1325.0/1440),sy*(861.0/900),vehicleHealth/10*sx*(109.0/1440)/100,sy*(19.0/900)
				hx5, hy5, hx6, hy6 = sx*(1370.0/1440),sy*(861.0/900),sx*(23.0/1440),sy*(20.0/900)
			elseif not ( vehicleFuel ) and ( enableVehicleHealth ) or ( enableVehicleHealth ) and not ( enableFuelHealth ) then
				hx1, hy1, hx2, hy2 = sx*(1207.0/1440),sy*(859.0/900),sx*(228.0/1440),sy*(23.0/900)
				hx3, hy3, hx4, hy4 = sx*(1209.0/1440),sy*(861.0/900),vehicleHealth/10*sx*(224.0/1440)/100,sy*(19.0/900)
				hx5, hy5, hx6, hy6 = sx*(1310.0/1440),sy*(860.0/900),sx*(23.0/1440),sy*(20.0/900)
			end
			
			if ( enableFuelHealth ) and ( enableVehicleHealth ) and ( vehicleFuel ) then
				fx1, fy1, fx2, fy2 = sx*(1207.0/1440),sy*(859.0/900),sx*(113.0/1440),sy*(23.0/900)
				fx3, fy3, fx4, fy4 = sx*(1209.0/1440),sy*(861.0/900),vehicleFuel*sx*(109.0/1440)/100,sy*(19.0/900)
				fx5, fy5, fx6, fy6 = sx*(1253.0/1440),sy*(862.0/900),sx*(20.0/1440),sy*(18.0/900)
			elseif ( vehicleFuel ) and ( enableFuelHealth ) and not ( enableVehicleHealth ) then
				fx1, fy1, fx2, fy2 = sx*(1207.0/1440),sy*(859.0/900),sx*(228.0/1440),sy*(23.0/900)
				fx3, fy3, fx4, fy4 = sx*(1209.0/1440),sy*(861.0/900),vehicleFuel/10*sx*(224.0/1440)/100,sy*(19.0/900)
				fx5, fy5, fx6, fy6 = sx*(1311.0/1440),sy*(861.0/900),sx*(20.0/1440),sy*(18.0/900)
			end
			
			local vehHealthColor = math.max(vehicleHealth - 250, 0)/750
			local vehHealthColorMath = -510*(vehHealthColor^2)
			local rh, gh = math.max(math.min(vehHealthColorMath + 255*vehHealthColor + 255, 255), 0), math.max(math.min(vehHealthColorMath + 765*vehHealthColor, 255), 0)
			
			if ( vehicleFuel ) then
				theFuel = ( vehicleFuel * 10 ) 
				vehFuelColor = math.max(theFuel - 250, 0)/750
				vehFuelthColorMath = -510*(vehFuelColor^2)
				rf, gf = math.max(math.min(vehFuelthColorMath + 255*vehFuelColor + 255, 255), 0), math.max(math.min(vehFuelthColorMath + 765*vehFuelColor, 255), 0)
			end
			
			if ( enableVehicleHealth ) then
				dxDrawRectangle(hx1, hy1, hx2, hy2,tocolor(0,0,0,150),false)
				dxDrawRectangle(hx3, hy3, hx4, hy4,tocolor(rh,gh,0,170),false)
				dxDrawImage	   (hx5, hy5, hx6, hy6,"images/health.png",0.0,0.0,0.0,tocolor(255,255,255,255),false)
			end
			
			if ( enableFuelHealth ) and ( vehicleFuel ) then
				dxDrawRectangle(fx1, fy1, fx2, fy2,tocolor(0,0,0,150),false)
				dxDrawRectangle(fx3, fy3, fx4, fy4,tocolor(rf,gf,0,170),false)
				dxDrawImage	   (fx5, fy5, fx6, fy6,"images/fuel.png",0.0,0.0,0.0,tocolor(255,255,255,255),false)
			end
			
			if ( enableSpeedMeter ) then
				if ( isVehicleLocked( theVehicle ) ) or ( getElementData( theVehicle, "vehicleLocked" ) ) then
					dxDrawImage(sx*(1208.0/1440),sy*(835.0/900),sx*(19.0/1440),sy*(19.0/900),"images/lock2.png",0.0,0.0,0.0,tocolor(255,255,255,255),false)
				else
					dxDrawImage(sx*(1208.0/1440),sy*(835.0/900),sx*(19.0/1440),sy*(19.0/900),"images/lock.png",0.0,0.0,0.0,tocolor(255,255,255,255),false)
				end
				
				dxDrawText(math.ceil(kphSpeed).." kmh / "..math.ceil(mphSpeed).." mph",sx*(1232.0/1440),sy*(832.0/900),sx*(1435.0/1440),sy*(857.0/900),tocolor(255,255,255,255),1.6,"clear","right","top",false,false,false)
			end
		end
   end
)