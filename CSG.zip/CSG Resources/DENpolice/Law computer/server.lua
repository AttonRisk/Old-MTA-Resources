local backupSpam = {}

addEvent ("onSendRequestMessage", true)
function onSendRequestMessage ( theTeam, theMessage )
	if ( backupSpam[source] ) and ( getTickCount()-backupSpam[source] < 30000 ) then
		exports.DENhelp:createNewHelpMessageForPlayer(source, "Wait 30 seconds before sending a new request!", 225, 0, 0)
	else
		local setting = nil
		if ( theTeam == "SWAT" ) then setting = "swatRequest" elseif ( theTeam == "Military Forces" ) then setting = "mfRequest" elseif ( theTeam == "Police" ) then setting = "policeRequest" elseif ( theTeam == "Department of Defense" ) then setting = "dodRequest" end
	
		backupSpam[source] = getTickCount()
		exports.DENhelp:createNewHelpMessageForPlayer(source, "Request was sent!", 0, 225, 0)
		
		for i, player in ipairs ( getElementsByType("player") ) do
			if ( getPlayerTeam( player ) ) then
				if (getTeamName(getPlayerTeam(player)) == "SWAT") or (getTeamName(getPlayerTeam(player)) == "Military Forces") or (getTeamName(getPlayerTeam(player)) == "Police") or (getTeamName(getPlayerTeam(player)) == "Department of Defense") then
					if ( source ~= player ) and ( setting ) and ( getElementData( player, setting ) ) then
						outputChatBox(theMessage, player, 225, 0, 0)
					end
				end
			end
		end
	end
end
addEventHandler ("onSendRequestMessage", root, onSendRequestMessage)