local militaryPickup = createPickup ( 224.94, 1853.53, 12.8, 3, 1242, 0)
local swatPickup = createPickup ( 1176.57, -1649.41, 17.6, 3, 1242, 0)

-- Military Forces pickups
function useMilitaryPickup ( player )
	if (getTeamName(getPlayerTeam(player)) == "Staff") or (getTeamName(getPlayerTeam(player)) == "SWAT") or (getTeamName(getPlayerTeam(player)) == "Military Forces") or (getTeamName(getPlayerTeam(player)) == "Police") or (getTeamName(getPlayerTeam(player)) == "Department of Defense") then
		setElementHealth ( player, 100 )
		setPedArmor (player, 100)
		giveWeapon(player, 46)
	else
		cancelEvent()
	end
end
addEventHandler ( "onPickupHit", militaryPickup, useMilitaryPickup )
addEventHandler ( "onPickupHit", swatPickup, useMilitaryPickup )

local policePickupTable = {
{ 1560.32, -1634.99, 13.55 },
{ 630.68, -572.91, 16.33 },
{ -215.65, 977.9, 19.49 },
{ -1616.03, 685.42, 7.18 },
{ -1394.25, 2641.45, 55.91 },
{ -2159.76, -2387.94, 30.62 },
{ 2067.89, 597.28, 11.71, 2 },
}

function usePoliceArmorPickup ( player )
	if (getTeamName(getPlayerTeam(player)) == "Staff") or (getTeamName(getPlayerTeam(player)) == "SWAT") or (getTeamName(getPlayerTeam(player)) == "Military Forces") or (getTeamName(getPlayerTeam(player)) == "Police") or (getTeamName(getPlayerTeam(player)) == "Department of Defense") then
		setPedArmor (player, 100)
		giveWeapon(player, 46)
	else
		cancelEvent()
	end
end

function useArmorParaPickup ( player )
	if (getTeamName(getPlayerTeam(player)) == "Staff") or (getTeamName(getPlayerTeam(player)) == "Criminals") then
		setPedArmor (player, 100)
		giveWeapon(player, 46)
	else
		cancelEvent()
	end
end

function useArmorPickup ( player )
	if (getTeamName(getPlayerTeam(player)) == "Staff") or (getTeamName(getPlayerTeam(player)) == "Criminals") then
		setPedArmor (player, 100)
	else
		cancelEvent()
	end
end

for i=1,#policePickupTable do
	local thePickup = createPickup ( policePickupTable[i][1], policePickupTable[i][2], policePickupTable[i][3], 3, 1242, 0)
	if ( policePickupTable[i][4] == 1 ) then addEventHandler ( "onPickupHit", thePickup, useArmorPickup ) elseif ( policePickupTable[i][4] == 2 ) then addEventHandler ( "onPickupHit", thePickup, useArmorParaPickup ) else addEventHandler ( "onPickupHit", thePickup, usePoliceArmorPickup ) end
end

addEvent( "onPlayerPayfine", true )
addEventHandler( "onPlayerPayfine", root,
function ( theMoney )
	takePlayerMoney( source, theMoney )
	exports.server:removePlayerWantedPoints( source, 10 )
end
)