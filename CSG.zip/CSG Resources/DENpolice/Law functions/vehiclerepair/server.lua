function startup()
	local file = xmlLoadFile("Law functions/vehiclerepair/locations.xml")
	for k, v in ipairs(xmlNodeGetChildren(file)) do
		local pos = split(xmlNodeGetAttribute(v,"pos"),string.byte(","))
		local marker = createMarker(pos[1],pos[2],pos[3],"cylinder", 4, 190, 0, 0, 170)
		setElementData(marker,"pnsMarker2",true)
	end
	xmlUnloadFile(file)
end
addEventHandler("onResourceStart",getResourceRootElement(),startup)

function payNSpray(hitElement)
	if (getElementData(source,"pnsMarker2") == true) then
		if (getElementType(hitElement) == "vehicle") then
			if (getElementHealth(hitElement) > 999) then
				local driver = getVehicleOccupant(hitElement)
				exports.DENhelp:createNewHelpMessageForPlayer(driver,"Your vehicle don't need a repair!",0,255,0)
			else
				setElementFrozen ( hitElement, true )
				if (getVehicleOccupant(hitElement)) then
					local driver = getVehicleOccupant(hitElement)
					if ( getElementData(driver, "isPlayerPremium") ) then
						-- If the player is VIP
						defaultCharge = math.floor(1000-getElementHealth(hitElement))
						charge = math.floor(( defaultCharge - defaultCharge / 100 * 30 ))
					else
						-- If the player is not VIP
						charge = math.floor(1000-getElementHealth(hitElement))
					end
						local money = getPlayerMoney(driver) 
						if (money < charge) then
							exports.DENhelp:createNewHelpMessageForPlayer(driver, "You need $"..charge.." before we can repair your vehicle.",255,0,0)
							setElementFrozen ( hitElement, false)
						else  
						
						exports.DENhelp:createNewHelpMessageForPlayer(driver,"Your vehicle has been repaired for $"..charge.."!",0,255,0)
						
						fixVehicle(hitElement)
						takePlayerMoney(driver,charge)
						for k, v in ipairs({"accelerate","enter_exit","handbrake"}) do
							toggleControl(driver,v,false)
						end
						
						setControlState(driver,"handbrake",true)
						fadeCamera(driver,false,1)
						setTimer(restoreControl,1000,1,driver)
						setElementFrozen ( hitElement, false)
					end
				end
			end
		end
	end
end
addEventHandler("onMarkerHit",getRootElement(),payNSpray)

function restoreControl(driver)
	for k, v in ipairs({"accelerate","enter_exit","handbrake"}) do
		toggleControl(driver,v,true)
	end
	setControlState(driver,"handbrake",false)
	fadeCamera(driver,true)
end