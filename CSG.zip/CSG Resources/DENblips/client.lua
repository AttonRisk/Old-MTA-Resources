-- Tables
local groupBlips = {}
local playerBlips = {}

-- Stuff that handles the group blips and tags
local enableGroupTags = false
local enableGroupBlips = true

addEvent( "onClientSwitchGroupBlips" )
addEventHandler( "onClientSwitchGroupBlips", localPlayer,
	function ( state )
		enableGroupBlips = state
	end 
)

addEvent( "onClientSwitchGroupTags" )
addEventHandler( "onClientSwitchGroupTags", localPlayer,
	function ( state )
		enableGroupTags = state
	end 
)

-- Create a blip for whenever a player joins
addEventHandler( "onClientResourceStart", getResourceRootElement( getThisResource() ),
	function ()
		for k, thePlayer in ipairs ( getElementsByType( "player" ) ) do
			if not ( playerBlips[thePlayer] ) then
				playerBlips[thePlayer] = createBlipAttachedTo( thePlayer, 0, 2, 0, 0, 0, 500 )
				setBlipVisibleDistance( playerBlips[thePlayer], 500 )
			end
		end
	end
)

addEventHandler( "onClientPlayerJoin", root,
	function()
		if not ( playerBlips[source] ) then
			playerBlips[source] = createBlipAttachedTo( source, 0, 2, 0, 0, 0, 500 )
			setBlipVisibleDistance( playerBlips[source], 500 )
		end
	end
)

-- The actual blip stuff
addEventHandler( "onClientRender", root,
	function ()
		for thePlayer, theBlip in pairs( playerBlips ) do
			if ( isElement( thePlayer ) ) and not ( thePlayer == localPlayer ) then
				if ( getPlayerTeam( thePlayer ) ) then
					if ( enableGroupBlips ) then
						if ( getElementData( localPlayer, "Group" ) ) and ( getElementData( thePlayer, "Group" ) ) then
							if ( getElementData( localPlayer, "Group" ) == getElementData( thePlayer, "Group" ) ) then
								if not ( groupBlips[thePlayer] ) then
									groupBlips[thePlayer] = createBlipAttachedTo ( thePlayer, 60, 0, 0, 0, 0, 0, 0, 500 )
									setBlipVisibleDistance( groupBlips[thePlayer], 500 )
								end
							end
						end
					else
						if ( isElement( groupBlips[thePlayer] ) ) then
							destroyElement( groupBlips[thePlayer] )
							groupBlips[thePlayer] = nil
						end
					end
					
					if ( enableGroupTags ) then
						if ( getElementData( localPlayer, "Group" ) ) and ( getElementData( thePlayer, "Group" ) ) then
							if ( getElementData( localPlayer, "Group" ) == getElementData( thePlayer, "Group" ) ) then
								setPlayerNametagColor ( thePlayer, 142, 56, 142 )
							end
						end
					else
						setPlayerNametagColor ( thePlayer, false )
					end
					
					if ( getElementAlpha( thePlayer ) == 0 ) then
						setBlipColor( theBlip, 225, 225, 225, 0 )	
						if ( isElement( groupBlips[thePlayer] ) ) then
							destroyElement( groupBlips[thePlayer] )
							groupBlips[thePlayer] = nil
						end
					else
						local R, G, B = getTeamColor( getPlayerTeam( thePlayer ) )
						setBlipColor( theBlip, R, G, B, 225 )
					end
				end
			end
		end
	end
)

addEventHandler("onClientPlayerQuit",root,
	function ()
		if ( isElement( groupBlips[source] ) ) then
			destroyElement( groupBlips[source] )
			groupBlips[source] = nil
		end
		if ( isElement( playerBlips[source] ) ) then
			destroyElement( playerBlips[source] )
			playerBlips[source] = nil
		end
	end
)

addEvent( "deleteGroupBlip", true )
addEventHandler( "deleteGroupBlip", root,
	function ( thePlayer )
		if ( isElement( groupBlips[thePlayer] ) ) then
			destroyElement( groupBlips[thePlayer] )
			groupBlips[thePlayer] = nil
		end
	end
)


