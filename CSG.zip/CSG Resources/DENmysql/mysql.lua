-- Connection functions
local connection = nil

local function connect( )
	connection = dbConnect( "mysql", "dbname=mtadev;host=127.0.0.1;port=3306;unix_socket=/var/run/mysqld/mysqld.sock", "mtadev", "t9CPZJbJTe8FtnwC", "share=1" )
	if connection then
		outputConsole ( "Server is now connected with the MySQL database!", 1 )
		return true
	else
		outputConsole ( "Connection with the MySQL database failed!", 1 )
		return false
	end
end
addEventHandler ( "onResourceStart", getResourceRootElement(getThisResource()), connect )

-- Exported functions
function query( ... )
    if connection then
        local qh = dbQuery( connection, ... )
        local result = dbPoll( qh, -1 )
        return result
    else
        return false
    end     
end

-- Get a single row from the database
function querySingle( str, ... )
	if connection then
		local result = query( str, ... )
		if type(result) == 'table' then
			return result[1]
		end
		return result
	else
		return false
	end
end

-- DB exec as used
function exec( str, ... )
	if connection then
		local qh = dbExec( connection, str, ... )
		return qh
	else
		return false
	end
end