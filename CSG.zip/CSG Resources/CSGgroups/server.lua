-- Group ranks
local groupRanks = { ["Guest"]=0, ["Trial"]=1, ["Member"]=2, ["Group staff"]=3, ["Group leader"]=4, ["Group founder"]=5 }

-- Get a table with all the players from a group
local updateTick = false
local theTable = {}

function getGroupPlayers ( theGroup )
	if not ( updateTick ) or ( getTickCount()-updateTick > 60000 ) then
		updateTick = getTickCount()
		theTable = {}
		for k, thePlayer in ipairs ( getElementsByType ( "player" ) ) do
			if ( getElementData( thePlayer, "Group" ) == theGroup ) then
				table.insert( theTable, thePlayer )
			end
		end
		return theTable
	else
		return theTable
	end
end

-- Get all the data needed to show the groups panel
addEvent( "requestGroupsData", true )
addEventHandler( "requestGroupsData", root,
	function ()
		local playerID = exports.server:playerID( source )
		local groupID = exports.server:getPlayerGroupID( source )
		if ( playerID ) and ( groupID ) then
			local groupsTable = exports.DENmysql:query( "SELECT * FROM groups ORDER BY groupid ASC" )
			local invitesTable = exports.DENmysql:query( "SELECT * FROM groups_invites WHERE memberid=? ORDER BY groupid ASC", playerID )
			local memberTable = exports.DENmysql:querySingle( "SELECT * FROM groups_members WHERE memberid=? LIMIT 1", playerID )
			local membersTable = exports.DENmysql:query( "SELECT * FROM groups_members WHERE groupid=? LIMIT 80", groupID )
			local bankingTable = exports.DENmysql:query( "SELECT * FROM groups_transactions WHERE groupid=? ORDER BY datum ASC LIMIT 25", groupID )	
			triggerClientEvent( source, "onRequestGroupDataCallback", source, groupsTable, invitesTable, memberTable, bankingTable, membersTable, groupID )
			
			if ( #membersTable ) then exports.DENmysql:exec( "UPDATE groups SET membercount=? WHERE groupid=?", #membersTable, groupID ) end
		else
			local groupsTable = exports.DENmysql:query( "SELECT * FROM groups ORDER BY groupid ASC" )
			local invitesTable = exports.DENmysql:query( "SELECT * FROM groups_invites WHERE memberid=? ORDER BY groupid ASC", playerID )
			triggerClientEvent( source, "onRequestGroupDataCallback", source, groupsTable, invitesTable, false, false )
		end
	end
)

-- When a player wants to create a new group
addEvent( "onServerCreateNewGroup", true )
addEventHandler( "onServerCreateNewGroup", root,
	function ( groupName )
		local groupCheck = exports.DENmysql:querySingle( "SELECT * FROM groups WHERE groupname=? LIMIT 1", groupName )
		if ( groupCheck ) then
			exports.DENhelp:createNewHelpMessageForPlayer( source, "There is already a group with this name!", 200, 0, 0 )
		else
			local playerAccount = exports.server:getPlayerAccountName ( source )
			local playerID = exports.server:playerID( source )
			local createMySQL = exports.DENmysql:exec( "INSERT INTO groups SET groupleader=?, groupname=?", playerAccount, groupName )
			if ( createMySQL ) then
				local groupTable = exports.DENmysql:querySingle( "SELECT * FROM groups WHERE groupname=? LIMIT 1", groupName )
				if ( groupTable ) then
					local memberMySQL = exports.DENmysql:exec("INSERT INTO groups_members SET groupid=?, memberid=?, membername=?, groupname=?, grouprank=?", groupTable.groupid, playerID, playerAccount, groupName, "Group founder" )
                    setElementData( source, "GroupID", groupTable.groupid )
					setElementData( source, "Group", groupTable.groupname )
					setElementData( source, "GroupRank", groupTable.grouprank )
					triggerClientEvent( source, "onClientFinishGroupCreate", source, true )
				end
			end
		end
	end
)

-- When a player leaves the group
addEvent( "onServerLeaveGroup", true )
addEventHandler( "onServerLeaveGroup", root,
	function ()
		local groupID = exports.server:getPlayerGroupID( source )
		local playerID = exports.server:playerID( source )
		if ( groupID ) then
			exports.DENchatsystem:outPutGroupMessageByPlayer( source, getPlayerName( source ).." left the group!" )
			exports.DENmysql:exec( "DELETE FROM groups_members WHERE memberid=?", playerID )
			setElementData( source, "Group", false )
			setElementData( source, "GroupID", false )
			setElementData( source, "GroupRank", false)
			triggerClientEvent( source, "onClientHideGroupsWindow", source )
		end
	end
)

-- When a player updates the group information
addEvent( "onServerUpdateGroupInformation", true )
addEventHandler( "onServerUpdateGroupInformation", root,
	function ( groupInformation )
		local groupID = exports.server:getPlayerGroupID( source )
		if ( groupID ) then
			exports.DENmysql:exec( "UPDATE groups SET groupinfo=? WHERE groupid=?", groupInformation, groupID )
			exports.DENchatsystem:outPutGroupMessageByPlayer( source, getPlayerName( source ).." updated the group information!" )
		end
	end
)

-- When the player want to deposit money
addEvent( "onServerGroupBankingDeposit", true )
addEventHandler( "onServerGroupBankingDeposit", root,
	function ( theMoney )
		local playerID = exports.server:playerID( source )
		local groupID = exports.server:getPlayerGroupID( source )
		if ( groupID ) then
			local groupsBalance = exports.DENmysql:querySingle( "SELECT * FROM groups WHERE groupid=? LIMIT 1", groupID )
			if ( groupsBalance ) then
				local theBalance = ( tonumber( groupsBalance.groupbalance ) + tonumber( theMoney ) )
				exports.DENmysql:exec( "UPDATE groups SET groupbalance=? WHERE groupid=?", theBalance, groupID )
				exports.DENmysql:exec( "INSERT INTO groups_transactions SET groupid=?, memberid=?, transaction=?", groupID, playerID, getPlayerName( source ).." deposited $"..theMoney )
				takePlayerMoney( source, tonumber( theMoney ) )
				for k, thePlayer in ipairs ( getGroupPlayers ( getElementData( source, "Group" ) ) ) do triggerClientEvent( thePlayer, "onClientUpdateGroupBalance", thePlayer, tonumber( theBalance ), tonumber( theMoney ), "deposited", source ) end
				exports.DENchatsystem:outPutGroupMessageByPlayer( source, getPlayerName( source ).." deposited $"..theMoney.." into the group bank!" )
				exports.DENlogging:writePlayerLog ( source, getPlayerName(source).." has deposited $" .. theMoney .. " to his group (GROUPID: " .. groupID .. ") (GROUP: " .. getElementData( source, "Group" ) .. ")")
			end
		end
	end
)

-- When the play withdraw money
addEvent( "onServerGroupBankingWithdrawn", true )
addEventHandler( "onServerGroupBankingWithdrawn", root,
	function ( theMoney )
		local playerID = exports.server:playerID( source )
		local groupID = exports.server:getPlayerGroupID( source )
		if ( groupID ) then
			local groupsBalance = exports.DENmysql:querySingle( "SELECT * FROM groups WHERE groupid=? LIMIT 1", groupID )
			if ( groupsBalance ) then
				if ( groupsBalance.groupbalance - tonumber( theMoney ) >= 0 ) then
					local theBalance = ( tonumber( groupsBalance.groupbalance ) - tonumber( theMoney ) )
					exports.DENmysql:exec( "UPDATE groups SET groupbalance=? WHERE groupid=?", theBalance, groupID )
					exports.DENmysql:exec( "INSERT INTO groups_transactions SET groupid=?, memberid=?, transaction=?", groupID, playerID, getPlayerName( source ).." withdrawn $"..theMoney )
					givePlayerMoney( source, tonumber( theMoney ) )
					for k, thePlayer in ipairs ( getGroupPlayers ( getElementData( source, "Group" ) ) ) do triggerClientEvent( thePlayer, "onClientUpdateGroupBalance", thePlayer, tonumber( theBalance ), tonumber( theMoney ), "withdrawn", source ) end
					exports.DENchatsystem:outPutGroupMessageByPlayer( source, getPlayerName( source ).." withdrawn $"..theMoney.." from the group bank!" )
					exports.DENlogging:writePlayerLog ( source, getPlayerName(source).." has withdrawn $" .. theMoney .. " from his group (GROUPID: " .. groupID .. ") (GROUP: " .. getElementData( source, "Group" ) .. ")")
				else
					exports.DENhelp:createNewHelpMessageForPlayer( source, "The group doesn't have this amount of money on the bank!", 225, 0, 0 )
				end
			end
		end
	end
)

-- When the player delete a group invite
addEvent( "onServerDeleteGroupInvite", true )
addEventHandler( "onServerDeleteGroupInvite", root,
	function ( groupID )
		local playerID = exports.server:playerID( source )
		exports.DENmysql:exec( "DELETE FROM groups_invites WHERE groupid=? AND memberid=?", groupID, playerID )
	end
)

-- When the player accept a group invite
addEvent( "onServerAcceptGroupInvite", true )
addEventHandler( "onServerAcceptGroupInvite", root,
	function ( groupID )
		local playerID = exports.server:playerID( source )
		local playerAccount = exports.server:getPlayerAccountName ( source )
		local groupTable = exports.DENmysql:querySingle( "SELECT * FROM groups WHERE groupid=? LIMIT 1", groupID )
		if ( groupTable ) then
			exports.DENmysql:exec( "DELETE FROM groups_invites WHERE memberid=?", playerID )
			exports.DENmysql:exec( "INSERT INTO groups_members SET groupid=?, memberid=?, membername=?, groupname=?, grouprank=?", groupTable.groupid, playerID, playerAccount, groupTable.groupname, "Trial" )
			setElementData( source, "Group", groupTable.groupname )
			setElementData( source, "GroupID", groupTable.groupid )
			setElementData( source, "GroupRank", groupTable.grouprank )
			exports.DENchatsystem:outPutGroupMessageByPlayer( source, getPlayerName( source ).." has joined the group!" )
			triggerClientEvent( source, "onClientHideGroupsWindow", source )
		end
	end
)

-- Send a note to all players
addEvent( "onServerSendNoteToAllPlayers", true )
addEventHandler( "onServerSendNoteToAllPlayers", root,
	function ( theMessage )
		exports.DENchatsystem:outPutGroupMessageByPlayer( source, "[GROUP NOTE] " .. getPlayerName( source ) .. ": "..theMessage )
	end
)

-- Send a note to a selected player
addEvent( "onServerSendNoteToPlayer", true )
addEventHandler( "onServerSendNoteToPlayer", root,
	function ( thePlayer, theMessage )
		outputChatBox( "[GROUP MESSAGE] " .. getPlayerName( source ) .. ": "..theMessage, thePlayer, 200, 0, 0 )
	end
)

-- When a new player gets invited
addEvent( "onServerGroupInvitePlayer", true )
addEventHandler( "onServerGroupInvitePlayer", root,
	function ( thePlayer )
		local playerID = exports.server:playerID( thePlayer )
		local groupID = exports.server:getPlayerGroupID( source )
		local groupName = getElementData( source, "Group" )
		local groupInvite = exports.DENmysql:querySingle( "SELECT * FROM groups_invites WHERE memberid=? AND groupid=? LIMIT 1", playerID, groupID )
		local groupMembers = exports.DENmysql:query( "SELECT * FROM groups_members WHERE groupid=?", groupID )
		if ( groupInvite ) then
			exports.DENhelp:createNewHelpMessageForPlayer( source, "This player is already invited for your group!", 0, 225, 0 )
		elseif ( #groupMembers >= 50 ) then
			exports.DENhelp:createNewHelpMessageForPlayer( source, "Your group already has reached the maximum amount of members! (50)", 0, 225, 0 )
		else
			exports.DENmysql:exec( "INSERT INTO groups_invites SET groupid=?, memberid=?, groupname=?, invitedby=?" ,groupID, playerID, groupName, getPlayerName( source ) )
			exports.DENchatsystem:outPutGroupMessageByPlayer( source, getPlayerName( source ).." invited "..getPlayerName( thePlayer ) )
			exports.DENhelp:createNewHelpMessageForPlayer( thePlayer, getPlayerName( source ).." invited you for the group "..groupName, 0, 225, 0 )
		end
	end
)

-- When a player get kicked
addEvent( "onServerGroupPlayerKicked", true )
addEventHandler( "onServerGroupPlayerKicked", root,
	function ( accountName, thePlayer )	
		exports.DENchatsystem:outPutGroupMessageByPlayer( source, getPlayerName( source ).." kicked "..accountName )
		exports.DENmysql:exec( "DELETE FROM groups_members WHERE membername=?", accountName )
		if ( thePlayer ) then
			setElementData( thePlayer, "Group", false )
			setElementData( thePlayer, "GroupID", false )
			setElementData( thePlayer, "GroupRank", false )
			triggerClientEvent( thePlayer, "onClientHideGroupsWindow", source )
		end
	end
) 

-- Change turf color
addEvent( "onServerGroupApplyTurfColor", true )
addEventHandler( "onServerGroupApplyTurfColor", root,
	function ( R, G, B )
		local groupID = exports.server:getPlayerGroupID( source )
		local colorString = R.."," .. G .. ","..B
		exports.DENmysql:exec( "UPDATE groups SET turfcolor=? WHERE groupid=?", colorString, groupID )
		exports.DENchatsystem:outPutGroupMessageByPlayer( source, getPlayerName( source ).." changed the turf color!" )
	end
)

-- Set new group leader
addEvent( "onServerGroupApplyNewFounder", true )
addEventHandler( "onServerGroupApplyNewFounder", root,
	function ( accountName, thePlayer )
		local playerID = exports.server:playerID( source )
		local groupID = exports.server:getPlayerGroupID( source )
		exports.DENmysql:exec( "UPDATE groups_members SET grouprank=? WHERE membername=?", "Group founder", accountName )
		exports.DENmysql:exec( "UPDATE groups_members SET grouprank=? WHERE memberid=?", "Group leader", playerID )
		exports.DENmysql:exec( "UPDATE groups SET groupleader=? WHERE groupid=?", groupID, accountName )
		exports.DENchatsystem:outPutGroupMessageByPlayer( source, getPlayerName( source ).." gave the leadership of the group to "..accountName )
		if ( thePlayer ) then
			setElementData( thePlayer, "GroupRank", "Group founder" )
			triggerClientEvent( thePlayer, "onClientHideGroupsWindow", source )
		end
		setElementData( source, "GroupRank", "Group leader" )
		triggerClientEvent( source, "onClientHideGroupsWindow", source )
	end
)

-- Promote member
addEvent( "onServerPromoteMember", true )
addEventHandler( "onServerPromoteMember", root,
	function ( thePlayer, accountName, newRank, theRow )
		exports.DENmysql:exec( "UPDATE groups_members SET grouprank=? WHERE membername=?", newRank, accountName )
		for k, thePlayer in ipairs ( getGroupPlayers ( getElementData( source, "Group" ) ) ) do triggerClientEvent( thePlayer, "onClientUpdateRankRow", thePlayer, theRow, newRank ) end
		exports.DENchatsystem:outPutGroupMessageByPlayer( source, getPlayerName( source ).." promoted " .. accountName .. " to "..newRank )
		
		if ( thePlayer ) then
			setElementData( thePlayer, "groupRank", newRank )
		end
	end
)

-- Demote member
addEvent( "onServerDemoteMember", true )
addEventHandler( "onServerDemoteMember", root,
	function ( thePlayer, accountName, newRank, theRow )
		exports.DENmysql:exec( "UPDATE groups_members SET grouprank=? WHERE membername=?", newRank, accountName )
		for k, thePlayer in ipairs ( getGroupPlayers ( getElementData( source, "Group" ) ) ) do triggerClientEvent( thePlayer, "onClientUpdateRankRow", thePlayer, theRow, newRank ) end
		exports.DENchatsystem:outPutGroupMessageByPlayer( source, getPlayerName( source ).." demoted " .. accountName .. " to "..newRank )
		
		if ( thePlayer ) then
			setElementData( thePlayer, "groupRank", newRank )
		end
	end
)

-- Delete group
addEvent( "onServerDeleteGroup", true )
addEventHandler( "onServerDeleteGroup", root,
	function ( username, password, groupID )
		local accountCheck = exports.DENmysql:querySingle( "SELECT * FROM accounts WHERE username=? AND password=? LIMIT 1", username, password )
		if ( accountCheck ) then

			exports.DENmysql:exec( "DELETE FROM groups_members WHERE groupid=?", groupID )
			exports.DENmysql:exec( "DELETE FROM groups_invites WHERE groupid=?", groupID )
			exports.DENmysql:exec( "DELETE FROM groups WHERE groupid=?", groupID )
			
			exports.DENchatsystem:outPutGroupMessageByPlayer( source, getPlayerName( source ).." deleted the group!" )
			
			for k, thePlayer in ipairs ( getGroupPlayers ( getElementData( source, "Group" ) ) ) do
				setElementData( thePlayer, "groupRank", false )
				setElementData( thePlayer, "Group", false )
				triggerClientEvent( thePlayer, "onClientFinishGroupCreate", thePlayer )
			end
		else
			exports.DENhelp:createNewHelpMessageForPlayer( source, "The password doesn't match with the username from the groupleader!", 225, 0, 0 )
		end
	end
)

-- When the player quit save the last online time
addEventHandler( "onPlayerQuit", root,
	function ()
		local playerID = exports.server:playerID( source )
		exports.DENmysql:exec( "UPDATE groups_members SET lastonline=? WHERE memberid=?", getRealTime().timestamp, playerID )
	end
)