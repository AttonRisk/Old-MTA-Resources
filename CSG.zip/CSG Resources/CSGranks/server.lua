local pilotRanks = {
	[0]= "Student Pilot",
	[20] = "Amature Pilot",
	[50] = "Private Pilot",
	[100] = "First Officer",
	[130] = "Senior First Officer",
	[170] = "Captain",
	[240] = "Flight Captain",
	[300] = "Senior Flight Captain",
	[360] = "Commercial Captain",
	[400] = "Pilot Intructor"
}

local busdriverRanks = {
	[0] = "Bus Driver In Training",
	[15] = "New Bus Driver",
	[45] = "Trained Bus Driver",
	[200] = "Experienced Bus Driver",
	[300] = "Senior Bus Driver",
	[400] = "Lead Bus Driver",
	[500] = "Chief Bus Driver",
	[1000] = "Head Bus Driver",
	[2000] = "SA Busing CEO"
}

local policeRanks = {}
local paramedicRanks = {}
local firefighterRanks = {}
local wastecollectorRanks = {}
local mechanicRanks = {}
local hookerRanks = {}
local truckerRanks = {}

local occupationToStat = {
	["Pilot"] = "pilot",
	["Police Officer"] = "arrests",
	["Paramedic"] = "paramedic",
	["Firefighter"] = "firefighter",
	["Waste Collector"] = "wastecollector",
	["Bus Driver"] = "busdriver",
	["Mechanic"] = "mechanic",
	["Hooker"] = "hooker",
	["Trucker"] = "trucker"
}

local occupationToRank = {
	["Pilot"] = pilotRanks,
	["Police Officer"] = policeRanks,
	["Paramedic"] = paramedicRanks,
	["Firefighter"] = firefighterRanks,
	["Waste Collector"] = wastecollectorRanks,
	["Bus Driver"] = busdriverRanks,
	["Mechanic"] = mechanicRanks,
	["Hooker"] = hookerRanks,
	["Trucker"] = truckerRanks
}

local hasJobRanks = { ["Pilot"]=true, ["Police Officer"]=true, ["Paramedic"]=true, ["Firefighter"]=true, ["Waste Collector"]=true, ["Bus Driver"]=true, ["Mechanic"]=true, ["Hooker"]=true, ["Trucker"]=true }

-- Check the occupation whenever needed
addEventHandler( "onElementDataChange", root,
	function ( theName, theValue )
		if ( theName == "Occupation" ) then
			local theOccupation = getElementData( source, "Occupation" )
			if ( hasJobRanks[theOccupation] ) then
				local theRank = getPlayerRank ( source, theOccupation )
				if ( theRank ) then
					setElementData( source, "Rank", theRank )
				else
					setElementData( source, "Rank", theOccupation )
				end
			else
				setElementData( source, "Rank", theOccupation )
			end
		end
	end
)

-- Get the ranks of the player
function getPlayerRank ( thePlayer, theOccupation )
	if ( isElement( thePlayer ) ) and ( theOccupation ) and ( hasJobRanks[theOccupation] ) then
		local rankTable = occupationToRank[theOccupation]
		local theStat = occupationToStat[theOccupation]
		if ( theStat ) then
			local rankStats = exports.DENstats:getPlayerStats( thePlayer, theStat )
			if ( rankTable ) and ( rankStats ) then
				local theRank = false
				for k, i in pairs ( rankTable ) do
					if not ( theRank ) then
						theRank = k
					elseif ( rankStats >= k ) then
						theRank = k
					else
						break;
					end
				end
				if ( theRank ) then return rankTable[theRank] else return false end
			else
				return false
			end
		else
			return false
		end
	else
		return false
	end
end