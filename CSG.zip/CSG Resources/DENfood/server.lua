function buySmallMenu ()
setElementHealth (source, getElementHealth(source) + 5)
takePlayerMoney (source, 10)
end

function buyMediumMenu ()
setElementHealth (source, getElementHealth(source) + 10)
takePlayerMoney (source, 20)
end

function buyBigMenu ()
setElementHealth (source, getElementHealth(source) + 15)
takePlayerMoney (source, 30)
end

function buySprunkDrink ()
setElementHealth (source, getElementHealth(source) + 3)
takePlayerMoney (source, 7)
end

function buyDonut()
setElementHealth (source, getElementHealth(source) + 10)
takePlayerMoney (source, 20)
end
addEvent ("buyDonut", true)
addEventHandler ("buyDonut", getRootElement(), buyDonut)
addEvent ("buySmallMenu", true)
addEventHandler ("buySmallMenu", getRootElement(), buySmallMenu)
addEvent ("buyBigMenu", true)
addEventHandler ("buyBigMenu", getRootElement(), buyBigMenu)
addEvent ("buyMediumMenu", true)
addEventHandler ("buyMediumMenu", getRootElement(), buyMediumMenu)
addEvent ("buySprunkDrink", true)
addEventHandler ("buySprunkDrink", getRootElement(), buySprunkDrink)