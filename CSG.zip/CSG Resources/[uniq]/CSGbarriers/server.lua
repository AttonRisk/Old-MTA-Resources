local barrier1 = {}
local barrier2 = {}
local barrier3 = {}
local barrier4 = {}

local col1 = {}
local col2 = {}
local col3 = {}
local col4 = {}

barrierSpam = {}

-- Create a barrier
function onPlayerCreateBarrier ( player, cmd, barrierType )
	if ( barrierType ) then
		local barrierType = tonumber(barrierType)
		local px, py, pz = getElementPosition( player )
		local rX, rY, rZ = getElementRotation( player )
		if ( not isPedInVehicle(player) ) then
			if (getTeamName(getPlayerTeam( player )) == "SWAT") or (getTeamName(getPlayerTeam( player )) == "Military Forces") or (getTeamName(getPlayerTeam( player )) == "Staff") then
				if not (( barrierType  < 1 ) or ( barrierType > 5 )) then
					if isPedOnGround ( player ) then
						if ( barrierType == 1 ) then
							barrier1[player] = createObject(1423, px, py, pz-0.25, 0, 0, rZ+180)
							col1[player] = createColSphere(px, py, pz-0.25, 1.5)
							setElementPosition(player, px+1, py, pz+1)
							setElementData( barrier1[player], "barrierCreator", player )
							setElementData( col1[player], "barrierColCreator", player )
							local object = barrier1[player]
							triggerUnbreakable (object)
						elseif ( barrierType == 2 ) then
							barrier2[player] = createObject(1423, px, py, pz-0.25, 0, 0, rZ+180)
							col2[player] = createColSphere(px, py, pz-0.25, 1.5)
							setElementPosition(player, px+1, py, pz+1)
							setElementData( barrier2[player], "barrierCreator", player )
							setElementData( col2[player], "barrierColCreator", player )
							local object = barrier2[player]
							triggerUnbreakable (object)
						elseif ( barrierType == 3 ) then
							barrier3[player] = createObject(1424, px, py, pz-0.38, 0, 0, rZ+180)
							col3[player] = createColSphere(px, py, pz-0.25, 1.5)
							setElementPosition(player, px+1, py, pz+1)
							setElementData( barrier3[player], "barrierCreator", player )
							setElementData( col3[player], "barrierColCreator", player )
							local object = barrier3[player]
							triggerUnbreakable (object)
						elseif ( barrierType == 4 ) then
							barrier4[player] = createObject(1424, px, py, pz-0.38, 0, 0, rZ+180)
							col4[player] = createColSphere(px, py, pz-0.25, 1.5)
							setElementPosition(player, px+1, py, pz)
							setElementData( barrier4[player], "barrierCreator", player )
							setElementData( col4[player], "barrierColCreator", player )
							local object = barrier4[player]
							triggerUnbreakable (object)
						end
					end
				end
			end
		end
	end
end

function triggerUnbreakable (object)
	for i,thePlayer in ipairs( getElementsByType("player") ) do 
		if ( exports.server:getPlayerAccountId(thePlayer) ) then
			triggerClientEvent("setBarriersUnBreakable", thePlayer, object )
		end
	end
end

function checkForBarriers (player, cmd, barrierType)
	if isTimer(barrierSpam[thePlayer]) then
		exports.DENhelp:createNewHelpMessageForPlayer(thePlayer, "You can only spawn a barrier once in 10 seconds!", 200, 0, 0)
	else
		if (isElement(barrier1[player])) then destroyElement(barrier1[player]) destroyElement(col1[player]) col1[player] = nil barrier1[player] = nil end
		if (isElement(barrier2[player])) then destroyElement(barrier2[player]) barrier2[player] = nil destroyElement(col2[player]) col2[player] = nil end
		if (isElement(barrier3[player])) then destroyElement(barrier3[player]) barrier3[player] = nil destroyElement(col3[player]) col3[player] = nil end
		if (isElement(barrier4[player])) then destroyElement(barrier4[player]) barrier4[player] = nil destroyElement(col4[player]) col4[player] = nil end
		onPlayerCreateBarrier ( player, cmd, barrierType )
		exports.DENhelp:createNewHelpMessageForPlayer(thePlayer, "Creating barrier!", 200, 0, 0)
		barrierSpam[player] = setTimer(function(player) barrierSpam[player] = nil end, 10000, 1, player)
	end
end
addCommandHandler( "barrier", checkForBarriers )

-- Delete all barriers and on playerquit
function deleteAllBarriers( player )
	if (isElement(barrier1[player])) then destroyElement(barrier1[player]) barrier1[player] = nil destroyElement(col1[player]) col1[player] = nil end
	if (isElement(barrier2[player])) then destroyElement(barrier2[player]) barrier2[player] = nil destroyElement(col2[player]) col2[player] = nil end
	if (isElement(barrier3[player])) then destroyElement(barrier3[player]) barrier3[player] = nil destroyElement(col3[player]) col3[player] = nil end
	if (isElement(barrier4[player])) then destroyElement(barrier4[player]) barrier4[player] = nil destroyElement(col4[player]) col4[player] = nil end
end
addCommandHandler( "deletebarriers", deleteAllBarriers )
addEventHandler( "onPlayerQuit", root, deleteAllBarriers )

addEvent("onBarrierGetDestroyed", true)
function onBarrierGetDestroyed()
	local player = getElementData( source, "barrierCreator" )
	local player2 = getElementData( source, "barrierColCreator" )
	if ( source == barrier1[player] ) or ( source == col1[player2] ) then
		if not player then player = player2 end
		destroyElement(barrier1[player]) barrier1[player] = nil
		destroyElement(col1[player]) col1[player] = nil
	elseif ( source == barrier2[player] ) or ( source == col2[player2] ) then
		if not player then player = player2 end
		destroyElement(barrier2[player]) barrier2[player] = nil
		destroyElement(col2[player]) col2[player] = nil
	elseif ( source == barrier3[player] ) or ( source == col3[player2] ) then
		if not player then player = player2 end
		destroyElement(barrier3[player]) barrier3[player] = nil
		destroyElement(col3[player]) col3[player] = nil
	elseif ( source == barrier4[player] ) or ( source == col4[player2] ) then
		if not player then player = player2 end
		destroyElement(barrier4[player]) barrier4[player] = nil
		destroyElement(col4[player]) col4[player] = nil
	end
end
addEventHandler("onBarrierGetDestroyed", root, onBarrierGetDestroyed)
