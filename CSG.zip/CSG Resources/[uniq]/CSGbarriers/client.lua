function onBarrierHitByWeapon( weapon, ammo, ammoInClip, hitX, hitY, hitZ, hitElement )
	if ( isElement ( hitElement ) ) then
		if (getElementType ( hitElement ) == "object") then
			if (getElementModel ( hitElement ) == 1423) or (getElementModel ( hitElement ) == 1424) then
				triggerServerEvent("onBarrierGetDestroyed", hitElement )
			end
		end
	end
end
addEventHandler("onClientPlayerWeaponFire", root, onBarrierHitByWeapon)

function onBarrierHitByExplosion( x, y, z, theType )
	for index, barrier in ipairs(getElementsByType("object")) do
		if (getElementModel ( barrier ) == 1423) or (getElementModel ( barrier ) == 1424) then
			local barrierx, barriery, barrierz = getElementPosition(barrier)
			local distance = getDistanceBetweenPoints2D(barrierx, barriery, x, y)
			if (distance <= 8) then
				triggerServerEvent("onBarrierGetDestroyed", barrier )
			end
		end
	end
end
addEventHandler("onClientExplosion", root, onBarrierHitByExplosion)

function onBarrierHitByVehicle ( hitElement, matchingDimension )
	if ( getElementType(hitElement) == "vehicle" ) then
		triggerServerEvent("onBarrierGetDestroyed", source )
	end
end
addEventHandler("onClientColShapeHit", root, onBarrierHitByVehicle)

addEvent("setBarriersUnBreakable", true)
function barriersUnBreakable (object)
setObjectBreakable(object,false)
end
addEventHandler("setBarriersUnBreakable", root, barriersUnBreakable)
