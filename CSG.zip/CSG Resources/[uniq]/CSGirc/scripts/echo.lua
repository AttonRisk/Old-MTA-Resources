﻿---------------------------------------------------------------------
-- Project: irc
-- Author: MCvarial
-- Contact: mcvarial@gmail.com
-- Version: 1.0.2
-- Date: 31.10.2010
---------------------------------------------------------------------

------------------------------------
-- Echo
------------------------------------

addEvent("onPlayerMainChat",true)
addEventHandler("onPlayerMainChat",root,
function ( theZone, theMessage )
	if not ( isGuestAccount( getPlayerAccount ( source ) )) then
		outputIRC("("..theZone..") "..getPlayerName(source)..": "..theMessage)
	end
end
)

addEvent("onPlayerSupportChat",true)
addEventHandler("onPlayerSupportChat",root,
function ( theMessage )
	if not ( isGuestAccount( getPlayerAccount ( source ) )) then
		outputIRC("(SUPPORT) "..getPlayerName(source)..": "..theMessage)
	end
end
)

addEvent("onServerNote",true)
addEventHandler("onServerNote",root,
function ( theMessage )
	if not ( isGuestAccount( getPlayerAccount ( source ) )) then
		outputIRC("(NOTE) "..getPlayerName(source)..": "..theMessage)
	end
end
)
