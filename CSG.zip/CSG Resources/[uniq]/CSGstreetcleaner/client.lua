trashTableLS = {
[0] = { 1066.76, -1322.67, 12.38}, 
[1] = { 1086.33, -1285.23, 12.38}, 
[2] = { 1123.18, -1276.59, 12.41},
[3] = { 1191.47, -1276.14, 12.29},
[4] = { 1220.64, -1229.74, 15.82},
[5] = { 1247.69, -1153.35, 22.58}, 
[6] = { 1284.09, -1136.66, 22.65 },
[7] = { 1267.07, -1098.49, 24.75 },
[8] = { 1257.76, -1074.79, 26.89 },
[9] = { 1281.26, -1043.68, 30.37 },
[10] = { 1318.29, -1033.2, 28.24 },
[11] = { 1360.01, -1026.2, 27.48 },
[12] = { 1393.23, -1039.85, 24.13 },
[13] = { 1432.28, -1029.67, 22.65 },
[14] = { 1470.55, -1038.91, 22.65 },
[15] = { 1522.2, -1044.45, 22.62 },
[16] = { 1565.06, -1070.62, 22.55 },
[17] = { 1572.93, -1148.14, 22.83 },
[18] = { 1643.04, -1165.57, 22.89 },
[19] = { 1670.54, -1156.28, 22.65 },
[20] = { 1710.34, -1174.46, 22.65 },
[21] = { 1719.37, -1269.44, 12.38 },
[22] = { 1738.49, -1304.42, 12.46 },
[23] = { 1807, -1259.45, 12.46 },
[24] = { 1861.82, -1250.11, 12.63}, 
[25] = { 1931.46, -1234.22, 17.3 },
[26] = { 1972.76, -1235.76, 19.05 },
[27] = { 2024.98, -1218.77, 20.88 },
[28] = { 2083.53, -1216.8, 22.8 },
[29] = { 2132.67, -1216.44, 22.81 },
[30] = { 2179.57, -1235.91, 22.82 },
[31] = { 2163.68, -1270.31, 22.82 },
[32] = { 2217.95, -1296.36, 22.82 },
[33] = { 2263.03, -1305.1, 22.82 },
[34] = { 2277.66, -1388.29, 22.91 },
[35] = { 2346.9, -1404.74, 22.81 },
[36] = { 2337.82, -1494, 22.83 },
[37] = { 2322.43, -1654.23, 12.86}, 
[38] = { 2264.93, -1663.58, 14.22 },
[39] = { 2224.14, -1645.03, 14.36 },
[40] = { 2187.98, -1661.67, 13.82 },
[41] = { 2180.41, -1724.66, 12.37 },
[42] = { 2220.79, -1771.14, 12.29 },
[43] = { 2214.06, -1879.18, 12.38 },
[44] = { 2149.82, -1899.13, 12.33 },
[45] = { 2114.91, -1889.63, 12.29 },
[46] = { 2086.55, -1916.67, 12.38 },
[47] = { 1966.23, -1921.71, 12.38 },
[48] = { 1933.04, -1928.9, 12.38 },
[49] = { 1896.91, -1927.97, 12.38 },
[50] = { 1826.37, -1882.43, 12.31 },
[51] = { 1706.16, -1816.78, 12.36 },
[52] = { 1631.74, -1867.4, 12.38},
[53] = { 1631.74, -1867.9, 12.38 },
[54] = { 1571.53, -1877.24, 12.38 },
[55] = { 1550.01, -1867.8, 12.38 },
[56] = { 1463.08, -1876.73, 12.38 },
[57] = { 1445.45, -1868.02, 12.39 },
[58] = { 1406.68, -1867.73, 12.38 },
[59] = { 1356.53, -1860.37, 12.38 },
[60] = { 1337.2, -1847.31, 12.54 },
[61] = { 1317.23, -1813.64, 12.38 },
[62] = { 1317.04, -1714.54, 12.38 },
[63] = { 1270.01, -1707.67, 12.38 },
[64] = { 1184.2, -1730.55, 12.39 },
[65] = { 1159.56, -1745.49, 12.39 },
[66] = { 1107.73, -1745.46, 12.39 },
[67] = { 1080.78, -1736.36, 12.53 },
[68] = { 1042.1, -1737.72, 12.38 },
[69] = { 1032.62, -1769.44, 12.37 },
[70] = { 998.01, -1784.21, 13.06 },
[71] = { 974.02, -1803.16, 13.08 },
[72] = { 918.87, -1792.47, 12.37 },
[73] = { 842.22, -1764.74, 12.39 },
[74] = { 805.91, -1734.71, 12.38 },
[75] = { 806.07, -1690.25, 12.38 },
[76] = { 810.81, -1639.92, 12.38 },
[77] = { 832.37, -1603.97, 12.38 },
[78] = { 821.98, -1593.87, 12.38 },
[79] = { 771.04, -1565.97, 12.38 },
[80] = { 790.16, -1467.36, 12.38 },
[81] = { 802.05, -1430.79, 12.39 },
[82] = { 811.43, -1391.41, 12.41 },
[83] = { 875.91, -1391.05, 12.3 },
[84] = { 905.97, -1410.21, 12.2 },
[85] = { 922.02, -1383.32, 12.25 },
[86] = { 912.72, -1357.34, 12.2 },
[87] = { 922.8, -1334.9, 12.38 },
[88] = { 963.69, -1331.3, 12.36 },
[89] = { 983.24, -1298.65, 12.38 },
[90] = { 1002.02, -1298.47, 12.38 },
[91] = { 1033.58, -1315.91, 12.38 },
[92] = { 1065.62, -1302.71, 12.38 },
[93] = { 991.78, -1347.09, 12.37 },
[94] = { 989.37, -1366.59, 12.37 },
[95] = { 1017.2, -1369.62, 12.38 },
[96] = { 1024.68, -1343.91, 12.72 },
[97] = { 1041.06, -1336.16, 12.55 },
[98] = { 1064.93, -1333.42, 12.38 },
}

trashTableSF = {
[0] = { -1945.97, -1085.79, 29.77 },
[1] = { -1803.55, 181.22, 13.95 },
[2] = { -1818.92, 232.08, 14.1 },
[3] = { -1770.9, 274.22, 9.79 },
[4] = { -1722.5, 288.22, 6.18 },
[5] = { -1685.84, 336, 6.18 },
[6] = { -1702.88, 370.7, 6.18 },
[7] = { -1681.8, 400.07, 6.17 },
[8] = { -1523.56, 492.88, 6.17 },
[9] = { -1570.23, 308.83, 6.18 },
[10] = { -1331.66, 342.76, 6.18 },
[11] = { -1470.21, 363.84, 6.18 },
[12] = { -1471.72, 415.5, 6.18 },
[13] = { -1496.37, 462.05, 6.18 },
[14] = { -1571.48, 590.12, 6.18 },
[15] = { -1487.99, 679.92, 6.17 },
[16] = { -1597.69, 772.82, 5.82 },
[17] = { -1572.53, 870.3, 6.37 },
[18] = { -1630.75, 874.6, 7.71 },
[19] = { -1696.47, 906.61, 23.89 },
[20] = { -1754.86, 951.96, 23.74 },
[21] = { -1930.01, 885.62, 34.41 },
[22] = { -1910.33, 822.08, 34.17 },
[23] = { -1886.61, 812.48, 34.94 },
[24] = { -1915.97, 792.18, 39.07 },
[25] = { -1888.29, 743.14, 44.44 },
[26] = { -1992.11, 744.24, 44.44 },
[27] = { -1993.07, 825.11, 44.44 },
[28] = { -2021.53, 921.49, 44.86 },
[29] = { -2038.28, 949.09, 48.75 },
[30] = { -2045.46, 900.9, 52.34 },
[31] = { -2071.03, 973.13, 61.92 },
[32] = { -2076.77, 909.43, 63.89 },
[33] = { -2092.38, 949.55, 69.78 },
[34] = { -2107.22, 909.04, 75.98 },
[35] = { -2131.7, 928.85, 79 },
[36] = { -2133.42, 1013.7, 79 },
[37] = { -2127.66, 1096.7, 79 },
[38] = { -2127.82, 1117.9, 72.42 },
[39] = { -2158.15, 1163.83, 54.72 },
[40] = { -2135.96, 1218.54, 46.27 },
[41] = { -2054.58, 1226.4, 30.64 },
[42] = { -2121.46, 1254.38, 19.13 },
[43] = { -2121.46, 1254.38, 19.13 },
[44] = { -2318.08, 1348.53, 6.18 },
[45] = { -2536, 1396.46, 6.18 },
[46] = { -2656.37, 1308.35, 6.81 },
[47] = { -2715.23, 1279.71, 6.19 },
[48] = { -2821.7, 1321.35, 6.1 },
[49] = { -2897.53, 1176.01, 11.29 },
[50] = { -2895.15, 1098.48, 26.86 },
[51] = { -2895.15, 1098.48, 26.86 },
[52] = { -2842.52, 942.83, 43.07 },
[53] = { -2804.21, 873.25, 42.9 },
[54] = { -2790.27, 765.47, 49.39 },
[55] = { -2741.16, 756.76, 52.53 },
[56] = { -2758.41, 717.91, 40.27 },
[57] = { -2757.58, 698.14, 40.27 },
[58] = { -2758.14, 638.35, 26.91 },
[59] = { -2758.27, 555.59, 13.55 },
[60] = { -2700.85, 508.83, 6.99 },
[61] = { -2696.02, 422.82, 3.33 },
[62] = { -2654.09, 379.34, 3.33 },
[63] = { -2690.3, 383.47, 3.37 },
[64] = { -2756.65, 374.73, 3.33 },
[65] = { -2699.08, 323.36, 3.75 },
[66] = { -2692.62, 267.36, 3.33 },
[67] = { -2660.11, 234.64, 3.33 },
[68] = { -2693.93, 207.66, 3.33 },
[69] = { -2671.89, 166.09, 3.32 },
[70] = { -2651.54, 121.35, 3.14 },
[71] = { -2637.42, 29.07, 3.33 },
[72] = { -2582.27, -9.07, 3.21 },
[73] = { -2509.75, -77.85, 24.61 },
[74] = { -2507.87, -119.2, 24.61 },
[75] = { -2490.74, -133.64, 24.62 },
[76] = { -2447.52, -122.51, 25.13 },
[77] = { -2480.37, -179.08, 24.61 },
[78] = { -2589.81, -202.74, 3.4 },
[79] = { -2752.48, -252.41, 6.18 },
[80] = { -2721.78, -315.12, 6.18 },
[81] = { -2828.94, -395.77, 6.18 },
[82] = { -2767.05, -509.72, 6.3 },
[83] = { -2675.72, -500.05, 19.13 },
[84] = { -2537.86, -360.98, 54.52 },
[85] = { -2344.71, -406.65, 78.53 },
[86] = { -2422.22, -410.75, 84.82 },
[87] = { -2593.68, -464.74, 67.35 },
[88] = { -2491.82, -472.29, 95.26 },
[89] = { -2385.05, -585.96, 131.11 },
[90] = { -2486.62, -612.96, 131.55 },
[91] = { -2349.67, -766.25, 95.33 },
[92] = { -2201.74, -776.85, 60.87 },
[93] = { -2214.49, -942.78, 39.38 },
[94] = { -2142.49, -948.11, 31.02 },
[95] = { -2110.36, -751.02, 31.17 },
[96] = { -1975.31, -728.86, 31.22 },
[97] = { -1931.02, -760.05, 31.2 },
[98] = { -1878.32, -858.91, 31.02 },
}

-- EventHandlers for showMarker

-- on occupation change
addEventHandler ( "onClientElementDataChange", root,
function ( dataName, oldValue )
	if ( dataName == "Occupation" ) then showMarker () end
end)

-- on team change
addEvent ( "onClientPlayerTeamChange" )
addEventHandler ("onClientPlayerTeamChange", root, 
	function ()
		setTimer ( showMarker, 500, 1 )
	end
)

-- create/destroy markers where you get orders/payout and destroy other elements on change
function showMarker ()
local cleaningPoints = getElementData(localPlayer, "cp")
	if ( getPlayerTeam(localPlayer) ) and (getElementData(localPlayer, "Occupation") == "Street Cleaner") and (getTeamName(getPlayerTeam(localPlayer)) == "Civilian Workers") then
		if not ( startFinishMarkerLS ) or ( startFinishMarkerSF ) then
			local startFinishMarkerLS = createMarker (2182.77, -1996.07, 12.54 , "cylinder", 3, 255, 165, 0, 200)
			local startFinishMarkerSF = createMarker (-2090.31, 95.32, 34.32 ,"cylinder", 3, 255, 165, 0, 200)
			addEventHandler("onClientMarkerHit", startFinishMarkerLS, onStartFinishTrashJob )
			addEventHandler("onClientMarkerHit", startFinishMarkerSF, onStartFinishTrashJob )
			setElementData(localPlayer, "cp", 0)
			setElementData(localPlayer, "streetCleanerMarkers", true)
		end
	elseif ( streetCleanerMarkers ) then
		removeEventHandler("onClientMarkerHit", startFinishMarkerLS, onStartFinishTrashJob )
		removeEventHandler("onClientMarkerHit", startFinishMarkerSF, onStartFinishTrashJob )
		destroyElement ( startFinishMarkerLS )
		destroyElement ( startFinishMarkerSF )
		setElementData(localPlayer, "cp", 0)
		setElementData(localPlayer, "streetCleanerMarkers", false)
		if ( theTrashBlip ) or ( theTrashCol ) or ( theTrashObject ) then
			destroyTrashMarkers ()
		end
	end
end
addEventHandler ( "onClientPlayerLogin", getLocalPlayer(), showMarker)
addEventHandler( "onClientResourceStart", getResourceRootElement ( getThisResource () ), showMarker)

-- start and finish of the job
function onStartFinishTrashJob ( hitElement, matchingDimension )
local cleaningPoints = getElementData(localPlayer, "cp")
	if ( hitElement == localPlayer ) and ( matchingDimension ) then
		if (getElementData(localPlayer, "Occupation") == "Street Cleaner") and (getTeamName(getPlayerTeam(localPlayer)) == "Civilian Workers") then
			if (getPedOccupiedVehicle ( localPlayer )) and ( ( getElementModel (getPedOccupiedVehicle ( localPlayer )) ) == 574 ) then
				if ( cleaningPoints > 5 ) then
					local amount = tonumber((getElementData(localPlayer, "cp"))*500)
					local amount2 = tonumber(getElementData(localPlayer, "cp"))
					triggerServerEvent("streetCleanerPayout", localPlayer, amount, amount2)
					exports.DENhelp:createNewHelpMessage("You made the city a bit cleaner, here is your " .. amount .. " reward", 0, 220, 0)
					setElementData(localPlayer, "cp", 0)
					destroyTrashMarkers ()
				elseif ( cleaningPoints == 0 ) then
					createTrash ()
				elseif ( cleaningPoints < 5 ) and ( cleaningPoints > 0 ) then
					exports.DENhelp:createNewHelpMessage("You'll have to come with more before we pay you!", 0, 220, 0)
				end
			end
		end
	end
end

-- when someone hits the trash object  remove it and pick a new one/tell the person to go back.
function onTrashHit ( hitElement, matchingDimension )
local cleaningPoints = getElementData(localPlayer, "cp")
	if (theTrashCol) then
		if ( source == theTrashCol ) and ( matchingDimension ) then
			if ( hitElement == localPlayer ) then
				if (getElementData(localPlayer, "Occupation") == "Street Cleaner") and (getTeamName(getPlayerTeam(localPlayer)) == "Civilian Workers") then
					if getPedOccupiedVehicle(localPlayer) and (getElementModel(getPedOccupiedVehicle(localPlayer)) == 574 ) then
						destroyTrashMarkers ()
						local points = (getElementData(localPlayer, "cp") +1)
						setElementData(localPlayer, "cp", points)
						local newCleaningPoints = getElementData(localPlayer, "cp")
						if ( newCleaningPoints == 20 ) then
							exports.DENhelp:createNewHelpMessage("Your sweeper is full, empty it at the drop off", 0, 220, 0)
						end
						if ( newCleaningPoints < 20 ) then
							createTrash ()
						end
					end
				end
			end
		end
	end
end

-- when player leaves the sweeper
addEventHandler("onClientPlayerVehicleExit", root, forVehicleLeave)
function forVehicleLeave (vehicle, seat)
	if ( theTrashBlip ) or ( theTrashCol ) or ( theTrashObject ) then
	local cleaningPoints = getElementData(localPlayer, "cp")
		if (getElementData(localPlayer, "Occupation") == "Street Cleaner") and (getTeamName(getPlayerTeam(localPlayer)) == "Civilian Workers") then
			if ( ( getElementModel ( vehicle ) ) == 574 ) then
				if ( cleaningPoints ) and (cleaningPoints > 0) then
					exports.DENhelp:createNewHelpMessage("You have left the vehicle! If you want another order go back to the drop off.", 0, 220, 0)
					setElementData(localPlayer, "cp", 0)
					if ("streetCleanerObjects") then
						setElementData(localPlayer, "cp", 0)
						destroyTrashMarkers ()
						setElementData (localPlayer, "streetCleanerObjects", false)
					end
				elseif (cleaningPoints == 0) then
					if ("streetCleanerObjects") then
					exports.DENhelp:createNewHelpMessage("You have left the vehicle! If you want another order go back to the drop off.", 0, 220, 0)
					setElementData(localPlayer, "cp", 0)
					destroyTrashMarkers ()
					setElementData (localPlayer, "streetCleanerObjects", false)
					end
				end
			end
		end
	end
end

-- when player dies inside the sweeper
addEventHandler("onClientPlayerWasted", root,
function ()	
	if (startFinishMarkerLS) or (startFinishMarkerSF) then
	local cleaningPoints = getElementData(localPlayer, "cp")
		if (getElementData(localPlayer, "Occupation") == "Street Cleaner") and (getTeamName(getPlayerTeam(localPlayer)) == "Civilian Workers") then
			if ("streetCleanerObjects") then
				exports.DENhelp:createNewHelpMessage("You have left the vehicle! If you want another order go back to the drop off.", 0, 220, 0)
				setElementData(localPlayer, "cp", 0)
				destroyTrashMarkers ()
				setElementData (localPlayer, "streetCleanerObjects", false)
			elseif (cleaningPoints) and (cleaningPoints == 20) then
				exports.DENhelp:createNewHelpMessage("You have left the vehicle! If you want another order go back to the drop off.", 0, 220, 0)
				setElementData(localPlayer, "cp", 0)
				destroyTrashMarkers ()
			end
		end
	end
end)

function destroyTrashMarkers ()
	destroyElement ( theTrashBlip )
	destroyElement ( theTrashCol )
	destroyElement ( theTrashObject )
end

function createTrash ()
	if (startFinishMarkerLS) or (startFinishMarkerSF) then
		local cleaningPoints = getElementData(localPlayer, "cp")
		if ((exports.server:getPlayChatZone(localPlayer)) == "LS" ) then theTable = trashTableLS elseif ((exports.server:getPlayChatZone(localPlayer)) == "SF" ) then theTable = trashTableSF end
		if ( theTable ) then
			local ID = math.random(0,98)
			theTrashCol = createColSphere (theTable[ID][1], theTable[ID][2], theTable[ID][3], 3)
			theTrashObject = createObject (2838, theTable[ID][1], theTable[ID][2], theTable[ID][3])
			theTrashBlip = createBlip (theTable[ID][1], theTable[ID][2], theTable[ID][3], 0, 3, 0, 255, 0, 255, 99999, localplayer)
			setElementData (localPlayer, "streetCleanerObjects", true)
			addEventHandler( "onClientColShapeHit", theTrashCol, onTrashHit )
			if ( cleaningPoints >= 5 ) then
				exports.DENhelp:createNewHelpMessage("Clean the street from the garbage or go back to the drop off!", 0, 220, 0)
			elseif ( cleaningPoints < 5 ) then
				exports.DENhelp:createNewHelpMessage("Clean the street from the garbage!", 0, 220, 0)
			end
		end
	end
end
