addEvent( "streetCleanerPayout", true )
function streetCleanerPayout ( amount, amount2 )
	givePlayerMoney ( source , amount )
	exports.DENstats:updatePlayerStats ( thePlayer, "wastecollector", amount2, true )
end
addEventHandler( "streetCleanerPayout", root, streetCleanerPayout )