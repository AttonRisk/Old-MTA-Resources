-- Create Col in LV
local LVcol = createColCuboid ( 889.06, 557.21, -10, 2500, 2800, 80 )

-- Check if player is in LV
addEvent( "isPlayerInLvColShape", true )
function isPlayerInLvColShape()
	setElementData ( source, "isPlayerInLvCol", false )
	if isElementWithinColShape ( source, LVcol ) then
		setElementData ( source, "isPlayerInLvCol", true )
	end
end
addEventHandler( "isPlayerInLvColShape", root, isPlayerInLvColShape )