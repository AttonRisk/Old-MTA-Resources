local jailPoints = {
{1535.93, -1670.89, 13, "LS1"},
{638.95, -571.69, 15.81, "LS2"},
{-2166.05, -2390.38, 30.04, "LS3"},
{-1606.34, 724.44, 11.53, "SF1"},
{-1402.04, 2637.7, 55.25, "SF2"},
{2290.46, 2416.55, 10.3, "LV1"},
{-208.63, 978.9, 18.73, "LV2"}
}

local theColBlips = {}

function onColJailMakrerHit ( thePlayer )
	if getElementData ( thePlayer, "isPlayerArrested" ) then
		local theJailPoint = getElementData ( source, "jailPoint" )
		local theOfficer = getElementData ( thePlayer, "arrestedBy" )
		triggerServerEvent ( "onJailArrestedPlayers", theOfficer, theJailPoint, localPlayer )
	end
end

for ID in pairs(jailPoints) do 
	local x, y, z = jailPoints[ID][1], jailPoints[ID][2], jailPoints[ID][3] 
	local jailPoint = jailPoints[ID][4] 
	theColShape = createColSphere ( x, y, z, 6 )
	setElementData ( theColShape, "jailPoint", jailPoint )
	addEventHandler ( "onClientColShapeHit", theColShape, onColJailMakrerHit)
end

addEvent("onCreateJailPoints", true)
function onCreateJailPoints ()
	onRemoveJailPoints ()
	for i=1,7 do 
		local x, y, z = jailPoints[i][1], jailPoints[i][2], jailPoints[i][3] 
		theColBlips[i] = createBlip ( x, y, z, 30, 3, 0, 0, 255, 255, 50 )
	end
end
addEventHandler("onCreateJailPoints", root, onCreateJailPoints)

addEvent("onPlayerSetArrested", true)
function onPlayerSetArrested ()
	triggerEvent( "onPlayerArrest", localPlayer )
end
addEventHandler("onPlayerSetArrested", root, onPlayerSetArrested)

addEvent("onRemoveJailPoints", true)
function onRemoveJailPoints ()
	for i=1,7 do
		if ( theColBlips[i] ) then
			destroyElement(theColBlips[i])
		end
	end
	theColBlips = {}
end
addEventHandler("onRemoveJailPoints", root, onRemoveJailPoints)

-- When the player got arrested make him follow the cop
addEvent("onClientFollowTheCop", true)
function onClientFollowTheCop ( officer, arrestedPerson )
	if ( officer ) then
		local prisoner = source or arrestedPerson
		local officerX, officerY, officerZ = getElementPosition ( officer )
		local prisonerX, prisonerY, prisonerZ = getElementPosition ( prisoner )
		local distance = getDistanceBetweenPoints3D ( officerX, officerY, officerZ, prisonerX, prisonerY, prisonerZ )	
		if ( getElementData ( prisoner, "isPlayerArrested" ) ) then
			local officerRotation = ( 360 - math.deg ( math.atan2 ( ( officerX - prisonerX ), ( officerY - prisonerY ) ) ) ) % 360
			setPedRotation ( prisoner, officerRotation )
			
			if ( getElementDimension( prisoner ) ~= getElementDimension( officer ) ) then
				exports.server:setClientPlayerDimension( prisoner, getElementDimension( officer ) )
			end
		
			if ( getElementInterior( prisoner ) ~= getElementInterior( officer ) ) then
				exports.server:setClientPlayerInterior( prisoner, getElementInterior( officer ) )
			end
			
			if ( distance > 9 ) and ( isPedInVehicle ( officer ) ) and not ( isPedInVehicle ( prisoner ) ) then
				triggerServerEvent( "onReleasePlayerFromArrest", prisoner, officer )
				setControlState ( "sprint", true )
				setControlState ( "walk", false )
				setControlState ( "forwards", true )
				setControlState ( "jump", true )
			elseif ( distance > 15 ) then
				setControlState ( "sprint", true )
				setControlState ( "walk", false )
				setControlState ( "forwards", true )
				setControlState ( "jump", true )
				setElementPosition (prisoner, officerX + 1, officerY + 1, officerZ)
				setTimer ( onClientFollowTheCop, 500, 1, officer, prisoner )
			elseif ( distance > 9 ) then
				setControlState ( "sprint", true )
				setControlState ( "walk", false )
				setControlState ( "forwards", true )
				setTimer ( onClientFollowTheCop, 500, 1, officer, prisoner )
			elseif ( distance > 6 ) then
				setControlState ( "sprint", false )
				setControlState ( "walk", false )
				setControlState ( "forwards", true )
				setTimer ( onClientFollowTheCop, 500, 1, officer, prisoner )
			elseif ( distance > 1.5 ) then
				setControlState ( "sprint", false )
				setControlState ( "walk", true )
				setControlState ( "forwards", true )
				setTimer ( onClientFollowTheCop, 500, 1, officer, prisoner )
			elseif ( distance < 1.5 ) then
				setControlState ( "sprint", false )
				setControlState ( "walk", false )
				setControlState ( "forwards", false )
				setTimer ( onClientFollowTheCop, 500, 1, officer, prisoner )
			end
			
			if ( isControlEnabled ( "fire" ) ) then
				toggleAllControls ( false, true, false )
			end
			
			if not ( isPedInVehicle ( prisoner ) ) then
				setCameraTarget ( prisoner, prisoner )
			end
			
			if ( isPedInVehicle ( officer ) ) then
				if not ( isPedInVehicle( prisoner ) ) then
					triggerServerEvent("warpPrisonerIntoVehicle", prisoner, officer)
				end
			end
			
			if ( isPedInVehicle ( prisoner ) ) and not ( isPedInVehicle( officer ) ) then
				triggerServerEvent("removePrisonerOutVehicle", prisoner, officer)
			end
		end
	end
end
addEventHandler("onClientFollowTheCop", root, onClientFollowTheCop)

-- The tazer script with checks
local tazerTable = {}

addEventHandler("onClientPlayerDamage", root, 
function( attacker, weapon, bodypart )
	if ( isElement( attacker ) ) and ( source == localPlayer) then
		if ( weapon == 23 ) and ( getPlayerTeam( attacker ) ) and not ( getTeamName( getPlayerTeam( attacker ) ) == "Staff" ) then
			if ( getElementData( source, "wantedPoints" ) >= 10 ) then
				if ( canCopTazer ( attacker, source ) ) then
					if not ( getElementData ( source, "isPlayerArrested" ) ) then
						if not ( getElementData ( source, "isPlayerRobbing" ) ) or not ( getElementData ( source, "robberyFinished" ) ) then
							if not ( getElementData ( source, "isPlayerRobbing" ) ) and not ( getElementDimension( source ) == 1 ) or not ( getElementDimension( source ) == 2 ) or not ( getElementDimension( source ) == 3 ) then	
								local ax, ay, az = getElementPosition( attacker )
								local bx, by, bz = getElementPosition( source ) 
								if ( tazerTable[attacker] ) and ( getTickCount()-tazerTable[attacker] < 7000 ) or ( math.floor ( getDistanceBetweenPoints2D( ax, ay, bx, by ) ) > 14 ) then
									cancelEvent()
								elseif ( getElementData( attacker, "Occupation" ) == "K-9 Unit Officer" ) then
									cancelEvent()
									tazerTable[attacker] = getTickCount()
									triggerServerEvent( "onWantedPlayerGotTazerd", attacker, source, true )
								else
									cancelEvent()
									tazerTable[attacker] = getTickCount()
									triggerServerEvent( "onWantedPlayerGotTazerd", attacker, source )
								end
							end
						end
					end
				end
			end
		end
	end
end
)

-- Check if tazer is allowed
function canCopTazer ( officer, thePrisoner )
	if ( thePrisoner ) and ( officer ) and ( officer ~= thePrisoner ) and ( getTeamName( getPlayerTeam( officer ) ) ) and ( getTeamName( getPlayerTeam( thePrisoner ) ) ) then
		local attackerTeam = (getTeamName(getPlayerTeam(officer)))
		local sourceTeam = (getTeamName(getPlayerTeam(thePrisoner)))
		if getElementData ( thePrisoner, "isPlayerArrested" ) then
			return false
		elseif getElementData ( thePrisoner, "isPlayerJailed" ) then 
			return false
		elseif ( getElementData ( thePrisoner, "isPlayerRobbing" ) ) or ( getElementData ( thePrisoner, "robberyFinished" ) ) then
			return false
		elseif ( attackerTeam == "Police" ) then
			if ( sourceTeam == "SWAT" ) or ( sourceTeam  == "Military Forces" ) or ( sourceTeam == "Department of Defense" ) or ( sourceTeam == "Police" ) then
				return false
			else
				return true
			end
		elseif ( attackerTeam == "SWAT" ) then
			if ( sourceTeam == "SWAT" ) or ( sourceTeam  == "Military Forces" ) or ( sourceTeam == "Department of Defense" ) then
				return false
			elseif ( sourceTeam == "Police" ) and ( getElementData( thePrisoner, "wantedPoints" ) < 9 ) then
				return false
			else
				return true
			end
		elseif ( attackerTeam == "Military Forces" ) then
			if ( sourceTeam == "SWAT" ) or ( sourceTeam  == "Military Forces" ) or ( sourceTeam == "Department of Defense" ) then
				return false
			elseif ( sourceTeam == "Police" ) and ( getElementData( thePrisoner, "wantedPoints" ) < 9 ) then
				return false
			else
				return true
			end
		elseif ( attackerTeam == "Department of Defense" ) then
			if ( sourceTeam == "SWAT" ) or ( sourceTeam  == "Military Forces" ) or ( sourceTeam == "Department of Defense" ) then
				return false
			elseif ( sourceTeam == "Police" ) and ( getElementData( thePrisoner, "wantedPoints" ) < 9 ) then
				return false
			else
				return true
			end
		else
			return false
		end
	end
end

-- Stop damage when jailed or arrested.
function stopArrestPlayerDamage ( attacker, weapon, bodypart )
	if ( source ) and (getElementData ( source, "isPlayerArrested" )) or ( getElementData ( source, "isPlayerJailed" ) ) then
		cancelEvent()
		return
	end

	if ( isElement( attacker ) ) and ( getPlayerTeam( attacker ) ) and ( getElementType( attacker ) == "player" ) and ( source ) and ( attacker ~= source ) and ( getTeamName( getPlayerTeam( attacker ) ) ) and ( getTeamName( getPlayerTeam( source ) ) ) then
		local attackerTeam = (getTeamName(getPlayerTeam(attacker)))
		local sourceTeam = (getTeamName(getPlayerTeam(source)))
		if ( attackerTeam == "Police" ) then
			if ( sourceTeam == "SWAT" ) or ( sourceTeam  == "Military Forces" ) or ( sourceTeam == "Department of Defense" ) or ( sourceTeam == "Police" ) then
				cancelEvent()
			end
		elseif ( attackerTeam == "SWAT" ) then
			if ( sourceTeam == "SWAT" ) or ( sourceTeam  == "Military Forces" ) or ( sourceTeam == "Department of Defense" ) then
				cancelEvent()
			elseif ( sourceTeam == "Police" ) and ( getElementData( source, "wantedPoints" ) < 9 ) then
				cancelEvent()
			end
		elseif ( attackerTeam == "Military Forces" ) then
			if ( sourceTeam == "SWAT" ) or ( sourceTeam  == "Military Forces" ) or ( sourceTeam == "Department of Defense" ) then
				cancelEvent()
			elseif ( sourceTeam == "Police" ) and ( getElementData( source, "wantedPoints" ) < 9 ) then
				cancelEvent()
			end
		elseif ( attackerTeam == "Department of Defense" ) then
			if ( sourceTeam == "SWAT" ) or ( sourceTeam  == "Military Forces" ) or ( sourceTeam == "Department of Defense" ) then
				cancelEvent()
			elseif ( sourceTeam == "Police" ) and ( getElementData( source, "wantedPoints" ) < 9 ) then
				cancelEvent()
			end
		end
	end
end
addEventHandler ( "onClientPlayerDamage", localPlayer, stopArrestPlayerDamage )

-- Check if the attack is allowed
function isAttackNotAllowed (attacker, victim)
	if getElementData(victim, "wantedPoints") > 9 then
		if (getTeamName(getPlayerTeam(attacker)) == "SWAT") or (getTeamName(getPlayerTeam(attacker)) == "Police") or (getTeamName(getPlayerTeam(attacker)) == "Military Forces") or (getTeamName(getPlayerTeam(attacker)) == "Department of Defense") then
			return false
		else
			return true
		end
	else
		return true
	end
end

-- Check if the police are friends
function isActionNotAllowedForLaw ( attacker, victim )
	if ( victim ) and ( attacker ) and ( attacker ~= victim ) then
		if ( getTeamName( getPlayerTeam( attacker ) ) == "SWAT" ) or  ( getTeamName( getPlayerTeam( attacker ) ) == "Military Forces" ) or  ( getTeamName( getPlayerTeam( attacker ) ) == "Department of Defense" ) or  ( getTeamName( getPlayerTeam( attacker ) ) == "Police" ) then
			if ( getTeamName( getPlayerTeam( victim ) ) == "SWAT" ) or  ( getTeamName( getPlayerTeam( victim ) ) == "Military Forces" ) or ( getTeamName( getPlayerTeam( victim ) ) == "Department of Defense" ) or  ( getTeamName( getPlayerTeam( victim ) ) == "Police" ) then
				return false
			else
				return true
			end
		else
			return true
		end
	else
		return false
	end
end

-- When player damage let him fall of bike
addEventHandler( "onClientPlayerDamage", root,
function ( attacker, weapon, bodypart )
	if ( isPedInVehicle ( source ) ) then
		if ( source == localPlayer ) then
			local theVehicle = getPedOccupiedVehicle( source )
			local theHealth = getElementHealth( source )
			if ( theHealth < 20 ) then
				if ( getVehicleType ( theVehicle ) == "BMX" ) or ( getVehicleType ( theVehicle ) == "Bike" ) then
					triggerServerEvent( "onRemovePlayerFromBike", source )
				end
			end
		end
	end
end
)