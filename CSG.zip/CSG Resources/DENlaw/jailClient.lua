local theJailTimer = {}

-- Jail the player when needed
addEvent( "onSetPlayerJailedClient", true )
addEventHandler( "onSetPlayerJailedClient", root,
	function ( thePlayer, theTime )
		if ( isElement(thePlayer) ) and ( theTime ) then
			if ( theJailTimer[thePlayer] ) then
				theJailTime = tonumber(theTime)
				theJailed = thePlayer
				if ( getElementInterior( thePlayer ) ~= 0 ) then exports.server:setClientPlayerInterior( thePlayer, 0 ) end
				setElementPosition( thePlayer, 1587.6 + math.random(0.1,2.0), -809.61 + math.random(0.1,2.0), 350.650 )
				setElementRotation ( thePlayer, 0, 0, 183.27947998047 )
			else
				theJailed = thePlayer
				theJailTime = tonumber(theTime)
				addEventHandler( "onClientRender", root, onDrawJailTimer )
				theJailTimer[thePlayer] = setTimer( function () theJailTime = theJailTime -1 setElementData( thePlayer, "jailTime", theJailTime -1 ) end, 1000, 0 )
				if ( getElementInterior( thePlayer ) ~= 0 ) then exports.server:setClientPlayerInterior( thePlayer, 0 ) end
				setElementPosition( thePlayer, 1587.6 + math.random(0.1,2.0), -809.61 + math.random(0.1,2.0), 350.650 )
				setElementRotation ( thePlayer, 0, 0, 183.27947998047 )
			end 
		end
	end
)

-- Draw the jail timer
function onDrawJailTimer ()
	if ( theJailTime ) > 0 then
		local scx, scy = guiGetScreenSize()
		dxDrawText( theJailTime .. " Seconds Remaining  ", scx - 125,scy - 70,scx,scx,tocolor(255,255,255,255),0.9, "bankgothic","right","top",false,false,false )
	else
		removeEventHandler(	"onClientRender", root, onDrawJailTimer	)
		triggerServerEvent( "onSetPlayerUnjailed", theJailed )
		killTimer ( theJailTimer[theJailed] )
		theJailTimer[theJailed] = nil
	end
end