-- Release points for the jail
local jailPoints = {
["LS1"] = {1535.93, -1670.89, 13},
["LS2"] = {638.95, -571.69, 15.81},
["LS3"] = {-2166.05, -2390.38, 30.04},
["SF1"] = {-1606.34, 724.44, 11.53},
["SF2"] = {-1402.04, 2637.7, 55.25},
["LV1"] = {2290.46, 2416.55, 10.3},
["LV2"] = {-208.63, 978.9, 18.73}
}

-- Jail a player
function onSetPlayerJailed ( thePlayer, theTime, jailPlace, theJailer, reason, isAdminJail )
	local theJailTime = tonumber(theTime)
	if ( isElement(thePlayer) ) and ( theJailTime ) then
		if (isPedInVehicle(thePlayer)) then
			removePedFromVehicle(thePlayer)
		end
		-- Jail functions
		local userID = exports.server:playerID( thePlayer )
		showCursor ( thePlayer, false )
		togglePlayerControls ( thePlayer, false )
		giveWeapon ( thePlayer, 0, 0, true )
		setElementData ( thePlayer, "isPlayerJailed", true )
		local isPlayerAlreadyJailed = exports.DENmysql:querySingle( "SELECT * FROM jail WHERE userid = '" .. userID .. "'" )
		if ( jailPlace ) then theJailPlace = jailPlace else theJailPlace = "LS1" end
		if ( isAdminJail ) and ( isPlayerAlreadyJailed ) then	
			local remainingTime = getElementData ( thePlayer, "jailTime" )
			if ( remainingTime ) and ( tonumber(remainingTime) > 0 ) then
				remainTime = getElementData ( thePlayer, "jailTime" )
			else
				remainTime = 0
			end
			
			local totalTime = ( theJailTime + remainTime )
			
			local updateOldJailRow = exports.DENmysql:exec( "UPDATE jail SET jailtime=? WHERE userid = '" .. userID .. "'", tonumber(totalTime) )
		elseif ( isPlayerAlreadyJailed ) then
			local deleteOldJailRow = exports.DENmysql:exec( "DELETE FROM jail WHERE userid=?", userID )
			local addNewJailRow = exports.DENmysql:exec( "INSERT INTO jail SET userid=?, jailtime=?, jailplace=?", userID, tonumber(theJailTime), theJailPlace )
		else	
			local wantedPoints = getElementData ( thePlayer, "wantedPoints" )
			if ( wantedPoints ) and ( tonumber(wantedPoints) > 0 ) then
				wantedTime = ( math.floor(tonumber(wantedPoints) * 100 / 26 ) )
			else
				wantedTime = 0
			end
			
			local aTime = ( theJailTime + wantedTime )
			local addNewJailRow = exports.DENmysql:exec( "INSERT INTO jail SET userid=?, jailtime=?, jailplace=?", userID, tonumber(aTime), theJailPlace )
		end
		
		local getPlayerJailData = exports.DENmysql:querySingle( "SELECT * FROM jail WHERE userid = '" .. userID .. "'" )
		if ( getPlayerJailData ) then
			setElementData ( thePlayer, "jailTime", tonumber(getPlayerJailData.jailtime) )
			setElementDimension( thePlayer, 2 )
			if ( getElementInterior( thePlayer ) ~= 0 ) then setElementInterior( thePlayer, 0 ) end
			triggerClientEvent( thePlayer, "onSetPlayerJailedClient", thePlayer, thePlayer, tonumber(getPlayerJailData.jailtime) )
		else
			setElementData ( thePlayer, "jailTime", theJailTime )
			setElementDimension( thePlayer, 2 )
			if ( getElementInterior( thePlayer ) ~= 0 ) then setElementInterior( thePlayer, 0 ) end
			triggerClientEvent( thePlayer, "onSetPlayerJailedClient", thePlayer, thePlayer, theJailTime )
		end
		
		triggerEvent( "onServerPlayerJailed", thePlayer, tonumber( theJailTime ) )
		
		-- Output message when admin jail
		if ( isAdminJail ) and ( reason ) and ( theJailer ) then
			outputChatBox(""..getPlayerName(theJailer).." jailed ".. getPlayerName(thePlayer) .." for " .. tonumber(theJailTime) .. " seconds (" .. reason .. ")", root, 225, 0, 0 )
			triggerEvent( "onServerPlayerJailed", thePlayer, tonumber( theJailTime ), reason, theJailer )
		end
	end
end

-- Remove the player from the jail
addEvent( "onSetPlayerUnjailed", true )
function onSetPlayerUnjailed ( thePlayer, reason )
	local thePlayer = thePlayer or source
	if ( isElement(thePlayer) ) then
		local userID = exports.server:playerID( thePlayer )
		local getPlayerJailData = exports.DENmysql:querySingle( "SELECT * FROM jail WHERE userid = '" .. userID .. "'" )
		if ( getPlayerJailData ) then
			local deleteOldJailRow = exports.DENmysql:exec( "DELETE FROM jail WHERE userid = '" .. userID .. "'" )
			local jailPlace = getPlayerJailData.jailplace
			local x, y, z = jailPoints[jailPlace][1], jailPoints[jailPlace][2], jailPoints[jailPlace][3]
			setElementPosition ( thePlayer, x + math.random(0.1,4.0), y + math.random(0.1,4.0), z )
			setElementDimension ( thePlayer, 0 )
		end
		local setWantedPoints = exports.server:setPlayerWantedPoints(thePlayer, 0)
		setPlayerWantedLevel ( thePlayer, 0 )
		togglePlayerControls ( thePlayer, true )
		setElementData ( thePlayer, "isPlayerJailed", false )
		setElementData( thePlayer, "jailTime", 0 )
	end
end
addEventHandler( "onSetPlayerUnjailed", root, onSetPlayerUnjailed )

-- Disabled or enable the controls
function togglePlayerControls ( thePlayer, state )
	if ( thePlayer ) then
		toggleControl ( thePlayer, "fire", state )
		toggleControl ( thePlayer, "next_weapon", state )
		toggleControl ( thePlayer, "previous_weapon", state )
		toggleControl ( thePlayer, "aim_weapon", state )
	end
end

-- When the player quit we want to save the jail time
addEventHandler( "onPlayerQuit", root, 
function ()
	if getElementData ( source, "isPlayerJailed" ) then
		local userID = exports.server:playerID( source )
		local updateOldJailRow = exports.DENmysql:exec( "UPDATE jail SET jailtime=? WHERE userid = '" .. userID .. "'", tonumber(getElementData( source, "jailTime" )) )
	end
end
)