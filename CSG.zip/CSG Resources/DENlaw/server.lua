-- Update player wanted level
setTimer ( 
function ()
	for k, thePlayer in pairs ( getElementsByType( "player" ) ) do
		setPlayerNametagText( thePlayer, getPlayerName( thePlayer ).." (" .. tostring( getPlayerWantedLevel ( thePlayer ) ) .. ")" )
	end
end
, 5000 , 0)

addEventHandler( "onElementDataChange", root,
function ( dataName )
	if ( exports.server:getPlayerAccountName ( source ) ) then
		if ( dataName == "wantedPoints" ) then
			local wantedPoints = getElementData ( source, dataName )
			if ( wantedPoints > 9 ) and ( wantedPoints < 20 ) then
				setPlayerWantedLevel( source, 1 )
			elseif ( wantedPoints > 19 ) and ( wantedPoints < 29 ) then
				setPlayerWantedLevel( source, 2 )
			elseif ( wantedPoints > 29 ) and ( wantedPoints < 39 ) then
				setPlayerWantedLevel( source, 3 )
				removeJobDueWantedLevel( source, "Emergency" )
			elseif ( wantedPoints > 39 ) and ( wantedPoints < 49 ) then
				setPlayerWantedLevel( source, 4 )
				removeJobDueWantedLevel( source, "All Jobs" )
			elseif ( wantedPoints > 49 ) and ( wantedPoints < 59 ) then
				setPlayerWantedLevel( source, 5 )
				removeJobDueWantedLevel( source, "All Jobs" )
			elseif ( wantedPoints > 59 ) then
				setPlayerWantedLevel( source, 6 )
				removeJobDueWantedLevel( source, "All Jobs" )
			elseif ( wantedPoints < 10 ) then
				setPlayerWantedLevel( source, 0 )
			end
			setPlayerNametagText( source, getPlayerName( source ).." (" .. tostring( getPlayerWantedLevel ( source ) ) .. ")" )
		end
	end
end
)

-- Kick from job if the player is high wanted
function removeJobDueWantedLevel (thePlayer, type)
	if not ( getTeamName( getPlayerTeam( thePlayer ) ) == "Criminals" ) then
		if ( type == "Emergency" ) then
			if (getTeamName(getPlayerTeam(thePlayer)) == "Police") or (getTeamName(getPlayerTeam(thePlayer)) == "SWAT") 
			or (getTeamName(getPlayerTeam(thePlayer)) == "Military Forces") or (getTeamName(getPlayerTeam(thePlayer)) == "Paramedics") or (getTeamName(getPlayerTeam(thePlayer)) == "Department of Defense") then
		
			exports.DENcriminal:setPlayerCriminal( thePlayer )	
			triggerEvent( "onPlayerJobKick", thePlayer )
		
			end		
		elseif type == "All Jobs" then
	
			exports.DENcriminal:setPlayerCriminal( thePlayer )
		
		end
	end
end

local arrestTable = {}

-- Add a new player to the arrested table of the cop
function addCopArrestedPlayer ( theCop, thePrisoner )
	if not arrestTable[theCop] then 
		arrestTable[theCop] = {}
	end

	table.insert ( arrestTable[theCop], thePrisoner )
end
 
-- Remove a player from the arrest table of the cop
function removeCopArrestedPlayer ( theCop, thePrisoner )
	if arrestTable[theCop] then
		for i=1,#arrestTable[theCop] do
			if arrestTable[theCop][i] == thePrisoner then
				table.remove ( arrestTable[theCop], i )
			end
		end
	end
end

-- Get all the arrested players of the cop
function getCopArrestedPlayers ( theCop ) 
	return arrestTable[theCop] 
end

-- When the player got arrested by a nightstick
function onPlayerNightstickArrest ( attacker, weapon, bodypart, loss )
	if isElement(attacker) and (weapon == 3) then
	setElementHealth(source, getElementHealth( source ) + loss)
		if (getTeamName(getPlayerTeam(attacker)) == "Police") or (getTeamName(getPlayerTeam(attacker)) == "SWAT") or (getTeamName(getPlayerTeam(attacker)) == "Military Forces") or (getTeamName(getPlayerTeam(attacker)) == "Department of Defense") then
			if ( isArrestAllowedForLaw ( attacker, source ) ) then
				if canCopArrest (attacker, source) then
					if not(getElementData ( source, "isPlayerArrested" )) and ( getPlayerWantedLevel(source) > 0 ) then
						triggerEvent( "onPlayerNightstickHit", source, attacker )
						if ( not wasEventCancelled() ) then
							if ( getElementData ( source, "isPlayerRobbing" ) ) and ( getElementDimension( source ) == 1 ) or ( getElementDimension( source ) == 2 ) or ( getElementDimension( source ) == 3 ) then
								return
							else
								setElementData ( source, "isPlayerArrested", true )
								toggleAllControls ( source, false, true, false )
								giveWeapon ( source, 0, 0, true )
								triggerClientEvent( source, "onClientFollowTheCop", source, attacker, source)
								triggerClientEvent( source, "onPlayerSetArrested", source )
								exports.DENhelp:createNewHelpMessageForPlayer(source, "You got arrest by " .. getPlayerName(attacker) .. "!", 0, 225, 0)
								exports.DENhelp:createNewHelpMessageForPlayer(attacker, "You arrested " .. getPlayerName(source) .. "!", 0, 225, 0)
								addCopArrestedPlayer ( attacker, source )
								setElementData( source, "arrestedBy", attacker )
								setCameraTarget ( source, source )
								triggerEvent( "onPlayerArrest", source, attacker, getElementData( source, "wantedPoints" ) )
								onCheckForJailPoints ( attacker, true )
								showCursor ( source, true, true )
								
								setElementData ( source, "isPlayerRobbing", false )
								setElementData( source, "robberyFinished", false )
							end
						end
					end
				end
			end
		end
	end
end
addEventHandler ( "onPlayerDamage", root, onPlayerNightstickArrest )

function onCheckForJailPoints ( theCop, state )
	if state and arrestTable[theCop] then
		triggerClientEvent ( theCop, "onCreateJailPoints", theCop )
	elseif not state and #arrestTable[theCop] == 0 then
		triggerClientEvent ( theCop, "onRemoveJailPoints", theCop )
	else
		triggerClientEvent ( theCop, "onRemoveJailPoints", theCop )
	end
end

-- Function that warp a player into the vehicle
function warpPrisonerIntoVehicle (officer)
local officerVehicle = getPedOccupiedVehicle ( officer )
local officerVehicleSeats = getVehicleMaxPassengers( officerVehicle )
local officerVehicleOccupants = getVehicleOccupants( officerVehicle )
	for seat = 0, officerVehicleSeats do
		local occupant = officerVehicleOccupants[seat]
		if not occupant then
			warpPedIntoVehicle( source, officerVehicle, seat)		
		end
	end
end
addEvent("warpPrisonerIntoVehicle", true)
addEventHandler("warpPrisonerIntoVehicle", root, warpPrisonerIntoVehicle)

-- Function that removes a player out the vehicle
function removePrisonerOutVehicle (theOfficer)
	removePedFromVehicle ( source )
	local x, y, z = getElementPosition ( theOfficer )
	setElementPosition ( source, x + 2, y + 2, z )
end
addEvent("removePrisonerOutVehicle", true)
addEventHandler("removePrisonerOutVehicle", root, removePrisonerOutVehicle)

-- Function that checks if the cop can arrest
function canCopArrest( officer, thePrisoner )
	-- Check if the player already has 2 prisoners
	if ( arrestTable[officer] ) then
		if ( #arrestTable[officer] > 2 ) then
			return false
		else
			return true
		end
	else
		return true
	end
end

-- Check so Police can't arrest SWAT or MF and SWAT and MF can't arrest eachother
function isArrestAllowedForLaw ( officer, thePrisoner )
	if ( thePrisoner ) and ( officer ) and ( officer ~= thePrisoner ) and ( getTeamName( getPlayerTeam( officer ) ) ) and ( getTeamName( getPlayerTeam( thePrisoner ) ) ) then
		local attackerTeam = (getTeamName(getPlayerTeam(officer)))
		local sourceTeam = (getTeamName(getPlayerTeam(thePrisoner)))
		if ( attackerTeam == "Police" ) then
			if ( sourceTeam == "SWAT" ) or ( sourceTeam  == "Military Forces" ) or ( sourceTeam == "Department of Defense" ) or ( sourceTeam == "Police" ) then
				return false
			else
				return true
			end
		elseif ( attackerTeam == "SWAT" ) then
			if ( sourceTeam == "SWAT" ) or ( sourceTeam  == "Military Forces" ) or ( sourceTeam == "Department of Defense" ) then
				return false
			elseif ( sourceTeam == "Police" ) and ( getElementData( thePrisoner, "wantedPoints" ) < 9 ) then
				return false
			else
				return true
			end
		elseif ( attackerTeam == "Military Forces" ) then
			if ( sourceTeam == "SWAT" ) or ( sourceTeam  == "Military Forces" ) or ( sourceTeam == "Department of Defense" ) then
				return false
			elseif ( sourceTeam == "Police" ) and ( getElementData( thePrisoner, "wantedPoints" ) < 9 ) then
				return false
			else
				return true
			end
		elseif ( attackerTeam == "Department of Defense" ) then
			if ( sourceTeam == "SWAT" ) or ( sourceTeam  == "Military Forces" ) or ( sourceTeam == "Department of Defense" ) then
				return false
			elseif ( sourceTeam == "Police" ) and ( getElementData( thePrisoner, "wantedPoints" ) < 9 ) then
				return false
			else
				return true
			end
		end
	end
end

-- /release function of the cop
function releasePlayerFromArrest (officer, cmd, prisoner)
	if ( arrestTable[officer] ) then
		if ( prisoner == "*" ) then
			for i, element in ipairs ( arrestTable[officer] ) do
				exports.DENhelp:createNewHelpMessageForPlayer(element, "You are now free! RUN!", 0, 225, 0)
				setElementData ( element, "isPlayerArrested", false )
				toggleAllControls ( element, true, true, true )
				onCheckForJailPoints ( officer, false )
				showCursor ( element, false, false )
			end
			exports.DENhelp:createNewHelpMessageForPlayer(officer, "You released all players under your custody!", 0, 225, 0)
			arrestTable[officer] = {}
		else
			local getPrisoner = exports.server:getPlayerFromNamePart( prisoner )
			for i=1,#arrestTable[officer] do
				local thePrisoner = arrestTable[officer][i]
				if ( getPrisoner ) and ( getPrisoner == thePrisoner ) then
					exports.DENhelp:createNewHelpMessageForPlayer(officer, "You released ".. getPlayerName( thePrisoner ) .."!", 0, 225, 0)
					exports.DENhelp:createNewHelpMessageForPlayer(thePrisoner, "You are now free! RUN!", 0, 225, 0)
					setElementData ( thePrisoner, "isPlayerArrested", false )
					toggleAllControls ( thePrisoner, true, true, true )
					removeCopArrestedPlayer ( officer, thePrisoner )
					onCheckForJailPoints ( officer, false )
					showCursor ( thePrisoner, false )
				else
					exports.DENhelp:createNewHelpMessageForPlayer(officer, "We couldn't find a player with that name!", 225, 0, 0)
				end
			end
		end
	end
end
addCommandHandler("release", releasePlayerFromArrest)

-- Serverside part when player got tazerd, source is the officer
addEvent("onWantedPlayerGotTazerd", true)
function onWantedPlayerGotTazerd ( prisoner, dogTaz )
	if ( isElement( source ) ) then
		giveWeapon ( source, 3, 1, true )
	end
	
	if ( isElement(prisoner) ) then
		setPedAnimation(prisoner, "CRACK", "crckidle2")
		setTimer(setPedAnimation, 3000, 1, prisoner)
		giveWeapon ( prisoner, 0, 0, true )
		toggleAllControls ( prisoner, false, true, false )
		setTimer(toggleAllControls, 3000, 1, prisoner, true, true, true)		
	end
	
	if ( dogTaz ) then
		local theAnimal = exports.CSGanimals:getPlayerAnimal ( source )
		if ( theAnimal ) then
			exports.CSGanimals:setAnimalFollowing ( theAnimal, prisoner )
			setTimer( call, 6000, 1, getResourceFromName("CSGanimals"), "resetAnimalFollowing", theAnimal )
			setElementHealth( prisoner, getElementHealth( prisoner ) -5 )
		end
	end
end
addEventHandler("onWantedPlayerGotTazerd", root, onWantedPlayerGotTazerd)

-- Release when the cop dies
addEventHandler( "onPlayerWasted", root,
function( ammo, attacker, weapon, bodypart )
	if ( exports.server:getPlayerAccountName ( source ) ) then
		if (getTeamName(getPlayerTeam(source)) == "Police") or (getTeamName(getPlayerTeam(source)) == "SWAT") or (getTeamName(getPlayerTeam(source)) == "Military Forces") or (getTeamName(getPlayerTeam(source)) == "Department of Defense") then
			if arrestTable[source] then
				for i, element in ipairs ( arrestTable[source] ) do
					exports.DENhelp:createNewHelpMessageForPlayer(element, "The cop died! You're free again.", 0, 225, 0)
					setElementData ( element, "isPlayerArrested", false )
					toggleAllControls ( element, true, true, true )
					onCheckForJailPoints ( source, false )
					showCursor ( element, false, false )
				end
				arrestTable[source] = {}
			end
		end
	end
end
)

-- Release when the cop reconnect
addEventHandler( "onPlayerQuit", root,
function()
	if ( exports.server:getPlayerAccountName ( source ) ) then
		if ( getPlayerTeam( source ) ) and (getTeamName(getPlayerTeam(source)) == "Police") or (getTeamName(getPlayerTeam(source)) == "SWAT") or (getTeamName(getPlayerTeam(source)) == "Military Forces") or (getTeamName(getPlayerTeam(source)) == "Department of Defense") then
			if arrestTable[source] then
				for i, element in ipairs ( arrestTable[source] ) do
					exports.DENhelp:createNewHelpMessageForPlayer(element, "The cop disconnected! You're free again!", 0, 225, 0)
					setElementData ( element, "isPlayerArrested", false )
					toggleAllControls ( element, true, true, true )
					showCursor ( element, false, false )
				end
				arrestTable[source] = {}
			end
		end
	end
end
)

-- Get nearst copy
function getNearestCop( thePlayer )
	if ( exports.server:getPlayerAccountName ( thePlayer ) ) then
		local x, y, z = getElementPosition( thePlayer )
		local distance = nil
		local theCopNear = nil
		for i, theCop in ipairs ( getElementsByType( "player" ) ) do
			local x1, x2, x3 = getElementPosition( theCop )
			if ( exports.server:getPlayerAccountName ( theCop ) ) then
				if (getTeamName(getPlayerTeam(theCop)) == "Police") or (getTeamName(getPlayerTeam(theCop)) == "SWAT") or (getTeamName(getPlayerTeam(theCop)) == "Military Forces") or (getTeamName(getPlayerTeam(theCop)) == "Department of Defense") then
					if ( distance ) and ( getDistanceBetweenPoints2D( x, y, x1, x2 ) < distance ) then
						distance = getDistanceBetweenPoints2D( x, y, x1, x2 )
						theCopNear = theCop
					elseif ( getDistanceBetweenPoints2D( x, y, x1, x2 ) < 40 ) then
						distance = getDistanceBetweenPoints2D( x, y, x1, x2 )
						theCopNear = theCop
					end
				end
			end
		end
		return theCopNear
	end
end

-- When the player that is arrest quit
addEventHandler( "onPlayerQuit", root,
	function()
		if ( exports.server:getPlayerAccountName ( source ) ) and ( getElementData ( source, "isPlayerArrested" ) ) then
			local theCop = getElementData( source, "arrestedBy" )
			if ( arrestTable[theCop] ) then
				for i=1,#arrestTable[theCop] do
					local thePrisoner = arrestTable[theCop][i]
					if ( thePrisoner == source ) then
						local userID = exports.server:playerID( source )
						local wantedPoints = getElementData ( source, "wantedPoints" )
						local jailTime = ( math.floor(tonumber(wantedPoints) * 100 / 26 ) )
						local jailMoney = ( math.floor(tonumber(wantedPoints) * 200 / 4.2 ) )
						local addJail = exports.DENmysql:exec( "INSERT INTO jail SET userid=?, jailtime=?, jailplace=?", userID, tonumber(jailTime), "LS1" )
						givePlayerMoney ( theCop, tonumber(jailMoney) )
						
						exports.DENstats:updatePlayerStats ( theCop, "arrests", 1, false )
						exports.DENstats:updatePlayerStats ( theCop, "arrestpoints", tonumber(wantedPoints), false )
						
						local message = exports.DENhelp:createNewHelpMessageForPlayer(theCop, "" .. getPlayerName(source) .." quited you earned $".. jailMoney .."", 0, 225, 0)
						removeCopArrestedPlayer ( theCop, source )
						onCheckForJailPoints ( theCop, false )
					end
				end
			end
		elseif ( exports.server:getPlayerAccountName ( source ) ) and not ( getElementData ( source, "isPlayerArrested" ) ) and not(getElementData ( source, "isPlayerJailed" )) and ( getElementData ( source, "wantedPoints" ) >= 10 ) then
			local nearestCop = getNearestCop( source )
			if ( nearestCop ) and not ( nearestCop == source ) then
				local userID = exports.server:playerID( source )
				local wantedPoints = getElementData ( source, "wantedPoints" )
				local jailTime = ( math.floor(tonumber(wantedPoints) * 100 / 26 ) )
				local jailMoney = ( math.floor(tonumber(wantedPoints) * 200 / 4.2 ) )
				local addJail = exports.DENmysql:exec( "INSERT INTO jail SET userid=?, jailtime=?, jailplace=?", userID, tonumber(jailTime), "LS1" )
				givePlayerMoney ( nearestCop, tonumber(jailMoney) )
				
				exports.DENstats:updatePlayerStats ( nearestCop, "arrests", 1, false )
				exports.DENstats:updatePlayerStats ( nearestCop, "arrestpoints", tonumber(wantedPoints), false )
				
				local message = exports.DENhelp:createNewHelpMessageForPlayer(nearestCop, "" .. getPlayerName(source) .." evaded his arrest, you earned $".. jailMoney .."!", 0, 225, 0)
				
				exports.DENstats:updatePlayerStats ( nearestCop, "arrests", 1, false )
				exports.DENstats:updatePlayerStats ( nearestCop, "arrestpoints", tonumber(wantedPoints), false )
			end
		end
	end
)

-- Release when vehicle with wanted player in it get too damaged
function onCopVehicleDamage( loss )
	if ( getElementHealth ( source ) < 380 ) then
		local occupants = getVehicleOccupants( source )
		local seats = getVehicleMaxPassengers( source )
		for seat = 0, seats do
			local occupant = occupants[seat]
			if occupant and getElementType(occupant)=="player" then
				if getElementData ( occupant, "isPlayerArrested" ) then
					exports.DENhelp:createNewHelpMessageForPlayer(thePrisoner, "The cop vehicle broke down! You're free now!", 0, 225, 0)
					setElementData ( occupant, "isPlayerArrested", false )
					toggleAllControls ( occupant, true, true, true )
					removeCopArrestedPlayer ( getElementData( occupant, "arrestedBy" ), occupant )
					removePedFromVehicle( occupant )
					onCheckForJailPoints ( getElementData( occupant, "arrestedBy" ), false )
					showCursor ( occupant, false, false )
				end
			end
		end
    end
end
addEventHandler ( "onVehicleDamage", root, onCopVehicleDamage )

addEvent( "onServerPlayerJailed" )
addEventHandler ( "onServerPlayerJailed", root,
	function ()
		local arrestedTable = getCopArrestedPlayers( source )
		if ( arrestedTable ) then
			for i, thePrisoner in ipairs ( arrestedTable ) do
				exports.DENhelp:createNewHelpMessageForPlayer(thePrisoner, "The cop get jailed! You're free again!", 0, 225, 0)
				setElementData ( thePrisoner, "isPlayerArrested", false )
				toggleAllControls ( thePrisoner, true, true, true )
				removeCopArrestedPlayer ( source, thePrisoner )
				onCheckForJailPoints ( source, false )
				showCursor ( thePrisoner, false, false )
			end
		end
	end
)

addEvent( "onPlayerJobKick" )
-- When the cop get kicked from job release wanteds
function onCopRemoveJob()
	local arrestedTable = getCopArrestedPlayers( source )
	if ( arrestedTable ) then
		for i, thePrisoner in ipairs ( arrestedTable ) do
			exports.DENhelp:createNewHelpMessageForPlayer(thePrisoner, "Cop switched job! You're free again!", 0, 225, 0)
			setElementData ( thePrisoner, "isPlayerArrested", false )
			toggleAllControls ( thePrisoner, true, true, true )
			removeCopArrestedPlayer ( source, thePrisoner )
			onCheckForJailPoints ( source, false )
			showCursor ( thePrisoner, false, false )
		end
	end
end
addEventHandler ( "onPlayerJobKick", root, onCopRemoveJob )

-- Arrest when a cop jacks him
function onCopJackWantedPlayer ( thePlayer, seat, jacked )
    if (getTeamName(getPlayerTeam(thePlayer)) == "Police") or (getTeamName(getPlayerTeam(thePlayer)) == "SWAT") or (getTeamName(getPlayerTeam(thePlayer)) == "Military Forces") or (getTeamName(getPlayerTeam(thePlayer)) == "Department of Defense")  then
        if ( jacked ) and ( seat == 0 ) then
			if ( isArrestAllowedForLaw ( thePlayer, jacked ) ) and ( canCopArrest( thePlayer, jacked ) ) then
				if ( getElementData( jacked, "wantedPoints" ) > 9 ) and not ( getElementData( jacked, "isPlayerArrested" ) ) and not ( getElementData( jacked, "isPlayerJailed" ) ) then
					setElementData ( jacked, "isPlayerArrested", true )
					toggleAllControls ( jacked, false, true, false )
					giveWeapon ( jacked, 0, 0, true )
					triggerClientEvent( jacked, "onClientFollowTheCop", jacked, thePlayer, jacked)		
					exports.DENhelp:createNewHelpMessageForPlayer(jacked, "You got arrest by " .. getPlayerName(thePlayer) .. "!", 0, 225, 0)
					exports.DENhelp:createNewHelpMessageForPlayer(thePlayer, "You arrested " .. getPlayerName(jacked) .. "!", 0, 225, 0)
					addCopArrestedPlayer ( thePlayer, jacked )
					setElementData( jacked, "arrestedBy", thePlayer )
					onCheckForJailPoints ( thePlayer, true )
					showCursor ( jacked, true, true )
				end
			end
		end
    end
end
addEventHandler ( "onVehicleEnter", root, onCopJackWantedPlayer )

-- Arrest all wanted player in the vehicle
function onCopJackWantedPlayer ( thePlayer, seat, jacked )
    if (getTeamName(getPlayerTeam(thePlayer)) == "Police") or (getTeamName(getPlayerTeam(thePlayer)) == "SWAT") or (getTeamName(getPlayerTeam(thePlayer)) == "Military Forces") or (getTeamName(getPlayerTeam(thePlayer)) == "Department of Defense")  then
        if ( seat == 0 ) then
			local occupants = getVehicleOccupants( source )
			local seats = getVehicleMaxPassengers( source )
			for seat = 0, seats do
				local occupant = occupants[seat]
				if ( occupant ) and ( getElementType(occupant)=="player" ) then
					if ( isArrestAllowedForLaw ( thePlayer, occupant ) ) and ( canCopArrest( thePlayer, occupant ) ) then
						if getElementData( occupant, "wantedPoints" ) > 9 and not ( getElementData( occupant, "isPlayerArrested" ) ) and not ( getElementData( occupant, "isPlayerJailed" ) ) then
							setElementData ( occupant, "isPlayerArrested", true )
							toggleAllControls ( occupant, false, true, false )
							giveWeapon ( occupant, 0, 0, true )
							triggerClientEvent( occupant, "onClientFollowTheCop", occupant, thePlayer, occupant)		
							exports.DENhelp:createNewHelpMessageForPlayer(occupant, "You got arrest by " .. getPlayerName(thePlayer) .. "!", 0, 225, 0)
							exports.DENhelp:createNewHelpMessageForPlayer(thePlayer, "You arrested " .. getPlayerName(occupant) .. "!", 0, 225, 0)
							addCopArrestedPlayer ( thePlayer, occupant )
							setElementData( occupant, "arrestedBy", thePlayer )
							onCheckForJailPoints ( thePlayer, true )
							showCursor ( occupant, true, true )
						end
					end
				end
			end
		end
    end
end
addEventHandler ( "onVehicleEnter", root, onCopJackWantedPlayer )


-- Jail the player when the prisoner hits the col jail
addEvent("onJailArrestedPlayers", true)
function onJailArrestedPlayers ( theJailPoint, thePrisoner )
	local arrestedTable = getCopArrestedPlayers( source )
	if ( arrestedTable ) then
		for i=1,#arrestedTable do
			if ( arrestedTable[i] == thePrisoner ) then
				local wantedPoints = getElementData ( thePrisoner, "wantedPoints" )
				local jailTime = ( math.floor(tonumber(wantedPoints) * 100 / 26 ) )
				local jailMoney = ( math.floor(tonumber(wantedPoints) * 200 / 4.2 ) )
				
				removePedFromVehicle ( thePrisoner )
				
				toggleAllControls ( thePrisoner, true, true, true )
				removeCopArrestedPlayer ( source, thePrisoner )
				showCursor ( thePrisoner, false )
				
				setControlState ( thePrisoner, "sprint", false )
				setControlState ( thePrisoner, "walk", false )
				setControlState ( thePrisoner, "forwards", false )
				setControlState ( thePrisoner, "jump", false )
				
				exports.DENstats:updatePlayerStats ( source, "arrests", 1, false )
				exports.DENstats:updatePlayerStats ( source, "arrestpoints", tonumber(wantedPoints), false )
				
				onSetPlayerJailed ( thePrisoner, jailTime, theJailPoint )
				givePlayerMoney ( source, jailMoney)
				exports.DENhelp:createNewHelpMessageForPlayer(thePrisoner, "You got jailed by ".. getPlayerName ( source ) .." for " .. jailTime .. " seconds", 225, 165, 0 )
				exports.DENhelp:createNewHelpMessageForPlayer(source, "You jailed ".. getPlayerName ( thePrisoner ) .." for " .. jailTime .. " seconds and earned $" .. jailMoney .. ".", 0, 225, 0 )
				
				setElementData ( thePrisoner, "isPlayerArrested", false )
				
				onCheckForJailPoints ( source, false )			
			end
		end
	end
end
addEventHandler("onJailArrestedPlayers", root, onJailArrestedPlayers)

-- Release player event
addEvent("onReleasePlayerFromArrest", true)
function onReleasePlayerFromArrest ( theCop )
	if ( arrestTable[theCop] ) then
		for i=1,#arrestTable[theCop] do
			local thePrisoner = arrestTable[theCop][i]
			if ( source ) and ( source == thePrisoner ) then
				exports.DENhelp:createNewHelpMessageForPlayer(theCop, "You released ".. getPlayerName( thePrisoner ) .."!", 0, 225, 0)
				exports.DENhelp:createNewHelpMessageForPlayer(thePrisoner, "You are now free! RUN!", 0, 225, 0)
				setElementData ( thePrisoner, "isPlayerArrested", false )
				toggleAllControls ( thePrisoner, true, true, true )
				removeCopArrestedPlayer ( theCop, thePrisoner )
				onCheckForJailPoints ( theCop, false )
				showCursor ( thePrisoner, false )
			end
		end
	end
end
addEventHandler("onReleasePlayerFromArrest", root, onReleasePlayerFromArrest)

-- Remove from bike
addEvent("onRemovePlayerFromBike", true)
function onRemovePlayerFromBike ( )
	if ( isElement( source ) ) then
		removePedFromVehicle ( source )
		exports.DENhelp:createNewHelpMessageForPlayer( source, "You fell of your bike due too much damage!", 0, 225, 0)
	end
end
addEventHandler("onRemovePlayerFromBike", root, onRemovePlayerFromBike)

-- Give the cop some money after killing a wanted crim in water
addEventHandler( "onPlayerWasted", root,
function ( ammo, attacker, weapon, bodypart )
	if ( attacker ) and ( isElement( attacker ) ) and ( getElementType ( attacker ) == "player" ) then
		if not ( source == attacker ) and ( getPlayerTeam( attacker ) )then
			if (getTeamName(getPlayerTeam(attacker)) == "Police") or (getTeamName(getPlayerTeam(attacker)) == "SWAT") or (getTeamName(getPlayerTeam(attacker)) == "Military Forces") or (getTeamName(getPlayerTeam(attacker)) == "Department of Defense")  then
				if ( isArrestAllowedForLaw ( attacker, source ) ) and ( isElementInWater ( source ) ) then
					local theReward = ( math.floor( tonumber( getElementData ( thePrisoner, "wantedPoints" ) ) * 200 / 8 ) )
					givePlayerMoney( attacker, tonumber( theReward ) )
					exports.DENhelp:createNewHelpMessageForPlayer( attacker, "You killed a wanted person in the water you earned $"..theReward, 225, 0, 0)
				end
			end
		end
	end
end
)