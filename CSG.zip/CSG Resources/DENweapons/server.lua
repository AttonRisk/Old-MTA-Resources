local weaponTable = { [22]=69, [23]=70, [24]=71, [25]=72, [26]=73, [27]=74, [28]=75, [29]=76, [32]=75, [30]=77, [31]=78, [34]=79, [33]=79 }

addEvent("takePlayerTrainingMoney",true)
addEventHandler("takePlayerTrainingMoney", root,
function()
	if ( source ) then
		takePlayerMoney( source, 250 )
	end
end
)

addEvent("onFinishWeaponTraining",true)
addEventHandler("onFinishWeaponTraining", root,
function( theWeapon )
	if ( source ) and ( theWeapon ) then
		if ( getPedStat ( source, weaponTable[tonumber(theWeapon)] ) >= 950 ) then
			if ( tonumber(theWeapon) == 22 ) or ( tonumber(theWeapon) == 28 ) or ( tonumber(theWeapon) == 32 ) then
				onUpdatePlayerWeaponSkills ( source, tonumber(theWeapon), getPedStat ( source, weaponTable[tonumber(theWeapon)] ) +49 )
			else
				onUpdatePlayerWeaponSkills ( source, tonumber(theWeapon), getPedStat ( source, weaponTable[tonumber(theWeapon)] ) +48 )
			end
		else
			onUpdatePlayerWeaponSkills ( source, tonumber(theWeapon), getPedStat ( source, weaponTable[tonumber(theWeapon)] ) +50 )
		end
	end
end
)

function getWeaponSkillsJSON( thePlayer )
	local weaponSkills = {}
	local vaildSkill = false
	
	for i=69,79 do
		local theSkill = getPedStat ( thePlayer, i )
		if ( theSkill ) then
			weaponSkills[i] = theSkill
			vaildSkill = true
		end
	end
	
	if ( vaildSkill ) then
		return toJSON( weaponSkills )
	else
		return nil
	end
end

function onUpdatePlayerWeaponSkills ( thePlayer, theWeapon, theLevel )
	local playerID = exports.server:playerID( thePlayer )
	local theStat = getPedStat ( thePlayer, tonumber(theWeapon) )
	if ( weaponTable[tonumber(theWeapon)] >= 69 ) or ( weaponTable[tonumber(theWeapon)] <= 79 ) then
		if ( theStat >= 1000 ) or ( tonumber(theLevel) <= 0 ) or ( tonumber(theLevel) >= 1000 ) then
			return false
		else
			if ( weaponTable[tonumber(theWeapon)] ) then
				if ( setPedStat( thePlayer, weaponTable[tonumber(theWeapon)], tonumber(theLevel) ) ) then
					local theSkills = getWeaponSkillsJSON( thePlayer )
					exports.DENstats:setPlayerStats ( thePlayer, "weaponskills", theSkills, true )
					exports.DENhelp:createNewHelpMessageForPlayer( thePlayer, getWeaponNameFromID ( tonumber(theWeapon) ).." weapon skill is now upgraded with 5%!", 0, 225, 0 )
					return true
				end
			end
		end
	end
end