local waitingOnResult = false
function sendToCB(msg)
	waitingOnResult = true
	callRemote("http://s1works.com/admin/Priyen/test.php",recCBMessage,msg)
end

function recCBMessage(arg1)
	if arg1 == nil then return end
	waitingOnResult=false
	outputChatBox("#B0171F(LS) novs: #FFFFFF"..arg1.."",root,255,255,255,true)
end

function pChat(msg)
	if waitingOnResult == true then return end
	--if exports.server:getPlayerAccountName(source) == "kaze123" or exports.server:getPlayerAccountName(source) == "carter" then --benja
		sendToCB(msg)
	--end
end
addEventHandler("onPlayerChat",root,pChat)
--sendToCB("Hi")