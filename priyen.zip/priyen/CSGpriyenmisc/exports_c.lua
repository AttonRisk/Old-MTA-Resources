
function dxDrawColorText(str, ax, ay, bx, by, color, scale, font, alignX, alignY)
  bx, by, color, scale, font = bx or ax, by or ay, color or tocolor(255,255,255,255), scale or 1, font or "default"
  if alignX then
    if alignX == "center" then
      ax = ax + (bx - ax - dxGetTextWidth(str:gsub("#%x%x%x%x%x%x",""), scale, font))/2
    elseif alignX == "right" then
      ax = bx - dxGetTextWidth(str:gsub("#%x%x%x%x%x%x",""), scale, font)
    end
  end
  if alignY then
    if alignY == "center" then
      ay = ay + (by - ay - dxGetFontHeight(scale, font))/2
    elseif alignY == "bottom" then
      ay = by - dxGetFontHeight(scale, font)
    end
  end
  local alpha = string.format("%08X", color):sub(1,2)
  local pat = "(.-)#(%x%x%x%x%x%x)"
  local s, e, cap, col = str:find(pat, 1)
  local last = 1
  while s do
    if cap == "" and col then color = tocolor(getColorFromString("#"..col..alpha)) end
    if s ~= 1 or cap ~= "" then
      local w = dxGetTextWidth(cap, scale, font)
      dxDrawText(cap, ax, ay, ax + w, by, color, scale, font)
      ax = ax + w
      color = tocolor(getColorFromString("#"..col..alpha))
    end
    last = e + 1
    s, e, cap, col = str:find(pat, last)
  end
  if last <= #str then
    cap = str:sub(last)
    dxDrawText(cap, ax, ay, ax + dxGetTextWidth(cap, scale, font), by, color, scale, font)
  end
end

function output()
	local x,y,z = getElementPosition(localPlayer)
	outputChatBox("{"..x..","..y..","..z.."},")
end
addCommandHandler("bpos",output)

local cityBoundary = 1600
local cities = {
[1] = "LS",
[2] = "SF",
[3] = "LV"
}
local cityNames = {
[1] = "Los Santos",
[2] = "San Fierro",
[3] = "Las Venturas"
}
local cityCenters = {
[1] = {1622.94140625, -1548.486328125, 13.671937942505},
[2] = {-2259.66015625, 543.3671875, 35.11096572876},
[3] = {2181.0390625, 1773.41015625, 10.671875}
}

function isWithinCityBoundary(cityID,x1,y1,z1)
    if cityID ~= 0 then
    else
    cityID = city
    end
    local dist = getDistanceBetweenPoints2D(x1,y1,cityCenters[cityID][1],cityCenters[cityID][2])
    if dist <= cityBoundary then
    return true
    else
    return false
    end
end
