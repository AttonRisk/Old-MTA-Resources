Fisher's Lagoon Creatures Cleo Myth V 1.0
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Credits:
Script by Xander3000
Turbosquid by the model
Goin-god for riggin the model
******************************************************************************************************************************************

About the mod:
Go anytime to the Fisher's Lagoon in the Red County and stand on earth about a minute. You will encounter 
with 4 sea monster who will try kill you!
But after kill you, the monsters will kill first to a ally who I added near of the Fisher's lagoon cabin. 

------------------------------------------------------------------------------------------------------------------------------------------
Before install!!! You must have to be installed Sannybuilder Cleo3 in your directory game.

Installation:

1)Add to GTA3.IMG with imgtool or txdworkshop these files:
sea.dff
sea.txd

2)Copy and paste the Fisher's_Lagoon_Creatures.cs in C:\Program Files\Rockstar Games\GTA San Andreas\cleo


3)Play the game and Enjoy!


