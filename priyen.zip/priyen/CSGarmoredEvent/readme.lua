--[[
	CRUISE CONTROL SCRIPT by DZEK.
	
	You are free to copy and use it,
	you can't write new scripts based on this one
	without claiming original author,
	but you are free to edit this one to suit your needs
	(any minor changes)
	
	Please do not remove this information (especially from client-side)
	
	http://dzek.metal.info/mta
	
	msn:   kns1@o2.pl
	mail:  kns1@o2.pl
	skype: dzek69
	gg:    2928054
	www:   dzek.metal.info/mta

	Thanks.
	
	Jacek Nowacki a.k.a. DZEK
]]--