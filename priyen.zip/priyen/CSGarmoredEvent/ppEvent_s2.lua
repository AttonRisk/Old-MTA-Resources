------------------------------------------------------------------------------------
--  CSG
--  v1.0
--  ppEvent_s.lua (server-side)
--  Armored Truck Event
--  Priyen Patel
------------------------------------------------------------------------------------
--NOT DONE YET
local truckMaxSpeed = 999 --kmh
local lawNeeded = 1
local timeWaitTillStart = 5 --seconds
local minBags = 3
local maxBags = 6
local perBagMin = 1500
local perBagMax = 2500
local copAmountTimes = 0.5 --cops get half crims would
local baseHealth = 5000
--local healthPerCrimOnline = 5000 --FORMULA: 5000+(2500*2(crims/law))
local truck = ""
local fromMarker = ""
local inProgress = ""
local toMarker = ""
local truckCol = ""
local healthBeforeBreakdown = 100
local globalTimeTillClean = 0
local currentHealth = 50000
local minTimeBetweenEvents =  2700 --seconds (seconds = minutes * 60)
local maxTimeBetweenEvents =  4500
local timeTillEvent = 1 -- starts on resource start -- 2 == 1 minute after
local truckBlip = ""
local colRadius = 15
local lawInFromMarker = {}
local bagRadius = 0.6 -- x 2, so 2.5 = 5 radius
local alreadyCollectedBag = {}
local backOfTruckMarker = ""
local autoEndTime = 15 --minutes
local winning = ""
local peds = {}
local fromPos = {
	--[1] = {2310.3205566406,1647.8489990234,9.8203125,["name"]="Caligula's Casino"} 
	[1] = {599.32220458984,-1305.9846191406,13.005281448364,292.81634521484,["name"]="LS Bank"},
	--[2] = {-1840.7551269531,1043.302734375,45.087707519531,89.875595092773,["name"]="SF Bank"},
	--[3] = {-2813.5786132813,375.2692565918,3.5082426071167,99.855331420898,["name"]="Whitehouse"},
	--[4] = {165.93356323242,-22.509349822998,0.578125,264.74078369141,["name"]="Blueberry Federal Depot"}
}
local toPos = {
	[1] = {599.32220458984,-1305.9846191406,13.005281448364,["name"]="LS Bank"},
 	[2] = {-1840.7551269531,1043.302734375,45.087707519531,["name"]="SF Bank"},
	[3] = {-2813.5786132813,375.2692565918,3.5082426071167,["name"]="Whitehouse"},
	[4] = {165.93356323242,-22.509349822998,0.578125,["name"]="Blueberry Federal Depot"},
	[5] = {1904.693359375,990.34851074219,9.8203125,["name"]="The Four Dragons Hotel & Casino"},
	[6] = {2310.3205566406,1647.8489990234,9.8203125,["name"]="Caligula's Casino"} 
}
local walkPaths = {
	["LS Bank"] = {{615.11, -1303.73, 14.73,8},{ 614.41, -1282.37, 16.19}}
}

local lawTeams = {
	"Military Forces",
	"SWAT",
	"Police"
}

local eventActive = false

function preStart()
	local validToI = false
	toI = math.random(1,#toPos)
	fromI = math.random(1,#fromPos)
	while (validToI == false) do
		if fromPos[fromI].name ~= toPos[toI].name then
			validToI = true 
			break
		else
			toI = math.random(1,#toPos)
		end
	end 
	local ped = createPed(165,walkPaths[fromPos[fromI].name][1][1],walkPaths[fromPos[fromI].name][1][2],walkPaths[fromPos[fromI].name][1][3],walkPaths[fromPos[fromI].name][1][4])
	--setPedAnimation(ped,"ped","WALK_armed",5000,true,true,false)
	table.insert(peds,ped)
	triggerClientEvent(root,"CSGarmorEventRecPedData",root,peds)
	giveWeapon(ped,31,9999)
	warnLaw("The "..fromPos[fromI].name.." is requesting a armored truck transport to "..toPos[toI].name..".")
	warnLaw("Arrive Promptly!")
	inProgress = false
	truck = createVehicle(428,fromPos[fromI][1],fromPos[fromI][2],fromPos[fromI][3]+2)
	addEventHandler("onVehicleDamage",root,vehDamage)
	setTimer(function()setElementFrozen(truck,true) end,2000,1)
	local rx,ry = getElementRotation(truck)
	local rz = fromPos[fromI][4]
	setElementRotation(truck,rx,ry,rz)
	--setElementHealth(truck,1000)
	setVehicleDamageProof(truck,true)
	fromMarker = createMarker(fromPos[fromI][1],fromPos[fromI][2],fromPos[fromI][3]-1,"cylinder",15,255,255,0,15)
	addEventHandler("onMarkerHit",fromMarker,hitMarker)
	addEventHandler("onMarkerLeave",fromMarker,leaveMarker)
end
setTimer(preStart,1000,1)

function hitMarker(e)
	if source == fromMarker then
		if getElementType(e) == "player" then
			if isLaw(e) == true then
				table.insert(lawInFromMarker,e)
				if #lawInFromMarker < lawNeeded then

				else	--6 law in marker
				
				end
			end
		end
	elseif source == toMarker then
		--if getElementType(e) ~= "vehicle" then return end
		if e == truck then
			warnLaw("The armored truck has been successfully delivered to "..toPos[toI].name.."")
			warnLaw("Please collect your cash within 1 minute near the truck to claim your reward")
			winning="law"
			prepareForMoneybags()
			setVehicleEngineState(e,false)
			warnCriminals("The armored truck has been successfully delivered to "..toPos[toI].name.."!")
			warnCriminals("Mission Failed!")
		end
	end
end

function leaveMarker(e)
	if source == fromMarker then
		if getElementType(e) == "player" then
			if isLaw(e) == true then
				for k,v in pairs(lawInFromMarker) do if v == e then table.remove(lawInFromMarker,k) break end end
			end
		end
	elseif source == toMarker then
	
	end
end

function vehEnter(e,seat)
	if inProgress == true then return end
	if timeTillEvent > 0 then return end
	if seat ~= 0 then return end
	if source == truck then
		if isLaw(e) == true then
			if #lawInFromMarker < lawNeeded then
				exports.DENhelp:createNewHelpMessageForPlayer(e,"Armored Transport Mission: You need "..lawNeeded.." law in the marker to begin!",255,0,0)
			else 
				exports.DENhelp:createNewHelpMessageForPlayer(e,"Armored Transport Mission: Remain in the vehicle! Starting in "..timeWaitTillStart.." seconds!",255,0,0)
				startTimer = setTimer(start,timeWaitTillStart*1000,1)
			end
		end
	end
end
addEventHandler("onVehicleEnter",root,vehEnter)

function vehExit(p,seat)
	if source == truck then if seat == 0 then if isTimer(startTimer) then killTimer(startTimer) end end end
end
addEventHandler("onVehicleExit",root,vehExit)

function start()
	setVehicleDamageProof(truck,false)
	local laws = getLawTable()
	local crims = getPlayersInTeam(getTeamFromName("Criminals"))
	currentHealth = baseHealth+(2500*2*(#crims/#laws))
	setElementFrozen(truck,false)
	inProgress = true
	truckBlip = createBlipAttachedTo(truck,51)
	triggerClientEvent(root,"CSGarmoredEventMakeBlip",root,toPos[toI][1],toPos[toI][2],toPos[toI][3],19,lawTeams)
	monitorTruckTimer = setTimer(monitorTruck,1000,0)
	warnLaw("The armored truck headed towards "..toPos[toI].name.." has just left "..fromPos[fromI].name.."!")
	warnLaw("You have "..autoEndTime.." minutes to deliver it! Protect it all the way for a large reward!")
	warnCriminals("A armored truck headed towards "..toPos[toI].name.." has just left "..fromPos[fromI].name.."!")
	warnCriminals("Destroy the truck and steal the money!")
	toMarker = createMarker(toPos[toI][1],toPos[toI][2],toPos[toI][3],"cylinder",15,255,255,0,15)
	addEventHandler("onMarkerHit",toMarker,hitMarker)
	setTimer(doEnd,autoEndTime*60*1000,1)
end

function monitorTruck()
	if isElement(truck) then
		--outputChatBox(currentHealth)
		local limit = truckMaxSpeed
		if stopTheTruck == true then limit = 0 end
		local speedx, speedy, speedz = getElementVelocity ( truck )
		local kmh = ((speedx^2 + speedy^2 + speedz^2)^(0.5))*180 
		if kmh > limit then
			setElementVelocity(truck,speedx*0.75,speedy*0.75,speedz)
		end
	end
end

function warnCriminals(msg)
	local list = getPlayersInTeam(getTeamFromName("Criminals"))
	for k,v in pairs(list) do
		exports.DENhelp:createNewHelpMessageForPlayer(v,msg,255,0,0)
	end
end

function crimWinning()
	warnCriminals("The armored truck has been broken down! Hurry!")
	warnCriminals("Kill the cops near the truck! You have 5 minutes do the job!")
	warnLaw("The armored truck has been broken down! You have failed the mission and the "..fromPos[fromI].name.."!")
	warnLaw("Protect it from potential criminals for 5 minutes!")	
end

function lawWinning()
	warnLaw("Clear out any remaining criminals near the truck!")
	warnCriminals()
end

function prepareForMoneybags()
	setTimer(function()
	setElementFrozen(truck,true) 
	killTimer(monitorTruckTimer) 
	local x,y = getElementPosition(truck)
	truckCol = createColCircle(x,y,colRadius) 
	monitorTruckColTimer = setTimer(monitorTruckCol,1000,0)
	if winning == "crim" then
	crimWinning()
	elseif winning == "law" then
	lawWinning()
	end
	setTimer(doEnd,300000,1)
	backOfTruckMarker = createMarker(fromPos[fromI][1],fromPos[fromI][2],fromPos[fromI][3],"cylinder",2,255,255,0,60)
	attachElements(backOfTruckMarker,truck,0,-3.5,-1)
	end,5000,1)
	destroyElement(truckBlip)
	removeEventHandler("onMarkerHit",toMarker,hitMarker)
	removeEventHandler("onMarkerHit",fromMarker,hitMarker)
	removeEventHandler("onMarkerLeave",fromMarker,leaveMarker)
	destroyElement(fromMarker)
	destroyElement(toMarker)
	setVehicleDamageProof(truck,true)
end

function vehDamage(loss)
	if source == truck then
		--outputChatBox("loss: "..loss.."")
		--if stopTheTruck == true then cancelEvent() return end

		currentHealth=currentHealth-loss*5
		if currentHealth < healthBeforeBreakdown then setVehicleDamageProof(source,true) setElementHealth(source,249) else setElementHealth(source,999)  return end
			setVehicleEngineState(source,false)			
			cancelEvent()
			setElementHealth(source,249)			
			if stopTheTruck ~= true then
			stopTheTruck = true
			winning="crim"
			prepareForMoneybags()
			end
		
	end
end

function explode()
	if source == truck then cancelEvent() end
end
addEventHandler("onVehicleExplode",root,explode)

function monitorTruckCol()
	if isElement(truckCol) then
		local t = getElementsWithinColShape(truckCol,"player")
		local isTypeNear = false
		
		for k,v in pairs(t) do
			if isTypeNear == true then break end
			if winning == "crim" then
			for k2,v2 in pairs(lawTeams) do
				if v2 == getTeamName(getPlayerTeam(v)) then
					isTypeNear = true
					break
				end
			end
			elseif winning == "law" then
				if getTeamName(getPlayerTeam(v)) == "Criminals" then isTypeNear = true break end
			end
		end
		if isTypeNear == false then
			local x,y,z = getElementPosition(backOfTruckMarker)
			globalTimeTillClean=60000
			setTimer(function() globalTimeTillClean=globalTimeTillClean-1000 end,1000,(globalTimeTillClean/1000)+1)
			setTimer(doEnd,60000,1)
			makeMoneyBags(x,y,z)
			setVehicleDoorState(truck,4,2)
			setVehicleDoorState(truck,5,4)	
			destroyElement(truckCol)
			if isTimer(monitorTruckColTimer) then
				killTimer(monitorTruckColTimer)
			end
		end
	end
end

function makeMoneyBags(x,y,z)	

	for k,v in pairs(getLawTable()) do
		triggerClientEvent(v,"CSGarmoredEventDestroyBlip",v,toPos[toI][1],toPos[toI][2],toPos[toI][3],19)
	end
	if isTimer(monitorTruckTimer) then killTimer(monitorTruckTimer) end 
	bags = {}
	local bagsAm = math.random(minBags,maxBags)
	for i=1,bagsAm do	
		local x2 = math.random(x-bagRadius,x+bagRadius)
		local y2 = math.random(y-bagRadius,y+bagRadius)
		--z2 = getGroundPosition(x2,y2,z)
		z2=z+0.75
		local m = createMarker(x2,y2,z2,"cylinder",1,255,255,0,0)
		addEventHandler("onMarkerHit",m,hitMoneyBag)
		local money = math.random(perBagMin,perBagMax)
		if winning == "law" then money=money*copAmountTimes end
		local obj = createObject(1550,x2,y2,z2)
		bags[i] = {obj,m,money}	
	end
	if winning == "crim" then
	warnLaw("The Criminals have broken into the armored truck!")
	warnCriminals("Hurry! The armored truck's doors are open. Get the money!")
	elseif winning == "law" then
	warnLaw("Congratulations! "..fromPos[fromI].name.." has decided to pay you for your service!")
    warnLaw("Hurry! Pickup your stash of the money near the truck!")
	end
	setTimer(cleanUpBags,globalTimeTillClean,1)
	triggerClientEvent(root,"CSGarmoredEventRecBags",root,bags,globalTimeTillClean)
end

function playerLogin()
	if globalTimeTillClean > 1000 then
		triggerClientEvent(source,"CSGarmoredEventRecBags",source,bags,globalTimeTillClean)
	end
end
addEventHandler("onPlayerLogin",root,playerLogin)

function hitMoneyBag(e)
	if getElementType(e) == "player" then
		if winning == "law" then if isLaw(e) == false then return end end
		if winning == "crim" then if getTeamName(getPlayerTeam(e)) ~= "Criminals" then return end end

			local i = 0
			for k,v in pairs(bags) do
				if v[2] == source then i = k break end
			end
			if i == 0 then return end
			local t = alreadyCollectedBag[e]
			if t == nil then
			if winning == "crim" then
				exports.server:givePlayerWantedPoints(e, 60)
			end
			alreadyCollectedBag[e] = {}
			t = {}
			end
			for k,v in pairs(t) do if v == i then return end end
			setPedAnimation(e,"MISC","pickup_box",1000,false)
			setTimer(function() setPedAnimation(e,false) end,1000,1)
			table.insert(alreadyCollectedBag[e],i)
			givePlayerMoney(e,bags[i][3])
			exports.DENhelp:createNewHelpMessageForPlayer(e,"Picked up $"..bags[i][3].."",0,255,0)				
	end
end

function cleanUpBags()

	for k,v in pairs(bags) do
		destroyElement(v[1])
		removeEventHandler("onMarkerHit",v[2],hitMoneyBag)
		destroyElement(v[2])
	end
	bags = {}
	alreadyCollectedBag = {}
end

function showData(ps)
	
	if inProgress == true then
		outputChatBox("Truck Health: "..currentHealth..". "..fromPos[fromI].name..". To "..toPos[toI].name.."",ps,0,255,0)
	else
		if timeTillEvent <= 0 then
			outputChatBox("Time Till Event: "..timeTillEvent.." Minutes. Ready At: "..fromPos[fromI].name..". To: "..toPos[toI].name.."",ps,0,255,0)
		else
			outputChatBox("Time Till Event: "..timeTillEvent.." Minutes",ps,0,255,0)
		end
	end
end
addCommandHandler("armoreventdata",showData)

function doEnd()
	if inProgress == true then
	cleanUpBags()
	winning=""
	if isTimer (monitorTruckColTimer) then killTimer(monitorTruckColTimer) end
	if isElement(truckCol) then destroyElement(truckCol) end
	if isElement(backOfTruckMarker) then destroyElement(backOfTruckMarker) end
	--blowVehicle(truck)
	setTimer(function() if isElement(truck) then destroyElement(truck) end stopTheTruck = false end,5000,1)
	triggerClientEvent(root,"CSGarmoredEventEnd",root)
	inProgress = false
	timeTillEvent = math.random(minTimeBetweenEvents,maxTimeBetweenEvents) 
	end
end

function manageTimeLeft()
	timeTillEvent = timeTillEvent-1
	if timeTillEvent == 1 then
		preStart()
	end
	if timeTillEvent <= 0 then
		timeTillEvent = 0
	end
end
setTimer(manageTimeLeft,60000,0)

function isLaw(e)
	local team = getTeamName(getPlayerTeam(e))
	for k,v in pairs(lawTeams) do if v == team then return true end end
	return false
end

function getLawTable()
	local law = {}
	for k,v in pairs (lawTeams) do
		local list = getPlayersInTeam(getTeamFromName(v))
		for k,v in pairs(list) do
			table.insert(law,v)
		end
	end
	return law
end

function warnLaw(msg)
	local law = getLawTable()
	for k,v in pairs(law) do
		--exports.DENhelp:createNewHelpMessageForPlayer(v,"---Notice---",0,255,0)
		exports.DENhelp:createNewHelpMessageForPlayer(v,msg,0,255,0)
	end
end
manageTimeLeft()

function CSGarmorEventGivePedWeapon(ped)
	giveWeapon(ped,31,9999)
end
addEvent("CSGarmorEventGivePedWeapon",true)
addEventHandler("CSGarmorEventGivePedWeapon",root,CSGarmorEventGivePedWeapon)