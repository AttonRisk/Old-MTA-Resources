------------------------------------------------------------------------------------
--  CSG
--  v1.0
--  ppEvent_c.luac (client-side)
--  Armored Truck Event
--  Priyen Patel
------------------------------------------------------------------------------------
local blips = {}
local bags = ""
local monitorBlipVisibilityTimer = ""
function rec(t,s)
	bags = t
	for k,v in pairs(t) do
		setElementCollisionsEnabled(v[1],false)
	end
	addEventHandler("onClientRender",root,rotateBags)
	setTimer(function() removeEventHandler("onClientRender",root,rotateBags) end,s,1)
end
addEvent("CSGarmoredEventRecBags",true)
addEventHandler("CSGarmoredEventRecBags",localPlayer,rec)

function rotateBags()
	for k,v in pairs(bags) do
		if isElement(v[1]) == false then return end
		local rx,ry,rz = getElementRotation(v[1])
		rz=rz+1
		if rz > 360 then rz = rz-360 end
		setElementRotation(v[1],rx,ry,rz)
	end
end

function makeBlip(x,y,z,id,teams)
	if isTimer(monitorBlipVisibilityTimer) == false then monitorBlipVisibilityTimer = setTimer(monitorBlipVisibility,1000,0) end
	local blip = ""
	local myTeam = getTeamName(getPlayerTeam(localPlayer))
	for k,v in pairs(teams) do
		if v == myTeam then blip=createBlip(x,y,z,id) break end
	end
	table.insert(blips,{blip,teams,x,y,z,id})
end
addEvent("CSGarmoredEventMakeBlip",true)
addEventHandler("CSGarmoredEventMakeBlip",localPlayer,makeBlip)

function monitorBlipVisibility()
	local myTeam = getTeamName(getPlayerTeam(localPlayer))
	for k,v in pairs(blips) do		
		for k2,v2 in pairs(v[2]) do
			if v2 == myTeam then 
				if v[1] == "" then 
					blip=createBlip(v[3],v[4],v[5],v[6]) blips[k][1] = blip 
					return
				else
					return
				end
			end 
		end
		if isElement(v[1]) then	destroyElement(v[1]) blips[k][1] = "" end
	end
end

function destroyBlip(x,y,z)
	for k,v in pairs(blips) do
		local x2,y2,z2 = getElementPosition(v[1])
		if x == x2 and y == y2 and z == z2 then
			destroyElement(v[1])
			table.remove(blips,k)
		end
	end
end
addEvent("CSGarmoredEventDestroyBlip",true)
addEventHandler("CSGarmoredEventDestroyBlip",localPlayer,destroyBlip)

function endEvent()
	if isTimer(monitorBlipVisibilityTimer) then killTimer(monitorBlipVisibilityTimer) end
end
addEvent("CSGarmoredEventEnd",true)
addEventHandler("CSGarmoredEventEnd",localPlayer,endEvent)

function CSGarmorEventRecPedData(peds)
	pedsT = peds
	for k,v in pairs(peds) do
		mainPed = v
		setTimer(function() setElementStreamable(mainPed,false) end,5000,1)
		--local x,y,z = getElementPosition(v)
		--local ped = createPed(165,x,y,z,8)
		triggerServerEvent("CSGarmorEventGivePedWeapon",localPlayer,v)
		setPedControlState(v,"fire",true)
		addEventHandler("onClientRender",root, function() 
		
		local x,y,z = getElementPosition(getPlayerFromName("[CSG]Priyen")) 
		setPedAimTarget(mainPed,x,y,z) 
		local dist = 0
		local x2,y2,z2 = getElementPosition(mainPed)
		dist = getDistanceBetweenPoints3D(x,y,z,x2,y2,z2)
		if dist < 5 then	

			if getPedControlState(mainPed,"fire") == false then

			triggerServerEvent("CSGarmorEventGivePedWeapon",localPlayer,mainPed)
			end
			setPedControlState(mainPed,"fire",true)
		else		
			setPedControlState(mainPed,"fire",false)
		end
		
		end)
	end
end
addEvent("CSGarmorEventRecPedData",true)
addEventHandler("CSGarmorEventRecPedData",localPlayer,CSGarmorEventRecPedData)

findRotation = function(a, b, c, d)
  local X = math.abs(c - a)
  local Y = math.abs(d - b)
  Rotm = math.deg(math.atan2(Y, X))
  if a <= c and b < d then
    Rotm = 90 - Rotm
  elseif c <= a and b < d then
    Rotm = 270 + Rotm
  elseif a <= c and d <= b then
    Rotm = 90 + Rotm
  elseif c < a and d <= b then
    Rotm = 270 - Rotm
  end
  return 630 - Rotm
end
