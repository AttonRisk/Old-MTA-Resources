local effectWalk = {}
function walkEffect(bool)
	effectWalk[source]=bool
end
addEvent("CSGcasinoShopEffectChange",true)
addEventHandler("CSGcasinoShopEffectChange",root,walkEffect)

function doEffect()
	for k,v in pairs(effectWalk) do
		if v == true then
			if isPedInVehicle(k) == false then
				local chance = math.random(1,100)
				if chance > 25 then
					local tim = math.random(1000,3000)
					setPedAnimation(k,"ped","WALK_drunk",tim,true,true,false)
					setTimer(function () setPedAnimation(k,false) end,tim,1)
				end
			end
		else
			--table.remove(effectWalk,tostring(k))
		end
	end
end
setTimer(doEffect,10000,0)
