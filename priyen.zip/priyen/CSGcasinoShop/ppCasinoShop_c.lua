local data = {
	{["name"]="Four Dragons Casino",px=1953.76,py=1018.31,pz=992.46,pr=270,skin=171,int=10,dim=0,offx=0,offy=1.7,offz=-1},
}
local markers = {}
local peds = {}
function start()
	for k,v in pairs(data) do
		local ped = createPed(v.skin,v.px,v.py,v.pz,v.pr)
		setElementFrozen(ped,true)
		setElementDimension(ped,v.dim)
		setElementInterior(ped,v.int)
		table.insert(peds,ped)
		local marker = createMarker(v.px,v.py,v.pz,"cylinder",1,255,255,0,60)
		setElementDimension(marker,v.dim)
		setElementInterior(marker,v.int)
		attachElements(marker,ped,v.offx,v.offy,v.offz)
	end
end
start()

function check(atker)
	for k,v in pairs(peds) do
		if v == source then cancelEvent() return end
	end
end
addEventHandler("onClientPedDamage",root,check)

-- Shop Items
local items = {
	--name        price strength
	{"Champagne",1000,0.5},
}

local bloodAlcoholLevel = 0
function drink(id)
	setBlurLevel(100)
	bloodAlcoholLevel = bloodAlcoholLevel + items[id][3]
	triggerServerEvent("CSGcasinoShopEffectChange",localPlayer,true)
end

function decrease()
	if bloodAlcoholLevel > 0 then
		if bloodAlcoholLevel-0.01 <= 0 then
		setBlurLevel(36)
		triggerServerEvent("CSGcasinoShopEffectChange",localPlayer,false)
		end
		bloodAlcoholLevel=bloodAlcoholLevel-0.01
	end
end
setTimer(decrease,1000,0)
local camRot = 0
local dir = -0.25
function test()
	drink(1)
end

addCommandHandler("shoptest",test)
w,h = guiGetScreenSize()
local screenSource = dxCreateScreenSource(w,h)
local x,y = 0,0
local count = 1

function circle(r,s,cx,cy)
	xVals = {}
	yVals = {}
	for i=1,s-1 do
		xVals[i] = (cx+r*math.cos(math.pi*i/s*2-math.pi/2))
		yVals[i] = (cy+r*math.sin(math.pi*i/s*2-math.pi/2))
		--outputChatBox('('..xVals[i]..','..yVals[i]..')')
	end
end
circle(10,200,10,10)
size = #xVals
iRot = 0
rotX,rotY=w/2,h*/2
rotInt = 0.06
function doEffect()
	if bloodAlcoholLevel > 0 then
		--[[x,y = xVals[count],yVals[count]
		count=count+1
		if count > size then count = 1 end
		dxUpdateScreenSource(screenSource)
		dxDrawImage(x,y,w,h,screenSource)
		--]]
		iRot=iRot+rotInt
		if iRot > 11.25 or iRot < -11.25 then rotInt=rotInt*-1 end
		dxUpdateScreenSource(screenSource)
		dxDrawImage(x,y,w,h,screenSource,iRot,rotX,rotY)
	end
end
addEventHandler("onClientRender",root,doEffect)

local controls = {
	"left","right"
}
function doEffect2()
	if bloodAlcoholLevel > 0 then
		local chance = math.random(1,100)
		outputChatBox(chance)
		if chance > 25 then
			local tim = math.random(4000,6000)
			local id = 1
			cont = controls[id]
			setControlState(cont,true)
			toggleControl(cont,false)
			setTimer(setControlState,tim,1,cont,false)
			setTimer(toggleControl,tim,1,cont,true)
		end
	end
end
setTimer(doEffect2,8000,0)
