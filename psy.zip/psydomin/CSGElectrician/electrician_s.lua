function payPlayer()
	local distance = getElementData(source, "Electrician:distance")
	if distance then
		local dislocationFee = distance/3
		local payment = dislocationFee + 800
		givePlayerMoney(source, payment)
		exports.DENhelp:createNewHelpMessageForPlayer(source, "You got paid $800 for the repair + $"..math.floor(tonumber(dislocationFee) + 0.5).." to cover transportation fees.", 0,217,0)
		exports.DENstats:updatePlayerStats ( source, "electrician", 1 ) 
	else
		givePlayerMoney(source, 800)
		exports.DENhelp:createNewHelpMessageForPlayer(source, "You got paid $800 for the repair.", 0,217,0)
		exports.DENstats:updatePlayerStats ( source, "electrician", 1 ) 
	end
end
addEvent("elec:payPlayer", true)
addEventHandler("elec:payPlayer", root, payPlayer)
----------Connect handler-----------
function onPlayerConnect()
	if exports.server:getPlayerOccupation(source) == "Electrician" then triggerClientEvent("elec:startWork", source, source, source) end
end
addEventHandler("onPlayerLogin", root, onPlayerConnect)