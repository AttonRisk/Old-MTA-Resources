-----------Arrest/kill handlers---------------------
function onPlayerDead ()
	if source == localPlayer and poleWindow and (guiGetVisible(poleWindow) == true) then
		guiSetVisible(poleWindow, false)
		showCursor(false)
		if t1 then
			killTimer(t1)
		else if t2 then
			killTimer(t2)
		end
		end
	end
end
addEventHandler("onClientPlayerWasted", root, onPlayerDead)

function occupCheck (thePlayer)
	if thePlayer == localPlayer and (exports.server:getPlayerOccupation() ~= "Electrician") and workMarker and workBlip then
		if isElement(workMarker) then destroyElement(workMarker) end
		if isElement(workBlip) then destroyElement(workBlip) end
		workMarker = nil
		workBlip = nil
			if poleWindow and (guiGetVisible(poleWindow) == true) then
				guiSetVisible(poleWindow, false)
				showCursor(false)
				if t1 then
					killTimer(t1)
				elseif t2 then
					killTimer(t2)
				end
		end
	elseif thePlayer == localPlayer and (exports.server:getPlayerOccupation() == "Electrician") and not workMarker and not workBlip then
		triggerWork(thePlayer)
	end
end
function onStart ()
checkTimer = setTimer(occupCheck, 10000, 0, localPlayer)
end
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), onStart)

addEvent( "onClientPlayerArrested" )
addEventHandler( "onClientPlayerArrested", root,
	function ( theCop )
		if source == localPlayer and (guiGetVisible(poleWindow) == true) then
			guiSetVisible(poleWindow, false)
			showCursor(false)
			if t1 then
				killTimer(t1)
			else if t2 then
				killTimer(t2)
			end
			end
		end
	end
)

---------------------------------------------------------------------------------------------
function payment ()
	if mForDistx and mForDisty and mForDistz and wx and wy and wz then
		local distance = getDistanceBetweenPoints3D(wx, wy, wz, mForDistx, mForDisty, mForDistz)
		setElementData(localPlayer, "Electrician:distance", distance)
	end
end

function triggerWork(thePlayer)
if thePlayer == localPlayer then
	if (exports.server:getPlayChatZone() == "SF") and (exports.server:getPlayerOccupation() == "Electrician") then
		local situation = math.random (1, #elecMarkersSF)
		wx, wy, wz, isLight = elecMarkersSF[situation][1], elecMarkersSF[situation][2],elecMarkersSF[situation][3], elecMarkersSF[situation][4]
		if wx and wy and wz and isLight then
			payment()
			mForDistx, mForDisty, mForDistz = wx, wy, wz
			workMarker = createMarker(wx, wy, wz-1 , "Cylinder", 2, 255, 255, 0, 255, localPlayer)
			workBlip = createBlip(wx, wy, wz, blipType, 2, 255, 0, 0, 255, -1, localPlayer)	
			addEventHandler("onClientMarkerHit", workMarker, showPoleGUI)
			addEventHandler("onClientMarkerLeave", workMarker, onPlayerDead)
		end 
	elseif (exports.server:getPlayChatZone() == "LS") and (exports.server:getPlayerOccupation() == "Electrician") then
		local situation = math.random (1, #elecMarkersLS) 
		wx, wy, wz, isLight = elecMarkersLS[situation][1], elecMarkersLS[situation][2],elecMarkersLS[situation][3], elecMarkersLS[situation][4]
		if wx and wy and wz and isLight then
			payment()
			mForDistx, mForDisty, mForDistz = wx, wy, wz
			workMarker = createMarker(wx, wy, wz-1 , "Cylinder", 2, 255, 255, 0, 255, localPlayer)
			workBlip = createBlip(wx, wy, wz, blipType, 2, 255, 0, 0, 255, -1, localPlayer)	
			addEventHandler("onClientMarkerHit", workMarker, showPoleGUI)
			addEventHandler("onClientMarkerLeave", workMarker, onPlayerDead)
		end
	end
end
end
addEvent("elec:startWork", true)
addEventHandler("elec:startWork", getRootElement(), triggerWork)
--------------Poles
function showPoleGUI(hitElement)
local vehicle = getPedOccupiedVehicle(localPlayer)
if hitElement == localPlayer then
	if not vehicle and not poleWindow then
		local screenWidth, screenHeight = guiGetScreenSize()
		local Width, Height = 637, 221
		local X = ( screenWidth/2 ) - ( Width/2 )
		local Y = ( screenHeight/2 ) - ( Height/2 )
		poleWindow = guiCreateWindow(X, Y, Width, Height, "CSG ~ Utility pole", false)
		checkButton = guiCreateButton(38, 40, 151, 42, "Check pole state", false, poleWindow)
		repairButton = guiCreateButton(475,50,117,45,"Repair pole",false,poleWindow)
		okButton = guiCreateButton(475,50,117,45,"Ok",false,poleWindow)
		guiSetVisible(okButton, false)
		cancelButton= guiCreateButton(475, 100, 117, 45, "Leave", false, poleWindow)
		stateLabel = guiCreateLabel(45,98,300,16,"Pole state:",false,poleWindow)
		detailsLabel = guiCreateLabel(44,117,300,16,"Details:",false,poleWindow)
		repairProgressBar = guiCreateProgressBar(41,156,555,59,false,poleWindow)
		showCursor(true)
		opt1 = guiCreateRadioButton(285,51,165,18,"Repair broken wire",false,poleWindow)
		opt2 = guiCreateRadioButton(285,82,177,18,"Replace burned transformer",false,poleWindow)
		opt3 = guiCreateRadioButton(285,117,177,18,"Replace defective fuse",false,poleWindow)
		if isLight and (isLight == 1) then
			guiSetText(poleWindow, "CSG ~ Light pole")
			guiSetText(opt1, "Repair defective lamp")
		end
		guiSetEnabled(repairButton, false)
		guiSetEnabled(opt1, false)
		guiSetEnabled(opt2, false)
		guiSetEnabled(opt3, false)
		guiWindowSetSizable(poleWindow, false) 
		----------Triggers
		addEventHandler("onClientGUIClick", okButton, ok, false)
		addEventHandler("onClientGUIClick", repairButton, timer2, false)
		addEventHandler("onClientGUIClick", checkButton, timer1, false)
		addEventHandler("onClientGUIClick", cancelButton, closeGUI2, false)
	elseif not vehicle and poleWindow then
		if isLight and (isLight == 1) then
			guiSetText(poleWindow, "CSG ~ Light pole")
			guiSetText(opt1, "Repair defective lamp")
		else
			guiSetText(poleWindow, "CSG ~ Utility pole")
			guiSetText(opt1, "Repair broken wire")
		end
		guiSetVisible(poleWindow, true) 
		showCursor(true)
		guiSetEnabled(checkButton, true)
		guiSetEnabled(repairButton, false)
		guiRadioButtonSetSelected(opt1, false)
		guiRadioButtonSetSelected(opt2, false)
		guiRadioButtonSetSelected(opt3, false)
		guiSetEnabled(opt1, false)
		guiSetEnabled(opt2, false)
		guiSetEnabled(opt3, false)
		guiSetText(stateLabel, "Pole state:") 
		guiSetText(detailsLabel, "Details:")
		guiProgressBarSetProgress(repairProgressBar, 0)
		guiSetVisible(repairButton, true)
		guiSetVisible(okButton, false)
		guiSetEnabled(cancelButton, true)
	end
	end
end	
function ok ()
showCursor(false)
guiSetVisible(poleWindow, false)
	if workMarker and isElement(workMarker) and isElement(workBlip) then
		destroyElement(workMarker)
		destroyElement(workBlip)
		triggerWork(localPlayer) 
	end
end
function closeGUI2 ()
	guiSetVisible(poleWindow, false)
	showCursor(false)
end
function timer1 ()
	setPedAnimation(localPlayer, "ped", "bomber", -1, true, false)
	t1 = setTimer(pBar1, 200, 0)
	guiProgressBarSetProgress(repairProgressBar, 0)
	guiSetEnabled(cancelButton, false)
	guiSetEnabled(checkButton, false)
end
function pBar1 ()
progress1 = guiProgressBarGetProgress(repairProgressBar)
guiProgressBarSetProgress(repairProgressBar, progress1 + 2)
	if (progress1 == 100) then
		setPedAnimation(localPlayer)
		killTimer(t1)
		t1 = nil
		guiSetEnabled(opt1, true)
		guiSetEnabled(opt2, true)
		guiSetEnabled(opt3, true)
		guiSetEnabled(repairButton, true)
		guiSetEnabled(cancelButton, true)
		local damagePole = math.random(1,4)
		if (damagePole == 1) then
			guiSetText(stateLabel, "Pole state: Working properly.") 
			guiSetText(detailsLabel, "Details: No action required.")
			guiSetVisible(repairButton, false)
			guiSetEnabled(opt1, false)
			guiSetEnabled(opt2, false)
			guiSetEnabled(opt3, false)
			guiSetEnabled(cancelButton, false)
			guiSetVisible(okButton, true)
		elseif (damagePole == 2) then
			if isLight and isLight == 0 then
			guiSetText(stateLabel, "Pole state: Needs to be fixed.") 
			guiSetText(detailsLabel, "Details: There are problems with the wires.")
			else
			guiSetText(stateLabel, "Pole state: Needs to be fixed.") 
			guiSetText(detailsLabel, "Details: There is a defective lamp.")
			end
		elseif (damagePole == 3) then
			guiSetText(stateLabel, "Pole state: Needs to be fixed.") 
			guiSetText(detailsLabel, "Details: There is a burned transformer.")
		elseif (damagePole == 4) then
			guiSetText(stateLabel, "Pole state: Needs to be fixed.") 
			guiSetText(detailsLabel, "Details: There is a defective fuse.")
		end
	end
end
function timer2 ()
	setPedAnimation(localPlayer, "ped", "bomber", -1, true, false)
	t2 = setTimer(pBar2, 500, 0)
	guiProgressBarSetProgress(repairProgressBar, 0)
	guiSetEnabled(cancelButton, false)
	guiSetEnabled(repairButton, false)
	guiSetEnabled(opt1, false)
	guiSetEnabled(opt2, false)
	guiSetEnabled(opt3, false)
end
function pBar2 ()
	progress2 = guiProgressBarGetProgress(repairProgressBar)
	guiProgressBarSetProgress(repairProgressBar, progress2 + 2)
	if (progress2 == 100) then
		setPedAnimation(getLocalPlayer())
		guiSetEnabled(cancelButton, true)
		killTimer(t2)
		t2 = nil
		if (guiGetText(detailsLabel) == "Details: There are problems with the wires.") or (guiGetText(detailsLabel) == "Details: There is a defective lamp.") then
			if (guiRadioButtonGetSelected(opt1) == true) then
				triggerServerEvent("elec:payPlayer", localPlayer)
				guiSetVisible(poleWindow, false)
				showCursor(false)
				if workMarker and isElement(workMarker) and isElement(workBlip) then
					destroyElement(workMarker)
					destroyElement(workBlip)
					triggerWork(localPlayer)
				end
			else exports.DENhelp:createNewHelpMessage("You haven't fixed the pole!",231,0,0)
				guiSetVisible(poleWindow, false)
				showCursor(false)
				if workMarker and isElement(workMarker) and isElement(workBlip) then
					destroyElement(workMarker)
					destroyElement(workBlip)
					triggerWork(localPlayer)
				end
			end
		elseif (guiGetText(detailsLabel) == "Details: There is a burned transformer.") and (guiRadioButtonGetSelected(opt2) == true) then
			triggerServerEvent("elec:payPlayer", localPlayer)
			guiSetVisible(poleWindow, false)
			showCursor(false)
			if workMarker and isElement(workMarker) and isElement(workBlip) then
				destroyElement(workMarker)
				destroyElement(workBlip)
				triggerWork(localPlayer)
			end
		elseif (guiGetText(detailsLabel) == "Details: There is a defective fuse.") and (guiRadioButtonGetSelected(opt3) == true) then
			triggerServerEvent("elec:payPlayer", localPlayer)
			guiSetVisible(poleWindow, false)
			showCursor(false)
			if workMarker and isElement(workMarker) and isElement(workBlip) then
				destroyElement(workMarker)
				destroyElement(workBlip)
				triggerWork(localPlayer)
			end
		else exports.DENhelp:createNewHelpMessage("You haven't fixed the pole!",231,0,0)
			guiSetVisible(poleWindow, false)
			showCursor(false)
			if workMarker and isElement(workMarker) and isElement(workBlip) then
				destroyElement(workMarker)
				destroyElement(workBlip)
				triggerWork(localPlayer)
			end
		end
	end
end





-----------------------------------------------------------------------------------------------------


blipType = 41
elecMarkersSF = {
--on the forth variable 1 means that it is a light
[1] = {-1550.8488769531,667.21807861328,7.1875,0},
[2] = {-1570.3455810547,743.03399658203,7.1875,0},
[3] = {-1547.9981689453,824.06628417969,7.265625,0},
[4] = {-1573.193359375,868.82861328125,7.5262145996094,0},
[5] = {-1548.2479248047,866.08410644531,7.265625,0},
[6] = {-1548.0206298828,901.83752441406,7.265625,0},
[7] = {-1568.8114013672,942.68444824219,7.1875,0},
[8] = {-1519.8251953125,942.20837402344,7.1875,0},
[9] = {-1600.6986083984,986.52337646484,7.1952724456787,0},
[10] = {-1563.4464111328,1080.1745605469,7.1875,0},
[11] = {-1620.4368896484,1092.8178710938,7.1875,0},
[12] = {-1631.7607421875,1088.3013916016,7.3896026611328,0},
[13] = {-1638.1433105469,1092.8167724609,7.5167179107666,0},
[14] = {-1660.3548583984,1088.1813964844,7.921875,0},
[15] = {-1615.0621337891,1143.3114013672,7.1875,0},
[16] = {-1588.4149169922,1206.1538085938,7.1960592269897,0},
[17] = {-1973.2531738281,906.63659667969,45.4453125,0},
[18] = {-1969.0076904297,826.59515380859,45.222396850586,0},
[19] = {-1913.9223632813,861.68737792969,35.309139251709,0},
[20] = {-1851.2403564453,827.36187744141,35.153011322021,0},
[21] = {-1807.248046875,861.64392089844,24.946071624756,0},
[22] = {-1810.11328125,827.66082763672,25.430141448975,0},
[23] = {-1805.4788818359,793.02703857422,29.044027328491,0},
[24] = {-1805.4791259766,745.82720947266,35.009189605713,0},
[25] = {-1661.4323730469,826.64862060547,20.229528427124,0},
[26] = {-1650.7452392578,780.95440673828,18.221523284912,0},
[27] = {-1655.3836669922,754.96130371094,17.839929580688,0},
[28] = {-1675.5119628906,864.03521728516,24.890625,0},
[29] = {-1629.3931884766,827.60723876953,7.7941341400146,0},
[30] = {-1726.8089599609,909.39733886719,24.890625,0},
[31] = {-1665.4095458984,943.0498046875,24.890625,0},
[32] = {-2844.125,395.80725097656,4.5,0},
[33] = {-2838.6662597656,344.58801269531,4.5,0},
[34] = {-2820.1452636719,292.69369506836,7.3352780342102,0},
[35] = {-2820.1435546875,242.12768554688,7.3908772468567,0},
[36] = {-2820.1452636719,191.51249694824,7.4040312767029,0},
[37] = {-2760.0612792969,172.58363342285,7.0339913368225,0},
[38] = {-2760.8435058594,206.44499206543,6.8955736160278,0},
[39] = {-2754.6789550781,-81.815589904785,7.03125,0},
[40] = {-2759.599609375,-103.50040435791,6.9940204620361,0},
[41] = {-2759.1481933594,-128.64183044434,6.9933385848999,0},
[42] = {-2754.0717773438,-152.51786804199,6.9495935440063,0},
[43] = {-2759.5603027344,-175.5079498291,6.9944620132446,0},
[44] = {-2760.5568847656,-199.21583557129,7.03125,0},
[45] = {-2748.8974609375,-219.76052856445,7.1875,0},
[46] = {-2820.0773925781,-213.54325866699,7.2661128044128,0},
[47] = {-2820.1450195313,-162.85029602051,7.3774471282959,0},
[48] = {-2820.150390625,-112.3603515625,7.2917585372925,0},
[49] = {-2792.9028320313,-219.75259399414,7.1875,0},
[50] = {-2820.5793457031,-280.5693359375,7.1875,0},
[51] = {-2825.4973144531,-340.19009399414,7.1793503761292,0},
[52] = {-2830.9809570313,-397.27450561523,7.1875,0},
[53] = {-2829.3405761719,-453.89385986328,7.1875,0},
[54] = {-2796.21875,-467.64080810547,7.1875,0},
[55] = {-2715.7275390625,-200.92314147949,4.3359375,0},
[56] = {-2696.654296875,-219.72895812988,4.3359375,0},
[57] = {-2657.9372558594,-198.80271911621,4.171895980835,0},
[58] = {-2619.8430175781,-219.7512512207,4.3359375,0},
[59] = {-2594.7028808594,-200.38436889648,4.3359375,0},
[60] = {-2612.939453125,-161.17361450195,4.3359375,0},
[61] = {-2594.6950683594,-140.43054199219,4.3359375,0},
[62] = {-2612.9631347656,-100.49067687988,4.3359375,0},
[63] = {-2619.4318847656,-60.878791809082,4.3359375,0},
[64] = {-2594.9626464844,-20.375919342041,4.328125,0},
[65] = {-2594.9621582031,17.890090942383,4.3203258514404,0},
[66] = {-2622.8583984375,30.108596801758,4.3359375,0},
[67] = {-2649.6484375,49.938640594482,4.1796875,0},
[68] = {-2650.810546875,74.224685668945,4.1458740234375,0},
[69] = {-2633.634765625,82.966484069824,4.1521596908569,0},
[70] = {-2594.7021484375,77.118385314941,4.3281402587891,0},
[71] = {-2612.9714355469,139.42709350586,4.3335471153259,0},
[72] = {-2663.8210449219,167.1021270752,4.328125,0},
[73] = {-2690.4389648438,167.06372070313,4.328125,0},
[74] = {-2696.9487304688,148.25559997559,4.328125,0},
[75] = {-2697.1611328125,79.776710510254,4.3359375,0},
[76] = {-2715.1677246094,18.23335647583,4.328125,0},
[77] = {-2697.1782226563,-13.376521110535,4.328125,0},
[78] = {-2715.2985839844,-60.367919921875,4.3359375,0},
[79] = {-2697.1862792969,-116.77879333496,4.328125,0},
[80] = {-2572.0366210938,-219.75270080566,7.1885900497437,0},
[81] = {-2532.0144042969,-219.75277709961,19.04677772522,0},
[82] = {-2491.3190917969,-219.73677062988,25.6171875,0},
[83] = {-2491.9145507813,-180.34332275391,25.6171875,0},
[84] = {-2415.0532226563,-195.4150390625,35.3203125,0},
[85] = {-2411.7092285156,-140.42256164551,35.3203125,0},
[86] = {-2411.5620117188,-80.256843566895,35.3203125,0},
[87] = {-2411.7172851563,-40.366855621338,35.3203125,0},
[88] = {-2411.5773925781,9.7783555984497,35.31050491333,0},
[89] = {-2411.7253417969,69.465026855469,35.171875,0},
[90] = {-2411.7204589844,109.77796173096,35.171875,0},
[91] = {-2410.3657226563,169.64093017578,35.171875,0},
[92] = {-2425.2702636719,212.60905456543,35.171875,0},
[93] = {-2424.935546875,275.34735107422,35.179679870605,0},
[94] = {-2381.1369628906,329.78610229492,35.171875,0},
[95] = {-2343.3942871094,371.7868347168,35.171875,0},
[96] = {-2498.7973632813,439.71612548828,27.7734375,0},
[97] = {-2461.3137207031,405.26058959961,35.110282897949,0},
[98] = {-2548.7592773438,331.98129272461,19.801034927368,0},
[99] = {-2585.5903320313,214.87313842773,9.523398399353,0},
[100] = {-2637.1494140625,227.42332458496,4.328125,0},
[101] = {-2637.2763671875,252.11791992188,4.328125,0},
[102] = {-2656.0651855469,270.91687011719,4.328125,0},
[103] = {-2656.5327148438,297.87615966797,4.328125,0},
[104] = {-2622.3120117188,303.55819702148,4.3347086906433,0},
[105] = {-2369.7595214844,47.750389099121,35.3125,0},
[106] = {-2362.5378417969,-0.36652761697769,35.3125,0},
[107] = {-2381.3386230469,-40.33911895752,35.3125,0},
[108] = {-2362.3112792969,-79.794784545898,35.3203125,0},
[109] = {-2362.4287109375,-130.24266052246,35.3203125,0},
[110] = {-2311.3322753906,-120.75615692139,35.3203125,0},
[111] = {-2820.1459960938,140.88859558105,7.6079206466675,0},
[112] = {-2820.1447753906,39.584003448486,7.3272614479065,0},
[113] = {-2820.1416015625,-11.025580406189,7.3252692222595,0},
[114] = {-2820.1455078125,-61.63431930542,7.2454519271851,0},
[115] = {-2715.0544433594,-272.11679077148,7.1875,1},
[116] = {-2220.4653320313,-209.81787109375,35.428401947021,1},
[117] = {-2220.1440429688,-238.20407104492,35.674457550049,1},
[118] = {-2220.4580078125,-248.96607971191,35.421875,1},
[119] = {-2220.2331542969,-289.36245727539,35.46875,1},
[120] = {-2200.2939453125,-306.33645629883,35.557041168213,1},
[121] = {-2100.033203125,-305.57577514648,35.506401062012,1},
[122] = {-2062.6684570313,-305.5602722168,35.506454467773,1},
[123] = {-2207.2370605469,-408.5185546875,35.3359375,1},
[124] = {-2169.0681152344,-446.79727172852,35.343013763428,1},
[125] = {-1968.5529785156,-507.12365722656,35.3359375,1},
[126] = {-1727.5723876953,-520.78729248047,14.1484375,1},
[127] = {-1641.2518310547,-392.26315307617,14.1484375,1},
[128] = {-1488.9790039063,-260.64501953125,14.1484375,1},
[129] = {-1461.3674316406,-214.79415893555,14.1484375,1},
[130] = {-1405.0860595703,-131.28330993652,14.14396572113,1},
[131] = {-1212.3748779297,-99.514381408691,14.14396572113,1},
[132] = {-1136.4649658203,-295.91552734375,14.1484375,1},
[133] = {-1245.8857421875,-289.16354370117,14.1484375,1},
[134] = {-1329.9443359375,-346.01998901367,14.1484375,1},
[135] = {-1376.30859375,-373.33538818359,14.1484375,1},
[136] = {-1365.1822509766,-642.82983398438,14.1484375,1},
[137] = {-1518.9029541016,-529.64245605469,14.143956184387,1},
[138] = {-1524.7248535156,-619.22644042969,14.1484375,1},
[139] = {-2137.0402832031,-111.57405853271,35.327342987061,1}
}
elecMarkersLS = {
--on the forth variable 1 means that it is a light
[1] = {198.78569030762,-1462.1727294922,12.938039779663,0},
[2] = {235.85313415527,-1463.9337158203,13.415843963623,0},
[3] = {232.80813598633,-1426.3804931641,13.400127410889,0},
[4] = {271.68374633789,-1402.75390625,13.790411949158,0},
[5] = {300.29574584961,-1368.9862060547,14.127193450928,0},
[6] = {327.33953857422,-1376.3419189453,14.254787445068,0},
[7] = {353.84866333008,-1361.9125976563,14.454172134399,0},
[8] = {399.45050048828,-1335.0037841797,14.795600891113,0},
[9] = {421.99215698242,-1357.6707763672,14.974919319153,0},
[10] = {419.00216674805,-1322.2554931641,14.947683334351,0},
[11] = {442.24462890625,-1305.4743652344,15.160201072693,0},
[12] = {460.73294067383,-1292.6300048828,15.350665092468,0},
[13] = {510.29724121094,-1290.3079833984,15.978420257568,0},
[14] = {510.13275146484,-1253.5009765625,16.12317276001,0},
[15] = {487.02569580078,-1256.6936035156,17.057168960571,0},
[16] = {119.05544281006,-1485.9312744141,15.644875526428,0},
[17] = {142.00140380859,-1455.7755126953,27.294178009033,0},
[18] = {170.78002929688,-1419.4951171875,43.565845489502,0},
[19] = {186.67623901367,-1398.9526367188,46.790161132813,0},
[20] = {171.0859375,-1388.4029541016,48.880126953125,0},
[21] = {123.80628204346,-1339.1037597656,49.442356109619,0},
[22] = {123.838722229,-1275.2670898438,47.759429931641,0},
[23] = {148.4002532959,-1205.1451416016,49.530433654785,0},
[24] = {177.35597229004,-1179.7385253906,53.697521209717,0},
[25] = {215.63589477539,-1345.994140625,51.36833190918,0},
[26] = {256.90740966797,-1336.7817382813,52.959987640381,0},
[27] = {238.81610107422,-1303.4224853516,56.241828918457,0},
[28] = {221.86692810059,-1266.2325439453,65.641189575195,0},
[29] = {245.77197265625,-1244.2890625,71.171920776367,0},
[30] = {287.2998046875,-1235.8995361328,74.909515380859,0},
[31] = {321.29550170898,-1211.1604003906,76.132385253906,0},
[32] = {348.82431030273,-1188.841796875,76.624740600586,0},
[33] = {357.79498291016,-1155.4255371094,78.276473999023,0},
[34] = {445.49642944336,-1194.9536132813,67.060493469238,0},
[35] = {504.63418579102,-1165.1151123047,59.476974487305,0},
[36] = {556.37902832031,-1140.4830322266,52.026962280273,0},
[37] = {593.62622070313,-1118.8039550781,47.508316040039,0},
[38] = {649.07049560547,-1100.7581787109,47.194313049316,0},
[39] = {669.94647216797,-1053.5571289063,49.659545898438,0},
[40] = {694.78582763672,-1010.2119750977,52.017391204834,0},
[41] = {781.50476074219,-928.34655761719,43.498947143555,0},
[42] = {804.35595703125,-952.94549560547,39.11328125,0},
[43] = {786.53131103516,-1029.2845458984,25.271574020386,0},
[44] = {851.13928222656,-1038.7707519531,25.895431518555,0},
[45] = {871.75396728516,-980.67224121094,35.480548858643,0},
[46] = {937.37451171875,-986.31811523438,38.513652801514,0},
[47] = {998.59204101563,-951.73071289063,42.065616607666,0},
[48] = {1072.8563232422,-940.7568359375,42.915477752686,0},
[49] = {1134.1452636719,-936.31030273438,42.897457122803,0},
[50] = {1232.9914550781,-921.69122314453,42.840881347656,0},
[51] = {1280.2474365234,-913.00079345703,41.916309356689,0},
[52] = {1320.8865966797,-912.76641845703,37.452945709229,0},
[53] = {1869.0753173828,-1041.8746337891,23.838844299316,0},
[54] = {1926.3151855469,-1052.3029785156,24.107894897461,0},
[55] = {1958.8218994141,-1037.1920166016,24.30729675293,0},
[56] = {2033.5665283203,-1063.341796875,24.743021011353,0},
[57] = {2057.4482421875,-1093.4720458984,24.703392028809,0},
[58] = {2108.4865722656,-1096.2902832031,25.212114334106,0},
[59] = {2210.0729980469,-1110.9837646484,25.796875,0},
[60] = {2281.1215820313,-1218.5633544922,23.999849319458,0},
[61] = {2280.8000488281,-1281.0715332031,23.997997283936,0},
[62] = {2280.3603515625,-1310.6922607422,24.005493164063,0},
[63] = {2280.6748046875,-1338.7239990234,23.992233276367,0},
[64] = {2280.46875,-1395.2175292969,23.978317260742,0},
[65] = {2331.4338378906,-1373.9516601563,24.014232635498,0},
[66] = {2333.8447265625,-1428.7493896484,24,0},
[67] = {2352.1584472656,-1482.060546875,24,0},
[68] = {2416.8061523438,-1478.4067382813,23.921295166016,0},
[69] = {2402.6499023438,-1432.6264648438,24.001630783081,0},
[70] = {2492.4157714844,-1648.7086181641,13.540050506592,0},
[71] = {2505.6813964844,-1702.1204833984,13.528658866882,0},
[72] = {2417.8786621094,-1048.0977783203,51.551532745361,0},
[73] = {2321.6010742188,-1069.1505126953,49.720035552979,0},
[74] = {2286.9375,-1061.7060546875,47.641746520996,0},
[75] = {2217.2229003906,-1009.353515625,60.866813659668,0},
[76] = {2190.8977050781,-1048.3104248047,52.223640441895,0},
[77] = {2179.4748535156,-1018.6707763672,62.876796722412,0},
[78] = {2448.9213867188,-1941.4228515625,13.539093017578,0},
[79] = {2433.1594238281,-1923.0225830078,13.546875,0},
[80] = {2519.9924316406,-1941.4471435547,13.546875,0},
[81] = {2783.2990722656,-1904.2043457031,13.546875,0},
[82] = {2780.0158691406,-1940.3547363281,13.546875,0},
[83] = {2510.4265136719,-2146.0029296875,13.546875,0},
[84] = {2423.0407714844,-2144.3129882813,13.546875,0},
[85] = {2431.4187011719,-2251.2934570313,13.546875,0},
[86] = {2485.0654296875,-2244.7895507813,13.546875,0},
[87] = {2237.0427246094,-2521.3981933594,13.660493850708,0},
[88] = {1844.2290039063,-1923.2269287109,13.546875,0},
[89] = {1891.4056396484,-1922.9515380859,13.546875,0},
[90] = {1915.4610595703,-1923.2222900391,13.546875,0},
[91] = {1938.5013427734,-1923.0672607422,13.546875,0},
[92] = {1970.6430664063,-1891.4313964844,13.546875,0},
[93] = {1968.8199462891,-1875.9711914063,13.546875,0},
[94] = {1952.5034179688,-1863.1002197266,13.546875,0},
[95] = {1946.9710693359,-1876.8582763672,13.557384490967,0},
[96] = {1971.3800048828,-1826.1787109375,13.546875,0},
[97] = {1952.8840332031,-1800.5388183594,13.546875,0},
[98] = {1970.9219970703,-1772.1700439453,13.546875,0},
[99] = {1978.8190917969,-1743.0551757813,13.546875,0},
[100] = {2025.7191162109,-1743.0871582031,13.546875,0},
[101] = {2061.7248535156,-1743.0400390625,13.546875,0},
[102] = {2087.8510742188,-1741.6381835938,13.553467750549,0},
[103] = {2072.9936523438,-1838.9154052734,13.554534912109,0},
[104] = {2072.5654296875,-1879.0621337891,13.546875,0},
[105] = {2072.4892578125,-1922.2348632813,13.546875,0},
[106] = {2044.2626953125,-1923.9097900391,13.546875,0},
[107] = {2026.5889892578,-1923.0405273438,13.546875,0},
[108] = {1990.5843505859,-1942.1889648438,13.546875,0},
[109] = {2229.5561523438,-1903.2764892578,13.546875,0},
[110] = {2239.0920410156,-1884.7825927734,13.546875,0},
[111] = {2288.5285644531,-1885.2091064453,13.580750465393,0},
[112] = {2322.0922851563,-1885.2177734375,13.61870098114,0},
[113] = {2316.7385253906,-1981.5346679688,13.565473556519,0},
[114] = {2358.0913085938,-1982.2999267578,13.546875,0},
[115] = {2394.3498535156,-1963.2385253906,13.546875,0},
[116] = {2404.7392578125,-1988.2712402344,13.546875,0},
[117] = {2404.7673339844,-2020.4210205078,13.546875,0},
[118] = {2405.3811035156,-2035.7178955078,13.546875,0},
[119] = {2403.7568359375,-2085.3391113281,13.553783416748,0},
[120] = {2459.0187988281,-1994.7302246094,13.546875,0},
[121] = {2403.8947753906,-1741.7296142578,13.546875,0},
[122] = {2364.7951660156,-1741.9376220703,13.546875,0},
[123] = {2331.8515625,-1742.4586181641,13.546875,0},
[124] = {2264.1098632813,-1741.8771972656,13.546875,0},
[125] = {2208.8752441406,-1723.1781005859,13.415113449097,0},
[126] = {2229.58984375,-1639.0628662109,15.489765167236,0},
[127] = {2137.3796386719,-1613.4327392578,13.565078735352,0},
[128] = {2058.6613769531,-1621.4772949219,13.546875,0},
[129] = {2017.2875976563,-1603.2845458984,13.539194107056,0},
[130] = {2010.8181152344,-1642.7960205078,13.546875,0},
[131] = {1040.6964111328,-1414.7706298828,13.387709617615,0},
[132] = {996.69152832031,-1414.7562255859,13.19193649292,0},
[133] = {969.65740966797,-1385.7725830078,13.511814117432,0},
[134] = {929.64367675781,-1414.6760253906,13.381008148193,0},
[135] = {925.53125,-1339.2584228516,13.524711608887,0},
[136] = {1044.7263183594,-1362.0979003906,13.578897476196,0},
[137] = {1044.9733886719,-1250.9006347656,15.168292045593,0},
[138] = {806.11987304688,-1363.849609375,13.546875,0},
[139] = {788.17956542969,-1384.5986328125,13.73112487793,0},
[140] = {609.39605712891,-1782.3908691406,14.328591346741,0},
[141] = {548.48052978516,-1773.3533935547,14.346680641174,0},
[142] = {486.08932495117,-1769.2470703125,14.155248641968,0},
[143] = {353.3991394043,-2050.201171875,7.8359375,0},
[144] = {352.8063659668,-2081.9155273438,7.8300905227661,0},
[145] = {400.79321289063,-2081.8793945313,7.8300905227661,0},
[146] = {401.68118286133,-2050.5812988281,7.8359375,0},
[147] = {561.56518554688,-1255.6564941406,17.2421875,1},
[148] = {695.52032470703,-1110.2396240234,18.200319290161,1},
[149] = {857.11651611328,-988.49920654297,34.31058883667,1},
[150] = {958.18774414063,-1377.7535400391,13.662767410278,1},
[151] = {1351.0399169922,-1718.3280029297,13.603309631348,1},
[152] = {1413.1212158203,-1722.7625732422,13.546875,1},
[153] = {1569.7193603516,-1720.6719970703,13.546875,1},
[154] = {1637.748046875,-1722.5849609375,13.546875,1},
[155] = {1885.0313720703,-1550.9691162109,13.025653839111,1},
[156] = {1863.9069824219,-1447.9321289063,13.49950504303,1},
[157] = {1973.8956298828,-1432.7767333984,13.750099182129,1},
[158] = {1983.8371582031,-1479.1607666016,11.309810638428,1},
[159] = {2099.7958984375,-1479.4337158203,21.44193649292,1},
[160] = {1851.2225341797,-1046.6130371094,24.126634597778,1},
[161] = {1494.6888427734,-946.36126708984,36.877662658691,1}
}