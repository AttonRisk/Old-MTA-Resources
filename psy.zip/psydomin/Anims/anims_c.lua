function onStart ()
	for i=1, #animsTable do 
	addCommandHandler(animsTable[i][1], anims)
	end
end
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()),onStart)

function anims (cmd)
	for i=1, #animsTable do 
		if cmd == animsTable[i][1] then triggerServerEvent("setAnimationByCmd", localPlayer, animsTable[i][2], animsTable[i][3], animsTable[i][4]) end
	end
end

cmdAnims = {
[1] = {"stopanim",nil, nil, nil},
[2] = {"handsup","ped", "handsup", false},
[3] = {"piss","PAULNMAC", "Piss_loop", true},
[4] = {"wank","PAULNMAC", "wank_loop", true},
[5] = {"sit", "ped", "SEAT_idle", false},
[6] = {"vomit", "FOOD", "EAT_Vomit_P", false}
}
