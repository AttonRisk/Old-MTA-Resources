function setAnim (block, anim, loop)
setPedAnimation(source, block, anim, -1, loop, false)
end
addEvent("setAnimationByCmd", true)
addEventHandler("setAnimationByCmd", root, setAnim) 