function pos ()
local x,y,z=getElementPosition(localPlayer)
local rotx, roty, rotz = getElementRotation(localPlayer)
if not i then i = (#table1 + 1) end
outputChatBox("["..i.."] = {"..x..","..y..","..z..","..rotz.."},")
i = i+1
local marker = createMarker(x, y, z,"cylinder", 1, 255, 255, 0)
--setElementInterior(marker, int)
end
addCommandHandler("psy:pos", pos)


---------------Temp table
table1={}

