----------------OnResourceStart
--[[function onstart()
        local screenWidth, screenHeight = guiGetScreenSize()
        local Width, Height = 300, 300
        local X = ( screenWidth/2 ) - ( Width/2 )
        local Y = ( screenHeight/2 ) - ( Height/2 )
   
        CGJobWindow = guiCreateWindow(X, Y, Width, Height, "CSG ~ Coast Guard Rescue Computer.", false)
        CGTabPanel = guiCreateTabPanel ( 0, 0.1, 1, 1, true, CGJobWindow )
        CMissionTab = guiCreateTab("Current Mission", CGTabPanel)
        label1 = guiCreateLabel(0, 15, 300, 25, "CURRENT MISSION", false, CMissionTab)
        guiLabelSetHorizontalAlign(label1, "center", false)
        label2 = guiCreateLabel(0, 50, 300, 25, "Initial brief:", false, CMissionTab)
        guiLabelSetHorizontalAlign(label2, "center", false)
     
        brief = guiCreateLabel(10, 65, 280, 100, "N/A persons have been reported missing! A rescue operation has been started. Go to the scene and bring that persons home safely!", false, CMissionTab)
        guiLabelSetHorizontalAlign(brief, "center", true)
        label3 = guiCreateLabel(10, 120, 280, 25, "Current state:", false, CMissionTab)
        guiLabelSetHorizontalAlign(label3, "center", true)
        currentState = guiCreateLabel(10, 135, 280, 100, "N/A victims have been rescued and N/A are still missing.", false, CMissionTab)
        guiLabelSetHorizontalAlign(currentState, "center", true)
     
        GStatsTab = guiCreateTab("General Stats", CGTabPanel)
        label4 = guiCreateLabel(10, 10, 260, 50, "N/A lives have been saved by the SA Coast Guard Team! Thanks. ", false, GStatsTab)
        guiLabelSetHorizontalAlign(label4, "center", true)
        label5 = guiCreateLabel(0, 60, 280, 25, "Personal Stats:", false, GStatsTab)
        guiLabelSetHorizontalAlign(label5, "center", false)
        individualLivesSaved = getElementData(localPlayer, "liveSaved")
		guiSetVisible(CGJobWindow, false)
        --updateGUIData()
		setElementData(localPlayer, "Occupation", "Coast Guard")
end
addEventHandler("onClientResourceStart",resourceRoot,onstart)
--------------------------------


----------------F5 GUI Handler
function show()
	--if (exports.server:getPlayerOccupation() == "Coast Guard") then 
        if (guiGetVisible(CGJobWindow) == false) then
            guiSetVisible(CGJobWindow,true)
            --refreshGUIData() -- call this when it opens so we can set our data.
        else
            guiSetVisible(CGJobWindow,false)
        end
	--end
end
bindKey("F5","down",show)
addEvent( "F5gui", true )
addEventHandler( "F5gui", getRootElement(), show )
]]---------------------------------


function receiveData (thePlayer, victims, XSA, YSA, colShapes)
if thePlayer == localPlayer then
	--if (exports.server:getPlayerOccupation() == "Coast Guard") then
		radarArea = createRadarArea(XSA, YSA, 300, 300, 51, 255, 255, 80, localPlayer)
		exports.DENhelp:createNewHelpMessage("A shipwreck has just occured! Get to the area and rescue the ship's passangers!",255, 0,0)
		for i=1, #victims do
			setElementAlpha(victims[i][1], 255)
			
			local x,y,z = getElementPosition(victims[i][1])
			local sound = playSound3D("sound.mp3", x,y,z, true)
			setSoundMaxDistance(sound, 100)
			setElementData(victims[i][1], tostring(localPlayer), sound)
			
			local x,y,z = getElementPosition(victims[i][1])
			if x<XSA or x>XSA+300 and y<YSA or y>YSA+300 then
				local blip = createBlipAttachedTo(victims[i][1],41)
				setElementData(victims[i][1], "CG:blip", blip)
			end
			addEventHandler("onClientPedDamage", victims[i][1], canceldmg)
		end
		for i=1, #colShapes do
			addEventHandler("onClientColShapeHit", colShapes[i][1], startRescue)
			addEventHandler("onClientColShapeLeave", colShapes[i][1], stopRescue)	
		end
	--end
end
end
addEvent("receiveData", true)
addEventHandler("receiveData", root, receiveData)
function canceldmg ()
	if getElementData(source, "CGped") == "yes" then
	cancelEvent()
	end
end
-------------------Rescue
function startRescue (hitElement)
local rveh = hitElement
local rdmg = getElementHealth(hitElement)
rPed = getElementAttachedTo(source)
col = source
	if rveh and isElement (rveh) and getElementType(rveh) == "vehicle" and rdmg > 300 then
		rescuer = getVehicleOccupant(rveh, 0)
		if getVehicleName(rveh) == "Raindance" and (getElementData(rveh, "CG:state") ~= "full") then
			if rescuer == localPlayer then
				exports.CSGrozmisc:startProgressBar(255, 255, 255, 0, 255, 255, "onRescue", "Rescueing...", 50)
			end
		elseif getVehicleName(rveh) == "Coastguard" and (getElementData(rveh, "CG:state") ~= "full") then
			if rescuer == localPlayer then
				exports.CSGrozmisc:startProgressBar(255, 255, 255, 0, 255, 255, "onRescue", "Rescueing...", 50)
			end
		end
	end
end
function stopRescue (hitElement)
	if hitElement == localPlayer then
		exports.CSGrozmisc:cancelProgressBar()
	end
end
function rescue()
	if rescuer == localPlayer then
		exports.DENhelp:createNewHelpMessage("You rescued a shipwrecked! Now take him to the closest hospital!",255, 215,0)
		if getPedOccupiedVehicle(rescuer) and getVehicleName(getPedOccupiedVehicle(rescuer)) == "Raindance" and (getElementData(getPedOccupiedVehicle(rescuer), "CG:state") ~= "full") then
			setElementData(getPedOccupiedVehicle(rescuer), "CG:state", "full")
			attachElements(rPed, getPedOccupiedVehicle(rescuer), 0, -2, 1, 0, 0, 0)
			setTimer(setPedAnimation, 1000, 1, rPed, "CRACK", "crckidle2", -1, false)
			dropCreateC(rescuer)
			timer = setTimer(checkVehicle, 1000, 0, getPedOccupiedVehicle(rescuer), rPed)
			local sound = getElementData(rPed, tostring(localPlayer))
			setTimer(stopSound, 500, 1,sound)
			removeEventHandler("onClientColShapeHit", col, startRescue)
			removeEventHandler("onClientColShapeLeave", col, stopRescue)
			if getElementData(rPed, "CG:blip") then
				if getElementType(getElementData(rPed, "CG:blip")) == "blip" and isElement(getElementData(rPed, "CG:blip")) then destroyElement(getElementData(rPed, "CG:blip")) end
			end	
		elseif getPedOccupiedVehicle(rescuer) and getVehicleName(getPedOccupiedVehicle(rescuer)) == "Coastguard" and (getElementData(getPedOccupiedVehicle(rescuer), "CG:state") ~= "full") then				
			setElementData(getPedOccupiedVehicle(rescuer), "CG:state", "full")
			attachElements(rPed, getPedOccupiedVehicle(rescuer), 0, 2, 1, 0, 0, 0)
			setTimer(setPedAnimation, 1000, 1, rPed, "CRACK", "crckidle2", -1, false)
			dropCreateB(rescuer)
			timer = setTimer(checkVehicle, 1000, 0, getPedOccupiedVehicle(rescuer), rPed)
			local sound = getElementData(rPed, tostring(localPlayer))
			setTimer(stopSound, 500, 1,sound)
			removeEventHandler("onClientColShapeHit", col, startRescue)
			removeEventHandler("onClientColShapeLeave", col, stopRescue)
			if getElementData(rPed, "CG:blip") then
				if getElementType(getElementData(rPed, "CG:blip")) == "blip" and isElement(getElementData(rPed, "CG:blip")) then destroyElement(getElementData(rPed, "CG:blip")) end
			end	
		end
	end
	local theTeam = getTeamFromName("Civilian Workers")
	local civilians = getPlayersInTeam(theTeam)
	for i,v in ipairs(civilians) do
		triggerEvent("synch", rPed)
	end

end
addEvent("onRescue", false)
addEventHandler("onRescue", root, rescue)
function synch()
	--if exports.server:getPlayerOccupation() =="Coast Guard" then
		local sound = getElementData(rPed, tostring(localPlayer))
		setTimer(stopSound, 500, 1,sound)
		removeEventHandler("onClientColShapeHit", col, startRescue)
		removeEventHandler("onClientColShapeLeave", col, stopRescue)
	--end
end
addEvent("synch", false)
addEventHandler("synch", root, synch)


function checkVehicle(vehicle, ped)
	if vehicle and ped then
		local vx, vy, vz = getElementPosition (vehicle)
		local dmg = getElementHealth(vehicle)
		if vz and vz < -2 then
			detachElements(ped, vehicle)
			triggerEvent("rescuedLost", ped)
			killTimer(timer)
			setElementData(vehicle, "CG:state", "empty")
			if dropTableB then
				for i=1, #dropTableB do
					if isElement(dropTableB[i][1]) and isElement(dropTableB[i][2]) then
						destroyElement(dropTableB[i][1])
						destroyElement(dropTableB[i][2])
					end
				end	
			elseif dropTableC then
				for i=1, #dropTableC do
					if isElement(dropTableC[i][1]) and isElement(dropTableC[i][2]) then
						destroyElement(dropTableC[i][1])
						destroyElement(dropTableC[i][2])
					end
				end
			end
		end
		if dmg and dmg < 500 then
			detachElements(ped, vehicle)
			triggerEvent("rescuedLost", ped)
			killTimer(timer)
			setElementData(vehicle, "CG:state", "empty")
			if dropTableB then
				for i=1, #dropTableB do
					if isElement(dropTableB[i][1]) and isElement(dropTableB[i][2]) then
						destroyElement(dropTableB[i][1])
						destroyElement(dropTableB[i][2])
					end
				end	
			elseif dropTableC then
				for i=1, #dropTableC do
					if isElement(dropTableC[i][1]) and isElement(dropTableC[i][2]) then
						destroyElement(dropTableC[i][1])
						destroyElement(dropTableC[i][2])
					end
				end
			end
		end
	end
end
function rescuedLost ()
	--if (exports.server:getPlayerOccupation() == "Coast Guard") then
		exports.DENhelp:createNewHelpMessage("One of the rescuers crashed and the shipwrecked is lost in the sea again! Save him!",255, 0,0)
		local blip = createBlipAttachedTo(source,41)
		setElementData(source, "CG:blip", blip)
		local colShape = createColCuboid(0, 0, 0,8,8,8)
		attachElements(colShape, source, -4, -4, 0)
		addEventHandler("onClientColShapeHit", colShape, startRescue)
		addEventHandler("onClientColShapeLeave", colShapes, stopRescue)
	--end
end
addEvent("rescuedLost", false)
addEventHandler("rescuedLost", root, rescuedLost)



------------------Create the drop points
function dropCreateC(player)
	if player == localPlayer then
		dropTableC = {}
		for i=1, #dropPointsChopper do
			local dropMarkerC = createMarker(dropPointsChopper[i][1],dropPointsChopper[i][2],dropPointsChopper[i][3], "cylinder", 5, 6, 200, 200, 200)
			local dropBlipC = createBlipAttachedTo(dropMarkerC, 22, 2, 255, 0, 0, 255, 0, 65535, localPlayer)
			addEventHandler("onClientMarkerHit", dropMarkerC, drop)
			dropTableC[i] = {dropMarkerC, dropBlipC}
		end
	end
end

dropPointsChopper ={
[1] = {-1606.7178955078,285.69787597656,6.1875},
[2] = {-2227.4892578125,2326.7766113281,6.546875},
[3] = {-2567.7888183594,647.94567871094,26.806203842163},
[4] = {836.04754638672,-2035.9748535156,11.8671875},
[5] = {2101.0715332031,-2220.0126953125,12.546875},
[6] = {2069.1088867188,-1422.5534667969,47.33145904541}
}
function dropCreateB (player)
	if player == localPlayer then
		dropTableB = {}
		for i=1, #dropPointsBoat do
			local dropMarkerB = createMarker(dropPointsBoat[i][1],dropPointsBoat[i][2],dropPointsBoat[i][3], "cylinder", 5, 6, 200, 200, 200)
			local dropBlipB = createBlipAttachedTo(dropMarkerB, 22, 2, 255, 0, 0, 255, 0, 65535, localPlayer)
			addEventHandler("onClientMarkerHit", dropMarkerB, drop)
			dropTableB[i] = {dropMarkerB, dropBlipB}
		end
	end
end

dropPointsBoat ={
[1] = {-2951.5046386719,504.68890380859,0.93584758043289},
[1] = {-2952.12890625,501.09048461914,-0.22177481651306},
[2] = {-1510.7934570313,1299.6259765625,-0.44610804319382},
[3] = {-2326.5812988281,2299.2717285156,-0.75570225715637},
[4] = {1628.7418212891,572.67657470703,-0.42519575357437},
[5] = {2960.0075683594,-1487.7034912109,-0.57722496986389},
[6] = {2715.0153808594,-2312.8215332031,-0.13201677799225},
[7] = {719.12048339844,-1702.8074951172,0.41858208179474},
[8] = {-1437, 426, -0.5}
}
--------------Drop the ped and trigger finalChecks on server side
function drop (hitElement)
	if hitElement and (hitElement == localPlayer) then --and (exports.server:getPlayerOccupation() == "Coast Guard") then 
		local vehicle = getPedOccupiedVehicle(hitElement)
		if vehicle and ((getVehicleName(vehicle) == "Coastguard") or (getVehicleName(vehicle) == "Raindance")) then
			local pedToDestroy = getAttachedElements(vehicle)
			for i, v in ipairs(pedToDestroy) do
				if getElementType(v) == "ped" and isElement(v) then
					finalChecks(vehicle, v)
					exports.DENhelp:createNewHelpMessage("You saved a shipwrecked!",0 , 217,0)
				end
			end	
			if dropTableB then
				for i=1, #dropTableB do
					if isElement(dropTableB[i][1]) and isElement(dropTableB[i][2]) then
						destroyElement(dropTableB[i][1])
						destroyElement(dropTableB[i][2])
					end
				end	
			elseif dropTableC then
				for i=1, #dropTableC do
					if isElement(dropTableC[i][1]) and isElement(dropTableC[i][2]) then
						destroyElement(dropTableC[i][1])
						destroyElement(dropTableC[i][2])
					end
				end
			end
		end
	end
end
function finalChecks (vehicle, ped)
	if vehicle and ped then --and (exports.server:getPlayerOccupation() == "Coast Guard") then 
		setElementData(vehicle, "CG:state", "empty")
		killTimer(timer)
		local attached = getAttachedElements(ped)
		for i,v in ipairs(attached) do
			if isElement(v) and getElementType(v) == "colshape" then
				triggerServerEvent("CG:payPlayer", localPlayer, ped, v)
			end
		end
	end
end

----------In case that there are no more peds this will be triggered serverside to delete the current search area
function endSituation ()
	if radarArea and isElement(radarArea) then --and (exports.server:getPlayerOccupation(localPlayer) == "Coast Guard") then
		destroyElement(radarArea)
	end
end
addEvent("CG:endSituation", true)
addEventHandler("CG:endSituation", root, endSituation)
